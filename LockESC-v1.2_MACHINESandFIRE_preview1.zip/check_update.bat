@echo off
setlocal EnableDelayedExpansion

:: ═══════════════════════════════════════════════════════
::  LockESC Auto-Updater
::  Place this .bat in the same folder as your LockESC
::  installation (next to lockesc_tracebackfinder.py).
::  Run it any time to check for a newer release.
:: ═══════════════════════════════════════════════════════

set OWNER=GoodPltheSniperer
set REPO=LockESC
set API=https://api.github.com/repos/%OWNER%/%REPO%/releases/latest
set TMPDIR=%TEMP%\lockesc_update

:: ── Read current version from version.txt (if present) ──────────────────────
set CURRENT_VER=0.0.0
if exist "%~dp0version.txt" (
    set /p CURRENT_VER=<"%~dp0version.txt"
    set CURRENT_VER=!CURRENT_VER: =!
)

echo.
echo  ██╗      ██████╗  ██████╗██╗  ██╗███████╗███████╗ ██████╗
echo  ██║     ██╔═══██╗██╔════╝██║ ██╔╝██╔════╝██╔════╝██╔════╝
echo  ██║     ██║   ██║██║     █████╔╝ █████╗  ███████╗██║
echo  ██║     ██║   ██║██║     ██╔═██╗ ██╔══╝  ╚════██║██║
echo  ███████╗╚██████╔╝╚██████╗██║  ██╗███████╗███████║╚██████╗
echo  ╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝╚══════╝╚══════╝ ╚═════╝
echo.
echo  Update Checker
echo  ─────────────────────────────────────────────────────────
echo  Current version : %CURRENT_VER%
echo  Checking        : https://github.com/%OWNER%/%REPO%/releases
echo.

:: ── Check for PowerShell (required for web requests) ────────────────────────
where powershell >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] PowerShell not found. Cannot check for updates.
    goto :end
)

:: ── Fetch latest release JSON via PowerShell ────────────────────────────────
echo  Fetching latest release info...
powershell -NoProfile -Command ^
    "$r = Invoke-RestMethod -Uri '%API%' -UseBasicParsing; ^
     $r.tag_name + '|' + $r.assets[0].browser_download_url + '|' + $r.assets[0].name" ^
    > "%TEMP%\lockesc_rel.txt" 2>nul

if %errorlevel% neq 0 (
    echo  [ERROR] Could not reach GitHub API.
    echo  Check your internet connection and try again.
    goto :end
)

:: ── Parse result ─────────────────────────────────────────────────────────────
set /p RELDATA=<"%TEMP%\lockesc_rel.txt"
del "%TEMP%\lockesc_rel.txt" >nul 2>&1

:: Split on | delimiter
for /f "tokens=1,2,3 delims=|" %%A in ("!RELDATA!") do (
    set LATEST_TAG=%%A
    set DOWNLOAD_URL=%%B
    set ASSET_NAME=%%C
)

:: Strip leading v from tag for comparison (v0.9.4 -> 0.9.4)
set LATEST_VER=!LATEST_TAG!
if "!LATEST_VER:~0,1!"=="v" set LATEST_VER=!LATEST_VER:~1!

echo  Latest release  : !LATEST_TAG!
echo.

:: ── Compare versions (simple string compare works for semver x.y.z) ─────────
if "!LATEST_VER!"=="!CURRENT_VER!" (
    echo  [OK] You are already on the latest version ^(!CURRENT_VER!^).
    goto :end
)

:: Check if latest > current using PowerShell version comparison
powershell -NoProfile -Command ^
    "[version]'!LATEST_VER!' -gt [version]'!CURRENT_VER!'" ^
    > "%TEMP%\lockesc_cmp.txt" 2>nul

set /p IS_NEWER=<"%TEMP%\lockesc_cmp.txt"
del "%TEMP%\lockesc_cmp.txt" >nul 2>&1
set IS_NEWER=!IS_NEWER: =!

if /i not "!IS_NEWER!"=="True" (
    echo  [OK] You are already on the latest version ^(!CURRENT_VER!^).
    goto :end
)

:: ── New version available — prompt user ──────────────────────────────────────
echo  ┌─────────────────────────────────────────────────────┐
echo  │  NEW VERSION AVAILABLE:  !LATEST_TAG!
echo  │  Current:  !CURRENT_VER!
echo  └─────────────────────────────────────────────────────┘
echo.

if "!DOWNLOAD_URL!"=="" (
    echo  [WARN] No downloadable asset found for !LATEST_TAG!.
    echo  Visit https://github.com/%OWNER%/%REPO%/releases to download manually.
    goto :end
)

set /p CONFIRM= Update now? (Y/N):  
if /i not "!CONFIRM!"=="Y" (
    echo.
    echo  Update cancelled. You can update manually at:
    echo  https://github.com/%OWNER%/%REPO%/releases
    goto :end
)

:: ── Download ──────────────────────────────────────────────────────────────────
echo.
echo  Downloading !ASSET_NAME!...
if not exist "%TMPDIR%" mkdir "%TMPDIR%"
set ZIPPATH=%TMPDIR%\!ASSET_NAME!

powershell -NoProfile -Command ^
    "Invoke-WebRequest -Uri '!DOWNLOAD_URL!' -OutFile '!ZIPPATH!' -UseBasicParsing"

if %errorlevel% neq 0 (
    echo  [ERROR] Download failed. Check your connection and try again.
    goto :end
)

if not exist "!ZIPPATH!" (
    echo  [ERROR] Downloaded file not found. Something went wrong.
    goto :end
)

echo  Download complete: !ZIPPATH!
echo.

:: ── Extract into the same directory as this .bat ─────────────────────────────
set INSTALL_DIR=%~dp0
:: Remove trailing backslash
if "!INSTALL_DIR:~-1!"=="\" set INSTALL_DIR=!INSTALL_DIR:~0,-1!

echo  Extracting into: !INSTALL_DIR!
echo  (Existing files will be overwritten)
echo.

powershell -NoProfile -Command ^
    "Expand-Archive -Path '!ZIPPATH!' -DestinationPath '!INSTALL_DIR!' -Force"

if %errorlevel% neq 0 (
    echo  [ERROR] Extraction failed.
    echo  The zip file is at: !ZIPPATH!
    echo  You can extract it manually.
    goto :end
)

:: ── Write new version to version.txt ─────────────────────────────────────────
echo !LATEST_VER!> "%INSTALL_DIR%\version.txt"

:: ── Clean up temp ─────────────────────────────────────────────────────────────
del "!ZIPPATH!" >nul 2>&1
rmdir "%TMPDIR%" >nul 2>&1

echo.
echo  ┌─────────────────────────────────────────────────────┐
echo  │  Update complete!  LockESC is now at !LATEST_TAG!
echo  └─────────────────────────────────────────────────────┘
echo.
echo  You can now launch the game normally.

:end
echo.
pause
endlocal
