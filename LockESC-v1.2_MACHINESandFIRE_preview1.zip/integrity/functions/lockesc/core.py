"""
LockESC – stealth game engine  v7
==================================
pip install pygame
python lockesc.py
python lockesc.py levels/my.ler

Controls
--------
WASD / Arrows  – Move  (quiet walk by default)
Hold SHIFT     – Sprint (loud – guards hear you)
E              – Use door / crash-door (sprint into crash-door)
H              – Hide  (when standing on a HIDE tile)
R              – Restart level
N              – Next level  (when won, if a next_level is defined)
ESC            – Pause menu (Resume / Back to Title / Quit)
F11            – Minimise (game runs borderless fullscreen; click taskbar to restore)

Entity types
------------
  player     – you
  guard      – AI security (or any enemy; guards can be anybody)
  loot       – +100 pts each; collect all to open exit
  main_loot  – the primary objective; collecting opens exit
  hide       – tile the player can press H on to vanish
  door       – toggle with E; guards open doors in their path
  crashdoor  – must be sprint-rammed to open; makes huge noise
  window     – transparent to guard LOS (guards see through it)
  noisemaker – emits periodic or triggered noise
  exit       – escape point (locked until win condition met)

Guard AI states
---------------
  PATROL   – waypoint loop; notices anomalies; pauses at ring waypoints
  ALERT    – heard/glimpsed something; pathfinds to last clue
  CHASE    – confirmed sighting; real-time A* pursuit
  INSPECT  – arrived at clue; slow rotation sweep; returns to patrol
  SEARCH   – main loot gone / player seen hiding; checks hide spots
  BRIEF    – physically walking to another guard to deliver a report (cyan »)

Guard adaptive memory
---------------------
  - Each alert records a hotspot. After 5 incidents, guard traps that spot.
  - Veteran guards (chased before) get +25% suspicion rate per chase (max +75%).
  - Curiosity wanders: guards deviate off-route unpredictably.

Physical briefing system
------------------------
  Instead of instant radio, guards physically walk to a nearby colleague
  after resolving a chase and brief them face-to-face (1.5s stand time).
  The briefed guard permanently upgrades based on urgency:

  URG_SUSPICIOUS (1) – raised suspicion, partial upgrade (wander +8%, susp +15%)
  URG_SPOTTED    (2) – confirmed sighting, significant upgrade + immediate alert
  URG_EMERGENCY  (3) – lost intruder after chase, maximum upgrade (susp +75%,
                        wander +50%, check +60%) – guard is now hypervigilant

  Briefings cascade one hop: a briefed guard queues a softer briefing for
  its own nearby colleagues (urgency reduced by 1).
  Cyan dots under a patrolling guard's feet show briefings received (max 3 shown).
  Guards in BRIEF state show a cyan » badge and cyan FOV tint.

Waypoint node types (set in wp_data per waypoint)
--------------------------------------------------
  waypoint   – default; walk through
  waitpoint  – pause and look around (wait_min/wait_max seconds)
  watch      – steer FOV toward watch_px while passing; stop and stare on arrival
  check      – brief inspection pause near hides/doors (check_chance %, check_time s)
               check_chance increases permanently when guard has been briefed

Level sequencing
----------------
  Add "next_level": "relative/path/to/next.ler" to a .ler file.
  On escape the player can press N to auto-load the next room.

Noise model
-----------
  - Walls dampen noise (0.55 ^ walls_between)
  - Opening a door once → 18 score (barely noticeable)
  - Opening same door twice quickly → 45 score
  - Sprinting → 55/burst, every 0.20s
  - Crashdoor → 95 score
  - Global alert threshold → 120 score

Audio
-----
  All sounds procedurally generated – no external files needed.
  Sounds: step, door, alert, chase, caught, escape, loot, crash.

Level .ler visuals dict extras
-------------------------------
  camera_smooth : float   – camera lerp speed (default 5.0)
"""

import pygame, math, sys, json, os, heapq, random
from collections import defaultdict

# ── GOAP AI planner ────────────────────────────────────────────────────────
from .ai.goap import GOAPAgent, GuardActionSet, SnitchActionSet, Goal

# ── builttags: Indent (tag) registry ─────────────────────────────────────────
# Load strategy (fastest first):
#   1. Try integrity/tags/cache.pkl  – written by Forgemason on every .lei save
#      and by `python builttags.py --compile`.  A single pickle.load() call,
#      no .lei parsing needed at game startup.
#   2. Fall back to importing builttags normally (parses all .lei files live).
#   3. If both fail, use empty stubs so the engine always starts.
_TAGS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "integrity", "tags")
if _TAGS_DIR not in sys.path:
    sys.path.insert(0, _TAGS_DIR)

_BUILTTAGS: dict = {}
_HAS_BUILTTAGS   = False

# ── 1. Try pickle cache (pygame startup fast path) ───────────────────────────
_TAG_CACHE_PATH = os.path.join(_TAGS_DIR, "cache.pkl")
try:
    import pickle as _pkl
    with open(_TAG_CACHE_PATH, "rb") as _f:
        _tag_cache = _pkl.load(_f)
    _BUILTTAGS     = _tag_cache.get("tags", {})
    _HAS_BUILTTAGS = bool(_BUILTTAGS)
    if _HAS_BUILTTAGS:
        print(f"[builttags] Loaded {len(_BUILTTAGS)} tags from cache.pkl")
    del _pkl, _f, _tag_cache
except Exception:
    pass  # cache missing or stale → fall through to live import

# ── 2. Fall back to live builttags import ────────────────────────────────────
if not _HAS_BUILTTAGS:
    try:
        from builttags import TAGS as _BUILTTAGS, all_tag_names as _all_tag_names
        _HAS_BUILTTAGS = True
    except ImportError:
        pass

# ── 3. Ensure _all_tag_names is always callable ──────────────────────────────
if not _HAS_BUILTTAGS:
    _BUILTTAGS = {}

try:
    _all_tag_names  # already imported from builttags in step 2
except NameError:
    def _all_tag_names(): return list(_BUILTTAGS.keys())


# ════════════════════════════════════════════════════════════════════════════
# .lev  Visual Definition System  (shared with KeyRing editor)
# ════════════════════════════════════════════════════════════════════════════
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(
                    os.path.abspath(__file__)))))
_LEV_DIR  = os.path.join(_PROJECT_ROOT, "integrity", "visuals")
_LEV_PATH = os.path.join(_LEV_DIR, "defaultvis_le.lev")
_LEV_DEFS: dict = {}   # tile_type → list[layer_dict]  (loaded once)

# ── .let tile definition files ───────────────────────────────────────────────
_LET_DIR = os.path.join(_PROJECT_ROOT, "integrity", "tiles")
# Per-tile _lockesc.lev files live alongside .let files in _LET_DIR.
# Naming convention: <tile_type>_lockesc.lev  (e.g. wall_lockesc.lev)

# PNG asset cache (generated by export_tiles_png.py). If a tile-specific
# PNG exists in _LET_DIR/png/<tile>.png it will be loaded once and blitted
# directly instead of procedurally drawing layers. This lets users supply
# hand-drawn art while retaining the procedural fallback behaviour.
_PNG_CACHE: dict[str, pygame.Surface | None] = {}

def _load_tile_png(tile_type: str):
    """Return a Surface or None for the given tile type's PNG.

    The result is cached. Looking in the subdirectory "png" under _LET_DIR.
    """
    if tile_type in _PNG_CACHE:
        return _PNG_CACHE[tile_type]
    path = os.path.join(_LET_DIR, "png", f"{tile_type}.png")
    surf = None
    if os.path.isfile(path):
        try:
            surf = pygame.image.load(path)
            # preserve alpha channel
            surf = surf.convert_alpha()
        except Exception:
            surf = None
    _PNG_CACHE[tile_type] = surf
    return surf

# ── Canonical default .lev content ──────────────────────────────────────────
_DEFAULT_LEV_JSON = {
    "_comment": "LockESC Visual Definition File (.lev) – auto-generated defaults",
    "_version": 1,
    "_doc": [
        "Each top-level key is a tile type. A tile entry is a list of LAYER objects.",
        "LAYER fields (coordinates 0..1 fractions of tile size):",
        "  type: rect | rect_outline | ellipse | ellipse_outline | line | cross |",
        "        arc | pie | triangle | text | radial_gradient_ellipse |",
        "        hinge_dot | hinge_line",
        "  color/color2: [R,G,B] or [R,G,B,A]  (0-255)",
        "  x,y,w,h: bounding box as fraction of tile (default 0,0,1,1)",
        "  pen_width: stroke width as fraction of tile (default 0.04)",
        "  dashed: true for dashed lines",
        "  rounded: true for rounded rects",
        "  text: string for text layers",
        "  font_scale: font size as fraction of tile (default 0.25)",
        "  pts: [[fx,fy],...] for triangles",
        "  start_angle/span_angle: degrees for arc/pie (Qt CCW from 3-oclock)",
        "  hinge: top-left|top-right|bottom-left|bottom-right|left|right|top|bottom",
        "  closed_angle: door closed angle in degrees",
        "  open_angle: degrees to add when open (default 90)"
    ],
    "wall": [
        {"type": "rect",    "color": [55, 70, 115]},
        {"type": "line",    "x1": 0.0, "y1": 0.0, "x2": 1.0, "y2": 0.0,  "color": [70, 95, 155],  "pen_width": 0.04},
        {"type": "line",    "x1": 0.0, "y1": 0.0, "x2": 0.0, "y2": 1.0,  "color": [70, 95, 155],  "pen_width": 0.04},
        {"type": "line",    "x1": 1.0, "y1": 0.0, "x2": 1.0, "y2": 1.0,  "color": [20, 28,  52],  "pen_width": 0.02},
        {"type": "line",    "x1": 0.0, "y1": 1.0, "x2": 1.0, "y2": 1.0,  "color": [20, 28,  52],  "pen_width": 0.02}
    ],
    "floor": [
        {"type": "rect", "color": [28, 52, 88]}
    ],
    "player": [
        {"type": "ellipse",         "x": 0.1,  "y": 0.1,  "w": 0.8,  "h": 0.8,  "color": [220, 55, 75]},
        {"type": "ellipse_outline", "x": 0.1,  "y": 0.1,  "w": 0.8,  "h": 0.8,  "color": [255,255,255,60], "pen_width": 0.04},
        {"type": "text",   "text": "P", "color": [255,255,255], "font_scale": 0.28}
    ],
    "exit": [
        {"type": "ellipse",         "x": 0.1,  "y": 0.1,  "w": 0.8,  "h": 0.8,  "color": [0, 200, 110]},
        {"type": "ellipse_outline", "x": 0.1,  "y": 0.1,  "w": 0.8,  "h": 0.8,  "color": [255,255,255,60], "pen_width": 0.04},
        {"type": "text",   "text": "E", "color": [255,255,255], "font_scale": 0.28}
    ],
    "loot": [
        {"type": "ellipse",         "x": 0.1,  "y": 0.1,  "w": 0.8,  "h": 0.8,  "color": [255, 200, 0]},
        {"type": "ellipse_outline", "x": 0.1,  "y": 0.1,  "w": 0.8,  "h": 0.8,  "color": [255,255,255,60], "pen_width": 0.04},
        {"type": "text",   "text": "$", "color": [255,255,255], "font_scale": 0.28}
    ],
    "mini_loot": [
        {"type": "ellipse",         "x": 0.2,  "y": 0.2,  "w": 0.6,  "h": 0.6,  "color": [200, 165, 0]},
        {"type": "ellipse_outline", "x": 0.2,  "y": 0.2,  "w": 0.6,  "h": 0.6,  "color": [255, 220, 80],  "pen_width": 0.05},
        {"type": "ellipse_outline", "x": 0.3,  "y": 0.3,  "w": 0.4,  "h": 0.4,  "color": [255,245,140,100], "pen_width": 0.03},
        {"type": "text",   "text": "¢", "color": [255,255,200], "font_scale": 0.22}
    ],
    "main_loot": [
        {"type": "radial_gradient_ellipse", "x": 0.05, "y": 0.05, "w": 0.9, "h": 0.9, "color": [255,160,60,200], "color2": [255,80,20,0]},
        {"type": "ellipse",         "x": 0.18, "y": 0.18, "w": 0.64, "h": 0.64, "color": [255, 80, 20]},
        {"type": "ellipse_outline", "x": 0.18, "y": 0.18, "w": 0.64, "h": 0.64, "color": [255,200,80], "pen_width": 0.04},
        {"type": "text",   "text": "★", "color": [255,255,200], "font_scale": 0.30}
    ],
    "hide": [
        {"type": "rect",         "x": 0.04, "y": 0.04, "w": 0.92, "h": 0.92, "color": [80,120,190,80], "rounded": True},
        {"type": "rect_outline", "x": 0.04, "y": 0.04, "w": 0.92, "h": 0.92, "color": [80,120,190],    "pen_width": 0.04, "rounded": True},
        {"type": "text",   "text": "H", "color": [255,255,255], "font_scale": 0.28}
    ],
    "guard": [
        {"type": "ellipse",         "x": 0.12, "y": 0.12, "w": 0.76, "h": 0.76, "color": [240,165,30]},
        {"type": "ellipse_outline", "x": 0.12, "y": 0.12, "w": 0.76, "h": 0.76, "color": [180,120,10], "pen_width": 0.04},
        {"type": "text",   "text": "G", "color": [255,255,255], "font_scale": 0.28}
    ],
    "door": [
        {"type": "rect",         "color": [140,100,40]},
        {"type": "line", "x1":0.02,"y1":0.02,"x2":1.0,"y2":0.02, "color":[180,140,70], "pen_width":0.04},
        {"type": "line", "x1":0.02,"y1":0.02,"x2":0.02,"y2":1.0, "color":[180,140,70], "pen_width":0.04},
        {"type": "line", "x1":0.02,"y1":0.98,"x2":1.0,"y2":0.98, "color":[50,35,10],   "pen_width":0.04},
        {"type": "line", "x1":0.98,"y1":0.02,"x2":0.98,"y2":0.98,"color":[50,35,10],   "pen_width":0.04},
        {"type": "ellipse", "x":0.78,"y":0.42,"w":0.10,"h":0.10,  "color":[255,200,80]},
        {"type": "text",   "text": "▬", "color": [255,255,255], "font_scale": 0.22}
    ],
    "crashdoor": [
        {"type": "rect",         "color": [180,60,20]},
        {"type": "rect_outline", "x":0.02,"y":0.02,"w":0.96,"h":0.96, "color":[220,80,40], "pen_width":0.06},
        {"type": "cross",        "x1":0.08,"y1":0.08,"x2":0.92,"y2":0.92,"color":[220,80,40],"pen_width":0.07},
        {"type": "text",   "text": "!", "color": [255,180,160], "font_scale": 0.30}
    ],
    "window": [
        {"type": "rect",         "color": [80,160,200,80]},
        {"type": "rect_outline", "x":0.04,"y":0.04,"w":0.92,"h":0.92,"color":[80,160,200],"pen_width":0.04},
        {"type": "line", "x1":0.5,"y1":0.04,"x2":0.5,"y2":0.96,"color":[80,160,200],"pen_width":0.04},
        {"type": "line", "x1":0.04,"y1":0.5,"x2":0.96,"y2":0.5,"color":[80,160,200],"pen_width":0.04},
        {"type": "text",   "text": "≡", "color": [200,240,255], "font_scale": 0.22}
    ],
    "noisemaker": [
        {"type": "radial_gradient_ellipse","x":0.05,"y":0.05,"w":0.9,"h":0.9,"color":[220,120,255,200],"color2":[180,60,220,0]},
        {"type": "ellipse",         "x":0.18,"y":0.18,"w":0.64,"h":0.64,"color":[200,100,220]},
        {"type": "ellipse_outline", "x":0.18,"y":0.18,"w":0.64,"h":0.64,"color":[220,80,255],"pen_width":0.04},
        {"type": "text",   "text": "♪", "color": [255,220,255], "font_scale": 0.26}
    ],
    "oiled_door": [
        {"type": "rect",         "color": [140,100,40]},
        {"type": "line", "x1":0.02,"y1":0.02,"x2":1.0,"y2":0.02, "color":[180,140,70],"pen_width":0.04},
        {"type": "line", "x1":0.02,"y1":0.02,"x2":0.02,"y2":1.0, "color":[180,140,70],"pen_width":0.04},
        {"type": "line", "x1":0.02,"y1":0.98,"x2":1.0,"y2":0.98, "color":[50,35,10],  "pen_width":0.04},
        {"type": "line", "x1":0.98,"y1":0.02,"x2":0.98,"y2":0.98,"color":[50,35,10],  "pen_width":0.04},
        {"type": "ellipse", "x":0.72,"y":0.04,"w":0.14,"h":0.14,  "color":[80,220,100]},
        {"type": "text",   "text": "○▬", "color": [200,255,200], "font_scale": 0.18}
    ],
    "wall_door": [
        {"type": "rect",         "color": [55,70,115]},
        {"type": "line", "x1":0.0,"y1":0.0,"x2":1.0,"y2":0.0, "color":[70,95,155],"pen_width":0.04},
        {"type": "line", "x1":0.0,"y1":0.0,"x2":0.0,"y2":1.0, "color":[70,95,155],"pen_width":0.04},
        {"type": "line", "x1":1.0,"y1":0.0,"x2":1.0,"y2":1.0, "color":[20,28,52], "pen_width":0.02},
        {"type": "line", "x1":0.0,"y1":1.0,"x2":1.0,"y2":1.0, "color":[20,28,52], "pen_width":0.02},
        {"type": "rect_outline","x":0.1,"y":0.1,"w":0.8,"h":0.8,"color":[120,100,170,120],"pen_width":0.02,"dashed":True},
        {"type": "ellipse","x":0.78,"y":0.04,"w":0.1,"h":0.1,   "color":[160,120,220,180]}
    ],
    "thin_door": [
        {"type": "hinge_dot",  "hinge":"top-left","color":[200,150,50], "radius":0.07},
        {"type": "hinge_line", "hinge":"top-left","color":[200,150,50], "pen_width":0.09,
         "closed_angle":0, "open_angle":90}
    ],
    "fence": [
        {"type": "rect",         "color": [28,52,88]},
        {"type": "rect_outline", "x":0.02,"y":0.02,"w":0.96,"h":0.96,"color":[90,120,70],"pen_width":0.04},
        {"_slats": True, "slat_color":[90,120,70],"slat_count":5,"pen_width":0.03},
        {"type": "line", "x1":0.04,"y1":0.5,"x2":0.96,"y2":0.5,"color":[90,120,70],"pen_width":0.02},
        {"type": "text",   "text": "╫", "color": [160,200,120], "font_scale": 0.26}
    ],
    "pit": [
        {"type": "rect",         "color": [12,16,36]},
        {"_hatch": True, "hatch_color":[20,25,50,140],"pen_width":0.02,"spacing":0.17},
        {"type": "ellipse",      "x":0.25,"y":0.25,"w":0.5,"h":0.5,"color":[8,10,22]},
        {"type": "ellipse_outline","x":0.25,"y":0.25,"w":0.5,"h":0.5,"color":[30,40,90],"pen_width":0.02},
        {"type": "text",   "text": "○", "color": [40,55,100], "font_scale": 0.22}
    ],
    "creak_floor": [
        {"_wave": True, "wave_color":[160,120,50,90], "pen_width":0.02, "amplitude":0.07}
    ],
    "snitch": [
        {"type": "triangle", "pts":[[0.5,0.0],[0.0,0.42],[1.0,0.42]], "color":[255,200,70,55]},
        {"type": "ellipse",         "x":0.12,"y":0.12,"w":0.76,"h":0.76,"color":[200,130,40]},
        {"type": "ellipse_outline", "x":0.12,"y":0.12,"w":0.76,"h":0.76,"color":[160,100,10],"pen_width":0.04},
        {"type": "ellipse_outline", "x":0.12,"y":0.12,"w":0.76,"h":0.76,"color":[255,255,255],"pen_width":0.02},
        {"type": "text",   "text": "◈", "color": [255,255,255], "font_scale": 0.26}
    ],
    "camera": [
        {"type": "pie",  "x":0.0,"y":-0.5,"w":2.0,"h":2.0,"color":[140,200,70,50],"start_angle":45,"span_angle":90},
        {"type": "rect", "x":0.25,"y":0.33,"w":0.5,"h":0.34,"color":[140,200,70]},
        {"type": "rect_outline","x":0.25,"y":0.33,"w":0.5,"h":0.34,"color":[80,160,40],"pen_width":0.04},
        {"type": "ellipse","x":0.64,"y":0.42,"w":0.18,"h":0.18,"color":[10,20,8]},
        {"type": "ellipse_outline","x":0.64,"y":0.42,"w":0.18,"h":0.18,"color":[140,200,70],"pen_width":0.02},
        {"type": "text",   "text": "⊙", "color": [220,255,180], "font_scale": 0.22}
    ],
    "invisible_wall": [
        {"type": "rect",         "color": [90,110,180,35]},
        {"type": "rect_outline", "x":0.04,"y":0.04,"w":0.92,"h":0.92,"color":[90,110,180,160],"pen_width":0.04,"dashed":True}
    ],
    "thin_wall": [
        {"_thin_wall_segments": True, "color":[170,195,255],"pen_width":0.11}
    ],
    "transmit_node": [
        {"type": "rect",         "x":0.06,"y":0.06,"w":0.88,"h":0.88,"color":[60,200,210,60]},
        {"type": "rect_outline", "x":0.06,"y":0.06,"w":0.88,"h":0.88,"color":[60,200,210],"pen_width":0.04},
        {"type": "text",   "text": "→", "color": [80,255,255], "font_scale": 0.30}
    ],
    "receive_node": [
        {"type": "rect",         "x":0.06,"y":0.06,"w":0.88,"h":0.88,"color":[210,170,60,60]},
        {"type": "rect_outline", "x":0.06,"y":0.06,"w":0.88,"h":0.88,"color":[210,170,60],"pen_width":0.04},
        {"type": "text",   "text": "←", "color": [255,220,100], "font_scale": 0.30}
    ]
}


def _ensure_lev_file():
    """Write per-tile *_lockesc.lev files into integrity/tiles/ if absent.

    Each tile type in _DEFAULT_LEV_JSON gets its own <type>_lockesc.lev file.
    The legacy monolithic defaultvis_le.lev is also written for compatibility.
    """
    os.makedirs(_LET_DIR, exist_ok=True)
    os.makedirs(_LEV_DIR, exist_ok=True)
    defaults = {k: v for k, v in _DEFAULT_LEV_JSON.items() if not k.startswith("_")}
    for tile_type, layers in defaults.items():
        per_tile_path = os.path.join(_LET_DIR, f"{tile_type}_lockesc.lev")
        if not os.path.exists(per_tile_path):
            try:
                data = {
                    "_comment": f"LockESC Visual Definition - GAME (LockESC) - {tile_type}",
                    "_version": 1,
                    "_note": f"Per-tile visual definition for '{tile_type}'. Used by lockesc.py.",
                    tile_type: layers,
                }
                with open(per_tile_path, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
            except Exception as e:
                print(f"[lev] Could not write {per_tile_path}: {e}")
    # also keep the monolithic fallback up-to-date
    if not os.path.exists(_LEV_PATH):
        try:
            with open(_LEV_PATH, "w", encoding="utf-8") as f:
                json.dump(_DEFAULT_LEV_JSON, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"[lev] Could not write {_LEV_PATH}: {e}")


def _load_lev_defs() -> dict:
    """Load tile visual definitions STRICTLY from per-tile *_lockesc.lev files.

    Priority (highest to lowest):
      1. Per-tile  integrity/tiles/CUSTOM/*_lockesc.lev  (custom tile overrides)
      2. Per-tile  integrity/tiles/*_lockesc.lev          (built-in tile visuals)
      3. Monolithic integrity/visuals/defaultvis_le.lev   (legacy monolithic fallback)

    The hardcoded _DEFAULT_LEV_JSON is NO LONGER used as a runtime fallback.
    If a tile's .lev file is absent, _draw_lev_tile_pygame returns False and the
    game falls back to its own procedural draw – but essential tiles should always
    have their .lev files present.  Use _check_level_integrity() / the per-level
    build script to ensure required files exist before playing.
    """
    global _LEV_DEFS
    if _LEV_DEFS:
        return _LEV_DEFS

    merged: dict = {}
    import glob as _glob

    # Step 1a: built-in per-tile files
    if os.path.isdir(_LET_DIR):
        for fpath in sorted(_glob.glob(os.path.join(_LET_DIR, "*_lockesc.lev"))):
            try:
                with open(fpath, encoding="utf-8") as f:
                    raw = json.load(f)
                for k, v in raw.items():
                    if not k.startswith("_"):
                        merged[k] = v
            except Exception as e:
                print(f"[lev] Skipping {fpath}: {e}")

    # Step 1b: CUSTOM tile overrides (take priority)
    custom_dir = os.path.join(_LET_DIR, "CUSTOM")
    if os.path.isdir(custom_dir):
        for fpath in sorted(_glob.glob(os.path.join(custom_dir, "*_lockesc.lev"))):
            try:
                with open(fpath, encoding="utf-8") as f:
                    raw = json.load(f)
                for k, v in raw.items():
                    if not k.startswith("_"):
                        merged[k] = v
            except Exception as e:
                print(f"[lev] Skipping custom {fpath}: {e}")

    # Step 2: monolithic fallback for anything still missing
    try:
        with open(_LEV_PATH, encoding="utf-8") as f:
            mono = json.load(f)
        for k, v in mono.items():
            if not k.startswith("_") and k not in merged:
                merged[k] = v
    except Exception:
        pass

    if merged:
        print(f"[lev] Loaded visuals for {len(merged)} tile type(s) from .lev files")
    else:
        print("[lev] WARNING: No .lev files found — tile visuals will use procedural fallbacks")

    _LEV_DEFS = merged
    return _LEV_DEFS


# ── State-visual definitions  (integrity/tiles/state_lockesc.lev) ──────────────
# These hold colour/style values for animated game states: guard FSM colours,
# player colours, exit colours, noise ring, loot glow, etc.
# The file is a flat dict  { "state_key": [R,G,B] or [R,G,B,A], ... }
# wrapped in the standard .lev envelope  { "_comment":…, "state": { … } }
# State-vis values are merged with the level's own visuals dict at draw time,
# with the level visuals taking priority.

_STATE_VIS_DEFS: dict = {}  # state_key → colour tuple


def _load_state_vis_defs() -> dict:
    """Load state colour definitions from state_lockesc.lev.

    Priority: CUSTOM/state_lockesc.lev  >  integrity/tiles/state_lockesc.lev
    Falls back to built-in C_* constants if the file is absent.
    """
    global _STATE_VIS_DEFS
    if _STATE_VIS_DEFS:
        return _STATE_VIS_DEFS

    candidates = [
        os.path.join(_LET_DIR, "CUSTOM", "state_lockesc.lev"),
        os.path.join(_LET_DIR, "state_lockesc.lev"),
    ]
    for path in candidates:
        if os.path.isfile(path):
            try:
                with open(path, encoding="utf-8") as f:
                    raw = json.load(f)
                # The file wraps colour data under the "state" key
                colours = raw.get("state", raw)
                merged: dict = {}
                for k, v in colours.items():
                    if k.startswith("_"):
                        continue
                    if isinstance(v, (list, tuple)) and len(v) >= 3:
                        merged[k] = tuple(int(x) for x in v[:4])
                _STATE_VIS_DEFS = merged
                print(f"[lev] Loaded {len(merged)} state visual(s) from {os.path.basename(path)}")
                return _STATE_VIS_DEFS
            except Exception as e:
                print(f"[lev] Could not load state vis from {path}: {e}")

    print("[lev] No state_lockesc.lev found – state visuals use built-in defaults")
    _STATE_VIS_DEFS = {}
    return _STATE_VIS_DEFS


def _svc(vis: dict, key: str, default):
    """State-vis colour lookup: level visuals  >  state_lockesc.lev  >  built-in default."""
    # Level-specific override has highest priority
    lv = vis.get(key)
    if lv and len(lv) >= 3:
        n = len(default) if isinstance(default, tuple) else 3
        return tuple(int(x) for x in lv[:n])
    # state_lockesc.lev
    sv = _load_state_vis_defs().get(key)
    if sv:
        return sv
    return default


# ── Level integrity helpers ────────────────────────────────────────────────────

# Tile types that every playable level MUST have .let + _lockesc.lev files for.
_ESSENTIAL_TILE_TYPES = {
    "wall", "floor", "player", "player2", "exit", "loot", "mini_loot", "main_loot",
    "hide", "guard", "door", "oiled_door", "wall_door", "crashdoor",
    "window", "fence", "pit", "creak_floor", "item_pile", "snitch", "camera",
    "invisible_wall", "thin_wall", "thin_door",
    "transmit_node", "receive_node", "noisemaker",
}


def _collect_required_tiles(level_data: dict) -> set:
    """Return the set of tile types actually referenced in level_data objects."""
    types: set = set()
    for obj in level_data.get("objects", []):
        t = obj.get("type", "")
        if t:
            types.add(t)
    # regions, players and exits are always needed if present
    return types


def _missing_tile_assets(required_types: set) -> list:
    """Return list of (tile_type, missing_file_kind) tuples for any absent files.

    missing_file_kind is one of: 'let', 'lockesc_lev'
    Custom tiles also need their .let; built-in tiles just need their _lockesc.lev.
    """
    missing = []
    # Find existing assets
    existing_let = set()
    existing_lev = set()
    import glob as _glob
    for d in (_LET_DIR, os.path.join(_LET_DIR, "CUSTOM")):
        if not os.path.isdir(d):
            continue
        for fp in _glob.glob(os.path.join(d, "*.let")):
            existing_let.add(os.path.basename(fp)[:-4])
        for fp in _glob.glob(os.path.join(d, "*_lockesc.lev")):
            name = os.path.basename(fp)
            if name.endswith("_lockesc.lev"):
                existing_lev.add(name[:-len("_lockesc.lev")])

    for tt in sorted(required_types):
        if tt in ("region", "region_inbetween", "region_inbetween_doorway",
                  "ai_coverhint", "ai_chokehint", "ai_avoidhint",
                  "timer_node", "input_node", "output_node",
                  "bob", "floor"):
            continue  # these have no mandatory visual files
        is_builtin = tt in _ESSENTIAL_TILE_TYPES
        if not is_builtin and tt not in existing_let:
            missing.append((tt, "let"))
        if tt not in existing_lev:
            missing.append((tt, "lockesc_lev"))

    return missing


def _generate_build_script(level_path: str, required_types: set) -> str:
    """Generate a per-level Python build script that creates missing .let and
    _lockesc.lev / _keyring.lev files in integrity/tiles/CUSTOM/.

    Returns the path of the generated script.
    """
    root_dir = os.path.dirname(os.path.abspath(level_path))
    # Walk up until we find integrity/ or hit the fs root
    search = root_dir
    for _ in range(6):
        if os.path.isdir(os.path.join(search, "integrity", "tiles")):
            root_dir = search
            break
        parent = os.path.dirname(search)
        if parent == search:
            break
        search = parent

    level_stem = os.path.splitext(os.path.basename(level_path))[0]
    script_path = os.path.join(root_dir, f"build_{level_stem}.py")

    # Build the set of tiles that are NOT built-in
    custom_types = sorted(t for t in required_types if t not in _ESSENTIAL_TILE_TYPES
                          and t not in ("region", "region_inbetween",
                                        "region_inbetween_doorway",
                                        "timer_node", "input_node",
                                        "output_node", "bob", "floor"))

    # Load existing _DEFAULT_LEV_JSON keys for template fallback reference
    default_layer = [
        {"type": "rect",    "color": [55, 70, 115]},
        {"type": "ellipse", "x": 0.25, "y": 0.25, "w": 0.5, "h": 0.5, "color": [90, 110, 180]},
        {"type": "text",    "text": "?", "color": [255, 255, 255], "font_scale": 0.28},
    ]

    lines = [
        '"""',
        f'Build script for level: {os.path.basename(level_path)}',
        '',
        'Auto-generated by LockESC.  Run this script once to create all',
        'missing tile asset files (.let, _lockesc.lev, _keyring.lev) that',
        f'this level requires in  integrity/tiles/CUSTOM/',
        '',
        'Usage:',
        f'  python build_{level_stem}.py',
        '"""',
        'import os, json, sys',
        '',
        '# ── Locate the project root ──────────────────────────────────────────',
        '_HERE = os.path.dirname(os.path.abspath(__file__))',
        '_ROOT = _HERE',
        'for _ in range(6):',
        '    if os.path.isdir(os.path.join(_ROOT, "integrity", "tiles")):',
        '        break',
        '    _ROOT = os.path.dirname(_ROOT)',
        '',
        '_CUSTOM = os.path.join(_ROOT, "integrity", "tiles", "CUSTOM")',
        'os.makedirs(_CUSTOM, exist_ok=True)',
        '',
    ]

    if not custom_types:
        lines += [
            '# All tile types used by this level are built-in.',
            '# This script ensures built-in _lockesc.lev and _keyring.lev',
            '# files are present in integrity/tiles/ (normally auto-created',
            '# on first run, but you can regenerate them here).',
            '',
            'sys.path.insert(0, _ROOT)',
            'from lockesc import _ensure_lev_file as _le',
            'from keyring import _ensure_lev_file as _kr',
            '_le()',
            '_kr()',
            'print("Built-in tile assets verified.")',
        ]
    else:
        lines += [
            f'# Custom tile types used by this level: {custom_types}',
            '',
            'CUSTOM_TILES = ' + repr(custom_types),
            '',
            '# Default layer stack for auto-generated visuals (edit as needed)',
            '_DEFAULT_LAYERS = ' + json.dumps(default_layer, ensure_ascii=False),
            '',
            'def _write(path, data):',
            '    if os.path.exists(path):',
            '        print(f"  exists: {path}")',
            '        return',
            '    with open(path, "w", encoding="utf-8") as f:',
            '        json.dump(data, f, indent=2, ensure_ascii=False)',
            '    print(f"  created: {path}")',
            '',
            'for tile_type in CUSTOM_TILES:',
            '    # .let definition',
            '    let_path = os.path.join(_CUSTOM, f"{tile_type}.let")',
            '    _write(let_path, {',
            '        "_comment": f"LockESC Tile Definition (.let) – {tile_type}",',
            '        "_version": 1,',
            '        "type":     tile_type,',
            '        "label":    tile_type.replace("_"," ").title(),',
            '        "category": "structure",',
            '        "flags": {',
            '            "openable": False, "bashable": False, "crashable": False,',
            '            "silent": False, "blocks_movement": True, "blocks_los": True,',
            '            "uses_channel": False, "linked_by_adjacency": False,',
            '            "guard_opens": False, "guard_closes": False,',
            '            "has_open_state": False, "hides_when_closed": False,',
            '            "thin": False, "is_fence": False, "is_pit": False,',
            '            "collectible": False, "emits_noise": False,',
            '            "has_fov": False, "is_entity": False',
            '        },',
            '        "defaults": {},',
            '        "noise": {},',
            '        "sound": {},',
            '        "visuals": {}',
            '    })',
            '    # _lockesc.lev',
            '    lev_path = os.path.join(_CUSTOM, f"{tile_type}_lockesc.lev")',
            '    _write(lev_path, {',
            '        "_comment": f"LockESC Visual Definition – GAME – {tile_type}",',
            '        "_version": 1,',
            '        "_note": f"Auto-generated by build_{level_stem}.py. Edit layers as needed.",',
            '        tile_type: _DEFAULT_LAYERS',
            '    })',
            '    # _keyring.lev',
            '    kr_path = os.path.join(_CUSTOM, f"{tile_type}_keyring.lev")',
            '    _write(kr_path, {',
            '        "_comment": f"LockESC Visual Definition – EDITOR (KeyRing) – {tile_type}",',
            '        "_version": 1,',
            '        "_note": f"Auto-generated by build_{level_stem}.py. Edit layers as needed.",',
            '        tile_type: _DEFAULT_LAYERS',
            '    })',
            '',
            'print(f"\\nDone. Created/verified assets for: {CUSTOM_TILES}")',
            'print(f"Edit the generated files in: {_CUSTOM}")',
        ]

    script_src = "\n".join(lines) + "\n"
    try:
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(script_src)
        print(f"[integrity] Build script written: {script_path}")
    except Exception as e:
        print(f"[integrity] Could not write build script: {e}")
    return script_path


def _check_level_integrity(level_path: str, level_data: dict) -> list:
    """Check that all tile assets required by this level are present.

    Returns a list of human-readable missing-asset messages.
    Also auto-generates a build script if anything is missing.
    """
    required = _collect_required_tiles(level_data)
    missing  = _missing_tile_assets(required)
    if not missing:
        return []

    messages = []
    by_tile: dict = {}
    for tt, kind in missing:
        by_tile.setdefault(tt, []).append(kind)
    for tt, kinds in sorted(by_tile.items()):
        desc = []
        if "let"         in kinds: desc.append(f"{tt}.let")
        if "lockesc_lev" in kinds: desc.append(f"{tt}_lockesc.lev")
        messages.append(f"  {tt}: missing {', '.join(desc)}")

    # Auto-generate the build script
    _generate_build_script(level_path, required)
    return messages


def _lev_color(lst, fallback=(200, 200, 200)):
    """[R,G,B] or [R,G,B,A] list → tuple."""
    if lst and len(lst) >= 3:
        return tuple(int(x) for x in lst[:4])
    return fallback


def _lev_font(size_px):
    """Return a cached pygame SysFont for the given pixel size."""
    if not hasattr(_lev_font, "_cache"):
        _lev_font._cache = {}
    if size_px not in _lev_font._cache:
        _lev_font._cache[size_px] = pygame.font.SysFont("monospace", max(6, size_px), bold=True)
    return _lev_font._cache[size_px]


def _load_bundle_tile_defs(bundle_path: str) -> dict:
    """Load tile definitions from <bundle>/tiles/, returning a merged dict.

    Loads in priority order:
      1. *_lockesc.lev  – procedural layer stacks (visual override)
      2. *.let          – tile property definitions (flags, defaults, noise)
    PNGs in <bundle>/tiles/png/ are registered for the per-call PNG lookup
    via the returned dict's special key '_bundle_png_dir'.
    """
    import glob as _glob
    tiles_dir = os.path.join(bundle_path, "tiles")
    if not os.path.isdir(tiles_dir):
        return {}
    merged = {}

    # 1. Load .lev layer stacks
    for fpath in sorted(_glob.glob(os.path.join(tiles_dir, "*_lockesc.lev"))):
        try:
            with open(fpath, encoding="utf-8") as f:
                raw = json.load(f)
            for k, v in raw.items():
                if not k.startswith("_"):
                    merged[k] = v
        except Exception as e:
            print(f"[bundle-tiles] Skipping {fpath}: {e}")

    # 2. Load .let property definitions into a sub-dict under '_let'
    let_defs = {}
    for fpath in sorted(_glob.glob(os.path.join(tiles_dir, "*.let"))):
        tile_name = os.path.basename(fpath)[:-4]
        try:
            with open(fpath, encoding="utf-8") as f:
                let_defs[tile_name] = json.load(f)
        except Exception as e:
            print(f"[bundle-tiles] Skipping {fpath}: {e}")
    if let_defs:
        merged["_let"] = let_defs

    # 3. Register bundle png directory for per-tile PNG lookups
    png_dir = os.path.join(tiles_dir, "png")
    if os.path.isdir(png_dir):
        merged["_bundle_png_dir"] = png_dir

    return merged


def _draw_lev_tile_pygame(surf, tile_type: str,
                           sx: int, sy: int, tile: int,
                           obj: dict = None,
                           vis: dict = None,
                           extra_defs: dict = None) -> bool:
    """
    Draw one tile onto *surf* using its .lev layer stack (pygame renderer).

    Tries to load a pre-rendered PNG first; if found, blits it and returns True.
    Otherwise falls back to the procedural layer renderer.

    sx, sy     = screen pixel top-left of the tile
    tile       = tile size in pixels
    obj        = tile object dict (for thin_door open/rotation state, thin_wall shape etc.)
    vis        = level visuals dict (used to override colours when a vis key is set)
    extra_defs = optional per-level tile defs from the bundle (override global defs)

    Returns True when drawn (either PNG or .lev); False when no entry exists.
    """
    # Check bundle-local PNG first (overrides global tiles/png/)
    bundle_png = None
    if extra_defs and "_bundle_png_dir" in extra_defs:
        bp = os.path.join(extra_defs["_bundle_png_dir"], f"{tile_type}.png")
        if os.path.isfile(bp):
            cache_key = f"_bundle_{bp}"
            if cache_key not in _PNG_CACHE:
                try:
                    s = pygame.image.load(bp).convert_alpha()
                    _PNG_CACHE[cache_key] = s
                except Exception:
                    _PNG_CACHE[cache_key] = None
            bundle_png = _PNG_CACHE[cache_key]
    png = bundle_png or _load_tile_png(tile_type)
    if png:
        try:
            surf.blit(png, (sx, sy))
            return True
        except Exception:
            pass
    defs = dict(_load_lev_defs())
    if extra_defs:
        defs.update(extra_defs)
    layers = defs.get(tile_type)
    if not layers:
        return False

    vis = vis or {}
    obj = obj or {}

    def ipx(f):  return sx + int(f * tile)
    def ipy(f):  return sy + int(f * tile)
    def ipw(f):  return max(1, int(f * tile))

    for layer in layers:
        lt   = layer.get("type", "")
        col  = _lev_color(layer.get("color"), (200, 200, 200))
        col2 = _lev_color(layer.get("color2"), (0, 0, 0, 0))
        lw   = ipw(layer.get("pen_width", 0.04))
        x0   = ipx(layer.get("x", 0.0))
        y0   = ipy(layer.get("y", 0.0))
        w0   = ipw(layer.get("w", 1.0))
        h0   = ipw(layer.get("h", 1.0))

        # Helper: draw onto an SRCALPHA surface if colour has alpha, else direct
        def _fill(surface, rect, color):
            if len(color) == 4 and color[3] < 255:
                s = pygame.Surface((rect[2], rect[3]), pygame.SRCALPHA)
                s.fill(color)
                surface.blit(s, rect[:2])
            else:
                pygame.draw.rect(surface, color[:3], rect)

        def _circle(surface, color, pos, radius, width=0):
            if len(color) == 4 and color[3] < 255:
                d = radius * 2
                s = pygame.Surface((d, d), pygame.SRCALPHA)
                pygame.draw.circle(s, color, (radius, radius), radius, width)
                surface.blit(s, (pos[0] - radius, pos[1] - radius))
            else:
                pygame.draw.circle(surface, color[:3], pos, radius, width)

        if lt == "rect":
            _fill(surf, (x0, y0, w0, h0), col)

        elif lt == "rect_outline":
            if layer.get("dashed"):
                # Simple dashed rect: draw dashes along each edge
                dash, gap = max(3, tile//8), max(2, tile//16)
                edges = [
                    ((x0, y0), (x0+w0, y0)),
                    ((x0+w0, y0), (x0+w0, y0+h0)),
                    ((x0+w0, y0+h0), (x0, y0+h0)),
                    ((x0, y0+h0), (x0, y0)),
                ]
                for (ax, ay), (bx, by) in edges:
                    length = max(abs(bx-ax), abs(by-ay))
                    steps  = max(1, length // (dash+gap))
                    for i in range(steps):
                        t0 = i*(dash+gap)/length
                        t1 = min(1.0, (i*(dash+gap)+dash)/length)
                        px0 = int(ax + (bx-ax)*t0); py0 = int(ay + (by-ay)*t0)
                        px1 = int(ax + (bx-ax)*t1); py1 = int(ay + (by-ay)*t1)
                        pygame.draw.line(surf, col[:3], (px0,py0), (px1,py1), lw)
            else:
                pygame.draw.rect(surf, col[:3], (x0, y0, w0, h0), lw)

        elif lt == "ellipse":
            _circle(surf, col, (x0 + w0//2, y0 + h0//2), w0//2)

        elif lt == "ellipse_outline":
            _circle(surf, col, (x0 + w0//2, y0 + h0//2), w0//2, lw)

        elif lt == "line":
            x1 = ipx(layer.get("x1", 0.0)); y1 = ipy(layer.get("y1", 0.0))
            x2 = ipx(layer.get("x2", 1.0)); y2 = ipy(layer.get("y2", 1.0))
            pygame.draw.line(surf, col[:3], (x1, y1), (x2, y2), lw)

        elif lt == "cross":
            x1 = ipx(layer.get("x1",0.08)); y1 = ipy(layer.get("y1",0.08))
            x2 = ipx(layer.get("x2",0.92)); y2 = ipy(layer.get("y2",0.92))
            pygame.draw.line(surf, col[:3], (x1,y1), (x2,y2), lw)
            pygame.draw.line(surf, col[:3], (x2,y1), (x1,y2), lw)

        elif lt == "triangle":
            pts_f = layer.get("pts", [[0.5,0],[0,1],[1,1]])
            pts   = [(ipx(p[0]), ipy(p[1])) for p in pts_f]
            if len(col) == 4 and col[3] < 255:
                s = pygame.Surface((tile, tile), pygame.SRCALPHA)
                local = [(p[0]-sx, p[1]-sy) for p in pts]
                pygame.draw.polygon(s, col, local)
                surf.blit(s, (sx, sy))
            else:
                pygame.draw.polygon(surf, col[:3], pts)

        elif lt == "pie":
            # pygame doesn't have arc-fill; approximate with polygon fan
            sa  = math.radians(layer.get("start_angle", 45))
            spa = math.radians(layer.get("span_angle", 90))
            cx2 = x0 + w0//2; cy2 = y0 + h0//2
            rx2 = w0//2;       ry2 = h0//2
            steps = max(8, int(abs(spa) / math.pi * 32))
            pts = [(cx2, cy2)]
            for i in range(steps+1):
                a = sa + i * spa / steps
                # Qt uses counter-clockwise from 3-o-clock; pygame coords have y flipped
                pts.append((int(cx2 + rx2*math.cos(-a)), int(cy2 + ry2*math.sin(-a))))
            if len(col) == 4 and col[3] < 255:
                s = pygame.Surface((tile*2, tile*2), pygame.SRCALPHA)
                local = [(p[0]-sx, p[1]-sy) for p in pts]
                pygame.draw.polygon(s, col, local)
                surf.blit(s, (sx, sy))
            else:
                pygame.draw.polygon(surf, col[:3], pts)

        elif lt == "radial_gradient_ellipse":
            # Approximate radial gradient with concentric circles
            cx2 = x0 + w0//2; cy2 = y0 + h0//2
            rad = w0//2
            steps = max(4, rad//2)
            s = pygame.Surface((tile, tile), pygame.SRCALPHA)
            for i in range(steps, -1, -1):
                t = i / steps
                r_i = max(0, int(t * t * rad))
                # lerp colour
                rc = [int(col[j] + (col2[j] - col[j]) * t) for j in range(3)]
                ac = int(col[3] if len(col)>3 else 255) if t < 0.5 else \
                     int((col2[3] if len(col2)>3 else 0))
                pygame.draw.circle(s, (*rc[:3], max(0,min(255,ac))),
                                   (cx2-sx, cy2-sy), r_i)
            surf.blit(s, (sx, sy))

        elif lt == "text":
            txt = layer.get("text", "?")
            fsize = max(6, int(layer.get("font_scale", 0.25) * tile))
            try:
                font = _lev_font(fsize)
                rendered = font.render(txt, True, col[:3])
                surf.blit(rendered, rendered.get_rect(center=(sx + tile//2, sy + tile//2)))
            except Exception:
                pass

        # ── Hinge layers (thin_door) ──────────────────────────────────────
        elif lt in ("hinge_dot", "hinge_line"):
            _draw_lev_hinge_pygame(surf, layer, sx, sy, tile, obj)

        # ── Special procedural layers ─────────────────────────────────────
        elif layer.get("_slats"):
            sc  = _lev_color(layer.get("slat_color"), col[:3])
            slw = ipw(layer.get("pen_width", 0.03))
            count = layer.get("slat_count", 5)
            for i in range(1, count):
                xi = sx + int(i * tile / count)
                pygame.draw.line(surf, sc[:3], (xi, sy+2), (xi, sy+tile-2), slw)

        elif layer.get("_hatch"):
            hc  = _lev_color(layer.get("hatch_color"), col)
            hlw = ipw(layer.get("pen_width", 0.02))
            gap = int(layer.get("spacing", 0.17) * tile)
            s   = pygame.Surface((tile, tile), pygame.SRCALPHA)
            for xi in range(0, tile*2, max(4, gap)):
                pygame.draw.line(s, hc, (xi-tile, 0), (xi, tile), hlw)
            surf.blit(s, (sx, sy))

        elif layer.get("_wave"):
            wc  = _lev_color(layer.get("wave_color"), col)
            wlw = ipw(layer.get("pen_width", 0.02))
            amp = layer.get("amplitude", 0.07) * tile
            cy2 = sy + tile//2
            pts_w = []
            for xi in range(sx+4, sx+tile-3, 2):
                yi = int(cy2 + math.sin((xi-sx)*0.5) * amp)
                pts_w.append((xi, yi))
            if len(pts_w) >= 2 and len(wc) == 4 and wc[3] < 255:
                s = pygame.Surface((tile, tile), pygame.SRCALPHA)
                local = [(p[0]-sx, p[1]-sy) for p in pts_w]
                for i in range(len(local)-1):
                    pygame.draw.line(s, wc, local[i], local[i+1], wlw)
                surf.blit(s, (sx, sy))
            elif len(pts_w) >= 2:
                for i in range(len(pts_w)-1):
                    pygame.draw.line(surf, wc[:3], pts_w[i], pts_w[i+1], wlw)

        elif layer.get("_thin_wall_segments"):
            tc2 = _lev_color(layer.get("color"), (170,195,255))
            tlw = ipw(layer.get("pen_width", 0.11))
            shape = obj.get("shape", "straight")
            rot   = obj.get("rotation", 0) % 360
            cx2, cy2 = sx + tile//2, sy + tile//2
            mg   = max(2, tile//8)
            top    = (cx2,        sy + mg)
            bottom = (cx2,        sy + tile - mg)
            left   = (sx + mg,    cy2)
            right  = (sx + tile - mg, cy2)
            ctr    = (cx2, cy2)
            def _seg(a, b):
                pygame.draw.line(surf, tc2[:3], a, b, tlw)
            if shape == "straight":
                if rot in (0,180): _seg(left, right)
                else: _seg(top, bottom)
            elif shape == "corner":
                pairs = [(top,ctr,right),(right,ctr,bottom),(bottom,ctr,left),(left,ctr,top)]
                a1,m1,b1 = pairs[(rot//90)%4]; _seg(a1,m1); _seg(m1,b1)
            elif shape == "t":
                segs4=[[(left,right),(top,ctr)],[(top,bottom),(ctr,right)],
                       [(left,right),(ctr,bottom)],[(top,bottom),(left,ctr)]]
                for a2,b2 in segs4[(rot//90)%4]: _seg(a2,b2)
            else:
                _seg(left,right); _seg(top,bottom)

    return True


def _lev_hinge_corner(hinge_str, sx, sy, tile):
    h = hinge_str.lower()
    if h == "top-left":     return sx,         sy
    if h == "top-right":    return sx + tile,  sy
    if h == "bottom-left":  return sx,         sy + tile
    if h == "bottom-right": return sx + tile,  sy + tile
    if h == "left":         return sx,         sy + tile//2
    if h == "right":        return sx + tile,  sy + tile//2
    if h == "top":          return sx + tile//2, sy
    if h == "bottom":       return sx + tile//2, sy + tile
    return sx, sy


def _draw_lev_hinge_pygame(surf, layer, sx, sy, tile, obj):
    obj        = obj or {}
    is_open    = obj.get("open", False)
    base_rot   = obj.get("rotation", 0)
    hinge_str  = layer.get("hinge", "top-left")
    hx, hy     = _lev_hinge_corner(hinge_str, sx, sy, tile)
    closed_ang = layer.get("closed_angle", 0)
    open_off   = layer.get("open_angle", 90)
    angle_deg  = (closed_ang + base_rot + (open_off if is_open else 0)) % 360
    angle_rad  = math.radians(angle_deg)
    door_len   = tile * 0.88
    ex = hx + door_len * math.cos(angle_rad)
    ey = hy + door_len * math.sin(angle_rad)
    col_list = layer.get("color", [200, 150, 50])
    col = (120, 200, 100) if is_open else tuple(int(x) for x in col_list[:3])
    lt  = layer.get("type", "")
    if lt == "hinge_line":
        lw = max(2, int(layer.get("pen_width", 0.09) * tile))
        pygame.draw.line(surf, col, (hx, hy), (int(ex), int(ey)), lw)
    elif lt == "hinge_dot":
        r = int(layer.get("radius", 0.07) * tile)
        pygame.draw.circle(surf, col, (hx, hy), r)


# ════════════════════════════════════════════════════════════════════════════
# ObjectRegistry  –  fully hardcoded object definitions
# ════════════════════════════════════════════════════════════════════════════
# All object types (door, crashdoor, oiled_door, wall_door, thin_door …) are
# defined in _FALLBACKS below.  No files or folders are read at runtime.
#
# To export definitions to JSON for external editing (optional), run:
#   python -c "from lockesc import ObjectRegistry; ObjectRegistry.export_json()"
# The game will NOT read those files back automatically – they are reference
# only unless you wire them in yourself.

# NOTE: Object definitions are fully hardcoded in ObjectRegistry._FALLBACKS.
# No folder or JSON files are needed or read at runtime.
# If you want to export the definitions to JSON for external editing, run:
#   python -c "from lockesc import ObjectRegistry; ObjectRegistry.export_json('game_files/objects')"
_OBJ_FOLDER = None  # unused at runtime

class ObjectRegistry:
    _defs: dict = {}   # type_str -> full JSON dict

    # ── Hardcoded fallbacks ───────────────────────────────────────────────
    # These are used when the JSON file is absent so the game never crashes.
    _FALLBACKS = {
        "door": {
            "flags": {"openable":True,"bashable":True,"crashable":False,
                      "silent":False,"blocks_movement":True,"blocks_los":True,
                      "uses_channel":False,"linked_by_adjacency":True,
                      "guard_opens":True,"guard_closes":True,"has_open_state":True,
                      "hides_when_closed":False,"thin":False,"is_fence":False,
                      "is_pit":False,"collectible":False,"emits_noise":False,
                      "has_fov":False,"is_entity":False},
            "defaults":{"open":False,"allow_manual":True,"channel":0},
            "noise":{"open_once_score":18,"open_twice_score":45,"bash_score":70,
                     "radius_tiles":3,"repeat_window_sec":3.0,"lifetime_sec":0.9},
            "sound":{"toggle":"door","bash":"crash"},
            "visuals":{"style":"bevel_door","sprite_key":"door_sprite",
                       "closed_color":[75,50,18],"open_color":[140,100,40],
                       "bashed_color":[90,30,10],"bevel_light":[180,140,70],
                       "bevel_dark":[50,35,10],"knob_color":[255,200,80],
                       "label_color":[180,140,80],"changed_color":[255,100,0],
                       "bash_x_color":[220,60,0],
                       "label_open":"▭","label_closed":"▬","label_bashed":"BASH"}},
        "crashdoor": {
            "flags": {"openable":False,"bashable":False,"crashable":True,
                      "silent":False,"blocks_movement":True,"blocks_los":True,
                      "uses_channel":False,"linked_by_adjacency":True,
                      "guard_opens":False,"guard_closes":False,"has_open_state":True,
                      "hides_when_closed":False,"thin":False,"is_fence":False,
                      "is_pit":False,"collectible":False,"emits_noise":False,
                      "has_fov":False,"is_entity":False},
            "defaults":{"open":False},
            "noise":{"crash_score":95,"radius_tiles":8,"lifetime_sec":2.5},
            "sound":{"crash":"crash"},
            "visuals":{"style":"crash_door","sprite_key":"crashdoor_sprite",
                       "closed_color":[90,30,10],"open_color":[180,60,20],
                       "border_color":[220,80,40],"x_color":[220,80,40],
                       "x_width":3,"border_width":3,"open_alpha":120,
                       "label_open":"▭","label_closed":"X"}},
        "oiled_door": {
            "flags": {"openable":True,"bashable":True,"crashable":False,
                      "silent":True,"blocks_movement":True,"blocks_los":True,
                      "uses_channel":False,"linked_by_adjacency":True,
                      "guard_opens":True,"guard_closes":True,"has_open_state":True,
                      "hides_when_closed":False,"thin":False,"is_fence":False,
                      "is_pit":False,"collectible":False,"emits_noise":False,
                      "has_fov":False,"is_entity":False},
            "defaults":{"open":False},
            "noise":{"open_once_score":0,"open_twice_score":0,"bash_score":0,
                     "radius_tiles":0,"lifetime_sec":0.0},
            "sound":{"toggle":None,"bash":None},
            "visuals":{"style":"oiled_door","sprite_key":"oiled_door_sprite",
                       "closed_color":[75,50,18],"open_color":[140,100,40],
                       "border_color":[35,52,95],"indicator_color":[80,220,100],
                       "indicator_inner":[160,255,160],"label_color":[150,155,175],
                       "label_open":"▭","label_closed":"▬"}},
        "wall_door": {
            "flags": {"openable":True,"bashable":False,"crashable":False,
                      "silent":False,"blocks_movement":True,"blocks_los":True,
                      "uses_channel":True,"linked_by_adjacency":True,
                      "guard_opens":False,"guard_closes":False,"has_open_state":True,
                      "hides_when_closed":True,"thin":False,"is_fence":False,
                      "is_pit":False,"collectible":False,"emits_noise":False,
                      "has_fov":False,"is_entity":False},
            "defaults":{"open":False,"allow_manual":True,"channel":0},
            "noise":{"open_once_score":18,"radius_tiles":3,"lifetime_sec":0.9},
            "sound":{"toggle":"door"},
            "visuals":{"style":"wall_door","sprite_key":None,
                       "open_color":[90,70,140],"open_border":[120,100,200],
                       "wall_color":[18,26,52],"wall_edge":[35,52,95],
                       "wall_line1":[45,68,115],"wall_line2":[28,44,78],
                       "label_color":[180,150,255],"label_open":"▭"}},
        "thin_door": {
            "flags": {"openable":True,"bashable":False,"crashable":False,
                      "silent":False,"blocks_movement":True,"blocks_los":True,
                      "uses_channel":True,"linked_by_adjacency":True,
                      "guard_opens":False,"guard_closes":False,"has_open_state":True,
                      "hides_when_closed":False,"thin":True,"is_fence":False,
                      "is_pit":False,"collectible":False,"emits_noise":False,
                      "has_fov":False,"is_entity":False},
            "defaults":{"open":False,"shape":"straight","rotation":0,"channel":0,"noise_score":0},
            "noise":{"open_once_score":18,"open_twice_score":45,"radius_tiles":3,
                     "repeat_window_sec":3.0,"lifetime_sec":0.9},
            "sound":{"toggle":"door"},
            "visuals":{"style":"thin_door","sprite_key":None,
                       "closed_color":[200,160,80],"open_color":[120,200,100],
                       "line_width_div":7,"label_open":"▭","label_closed":"▬"}},
    }

    @classmethod
    def load(cls):
        """Load object definitions from integrity/tiles/*.let files.

        Each .let file defines one object type (flags, defaults, noise, sound, visuals).
        Missing or corrupt files fall back to _FALLBACKS for that type individually,
        so a bad file only affects its own type – nothing else crashes.
        If the directory is empty or missing, fallback .let files are written so the
        tile definitions are always available on disk for editing.

        Call once at startup; call reload() to hot-reload during development.
        """
        cls._defs = {}
        loaded = 0

        # Ensure integrity/tiles/ exists and has fallback .let files
        os.makedirs(_LET_DIR, exist_ok=True)
        for type_name, fallback in cls._FALLBACKS.items():
            let_path = os.path.join(_LET_DIR, f"{type_name}.let")
            if not os.path.exists(let_path):
                try:
                    data = {
                        "_comment": f"LockESC Tile Definition (.let) - {type_name}",
                        "_version": 1,
                        "type":     type_name,
                        "label":    type_name.replace("_", " ").title(),
                        "category": "structure",
                    }
                    data.update(fallback)
                    with open(let_path, "w", encoding="utf-8") as f:
                        json.dump(data, f, indent=2, ensure_ascii=False)
                except Exception as e:
                    print(f"[ObjectRegistry] Could not write {let_path}: {e}")

        # ── Helper: load one .let file into cls._defs ───────────────────────
        def _load_let(path, fname):
            nonlocal loaded
            type_name = fname[:-4]
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                entry = {
                    k: data[k]
                    for k in ("flags", "defaults", "noise", "sound", "visuals")
                    if k in data
                }
                # ── Merge builttags defaults into flags ──────────────────────
                # Any flag declared in builttags but absent from this .let gets
                # its default value (always False) so the engine never KeyErrors.
                if _HAS_BUILTTAGS:
                    flags = entry.setdefault("flags", {})
                    for tag_name in _all_tag_names():
                        if tag_name not in flags:
                            tag_info = _BUILTTAGS.get(tag_name, {})
                            flags[tag_name] = bool(tag_info.get("default", False))
                cls._defs[type_name] = entry
                return True
            except Exception as e:
                print(f"[ObjectRegistry] Bad .let file {fname}: {e} – using built-in fallback")
                if type_name in cls._FALLBACKS:
                    cls._defs[type_name] = cls._FALLBACKS[type_name]
                return False

        if os.path.isdir(_LET_DIR):
            # ── Default tiles ────────────────────────────────────────────────
            for fname in sorted(os.listdir(_LET_DIR)):
                if not fname.endswith(".let"):
                    continue
                path = os.path.join(_LET_DIR, fname)
                if _load_let(path, fname):
                    loaded += 1

            # ── Custom tiles (CUSTOM/ overrides default if same type_name) ───
            custom_dir = os.path.join(_LET_DIR, "CUSTOM")
            if os.path.isdir(custom_dir):
                custom_loaded = 0
                for fname in sorted(os.listdir(custom_dir)):
                    if not fname.endswith(".let"):
                        continue
                    path = os.path.join(custom_dir, fname)
                    if _load_let(path, fname):
                        loaded += 1
                        custom_loaded += 1
                if custom_loaded:
                    print(f"[ObjectRegistry] + {custom_loaded} custom tile(s) from CUSTOM/")
        else:
            print(f"[ObjectRegistry] integrity/tiles/ not found – using built-in fallbacks")

        # Fill in any types not covered by .let files from _FALLBACKS
        for type_name, data in cls._FALLBACKS.items():
            if type_name not in cls._defs:
                cls._defs[type_name] = data

        # ── Ensure ALL loaded tiles have full builttag flag coverage ─────────
        if _HAS_BUILTTAGS:
            tag_names = _all_tag_names()
            for tname, entry in cls._defs.items():
                flags = entry.setdefault("flags", {})
                for tag_name in tag_names:
                    if tag_name not in flags:
                        tag_info = _BUILTTAGS.get(tag_name, {})
                        flags[tag_name] = bool(tag_info.get("default", False))

        if loaded:
            print(f"[ObjectRegistry] Loaded {loaded} tile definition(s) total")
            if _HAS_BUILTTAGS:
                print(f"[ObjectRegistry] Merged {len(_all_tag_names())} builttag flags into definitions")

    @classmethod
    def get(cls, type_name: str) -> dict:
        """Return the full definition dict for type_name.
        Falls back to _FALLBACKS, then to a bare minimal stub."""
        if type_name in cls._defs:
            return cls._defs[type_name]
        if type_name in cls._FALLBACKS:
            return cls._FALLBACKS[type_name]
        # Bare stub so unknown types don't crash
        return {"flags": {}, "defaults": {}, "noise": {}, "sound": {}, "visuals": {}}

    @classmethod
    def flags(cls, type_name: str) -> dict:
        return cls.get(type_name).get("flags", {})

    @classmethod
    def flag(cls, type_name: str, flag: str, default=False) -> bool:
        return cls.flags(type_name).get(flag, default)

    @classmethod
    def noise_val(cls, type_name: str, key: str, default=0):
        return cls.get(type_name).get("noise", {}).get(key, default)

    @classmethod
    def visuals(cls, type_name: str) -> dict:
        return cls.get(type_name).get("visuals", {})

    @classmethod
    def vis(cls, type_name: str, key: str, default=None):
        """Fetch a visuals value, converting lists to tuples for pygame."""
        val = cls.visuals(type_name).get(key, default)
        if isinstance(val, list):
            return tuple(val)
        return val

    @classmethod
    def sound_key(cls, type_name: str, action: str) -> str | None:
        return cls.get(type_name).get("sound", {}).get(action)

    @classmethod
    def reload(cls):
        """Re-initialise from hardcoded definitions."""
        cls.load()

    @classmethod
    def export_json(cls, folder="game_files/objects"):
        """Optional: export all hardcoded definitions to JSON files for external editing.
        Not called at runtime. Run manually if you want to tweak objects via JSON:
            python -c "from lockesc import ObjectRegistry; ObjectRegistry.export_json()"
        """
        os.makedirs(folder, exist_ok=True)
        for type_name, data in cls._FALLBACKS.items():
            path = os.path.join(folder, f"{type_name}.json")
            with open(path, "w", encoding="utf-8") as f:
                json.dump({"type": type_name, **data}, f, indent=2, ensure_ascii=False)
            print(f"[ObjectRegistry] Exported {path}")

TILE = 48
FPS  = 60

# ── colours ──────────────────────────────────────────────────────────────────
C_BG          = ( 10,  13,  28)
C_WALL        = ( 18,  26,  52)
C_WALL_EDGE   = ( 35,  52,  95)
C_FLOOR_A     = ( 20,  46,  84)
C_FLOOR_B     = ( 16,  38,  70)
C_DOOR_O      = (140, 100,  40)
C_DOOR_C      = ( 75,  50,  18)
C_OILED_O     = (100, 160,  60)
C_OILED_C     = ( 55,  90,  30)
C_WALLDOOR_O  = ( 90,  70, 140)
C_WALLDOOR_C  = ( 40,  30,  80)
C_CRASHDOOR_O = (180,  60,  20)
C_CRASHDOOR_C = ( 90,  30,  10)
C_WINDOW      = ( 80, 160, 200)
C_FENCE       = ( 90, 120,  70)
C_PIT         = ( 12,  16,  36)
C_CREAK       = ( 55,  80, 130)
C_SNITCH      = (200, 130,  40)
C_CAMERA      = (140, 200,  70)
C_MINI_LOOT   = (200, 165,   0)
C_INPUT       = ( 60, 200, 210)
C_OUTPUT      = (210, 170,  60)
C_NOISEMAKER  = (200, 100, 220)
C_PLAYER      = (220,  55,  75)
C_PLAYER_SPR  = (255, 110,  40)
C_PLAYER_HID  = ( 55,  75, 125)
C_GUARD       = (240, 170,  30)
C_GUARD_AL    = (255, 130,   0)
C_GUARD_CH    = (255,  40,  40)
C_GUARD_INS   = ( 80, 180, 255)
C_GUARD_SRC   = (200,  60, 255)
C_LOOT        = (255, 210,   0)
C_LOOT_G      = (255, 245, 140)
C_MLOOT       = (255,  80,  20)
C_MLOOT_G     = (255, 160,  80)
C_MLOOT_GONE  = ( 80,  30,  10)
C_EXIT        = (  0, 220, 120)
C_EXIT_OFF    = (  0,  80,  50)
C_HIDE        = ( 55,  90, 155)
C_HIDE_ON     = ( 90, 150, 220)
C_WAYPT       = ( 70, 140, 200)
C_WAYPT_PAUSE = (200, 160,  60)
C_NOISE_C     = (255, 170,   0)
C_WHITE       = (255, 255, 255)
C_GRAY        = (150, 155, 175)
C_RED         = (255,  45,  45)
C_GREEN       = (  0, 215, 115)
C_TITLE_BG    = (  6,   8,  20)

# guard states
PATROL  = "patrol"
ALERT   = "alert"
CHASE   = "chase"
INSPECT = "inspect"
SEARCH  = "search"
BRIEF   = "brief"     # physically walking to brief another guard
DEAD    = "dead"      # killed – body left on floor, can be dragged
PANICKED = "panicked" # discovered a body
COMBAT   = "combat"   # witnessed gunshot – cautious frantic sweep, alerts everyone

# Guard callsigns (rule 9) – used in debug/story mode
GUARD_CALLSIGNS = [
    "Alpha", "Bravo", "Charlie", "Delta", "Echo",
    "Foxtrot", "Golf", "Hotel", "India", "Juliet",
    "Kilo", "Lima", "Mike", "November", "Oscar"
]

# Alert urgency levels (used for briefing severity)
URG_SUSPICIOUS = 1   # raised suspicion but no full chase
URG_SPOTTED    = 2   # confirmed player sighting / chase
URG_EMERGENCY  = 3   # lost player after chase – intruder still at large

# noise scores
NOISE_SPRINT     = 55
NOISE_GLOBAL     = 120
NOISE_SPRINT_R   = 160
NOISE_DOOR_ONCE  = 18    # single door open – barely noticeable
NOISE_DOOR_TWICE = 45    # double-open in short window – suspicious
NOISE_CRASH      = 95    # crash-door ram
NOISE_BASH_DOOR  = 70    # sprint-bash a regular door open
NOISE_CREAK_WALK = 35    # creak floor walked on
NOISE_CREAK_SPR  = 60    # creak floor sprinted on
NOISE_PIT_DEATH  = 0     # pit doesn't emit noise (player just dies)

# wall hearing dampening: each wall between source and guard reduces score
WALL_DAMP_PER_WALL = 0.55  # multiplied per wall crossed


# ════════════════════════════════════════════════════════════════════════════
# Geometry helpers
# ════════════════════════════════════════════════════════════════════════════
def tc(col, row, tile=TILE):
    return col * tile + tile // 2, row * tile + tile // 2

def ptile(px, py, tile=TILE):
    return int(px // tile), int(py // tile)

def dist(ax, ay, bx, by):
    return math.hypot(bx - ax, by - ay)

def adiff(a, b):
    d = (a - b) % (2 * math.pi)
    return d - 2 * math.pi if d > math.pi else d

def count_walls_between(walls, windows, ax, ay, bx, by, tile=TILE, steps=24):
    """Count how many wall tiles the ray passes through (windows don't block)."""
    count = 0
    last_tile = None
    for i in range(1, steps + 1):
        t = i / steps
        tx = int((ax + (bx - ax) * t) // tile)
        ty = int((ay + (by - ay) * t) // tile)
        if (tx, ty) != last_tile:
            if (tx, ty) in walls:
                count += 1
            last_tile = (tx, ty)
    return count

def los_check(walls, ax, ay, bx, by, extra_blocked=None, windows=None,
              tile=TILE, steps=32):
    """LOS blocked by walls. Windows are transparent."""
    transparent = windows or set()
    for i in range(1, steps + 1):
        t = i / steps
        tx = int((ax + (bx - ax) * t) // tile)
        ty = int((ay + (by - ay) * t) // tile)
        if (tx, ty) in transparent:
            continue  # windows pass sight through
        if (tx, ty) in walls:
            return False
        if extra_blocked and (tx, ty) in extra_blocked:
            return False
    return True


def los_check_windows_hit(walls, ax, ay, bx, by, extra_blocked=None, windows=None,
                          tile=TILE, steps=32):
    """Like los_check but also returns the set of window tiles the ray passed through.
    Returns (visible: bool, window_tiles_hit: set).
    """
    transparent = windows or set()
    hit_windows: set = set()
    for i in range(1, steps + 1):
        t = i / steps
        tx = int((ax + (bx - ax) * t) // tile)
        ty = int((ay + (by - ay) * t) // tile)
        if (tx, ty) in transparent:
            hit_windows.add((tx, ty))
            continue
        if (tx, ty) in walls:
            return False, hit_windows
        if extra_blocked and (tx, ty) in extra_blocked:
            return False, hit_windows
    return True, hit_windows


# ════════════════════════════════════════════════════════════════════════════
# Sprite / visual cache  (PNG / JPG / BMP / GIF / SVG)
# ════════════════════════════════════════════════════════════════════════════
def _load_svg_surface(path, size):
    """Rasterise an SVG to a pygame Surface. Tries cairosvg first, then Inkscape."""
    w, h = size if size else (48, 48)
    # --- cairosvg (pip install cairosvg) ---
    try:
        import cairosvg, io
        png_bytes = cairosvg.svg2png(url=path, output_width=w, output_height=h)
        return pygame.image.load(io.BytesIO(png_bytes)).convert_alpha()
    except Exception:
        pass
    # --- rsvg-convert / Inkscape CLI fallback ---
    try:
        import subprocess, tempfile, io as _io
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
            tmp_path = tmp.name
        subprocess.run(["rsvg-convert", "-w", str(w), "-h", str(h),
                        "-o", tmp_path, path], check=True,
                       capture_output=True, timeout=5)
        surf = pygame.image.load(tmp_path).convert_alpha()
        os.unlink(tmp_path)
        return surf
    except Exception:
        pass
    return None


class SpriteCache:
    """
    Loads and caches images referenced by the room's visuals config.
    Supports PNG, JPG, BMP, GIF and SVG (via cairosvg or rsvg-convert).
    Falls back to None if the file is missing; callers draw procedurally.

    Cached assets are also written to the project's _assets/ folder when
    the project is exported (see IntegrityEditor.export_assets).

    Visuals fields (all optional):
      background_image   : path to bg image (tiled across floor)
      background_color   : [r,g,b] solid color if no image
      player_sprite      : path to player image/SVG
      guard_sprite       : path to guard image/SVG
      door_sprite        : path to door image/SVG (shown open)
      wall_color         : [r,g,b]
      wall_edge_color    : [r,g,b]
      floor_color_a/b    : [r,g,b]
      loot_color         : [r,g,b]
      guard_fov_color    : [r,g,b,a]  patrol FOV fill
      noise_color        : [r,g,b]
      exit_color         : [r,g,b]
      hide_color         : [r,g,b]
      hud_bg_color       : [r,g,b]
    """
    _cache = {}   # (path, size) -> Surface or None

    @classmethod
    def _resolve(cls, path, base_dir=None):
        """Resolve a potentially-relative asset path to absolute.
        For bundle-based levels, base_dir is the bundle folder itself;
        we check <bundle>/images/ first, then <bundle>/_assets/, then direct."""
        if not path:
            return None
        if os.path.isabs(path) and os.path.exists(path):
            return path
        if base_dir:
            for sub in ("images", "_assets", ""):
                candidate = os.path.normpath(
                    os.path.join(base_dir, sub, path) if sub
                    else os.path.join(base_dir, path))
                if os.path.exists(candidate):
                    return candidate
        return os.path.normpath(os.path.abspath(path))

    @classmethod
    def get(cls, path, size=None, base_dir=None):
        """Load and cache a Surface. base_dir resolves relative asset paths."""
        if not path:
            return None
        abs_path = cls._resolve(path, base_dir)
        if not abs_path:
            return None
        key = (abs_path, size)
        if key not in cls._cache:
            try:
                if abs_path.lower().endswith(".svg"):
                    cls._cache[key] = _load_svg_surface(abs_path, size)
                else:
                    img = pygame.image.load(abs_path).convert_alpha()
                    if size:
                        img = pygame.transform.smoothscale(img, size)
                    cls._cache[key] = img
            except Exception:
                cls._cache[key] = None
        return cls._cache[key]

    @classmethod
    def clear(cls):
        cls._cache.clear()

    @classmethod
    def all_paths(cls):
        """Return all successfully-loaded source paths (for asset export)."""
        return {k[0] for k, v in cls._cache.items() if v is not None}


def _vis_color(visuals, key, default):
    """Pull [r,g,b] or [r,g,b,a] from visuals dict, return tuple or default."""
    v = visuals.get(key)
    if v and len(v) >= 3:
        # Only slice to len(default) when default is a sized sequence (not None)
        n = len(default) if default is not None else len(v)
        return tuple(int(x) for x in v[:n])
    return default


def _vc(vis, key, default):
    """Colour lookup: level visuals dict  >  state_lockesc.lev  >  built-in default.

    State-related keys (guard/player/exit/fov colours) fall through to the
    state_lockesc.lev definitions when the level doesn't override them.
    """
    # 1. Level-specific override
    v = vis.get(key)
    if v and len(v) >= 3:
        n = len(default) if default is not None else len(v)
        return tuple(int(x) for x in v[:n])
    # 2. state_lockesc.lev
    sv = _load_state_vis_defs().get(key)
    if sv:
        return sv
    # 3. Built-in constant
    return default


def draw_text(surf, text, x, y, font, colour, anchor="topleft"):
    s = font.render(text, True, colour)
    r = s.get_rect(**{anchor: (x, y)})
    surf.blit(s, r)


# ════════════════════════════════════════════════════════════════════════════
# A* pathfinder (8-directional)
# ════════════════════════════════════════════════════════════════════════════
DIRS4 = [(-1,0),(1,0),(0,-1),(0,1)]   # cardinal only

def astar(blocked, start, goal, cols, rows):
    if start == goal:
        return []
    if goal in blocked:
        best = None; best_d = 9999
        gx0, gy0 = goal
        for _dc in range(-2, 3):
            for _dr in range(-2, 3):
                cand = (gx0+_dc, gy0+_dr)
                if cand not in blocked and 0<=cand[0]<cols and 0<=cand[1]<rows:
                    _d = abs(_dc)+abs(_dr)
                    if _d < best_d:
                        best = cand; best_d = _d
        if best is None: return []
        goal = best
    open_set = []
    heapq.heappush(open_set, (0.0, start))
    came  = {}
    g_sc  = defaultdict(lambda: float('inf'))
    g_sc[start] = 0.0
    gx, gy = goal
    while open_set:
        _, cur = heapq.heappop(open_set)
        if cur == goal:
            path = []
            while cur in came:
                path.append(cur); cur = came[cur]
            path.reverse(); return path
        cx, cy = cur
        for dx, dy in DIRS4:  # cardinal only
            nx, ny = cx+dx, cy+dy
            if not (0 <= nx < cols and 0 <= ny < rows): continue
            if (nx, ny) in blocked: continue
            ng = g_sc[cur] + 1.0
            nb = (nx, ny)
            if ng < g_sc[nb]:
                g_sc[nb] = ng; came[nb] = cur
                heapq.heappush(open_set, (ng + math.hypot(nx-gx, ny-gy), nb))
    return []


def astar_longest(blocked, start, goal, cols, rows, max_extra=40):
    """Find a longer-than-shortest path from start to goal by penalising tiles
    that are close to the goal (inverse-heuristic A*).  Used by walkaholic
    guards to wander the longest sensible route to a waypoint.
    Falls back to normal astar if no longer path is found.
    max_extra caps how many extra tiles beyond shortest we'll attempt."""
    short = astar(blocked, start, goal, cols, rows)
    if not short:
        return short
    short_len = len(short)
    limit = short_len + max_extra

    gx, gy = goal
    open_set = []
    heapq.heappush(open_set, (0.0, start))
    came  = {}
    g_sc  = defaultdict(lambda: float('inf'))
    g_sc[start] = 0.0
    best_path = short   # fallback

    while open_set:
        _, cur = heapq.heappop(open_set)
        steps_so_far = g_sc[cur]
        if steps_so_far > limit:
            continue
        if cur == goal:
            path = []
            n = cur
            while n in came:
                path.append(n); n = came[n]
            path.reverse()
            if len(path) > len(best_path):
                best_path = path
            continue   # keep searching for even longer within limit
        cx, cy = cur
        for dx, dy in DIRS4:
            nx, ny = cx + dx, cy + dy
            if not (0 <= nx < cols and 0 <= ny < rows): continue
            if (nx, ny) in blocked: continue
            ng = steps_so_far + 1.0
            nb = (nx, ny)
            # Anti-heuristic: nodes far from goal get lower priority value
            far_bonus = -math.hypot(nx - gx, ny - gy) * 0.5
            priority = ng + far_bonus
            if ng < g_sc[nb]:
                g_sc[nb] = ng; came[nb] = cur
                heapq.heappush(open_set, (priority, nb))
    return best_path


# ════════════════════════════════════════════════════════════════════════════
# FOV ray-clipping against walls
# ════════════════════════════════════════════════════════════════════════════
def cast_fov_polygon(origin_x, origin_y, facing, half_fov, max_r,
                     walls, windows, closed_doors, tile=TILE, rays=32):
    """
    Returns a list of (x,y) points forming the visible polygon.
    Each ray is cast and stopped at the first opaque tile
    (walls, closed doors). Windows let light through.
    """
    opaque = walls | closed_doors
    transparent = windows
    pts = [(origin_x, origin_y)]

    for i in range(rays + 1):
        angle = facing - half_fov + 2 * half_fov * i / rays
        dx = math.cos(angle)
        dy = math.sin(angle)

        hit_r = max_r
        steps = int(max_r / (tile * 0.4)) + 1
        for s in range(1, steps + 1):
            r = max_r * s / steps
            tx = int((origin_x + dx * r) // tile)
            ty = int((origin_y + dy * r) // tile)
            if (tx, ty) in transparent:
                continue
            if (tx, ty) in opaque:
                hit_r = r
                break

        pts.append((origin_x + dx * hit_r, origin_y + dy * hit_r))

    return pts


# ════════════════════════════════════════════════════════════════════════════
# Noise event
# ════════════════════════════════════════════════════════════════════════════
class NoiseEvent:
    FADE_IN_DUR = 0.06   # seconds to reach full alpha (near-instant)

    def __init__(self, x, y, score, radius, lifetime=1.8, ambiguous=False,
                 visual_only=False, is_gunshot=False):
        self.x, self.y   = x, y
        self.score       = score
        self.radius      = radius
        self.life        = lifetime
        self._maxlife    = lifetime
        self._fade_in    = 0.0   # counts up to FADE_IN_DUR
        self.ring_r      = 4.0
        self.ambiguous   = ambiguous  # if True, guards search general area not exact spot
        self.visual_only = visual_only  # if True, skip AI hearing entirely
        self.is_gunshot  = is_gunshot  # if True, guards go COMBAT not ALERT

    def update(self, dt):
        self.life    -= dt
        self._fade_in = min(self.FADE_IN_DUR, self._fade_in + dt)
        self.ring_r   = min(self.radius, self.ring_r + self.radius * 1.8 * dt)

    @property
    def dead(self): return self.life <= 0

    @property
    def alpha(self):
        fade_in  = self._fade_in / self.FADE_IN_DUR if self.FADE_IN_DUR > 0 else 1.0
        fade_out = max(0.0, self.life / self._maxlife)
        return min(fade_in, fade_out)

    # Module-level cache: radius -> Surface (avoid per-frame allocation)
    _ring_surf_cache: dict = {}

    def draw(self, surf, cam_x=0, cam_y=0, ring_col=None):
        a = int(210 * self.alpha)
        if a < 4 or self.ring_r < 2: return
        r   = int(self.ring_r)
        col = ring_col if ring_col else C_NOISE_C
        # Retrieve or build a cached surface for this radius
        s = NoiseEvent._ring_surf_cache.get(r)
        if s is None:
            s = pygame.Surface((r*2+4, r*2+4), pygame.SRCALPHA)
            pygame.draw.circle(s, (*col, 210), (r+2, r+2), r, 2)
            NoiseEvent._ring_surf_cache[r] = s
            if len(NoiseEvent._ring_surf_cache) > 256:
                NoiseEvent._ring_surf_cache.clear()
        tmp = s.copy()
        tmp.set_alpha(a)
        surf.blit(tmp, (int(self.x - cam_x) - r - 2, int(self.y - cam_y) - r - 2))


# ════════════════════════════════════════════════════════════════════════════
# Door
# ════════════════════════════════════════════════════════════════════════════
class Door:
    def __init__(self, col, row, open_=False):
        self.col = col; self.row = row
        self.open = open_; self.original_open = open_
        self.bashed = False
        self._recent_opens = []    # timestamps of opens for double-open detection
        self.def_  = ObjectRegistry.get("door")   # full JSON definition
        self._linked_partner = None               # set by _autolink()

    @property
    def changed(self): return self.open != self.original_open

    def bash_open(self):
        """Sprint-bash: instantly open the door, mark it permanently changed."""
        self.open   = True
        self.bashed = True   # visual indicator; can't be closed again

    def toggle(self, now):
        if self.bashed: return   # bashed doors stay open
        self.open = not self.open
        if self.open:
            self._recent_opens.append(now)
        # clean up old entries
        self._recent_opens = [t for t in self._recent_opens if now - t < 4.0]

    def noise_score(self, now):
        """Return noise score for a toggle at 'now'."""
        recent = [t for t in self._recent_opens if now - t < 3.0]
        if len(recent) >= 2:
            return NOISE_DOOR_TWICE
        return NOISE_DOOR_ONCE

    def tile_pos(self): return (self.col, self.row)


# ════════════════════════════════════════════════════════════════════════════
# CrashDoor – must sprint-ram to open
# ════════════════════════════════════════════════════════════════════════════
class CrashDoor:
    def __init__(self, col, row):
        self.col = col; self.row = row
        self.open = False
        self.def_  = ObjectRegistry.get("crashdoor")
        self._linked_partner = None

    def tile_pos(self): return (self.col, self.row)


# ════════════════════════════════════════════════════════════════════════════
# OiledDoor – completely silent, no noise ever
# ════════════════════════════════════════════════════════════════════════════
class OiledDoor:
    def __init__(self, col, row, open_=False):
        self.col = col; self.row = row
        self.open = open_
        self.def_  = ObjectRegistry.get("oiled_door")
        self._linked_partner = None

    def toggle(self, _now):
        self.open = not self.open

    def tile_pos(self): return (self.col, self.row)


# ════════════════════════════════════════════════════════════════════════════
# WallDoor – looks like wall when closed; triggered by channel or E key
# ════════════════════════════════════════════════════════════════════════════
class WallDoor:
    def __init__(self, col, row, open_=False, allow_manual=True, channel=0):
        self.col = col; self.row = row
        self.open = open_
        self.allow_manual = allow_manual
        self.channel = channel
        self.def_  = ObjectRegistry.get("wall_door")
        self._linked_partner = None

    def toggle(self, _now):
        self.open = not self.open

    def trigger(self):
        """Called by IOSystem when its channel fires."""
        self.open = not self.open

    def tile_pos(self): return (self.col, self.row)


# ════════════════════════════════════════════════════════════════════════════
# ThinDoor – like a thin wall but toggleable; visually rotates open/closed
# Player presses E when adjacent. Makes door noise.  Guards notice open state.
# ════════════════════════════════════════════════════════════════════════════
class ThinDoor:
    """
    A thin-wall-style door. Closed = blocks movement & LOS (added to walls_set
    by the Game on reset). Open = acts like a thin wall gap (removed from walls).
    Renders as a thin line that rotates 90° when open (like a hinged door).

    Props (from .ler object dict):
      shape      : "straight" | "corner" (default "straight")
      rotation   : 0 | 90 | 180 | 270  (base closed rotation)
      open       : bool (initially open)
      noise_score: int (override; default uses NOISE_DOOR_ONCE/TWICE logic)
      channel    : int (IO channel for remote trigger)
    """
    def __init__(self, props, tile=TILE):
        p = props
        self.col    = p["col"]; self.row = p["row"]
        self.shape  = p.get("shape", "straight")
        self.rot    = p.get("rotation", 0)      # degrees, closed orientation
        self.open   = p.get("open", False)
        self.channel = p.get("channel", 0)
        self.noise_score_override = p.get("noise_score", 0)
        self._tile  = tile
        self._open_times: list[float] = []
        self.def_  = ObjectRegistry.get("thin_door")
        self._linked_partner = None

    def toggle(self, now: float):
        self.open = not self.open
        self._open_times.append(now)
        self._open_times = [t for t in self._open_times if now - t < 3.0]

    def noise_score(self):
        if self.noise_score_override:
            return self.noise_score_override
        return NOISE_DOOR_TWICE if len(self._open_times) >= 2 else NOISE_DOOR_ONCE

    def noise_radius(self):
        return TILE * 6

    def trigger(self):
        import time
        self.open = not self.open

    def tile_pos(self): return (self.col, self.row)

    def current_rot(self):
        """Visual rotation: open doors are rotated 90° from closed."""
        return (self.rot + 90) % 360 if self.open else self.rot


# ════════════════════════════════════════════════════════════════════════════
# TimerNode – off-level timer that fires an IO channel on a schedule
# Not placed on a tile; lives in a separate "timers" list in the .ler.
# In the editor it appears in the IO panel (not the canvas).
# ════════════════════════════════════════════════════════════════════════════
class TimerNode:
    """
    Fires a NoiseEvent (or triggers an IO channel) on a configurable interval.

    Props:
      channel  : int  – IO channel to fire
      interval : float – seconds between fires
      delay    : float – initial delay before first fire (default 0)
      one_shot : bool  – fire once then stop (default False)
      active   : bool  – initially active (default True)
    """
    def __init__(self, props, tile=TILE):
        p = props or {}
        self.channel  = p.get("channel", 0)
        self.interval = p.get("interval", 5.0)
        self.delay    = p.get("delay", 0.0)
        self.one_shot = p.get("one_shot", False)
        self.active   = p.get("active", True)
        self._t       = -self.delay   # negative = delay remaining
        self._fired   = False

    def update(self, dt, fire_channel_fn):
        """Call every frame. fire_channel_fn(channel) triggers IO dispatch."""
        if not self.active: return
        if self.one_shot and self._fired: return
        self._t += dt
        if self._t >= self.interval:
            self._t -= self.interval
            self._fired = True
            fire_channel_fn(self.channel)


# ════════════════════════════════════════════════════════════════════════════
# IOInput (transmit_node) – fires a channel when triggered
# IOOutput (receive_node) – receives a channel and acts on a door/noisemaker
# ════════════════════════════════════════════════════════════════════════════
class IOInput:
    def __init__(self, col, row, props=None, tile=TILE):
        p = props or {}
        self.col          = col; self.row = row
        self.channel      = p.get("channel", 1)
        self.trigger_mode = p.get("trigger_mode", "player_step")
        self.interval     = p.get("interval", 5.0)
        self.one_shot     = p.get("one_shot", False)
        self._fired       = False
        self._timer       = 0.0
        self._tile        = tile

    def update(self, player_tile, dt, fire_fn):
        if self._fired and self.one_shot: return
        if self.trigger_mode == "player_step":
            if player_tile == (self.col, self.row):
                if not self._fired:
                    self._fired = True
                    fire_fn(self.channel)
            else:
                if not self.one_shot:
                    self._fired = False
        elif self.trigger_mode == "timed":
            self._timer += dt
            if self._timer >= self.interval:
                self._timer -= self.interval
                fire_fn(self.channel)

    def tile_pos(self): return (self.col, self.row)


class IOOutput:
    def __init__(self, col, row, props=None):
        p = props or {}
        self.col     = col; self.row = row
        self.channel = p.get("channel", 1)
        self.action  = p.get("action", "toggle_door")
        # resolved by Game after level load
        self._doors      = []
        self._wall_doors = []
        self._noisemakers = []

    def bind(self, doors, wall_doors, noisemakers):
        """Called by Game after loading to give this output access to scene objects."""
        self._doors       = doors
        self._wall_doors  = wall_doors
        self._noisemakers = noisemakers

    def trigger(self):
        """Execute the action for this output node."""
        act = self.action
        if act in ("toggle_door", "open_door", "close_door"):
            for wd in self._wall_doors:
                if wd.channel == self.channel:
                    if act == "toggle_door": wd.open = not wd.open
                    elif act == "open_door":  wd.open = True
                    elif act == "close_door": wd.open = False
            for rd in self._doors:
                if rd.col == self.col and rd.row == self.row:
                    if act == "toggle_door": rd.open = not rd.open
                    elif act == "open_door":  rd.open = True
                    elif act == "close_door": rd.open = False
        elif act == "toggle_noisemaker":
            for nm in self._noisemakers:
                if nm.col == self.col and nm.row == self.row:
                    nm.active = not nm.active

    def tile_pos(self): return (self.col, self.row)
# ════════════════════════════════════════════════════════════════════════════
class Pit:
    def __init__(self, col, row):
        self.col = col; self.row = row

    def tile_pos(self): return (self.col, self.row)


# ════════════════════════════════════════════════════════════════════════════
# CreakFloor – emits noise when walked/sprinted on
# ════════════════════════════════════════════════════════════════════════════
class CreakFloor:
    def __init__(self, col, row, props=None):
        self.col = col; self.row = row
        p = props or {}
        self.noise_score        = p.get("noise_score", NOISE_CREAK_WALK)
        self.sprint_noise_score = p.get("sprint_noise_score", NOISE_CREAK_SPR)
        self._cooldown_max = p.get("cooldown", 0.5)
        self._cooldown = 0.0   # seconds until it can creak again
        self.active    = p.get("active", True)

    def update(self, dt):
        if self._cooldown > 0:
            self._cooldown -= dt

    def step(self, sprinting, noise_events, tile=TILE):
        if not self.active or self._cooldown > 0: return
        score = self.sprint_noise_score if sprinting else self.noise_score
        px, py = tc(self.col, self.row, tile)
        noise_events.append(
            NoiseEvent(px, py, score, tile * 4, 1.0, ambiguous=True))
        self._cooldown = self._cooldown_max

    def tile_pos(self): return (self.col, self.row)


# ════════════════════════════════════════════════════════════════════════════
# ItemPile – floor collectible pile; picked up by walking over it
# ════════════════════════════════════════════════════════════════════════════
# Item slot classification
ITEM_SLOTS = {
    "silenced_pistol": "primary",
    "1911":            "primary",
    "shotgun":         "primary",
    "m4a1":            "primary",
    "keycard":         "other",
    # Equipment – wearable (passive effect, one slot)
    "creased_sneakers":    "equip_wear",
    "rubber_soles":        "equip_wear",
    "socks":               "equip_wear",
    "lead_boots":          "equip_wear",
    "static_wrap":         "equip_wear",
    "ghost_threads":       "equip_wear",
    # Equipment – gear (active, uses Q key, one slot per gear slot)
    "invisi_cloak":        "equip_gear",
    "raycast_goggles":     "equip_gear",
    "smoke_pellet":        "equip_gear",
    "emp_pulse":           "equip_gear",
    "adrenaline_shot":     "equip_gear",
    "decoy_beeper":        "equip_gear",
}

# ════════════════════════════════════════════════════════════════════════════
# Equipment Definitions
# Each entry: type ("wear"|"gear"), description, and effect keys read by
# EquipmentState.apply() and Game.update_equipment().
# ════════════════════════════════════════════════════════════════════════════
EQUIPMENT_DEFS = {
    # ── Wearable ─────────────────────────────────────────────────────────────
    "creased_sneakers": {
        "type":  "wear",
        "label": "Creased Sneakers",
        "desc":  "+30% move speed. 5% chance each step emits a loud squeak.",
        "color": (220, 200, 120),
        "effects": {"speed_mult": 1.30, "squeak_chance": 0.05, "squeak_score": 55},
    },
    "rubber_soles": {
        "type":  "wear",
        "label": "Rubber Soles",
        "desc":  "Footsteps emit 60% less noise. No downside.",
        "color": (160, 200, 160),
        "effects": {"walk_noise_mult": 0.40},
    },
    "socks": {
        "type":  "wear",
        "label": "Thick Socks",
        "desc":  "Sprint noise eliminated. After 10s of sprinting, movement becomes slippery.",
        "color": (200, 220, 255),
        "effects": {"sprint_silent": True, "slip_threshold": 10.0},
    },
    "lead_boots": {
        "type":  "wear",
        "label": "Lead Boots",
        "desc":  "-20% speed. Every step sounds like you're stamping concrete (+40% walk noise).",
        "color": (120, 110, 100),
        "effects": {"speed_mult": 0.80, "walk_noise_mult": 1.40},
    },
    "static_wrap": {
        "type":  "wear",
        "label": "Static Wrap",
        "desc":  "Guards within 2 tiles have their comms jammed — no briefing calls.",
        "color": (180, 140, 255),
        "effects": {"jam_brief_radius": 2},
    },
    "ghost_threads": {
        "type":  "wear",
        "label": "Ghost Threads",
        "desc":  "You blend with shadows. Guards need 40% more suspicion to trigger CHASE.",
        "color": (80, 80, 120),
        "effects": {"susp_threshold_mult": 1.40},
    },
    # ── Gear (active) ────────────────────────────────────────────────────────
    "invisi_cloak": {
        "type":  "gear",
        "label": "Burning Invisi-Cloak",
        "desc":  "Q: Activate. Invisible for 15s, then burns out. Burning cloak alerts guards after ~10s by smell.",
        "color": (100, 220, 255),
        "effects": {"cloak_duration": 15.0, "burn_smell_delay": 10.0},
        "charges": 1,
    },
    "raycast_goggles": {
        "type":  "gear",
        "label": "Raycast Goggles",
        "desc":  "Q: Toggle. See into adjacent rooms through walls. Walls dim 60% when active.",
        "color": (80, 200, 160),
        "effects": {"see_through_walls": True},
        "charges": -1,   # -1 = toggleable, unlimited
    },
    "smoke_pellet": {
        "type":  "gear",
        "label": "Smoke Pellet",
        "desc":  "Q: Throw at feet. 6-tile smoke cloud for 8s — breaks guard line-of-sight.",
        "color": (180, 180, 180),
        "effects": {"smoke_radius": 6, "smoke_duration": 8.0},
        "charges": 3,
    },
    "emp_pulse": {
        "type":  "gear",
        "label": "EMP Pulse",
        "desc":  "Q: Emit pulse. All cameras and noisemakers disabled in 8-tile radius for 12s.",
        "color": (120, 220, 255),
        "effects": {"emp_radius": 8, "emp_duration": 12.0},
        "charges": 2,
    },
    "adrenaline_shot": {
        "type":  "gear",
        "label": "Adrenaline Shot",
        "desc":  "Q: Inject. +60% speed for 8s. No sprint noise during boost.",
        "color": (255, 100, 80),
        "effects": {"boost_speed_mult": 1.60, "boost_duration": 8.0},
        "charges": 2,
    },
    "decoy_beeper": {
        "type":  "gear",
        "label": "Decoy Beeper",
        "desc":  "Q: Toss. Emits repeating noise 10 tiles away in facing direction for 6s.",
        "color": (255, 200, 80),
        "effects": {"decoy_score": 70, "decoy_duration": 6.0},
        "charges": 3,
    },
}


# ════════════════════════════════════════════════════════════════════════════
# EquipmentState – tracks what the player has equipped and active gear state
# Lives on Game as self.equipment
# ════════════════════════════════════════════════════════════════════════════
class EquipmentState:
    MAX_GEAR_SLOTS = 3

    def __init__(self):
        self.worn: str | None = None        # current wearable key
        self.gear: list[str|None] = [None, None, None]  # up to 3 gear slots
        self.gear_sel: int = 0              # currently selected gear slot index

        # Runtime state
        self.cloak_active    = False
        self.cloak_timer     = 0.0          # seconds remaining
        self.goggles_on      = False
        self.sprint_timer    = 0.0          # cumulative sprint time (for socks)
        self.slip_active     = False
        self.boost_active    = False
        self.boost_timer     = 0.0
        self.emp_active      = False
        self.emp_timer       = 0.0
        self.smoke_clouds: list[dict] = []  # [{x,y,radius,timer}]
        self.decoys: list[dict] = []        # [{x,y,score,timer}]
        self._squeak_step_timer = 0.0
        self.gear_charges: dict[str, int] = {}  # key -> remaining charges

    def equip_worn(self, key: str | None):
        self.worn = key

    def equip_gear_slot(self, slot: int, key: str | None):
        if 0 <= slot < self.MAX_GEAR_SLOTS:
            self.gear[slot] = key
            if key and key in EQUIPMENT_DEFS:
                ch = EQUIPMENT_DEFS[key].get("charges", 1)
                if ch > 0:
                    self.gear_charges[key] = ch

    def cycle_gear(self):
        """~ key: cycle to next non-empty gear slot."""
        n = self.MAX_GEAR_SLOTS
        for _ in range(n):
            self.gear_sel = (self.gear_sel + 1) % n
            if self.gear[self.gear_sel] is not None:
                break

    def selected_gear_key(self) -> str | None:
        return self.gear[self.gear_sel]

    def worn_effects(self) -> dict:
        if self.worn and self.worn in EQUIPMENT_DEFS:
            return EQUIPMENT_DEFS[self.worn].get("effects", {})
        return {}

    def active_gear_effects(self) -> dict:
        key = self.selected_gear_key()
        if key and key in EQUIPMENT_DEFS:
            return EQUIPMENT_DEFS[key].get("effects", {})
        return {}

    def has_charges(self, key: str) -> bool:
        defn = EQUIPMENT_DEFS.get(key, {})
        ch = defn.get("charges", 1)
        if ch == -1: return True   # toggleable
        return self.gear_charges.get(key, ch) > 0

    def spend_charge(self, key: str):
        defn = EQUIPMENT_DEFS.get(key, {})
        ch = defn.get("charges", 1)
        if ch == -1: return
        if key not in self.gear_charges:
            self.gear_charges[key] = ch
        self.gear_charges[key] = max(0, self.gear_charges[key] - 1)

    def use_gear(self, player, noise_events, tile) -> bool:
        """Q key: activate selected gear. Returns True if something happened."""
        key = self.selected_gear_key()
        if not key or not self.has_charges(key): return False
        defn = EQUIPMENT_DEFS.get(key, {})
        eff  = defn.get("effects", {})

        if key == "invisi_cloak":
            if not self.cloak_active:
                self.cloak_active = True
                self.cloak_timer  = eff.get("cloak_duration", 15.0)
                self.spend_charge(key)
                return True

        elif key == "raycast_goggles":
            self.goggles_on = not self.goggles_on
            return True

        elif key == "smoke_pellet":
            r = eff.get("smoke_radius", 6) * tile
            self.smoke_clouds.append({"x": player.x, "y": player.y,
                                      "radius": r, "timer": eff.get("smoke_duration", 8.0)})
            self.spend_charge(key)
            return True

        elif key == "emp_pulse":
            if not self.emp_active:
                self.emp_active = True
                self.emp_timer  = eff.get("emp_duration", 12.0)
                self.emp_radius = eff.get("emp_radius", 8) * tile
                self.emp_origin = (player.x, player.y)
                self.spend_charge(key)
                return True

        elif key == "adrenaline_shot":
            if not self.boost_active:
                self.boost_active = True
                self.boost_timer  = eff.get("boost_duration", 8.0)
                self.spend_charge(key)
                return True

        elif key == "decoy_beeper":
            r_tiles = 10
            dx = math.cos(player.facing) * r_tiles * tile
            dy = math.sin(player.facing) * r_tiles * tile
            self.decoys.append({"x": player.x + dx, "y": player.y + dy,
                                 "score": eff.get("decoy_score", 70),
                                 "timer": eff.get("decoy_duration", 6.0),
                                 "interval": 1.2, "_next": 0.0})
            self.spend_charge(key)
            return True

        return False

    def update(self, dt, player, noise_events, tile) -> list[dict]:
        """Tick all active gear states. Returns list of floor hazards to spawn."""
        floor_hazards = []
        wx = self.worn_effects()

        # Sprint slip tracking (Socks)
        if wx.get("sprint_silent") and player.sprinting:
            self.sprint_timer += dt
            if self.sprint_timer >= wx.get("slip_threshold", 10.0):
                self.slip_active = True
        else:
            self.sprint_timer = max(0.0, self.sprint_timer - dt * 2)
            if self.sprint_timer <= 0:
                self.slip_active = False

        # Cloak countdown
        if self.cloak_active:
            self.cloak_timer -= dt
            if self.cloak_timer <= 0:
                self.cloak_active = False
                # Spawn burning cloak hazard at player position
                floor_hazards.append({
                    "type": "burning_cloak",
                    "x": player.x, "y": player.y,
                    "smell_timer": 10.0,   # guards detect smell after this
                    "life": 25.0,          # cloak burns for 25s total
                })

        # Boost countdown
        if self.boost_active:
            self.boost_timer -= dt
            if self.boost_timer <= 0:
                self.boost_active = False

        # EMP countdown
        if self.emp_active:
            self.emp_timer -= dt
            if self.emp_timer <= 0:
                self.emp_active = False

        # Smoke clouds
        for c in self.smoke_clouds:
            c["timer"] -= dt
        self.smoke_clouds = [c for c in self.smoke_clouds if c["timer"] > 0]

        # Decoys
        for d in self.decoys:
            d["timer"] -= dt
            d["_next"] -= dt
            if d["_next"] <= 0:
                d["_next"] = d.get("interval", 1.2)
                noise_events.append(
                    NoiseEvent(d["x"], d["y"], d["score"], tile * 6, 2.0, ambiguous=False))
        self.decoys = [d for d in self.decoys if d["timer"] > 0]

        return floor_hazards

    def speed_multiplier(self, sprinting: bool) -> float:
        wx  = self.worn_effects()
        mul = wx.get("speed_mult", 1.0)
        if self.boost_active:
            mul *= EQUIPMENT_DEFS["adrenaline_shot"]["effects"]["boost_speed_mult"]
        if self.slip_active and sprinting:
            mul *= 1.15   # slippery = slight overshoot
        return mul

    def walk_noise_multiplier(self) -> float:
        wx = self.worn_effects()
        if wx.get("sprint_silent") and self.boost_active:
            return 0.0
        return wx.get("walk_noise_mult", 1.0)

    def sprint_noise_suppressed(self) -> bool:
        wx = self.worn_effects()
        if wx.get("sprint_silent"): return True
        if self.boost_active and self.worn == "adrenaline_shot": return True
        return False

    def is_invisible(self) -> bool:
        return self.cloak_active

    def in_smoke(self, px, py) -> bool:
        for c in self.smoke_clouds:
            if dist(px, py, c["x"], c["y"]) <= c["radius"]:
                return True
        return False

    def goggles_active(self) -> bool:
        return self.goggles_on and self.selected_gear_key() == "raycast_goggles"


# ════════════════════════════════════════════════════════════════════════════
# BurningCloak – floor hazard left behind when invisi-cloak burns out
# ════════════════════════════════════════════════════════════════════════════
class BurningCloak:
    def __init__(self, x, y, tile=TILE):
        self.x = x; self.y = y
        self._tile = tile
        self.smell_timer = 10.0    # time before guards detect smell
        self.smell_emitted = False
        self.life = 25.0
        self.dead = False

    def update(self, dt, noise_events, guards, walls):
        self.life -= dt
        if self.life <= 0:
            self.dead = True
            return

        if not self.smell_emitted:
            self.smell_timer -= dt
            if self.smell_timer <= 0:
                self.smell_emitted = True
                # Emit a high-score noise that guards will investigate
                noise_events.append(
                    NoiseEvent(self.x, self.y, score=85,
                               radius=self._tile * 8, lifetime=4.0,
                               ambiguous=False))

        # Guards that reach the cloak can "put it out" (reduces remaining life)
        for g in guards:
            if g.state == PATROL and dist(g.x, g.y, self.x, self.y) < self._tile * 0.8:
                self.life = min(self.life, 2.0)   # almost out


# ════════════════════════════════════════════════════════════════════════════
# EquipScreen – pre/post level loadout screen
# ════════════════════════════════════════════════════════════════════════════
class EquipScreen:
    """
    Full-screen loadout screen shown before and after each level.
    Player can:
      - Configure worn equipment (one slot)
      - Configure up to 3 gear slots
      - Continue to next level
    Navigation: arrow keys, TAB to switch panels, ENTER/Z to confirm, ESC/X to proceed.
    """
    _BG    = (10, 12, 18)
    _PANEL = (18, 22, 32, 230)
    _BORD  = (60, 90, 160)
    _SEL   = (40, 70, 140)
    _FG    = (180, 200, 240)
    _DIM   = (70, 80, 100)
    _GOLD  = (200, 170, 80)
    _GREEN = (80, 200, 100)
    _RED   = (200, 80, 80)

    def __init__(self, screen, clock, equipment: EquipmentState,
                 inventory: "Inventory", gold: int, post_level: bool = False,
                 score: int = 0, has_next: bool = False):
        self.screen     = screen
        self.clock      = clock
        self.eq         = equipment
        self.inv        = inventory
        self.gold       = gold
        self.post_level = post_level
        self.score      = score
        self.has_next   = has_next

        W, H = screen.get_size()
        self.W = W; self.H = H

        self.font_xl = pygame.font.SysFont("consolas", 36, bold=True)
        self.font_lg = pygame.font.SysFont("consolas", 22, bold=True)
        self.font_md = pygame.font.SysFont("consolas", 16, bold=True)
        self.font_sm = pygame.font.SysFont("consolas", 13)

        # All equipment the player owns (in inventory equip_wear / equip_gear slots)
        self._owned_wear = self._collect_owned("equip_wear")
        self._owned_gear = self._collect_owned("equip_gear")

        # Panel focus: 0=worn, 1=gear, 2=action
        self._focus   = 0
        self._sel_wear = 0        # index into _owned_wear
        self._sel_gear_slot = 0   # which gear slot (0-2)
        self._sel_gear_item = 0   # index into _owned_gear for current slot
        self._action  = 0         # 0=configure, 1=continue, 2=skip

        self.result   = None      # "continue" or "skip"

    def _collect_owned(self, slot_type) -> list[str]:
        items = []
        # Check inventory other slots
        for item in self.inv.other:
            if item and ITEM_SLOTS.get(item) == slot_type:
                items.append(item)
        return items

    def run(self) -> str:
        """Run the screen loop. Returns 'continue' or 'skip'."""
        while self.result is None:
            dt = self.clock.tick(60) / 1000.0
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    pygame.quit(); sys.exit()
                if ev.type == pygame.KEYDOWN:
                    self._handle_key(ev.key)
            self._draw()
            pygame.display.flip()
        return self.result

    def _handle_key(self, key):
        import pygame as pg
        if key in (pg.K_TAB,):
            self._focus = (self._focus + 1) % 3
            return

        if self._focus == 0:   # worn panel
            if key in (pg.K_UP,):
                self._sel_wear = max(0, self._sel_wear - 1)
            elif key in (pg.K_DOWN,):
                self._sel_wear = min(len(self._owned_wear), self._sel_wear + 1)
            elif key in (pg.K_RETURN, pg.K_z):
                if self._sel_wear == 0:
                    self.eq.equip_worn(None)
                elif self._sel_wear <= len(self._owned_wear):
                    self.eq.equip_worn(self._owned_wear[self._sel_wear - 1])

        elif self._focus == 1:  # gear panel
            if key in (pg.K_LEFT,):
                self._sel_gear_slot = max(0, self._sel_gear_slot - 1)
            elif key in (pg.K_RIGHT,):
                self._sel_gear_slot = min(2, self._sel_gear_slot + 1)
            elif key in (pg.K_UP,):
                self._sel_gear_item = max(0, self._sel_gear_item - 1)
            elif key in (pg.K_DOWN,):
                self._sel_gear_item = min(len(self._owned_gear), self._sel_gear_item + 1)
            elif key in (pg.K_RETURN, pg.K_z):
                slot = self._sel_gear_slot
                if self._sel_gear_item == 0:
                    self.eq.equip_gear_slot(slot, None)
                elif self._sel_gear_item <= len(self._owned_gear):
                    self.eq.equip_gear_slot(slot, self._owned_gear[self._sel_gear_item - 1])

        elif self._focus == 2:  # action panel
            if key in (pg.K_LEFT, pg.K_UP):
                self._action = max(0, self._action - 1)
            elif key in (pg.K_RIGHT, pg.K_DOWN):
                self._action = min(1, self._action + 1)
            elif key in (pg.K_RETURN, pg.K_z, pg.K_SPACE):
                self.result = "continue" if self._action == 0 else "skip"

        if key in (pg.K_ESCAPE, pg.K_x):
            self.result = "continue"

    def _draw(self):
        scr = self.screen
        W, H = self.W, self.H

        # ── Animated background ───────────────────────────────────────────────
        scr.fill(self._BG)
        t = pygame.time.get_ticks() / 1000.0
        # Subtle scanlines
        sl = pygame.Surface((W, H), pygame.SRCALPHA)
        for sy in range(0, H, 3):
            pygame.draw.line(sl, (0,0,0,25), (0,sy), (W,sy))
        scr.blit(sl, (0,0))
        # Corner accent glows
        for corner, cr in [((0,0),(120,60,0)), ((W,0),(0,60,120)),
                            ((0,H),(0,40,100)), ((W,H),(80,0,120))]:
            gs = pygame.Surface((300,300), pygame.SRCALPHA)
            pygame.draw.circle(gs, (*cr, 18), (150,150), 150)
            scr.blit(gs, (corner[0]-150, corner[1]-150))

        # ── Header ────────────────────────────────────────────────────────────
        pygame.draw.rect(scr, (16, 20, 30), (0, 0, W, 80))
        pygame.draw.line(scr, (60, 100, 180), (0, 80), (W, 80), 1)

        if self.post_level:
            title_str = f"LEVEL COMPLETE"
            scr.blit(self.font_xl.render(title_str, True, (100, 220, 120)),
                     self.font_xl.render(title_str, True, (0,0,0)).get_rect(midtop=(W//2, 10)))
            score_s = self.font_lg.render(f"SCORE  {self.score}", True, (200, 170, 80))
            scr.blit(score_s, score_s.get_rect(midtop=(W//2, 46)))
        else:
            title_s = self.font_xl.render("LOADOUT", True, (140, 200, 255))
            scr.blit(title_s, title_s.get_rect(midtop=(W//2, 14)))
            sub_s = self.font_sm.render("Configure gear before heading in",
                                        True, (80, 110, 160))
            scr.blit(sub_s, sub_s.get_rect(midtop=(W//2, 56)))

        # ── Layout geometry ───────────────────────────────────────────────────
        PAD    = 18
        TOP    = 92
        BTN_H  = 50
        DESC_H = 52
        BOTTOM = H - BTN_H - DESC_H - PAD*2
        mid    = W // 2

        # ── WORN panel (left half) ────────────────────────────────────────────
        wx0, wy0, ww, wh = PAD, TOP, mid - PAD*2, BOTTOM - TOP
        focus_w = (self._focus == 0)
        self._draw_panel(scr, "① WORN  [TAB→]", wx0, wy0, ww, wh, focus_w)

        items_w  = [None] + self._owned_wear
        labels_w = ["  (none)"] + [EQUIPMENT_DEFS.get(k,{}).get("label",k) for k in self._owned_wear]
        self._draw_item_list(scr, items_w, labels_w, self.eq.worn,
                             self._sel_wear if focus_w else -1,
                             wx0+8, wy0+36, ww-16, wh-40, True)

        # ── GEAR panel (right half) ───────────────────────────────────────────
        gx0, gy0, gw, gh = mid + PAD, TOP, mid - PAD*2, BOTTOM - TOP
        focus_g = (self._focus == 1)
        self._draw_panel(scr, "② GEAR  [TAB→]", gx0, gy0, gw, gh, focus_g)

        # 3 slot tabs
        sw = (gw - 12) // 3
        for si in range(3):
            sx_ = gx0 + 6 + si*sw
            sy_ = gy0 + 32
            is_active_slot = (si == self._sel_gear_slot)
            key = self.eq.gear[si]
            tab_bg = (50, 80, 140) if (focus_g and is_active_slot) else \
                     (30, 45, 70) if is_active_slot else (20, 26, 40)
            pygame.draw.rect(scr, tab_bg, (sx_, sy_, sw-3, 42), border_radius=5)
            bord_c = (120, 180, 255) if (focus_g and is_active_slot) else \
                     (60, 90, 140) if is_active_slot else (35, 45, 65)
            pygame.draw.rect(scr, bord_c, (sx_, sy_, sw-3, 42), 1, border_radius=5)
            num_s = self.font_sm.render(f"[{si+1}]", True,
                                         (180, 220, 255) if is_active_slot else (60, 80, 110))
            scr.blit(num_s, (sx_+5, sy_+4))
            if key:
                defn  = EQUIPMENT_DEFS.get(key, {})
                dot_c = defn.get("color", (160, 180, 200))
                pygame.draw.circle(scr, dot_c, (sx_+11, sy_+28), 4)
                kl = defn.get("label", key)[:10]
                ks = self.font_sm.render(kl, True, dot_c if is_active_slot else (100,120,150))
                scr.blit(ks, (sx_+18, sy_+21))
                ch = self.eq.gear_charges.get(key, EQUIPMENT_DEFS.get(key,{}).get("charges",1))
                ch_str = "∞" if ch == -1 else f"×{ch}"
                chs = self.font_sm.render(ch_str, True, (200,170,80))
                scr.blit(chs, chs.get_rect(topright=(sx_+sw-6, sy_+4)))
            else:
                es = self.font_sm.render("empty", True, (35, 45, 60))
                scr.blit(es, es.get_rect(center=(sx_+sw//2-2, sy_+28)))

        # Gear item list (for active slot)
        items_g  = [None] + self._owned_gear
        labels_g = ["  (none)"] + [EQUIPMENT_DEFS.get(k,{}).get("label",k) for k in self._owned_gear]
        self._draw_item_list(scr, items_g, labels_g, self.eq.gear[self._sel_gear_slot],
                             self._sel_gear_item if focus_g else -1,
                             gx0+8, gy0+82, gw-16, gh-88, False)

        # ── Description strip ─────────────────────────────────────────────────
        desc_y = BOTTOM + PAD
        pygame.draw.rect(scr, (14, 18, 28), (PAD, desc_y, W - PAD*2, DESC_H), border_radius=6)
        pygame.draw.rect(scr, (40, 60, 100), (PAD, desc_y, W - PAD*2, DESC_H), 1, border_radius=6)

        sel_key = None
        if focus_w and self._sel_wear > 0 and self._sel_wear <= len(self._owned_wear):
            sel_key = self._owned_wear[self._sel_wear - 1]
        elif focus_g and self._sel_gear_item > 0 and self._sel_gear_item <= len(self._owned_gear):
            sel_key = self._owned_gear[self._sel_gear_item - 1]

        if sel_key and sel_key in EQUIPMENT_DEFS:
            defn   = EQUIPMENT_DEFS[sel_key]
            dot_c  = defn.get("color", (180, 200, 220))
            pygame.draw.circle(scr, dot_c, (PAD+14, desc_y+16), 6)
            hdr = self.font_md.render(defn.get("label",""), True, dot_c)
            scr.blit(hdr, (PAD+26, desc_y+6))
            typ = "WEARABLE" if EQUIPMENT_DEFS[sel_key].get("type") == "wear" else "GEAR  (Q to use)"
            typ_c = (100,200,160) if typ == "WEARABLE" else (180,130,255)
            ts = self.font_sm.render(typ, True, typ_c)
            scr.blit(ts, (W - PAD - ts.get_width() - 4, desc_y+8))
            desc_s = self.font_sm.render(defn.get("desc","")[:90], True, (140, 170, 210))
            scr.blit(desc_s, (PAD+14, desc_y+30))
        else:
            ph = self.font_sm.render("Select an item to see its description", True, (50,65,90))
            scr.blit(ph, ph.get_rect(center=(W//2, desc_y + DESC_H//2)))

        # ── Action buttons ────────────────────────────────────────────────────
        by0 = H - BTN_H - PAD + 4
        btns = [("▶  CONTINUE →", (45, 120, 55), (80, 200, 100)),
                ("  SKIP", (60, 45, 45), (140, 90, 90))]
        bw = 220; gap = 20
        tot = len(btns)*bw + (len(btns)-1)*gap
        bx0 = W//2 - tot//2
        for i, (lbl, bg, hov) in enumerate(btns):
            bx_ = bx0 + i*(bw+gap)
            is_act = (self._focus == 2 and self._action == i)
            col = tuple(min(255, c+20) for c in hov) if is_act else bg
            pygame.draw.rect(scr, col, (bx_, by0, bw, BTN_H-4), border_radius=8)
            bord = (120,200,140) if i==0 and is_act else \
                   (200,100,100) if i==1 and is_act else (50,70,90)
            pygame.draw.rect(scr, bord, (bx_, by0, bw, BTN_H-4), 2, border_radius=8)
            ls = self.font_md.render(lbl, True, (230,250,230) if is_act else (160,180,160))
            scr.blit(ls, ls.get_rect(center=(bx_+bw//2, by0+(BTN_H-4)//2)))

        # ── Nav hint ──────────────────────────────────────────────────────────
        hint = self.font_sm.render(
            "TAB  switch panel   ·   ↑↓ / ←→  navigate   ·   Z / Enter  equip   ·   ESC  proceed",
            True, (45, 60, 85))
        scr.blit(hint, hint.get_rect(midbottom=(W//2, H - 4)))

    def _draw_panel(self, scr, title, x, y, w, h, focused):
        # Background
        panel = pygame.Surface((w, h), pygame.SRCALPHA)
        panel.fill((16, 21, 32, 210))
        scr.blit(panel, (x, y))
        # Border — brighter when focused
        bord = (90, 140, 240) if focused else (40, 55, 80)
        pygame.draw.rect(scr, bord, (x, y, w, h), 2, border_radius=7)
        # Top accent bar
        accent = (50, 90, 180) if focused else (28, 38, 58)
        pygame.draw.rect(scr, accent, (x+1, y+1, w-2, 28), border_radius=7)
        # Title
        tc = (180, 215, 255) if focused else (80, 100, 140)
        t = self.font_md.render(title, True, tc)
        scr.blit(t, (x+10, y+6))

    def _draw_item_list(self, scr, items, labels, equipped, sel_idx,
                        x, y, w, h, show_type):
        row_h = 32
        for i, (key, lbl) in enumerate(zip(items, labels)):
            iy = y + i * row_h
            if iy + row_h > y + h: break
            is_sel = (i == sel_idx)
            is_eq  = (key == equipped) if key is not None else (equipped is None)

            # Row background
            if is_sel:
                pygame.draw.rect(scr, (45, 75, 145), (x, iy, w, row_h-1), border_radius=4)
                pygame.draw.rect(scr, (100, 160, 255), (x, iy, w, row_h-1), 1, border_radius=4)
            elif i % 2 == 0:
                pygame.draw.rect(scr, (16, 21, 30), (x, iy, w, row_h-1), border_radius=3)

            # Equipped dot
            dot_col = (80, 210, 100) if is_eq else (28, 38, 52)
            pygame.draw.circle(scr, dot_col, (x+9, iy+row_h//2), 4)
            if is_eq:
                pygame.draw.circle(scr, (120, 255, 140), (x+9, iy+row_h//2), 4, 1)

            # Label
            defn = EQUIPMENT_DEFS.get(key, {}) if key else {}
            if is_sel:
                txt_c = (255, 255, 255)
            elif key:
                txt_c = defn.get("color", (180, 200, 240))
            else:
                txt_c = (45, 58, 75)
            ls = self.font_sm.render(lbl, True, txt_c)
            scr.blit(ls, (x+20, iy + (row_h - ls.get_height())//2))

            # Type badge
            if show_type and key:
                typ = defn.get("type", "")
                if typ == "wear":
                    tb_col = (30, 80, 60); tf_col = (100, 210, 160)
                    tag = "WEAR"
                else:
                    tb_col = (60, 35, 90); tf_col = (190, 130, 255)
                    tag = "GEAR"
                tw = 42; th = 16
                tx_ = x + w - tw - 4
                ty_ = iy + (row_h - th)//2
                pygame.draw.rect(scr, tb_col, (tx_, ty_, tw, th), border_radius=3)
                pygame.draw.rect(scr, tf_col, (tx_, ty_, tw, th), 1, border_radius=3)
                tag_s = self.font_sm.render(tag, True, tf_col)
                scr.blit(tag_s, tag_s.get_rect(center=(tx_+tw//2, ty_+th//2)))


# ════════════════════════════════════════════════════════════════════════════
# ItemPile – floor collectible pile; picked up by walking over it
# ════════════════════════════════════════════════════════════════════════════
class ItemPile:
    def __init__(self, col, row, props=None):
        self.col = col; self.row = row
        p = props or {}
        # contents: dict of item_key -> count
        self.contents = dict(p.get("contents", {}))
        self.picked_up = False

    def tile_pos(self): return (self.col, self.row)

    def try_pickup(self, inventory):
        """Try to add all items from this pile into inventory. Returns True if anything taken."""
        if self.picked_up or not self.contents:
            return False
        took_any = False
        for item_key, count in list(self.contents.items()):
            slot = ITEM_SLOTS.get(item_key, "other")
            for _ in range(count):
                if inventory.add(item_key, slot):
                    took_any = True
        if took_any:
            self.picked_up = True
        return took_any


# ════════════════════════════════════════════════════════════════════════════
# Inventory – primary (1 slot), secondary (1 slot), other (4 slots)
# ════════════════════════════════════════════════════════════════════════════

# BuyItem – shop tile; opens keyboard-driven purchase menu when stepped on
# ════════════════════════════════════════════════════════════════════════════

class BuyItem:
    """
    A shop tile.  When the player steps on it a keyboard-navigable ShopMenu
    appears listing all items in `contents` with their prices.
    The player can buy any item that they can afford (gold ≥ price).

    JSON props
    ----------
    contents : dict[str, {"price": int, "stock": int}]
        e.g. {"silenced_pistol": {"price": 150, "stock": 1}, ...}
    """

    def __init__(self, col, row, props=None):
        self.col  = col
        self.row  = row
        p = props or {}
        raw = p.get("contents", {})
        # Normalise – allow old-style int values (treated as price, stock 99)
        self.contents: dict[str, dict] = {}
        for key, val in raw.items():
            if isinstance(val, dict):
                self.contents[key] = {"price": int(val.get("price", 0)),
                                       "stock": int(val.get("stock", 99))}
            else:
                self.contents[key] = {"price": int(val), "stock": 99}
        self.active = p.get("active", True)

    def tile_pos(self): return (self.col, self.row)


class ShopMenu:
    """
    Keyboard-only in-game shop overlay.

    Controls
    --------
    UP / DOWN  – navigate items
    ENTER / Z  – buy selected item
    ESCAPE / X – close menu

    Integrated into the Game render/event loop via Game._shop_menu.
    """

    ITEMS_VISIBLE = 6   # rows shown at once

    _STYLE = {
        "bg":       (14,  16,  22, 220),
        "border":   (80, 120, 200),
        "title":    (200, 220, 255),
        "item_fg":  (180, 200, 240),
        "price_fg": (200, 170,  80),
        "sel_bg":   (30,  60, 110),
        "disabled": (70,  80, 100),
        "bought":   (60, 160,  80),
    }

    def __init__(self, buy_item: BuyItem, player_gold: int):
        self.source    = buy_item
        # Build display list from contents
        self.entries   = [
            {"key": k, **v, "purchased": False}
            for k, v in buy_item.contents.items()
            if v.get("stock", 99) > 0
        ]
        self.sel       = 0
        self.scroll    = 0
        self.player_gold = player_gold
        self.closed    = False
        self.purchased_keys: list[str] = []   # items successfully bought this session

    # ── Input ──────────────────────────────────────────────────────────────

    def handle_key(self, key, inventory: "Inventory") -> bool:
        """
        Returns True if the menu consumed the key.
        Sets self.closed = True when the player exits.
        """
        import pygame
        if key in (pygame.K_UP,):
            self.sel = max(0, self.sel - 1)
            self._fix_scroll()
            return True
        if key in (pygame.K_DOWN,):
            self.sel = min(len(self.entries) - 1, self.sel + 1)
            self._fix_scroll()
            return True
        if key in (pygame.K_RETURN, pygame.K_z):
            self._buy(inventory)
            return True
        if key in (pygame.K_ESCAPE, pygame.K_x):
            self.closed = True
            return True
        return False

    def _buy(self, inventory: "Inventory"):
        if not self.entries: return
        entry = self.entries[self.sel]
        if entry["purchased"]:
            return
        if entry["stock"] <= 0:
            return
        if self.player_gold < entry["price"]:
            return   # can't afford
        slot = ITEM_SLOTS.get(entry["key"], "other")
        if inventory.add(entry["key"], slot):
            self.player_gold -= entry["price"]
            entry["stock"]   -= 1
            entry["purchased"] = True
            self.purchased_keys.append(entry["key"])
            # Reflect stock back onto the source BuyItem
            if entry["key"] in self.source.contents:
                self.source.contents[entry["key"]]["stock"] -= 1

    def _fix_scroll(self):
        vis = self.ITEMS_VISIBLE
        if self.sel < self.scroll:
            self.scroll = self.sel
        elif self.sel >= self.scroll + vis:
            self.scroll = self.sel - vis + 1

    # ── Render ─────────────────────────────────────────────────────────────

    def draw(self, surf, view_w, view_h, font):
        """Draw the shop overlay centred on the screen."""
        S = self._STYLE
        # Calculate height based on items, with minimum for description row
        item_h   = 42
        W = 620
        H = min(460, 110 + len(self.entries) * item_h + 60)
        x = (view_w - W) // 2
        y = (view_h - H) // 2

        # Background panel
        panel = pygame.Surface((W, H), pygame.SRCALPHA)
        panel.fill(S["bg"])
        surf.blit(panel, (x, y))
        pygame.draw.rect(surf, S["border"], (x, y, W, H), 2, border_radius=8)

        # Title bar
        pygame.draw.rect(surf, (20, 30, 50), (x, y, W, 36), border_radius=8)
        title = font.render("  SHOP  –  ↑↓ navigate  ·  Z buy  ·  X close", True, S["title"])
        surf.blit(title, (x + 10, y + 8))

        # Loot Tradeable display
        gold_txt = font.render(f"Loot Tradeable: {self.player_gold}", True, S["price_fg"])
        surf.blit(gold_txt, (x + W - gold_txt.get_width() - 12, y + 8))
        pygame.draw.line(surf, S["border"], (x+6, y+36), (x+W-6, y+36), 1)

        # Items
        row_y0 = y + 44
        vis    = self.ITEMS_VISIBLE
        font_xs = pygame.font.SysFont("consolas", 11)
        for i, entry in enumerate(self.entries[self.scroll:self.scroll+vis]):
            abs_i  = i + self.scroll
            iy     = row_y0 + i * item_h
            is_sel = (abs_i == self.sel)

            if is_sel:
                pygame.draw.rect(surf, S["sel_bg"], (x+4, iy, W-8, item_h-2), border_radius=4)
                pygame.draw.rect(surf, S["border"], (x+4, iy, W-8, item_h-2), 1, border_radius=4)

            can_afford = self.player_gold >= entry["price"]
            bought     = entry["purchased"] or entry["stock"] <= 0
            label_col  = S["bought"] if bought else (S["item_fg"] if can_afford else S["disabled"])
            price_col  = S["bought"] if bought else (S["price_fg"] if can_afford else S["disabled"])

            key   = entry["key"]
            defn  = EQUIPMENT_DEFS.get(key, {})
            label = defn.get("label", key.replace("_", " ").title())
            if bought: label += "  ✓"

            # Type tag for equipment
            item_type = ITEM_SLOTS.get(key, "")
            if item_type == "equip_wear":
                tag = "WEAR"; tag_col = (120, 210, 160)
            elif item_type == "equip_gear":
                tag = "GEAR"; tag_col = (180, 140, 255)
            else:
                tag = ""; tag_col = S["disabled"]

            # Colour dot from EQUIPMENT_DEFS
            dot_col = defn.get("color", (100, 120, 160)) if defn else (100, 120, 160)
            pygame.draw.circle(surf, dot_col, (x+14, iy+13), 5)

            lbl_surf = font.render(label, True, label_col)
            surf.blit(lbl_surf, (x + 24, iy + 4))

            # Description always visible (wider panel makes this readable)
            if defn.get("desc"):
                desc_col = (130, 160, 195) if is_sel else (65, 80, 105)
                desc_s = font_xs.render(defn["desc"][:90], True, desc_col)
                surf.blit(desc_s, (x + 24, iy + 22))

            if tag:
                ts = font.render(tag, True, tag_col)
                surf.blit(ts, ts.get_rect(midright=(x + W - 140, iy + 13)))

            price_str  = f"{entry['price']}T  ×{entry['stock']}"
            price_surf = font.render(price_str, True, price_col)
            surf.blit(price_surf, (x + W - price_surf.get_width() - 14, iy + 4))

        # Scroll hint
        total = len(self.entries)
        if total > vis:
            hint = font.render(f"  {self.scroll+1}–{min(self.scroll+vis,total)} / {total}",
                               True, S["disabled"])
            surf.blit(hint, (x + W//2 - hint.get_width()//2, y + H - 22))
        for i, entry in enumerate(self.entries[self.scroll:self.scroll+vis]):
            abs_i  = i + self.scroll
            iy     = row_y0 + i * item_h
            is_sel = (abs_i == self.sel)

            if is_sel:
                pygame.draw.rect(surf, S["sel_bg"], (x+4, iy, W-8, item_h-2), border_radius=4)
                pygame.draw.rect(surf, S["border"], (x+4, iy, W-8, item_h-2), 1, border_radius=4)

            can_afford = self.player_gold >= entry["price"]
            bought     = entry["purchased"] or entry["stock"] <= 0
            label_col  = S["bought"] if bought else (S["item_fg"] if can_afford else S["disabled"])
            price_col  = S["bought"] if bought else (S["price_fg"] if can_afford else S["disabled"])

            key   = entry["key"]
            defn  = EQUIPMENT_DEFS.get(key, {})
            label = defn.get("label", key.replace("_", " ").title())
            if bought: label += "  ✓"

            # Type tag for equipment
            item_type = ITEM_SLOTS.get(key, "")
            if item_type == "equip_wear":
                tag = "WEAR"; tag_col = (120, 210, 160)
            elif item_type == "equip_gear":
                tag = "GEAR"; tag_col = (180, 140, 255)
            else:
                tag = ""; tag_col = S["disabled"]

            # Colour dot from EQUIPMENT_DEFS
            dot_col = defn.get("color", (100, 120, 160)) if defn else (100, 120, 160)
            pygame.draw.circle(surf, dot_col, (x+14, iy+13), 5)

            lbl_surf = font.render(label, True, label_col)
            surf.blit(lbl_surf, (x + 24, iy + 4))

            # Description (small, below label)
            if is_sel and defn.get("desc"):
                font_xs = pygame.font.SysFont("consolas", 11)
                desc_s = font_xs.render(defn["desc"][:62], True, (120, 150, 180))
                surf.blit(desc_s, (x + 24, iy + 22))

            if tag:
                ts = font.render(tag, True, tag_col)
                surf.blit(ts, ts.get_rect(midright=(x + W - 110, iy + 13)))

            price_str  = f"{entry['price']}g  ×{entry['stock']}"
            price_surf = font.render(price_str, True, price_col)
            surf.blit(price_surf, (x + W - price_surf.get_width() - 14, iy + 4))

        # Scroll hint
        total = len(self.entries)
        if total > vis:
            hint = font.render(f"  {self.scroll+1}–{min(self.scroll+vis,total)} / {total}",
                               True, S["disabled"])
            surf.blit(hint, (x + W//2 - hint.get_width()//2, y + H - 22))


# ════════════════════════════════════════════════════════════════════════════
# Detail Image / Detail Text – decorative floor graphics & labels
# ════════════════════════════════════════════════════════════════════════════
# layer:  0 = drawn after floor tiles, before items/doors  (deepest)
#         1 = drawn after items/doors, before player        (mid)
#         2 = drawn after player / guards                   (topmost)
# size_w / size_h: width/height in tiles (can exceed 1.0 for large art)
# offset_x / offset_y: pixel nudge from tile origin

class DetailImg:
    """
    A decorative image tile drawn at a specific render layer.
    Can be larger than one tile (e.g. a 3×2 floor graphic for a tutorial prompt).
    `image` is a path relative to the level's _assets/ folder (PNG).
    """
    def __init__(self, col, row, props=None):
        self.col = col; self.row = row
        p = props or {}
        self.layer    = int(p.get("layer", 0))
        self.size_w   = float(p.get("size_w", 1.0))
        self.size_h   = float(p.get("size_h", 1.0))
        self.image    = str(p.get("image", ""))
        self.alpha    = int(p.get("alpha", 255))
        self.offset_x = int(p.get("offset_x", 0))
        self.offset_y = int(p.get("offset_y", 0))
        self._cached_surf = None
        self._cached_key  = None

    def get_surf(self, tile, level_dir):
        """Return a scaled pygame.Surface for this detail image, cached."""
        w = max(1, int(tile * self.size_w))
        h = max(1, int(tile * self.size_h))
        key = (self.image, w, h, self.alpha)
        if key == self._cached_key and self._cached_surf is not None:
            return self._cached_surf
        surf = None
        if self.image:
            # Search order for image resolution:
            #   1. <bundle>/images/<name>          (bundle-local, primary)
            #   2. <bundle>/_assets/<name>         (legacy export path)
            #   3. <bundle>/<image> as stored      (absolute or relative)
            candidates = [
                os.path.join(level_dir, "images", self.image),
                os.path.join(level_dir, "_assets", self.image),
                os.path.join(level_dir, self.image),
                self.image,  # absolute path
            ]
            img_path = next((p for p in candidates if os.path.isfile(p)), None)
            if img_path:
                try:
                    raw = pygame.image.load(img_path).convert_alpha()
                    surf = pygame.transform.smoothscale(raw, (w, h))
                except Exception:
                    surf = None
        if surf is None:
            # Fallback: tinted rect with "IMG" label
            surf = pygame.Surface((w, h), pygame.SRCALPHA)
            surf.fill((180, 100, 200, 80))
            try:
                fnt = pygame.font.SysFont("consolas", max(8, h // 3))
                lbl = fnt.render("IMG", True, (200, 150, 230))
                surf.blit(lbl, lbl.get_rect(center=(w // 2, h // 2)))
            except Exception:
                pass
        if self.alpha < 255:
            surf.set_alpha(self.alpha)
        self._cached_surf = surf
        self._cached_key  = key
        return surf

    def draw(self, world_surf, cam, tile, level_dir):
        sx, sy = cam.world_to_screen(self.col * tile, self.row * tile)
        sx += self.offset_x; sy += self.offset_y
        s = self.get_surf(tile, level_dir)
        world_surf.blit(s, (int(sx), int(sy)))


class DetailTxt:
    """
    A decorative text label drawn at a specific render layer.
    Can span multiple tiles via size_w/size_h (used for word-wrap bounds).
    `text` supports \\n for newlines.
    """
    def __init__(self, col, row, props=None):
        self.col = col; self.row = row
        p = props or {}
        self.layer      = int(p.get("layer", 0))
        self.size_w     = float(p.get("size_w", 1.0))
        self.size_h     = float(p.get("size_h", 1.0))
        self.text       = str(p.get("text", ""))
        self.color      = tuple(p.get("color", [220, 220, 180]))
        self.alpha      = int(p.get("alpha", 255))
        self.font_scale = float(p.get("font_scale", 0.3))
        self.offset_x   = int(p.get("offset_x", 0))
        self.offset_y   = int(p.get("offset_y", 0))
        self.align      = str(p.get("align", "center"))  # "left", "center", "right"

    def draw(self, world_surf, cam, tile, font_sm, font_md):
        if not self.text:
            return
        sx, sy = cam.world_to_screen(self.col * tile, self.row * tile)
        sx += self.offset_x; sy += self.offset_y
        w = max(1, int(tile * self.size_w))
        h = max(1, int(tile * self.size_h))
        fsize = max(6, int(tile * self.font_scale))
        try:
            fnt = pygame.font.SysFont("consolas", fsize)
        except Exception:
            fnt = font_sm
        lines = self.text.replace("\\n", "\n").split("\n")
        col = (*self.color[:3], self.alpha) if len(self.color) >= 3 else (220, 220, 180, self.alpha)
        cy = sy + (h - fsize * len(lines)) // 2
        for line in lines:
            lbl = fnt.render(line, True, col[:3])
            if self.alpha < 255:
                lbl.set_alpha(self.alpha)
            if self.align == "center":
                lx = sx + (w - lbl.get_width()) // 2
            elif self.align == "right":
                lx = sx + w - lbl.get_width()
            else:
                lx = sx
            world_surf.blit(lbl, (int(lx), int(cy)))
            cy += fsize + 2


# ════════════════════════════════════════════════════════════════════════════
# Inventory – primary (1 slot), secondary (1 slot), other (4 slots)
# ════════════════════════════════════════════════════════════════════════════
class Inventory:
    def __init__(self):
        self.primary   = None        # item key or None
        self.secondary = None        # item key or None
        self.other     = [None, None, None, None]   # 4 slots
        self.other_sel = 0           # selected other-slot index (0-3)
        self.active_slot = "primary" # "primary" or "secondary" (for TAB/Q cycling)

    def add(self, item_key, slot):
        """Try to place item_key into appropriate slot. Returns True if placed."""
        if slot == "primary":
            if self.primary is None:
                self.primary = item_key; return True
            if self.secondary is None:
                self.secondary = item_key; return True
            return False  # both gun slots full
        else:  # other, equip_wear, equip_gear all go into other slots
            for i, s in enumerate(self.other):
                if s is None:
                    self.other[i] = item_key; return True
            return False  # all other slots full

    def drop_selected(self):
        """Drop whichever item is currently 'active'. Returns (item_key, slot) or None."""
        if self.active_slot == "primary" and self.primary:
            item = self.primary; self.primary = None
            return (item, "primary")
        if self.active_slot == "secondary" and self.secondary:
            item = self.secondary; self.secondary = None
            return (item, "secondary")
        if self.active_slot == "other":
            item = self.other[self.other_sel]
            if item:
                self.other[self.other_sel] = None
                return (item, "other")
        return None

    def cycle_gun(self):
        """Toggle active gun slot between primary and secondary (also switches context to gun)."""
        if self.active_slot == "primary":
            self.active_slot = "secondary"
        elif self.active_slot == "secondary":
            self.active_slot = "primary"
        else:
            # coming from other context – go back to primary
            self.active_slot = "primary"

    def selected_item(self):
        """Return currently selected item key or None."""
        if self.active_slot == "primary":
            return self.primary
        if self.active_slot == "secondary":
            return self.secondary
        return self.other[self.other_sel]

    def cycle_other(self, delta=1):
        """Cycle other slot selection by delta (+1 or -1)."""
        self.other_sel = (self.other_sel + delta) % 4


class MPEquipScreen:
    """
    Dual loadout screen for MP.  Shows P1 and P2 panels side-by-side.

    P1 controls: TAB / ↑↓ / ←→ / Enter / Z / ESC  (same as solo)
    P2 controls: KP5 (focus) / KP8↑ KP2↓ KP4← KP6→ / KP_Enter / KP0 (proceed)

    Either player pressing Continue / ESC / KP0 flags ready.
    The screen closes once BOTH players are ready.
    """

    _P1_COL = (100, 170, 255)   # blue accent for P1
    _P2_COL = (40,  200, 240)   # cyan accent for P2

    def __init__(self, screen, clock,
                 equipment1, inventory1,
                 equipment2, inventory2,
                 gold: int, post_level: bool = False,
                 score: int = 0, has_next: bool = False):
        self.screen     = screen
        self.clock      = clock
        self.W, self.H  = screen.get_size()

        # Wrap each player's data in a standard EquipScreen
        half_w = self.W // 2
        # Build sub-surfaces so each EquipScreen thinks it has a half-width screen
        self._surf1 = pygame.Surface((half_w, self.H))
        self._surf2 = pygame.Surface((half_w, self.H))

        self._es1 = EquipScreen(self._surf1, clock, equipment1, inventory1,
                                gold, post_level, score, has_next)
        self._es2 = EquipScreen(self._surf2, clock, equipment2, inventory2,
                                gold, post_level, score, has_next)

        # Override key-handling: P2 uses numpad, P1 uses normal keys
        self._p1_ready = False
        self._p2_ready = False

        self._font_lg = pygame.font.SysFont("consolas", 18, bold=True)
        self._font_sm = pygame.font.SysFont("consolas", 13)

    # numpad → EquipScreen key mapping
    _KP_MAP = {
        pygame.K_KP8:      pygame.K_UP,
        pygame.K_KP2:      pygame.K_DOWN,
        pygame.K_KP4:      pygame.K_LEFT,
        pygame.K_KP6:      pygame.K_RIGHT,
        pygame.K_KP_ENTER: pygame.K_RETURN,
        pygame.K_KP5:      pygame.K_TAB,
        pygame.K_KP0:      pygame.K_ESCAPE,   # KP0 = P2 "proceed"
        pygame.K_KP_PLUS:  pygame.K_z,        # KP+ = confirm / equip
    }

    def run(self) -> str:
        while not (self._p1_ready and self._p2_ready):
            self.clock.tick(60)
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    pygame.quit(); import sys; sys.exit()
                if ev.type == pygame.KEYDOWN:
                    k = ev.key
                    # P2 numpad keys
                    if k in self._KP_MAP:
                        mapped = self._KP_MAP[k]
                        if mapped == pygame.K_ESCAPE:
                            self._p2_ready = True
                        else:
                            self._es2._handle_key(mapped)
                            if self._es2.result:
                                self._p2_ready = True
                    # P1 normal keys
                    else:
                        if k in (pygame.K_ESCAPE, pygame.K_x):
                            self._p1_ready = True
                        else:
                            self._es1._handle_key(k)
                            if self._es1.result:
                                self._p1_ready = True

            self._draw()
            pygame.display.flip()
        return "continue"

    def _draw(self):
        scr = self.screen
        W, H = self.W, self.H
        half = W // 2

        # Draw each player's equip screen into its own surface
        self._es1.screen = self._surf1
        self._es1._draw()
        self._es2.screen = self._surf2
        self._es2._draw()

        scr.blit(self._surf1, (0,    0))
        scr.blit(self._surf2, (half, 0))

        # Divider line
        pygame.draw.line(scr, (60, 90, 160), (half, 0), (half, H), 2)

        # Player labels at the top of each half
        font = self._font_lg
        p1_lbl = font.render("◀  PLAYER 1  (WASD / arrows)", True, self._P1_COL)
        p2_lbl = font.render("PLAYER 2  (numpad)  ▶",        True, self._P2_COL)
        scr.blit(p1_lbl, p1_lbl.get_rect(midtop=(half//2,    4)))
        scr.blit(p2_lbl, p2_lbl.get_rect(midtop=(half+half//2, 4)))

        # Ready indicators
        sm = self._font_sm
        if self._p1_ready:
            r1 = sm.render("READY", True, (80, 220, 100))
            scr.blit(r1, r1.get_rect(midtop=(half//2, 26)))
        if self._p2_ready:
            r2 = sm.render("READY", True, (80, 220, 100))
            scr.blit(r2, r2.get_rect(midtop=(half+half//2, 26)))

        # Hint bar
        hint = self._font_sm.render(
            "P1: TAB·↑↓·Enter·ESC=ready     |     P2: KP5=tab·KP8/2/4/6·KP-Enter·KP0=ready",
            True, (45, 60, 85))
        scr.blit(hint, hint.get_rect(midbottom=(W//2, H-2)))


# ════════════════════════════════════════════════════════════════════════════
# Snitch – patrols like a guard but NEVER fights; runs to report sightings
# ════════════════════════════════════════════════════════════════════════════
# ════════════════════════════════════════════════════════════════════════════
# Player
# ════════════════════════════════════════════════════════════════════════════
class Player:
    SPD_WALK   = 2.0
    SPD_SPRINT = 4.2
    RAD        = 11
    NOISE_INT  = 0.20
    WALK_NOISE_INT = 0.45   # seconds between footstep noise pulses when walking

    def __init__(self, tx, ty, tile=TILE):
        cx, cy = tc(tx, ty, tile)
        self.x, self.y  = float(cx), float(cy)
        self._tile       = tile
        self.use_dist    = tile * 1.5
        self.sprinting   = False
        self.hidden      = False
        self.facing      = 0.0
        self._noise_tmr  = 0.0
        self._walk_noise_tmr = 0.0
        self.hp = 2   # 2 pistol shots to die; 1 shotgun

    @property
    def speed(self):
        if self.hidden:    return 0.0
        mul = getattr(self, '_equip_speed_mul', 1.0)
        if getattr(self, '_drag_slowed', False): return self.SPD_WALK * 0.5 * mul
        if self.sprinting: return self.SPD_SPRINT * mul
        return self.SPD_WALK * mul

    def move(self, dx, dy, walls, closed_doors, crashdoor_closed=None):
        if self.hidden or (dx == 0 and dy == 0): return
        n = math.hypot(dx, dy); dx /= n; dy /= n
        self.facing = math.atan2(dy, dx)
        s = self.speed
        nx, ny = self.x + dx*s, self.y + dy*s
        extra = set()
        if crashdoor_closed:
            extra = crashdoor_closed
        if not self._hit(nx, self.y, walls, closed_doors, extra): self.x = nx
        if not self._hit(self.x, ny, walls, closed_doors, extra): self.y = ny

    def emit_noise(self, dt, noise_events, moving=True):
        sprint_suppressed = getattr(self, '_sprint_noise_suppressed', False)
        if self.sprinting and not self.hidden and not sprint_suppressed:
            self._noise_tmr -= dt
            if self._noise_tmr <= 0:
                noise_events.append(
                    NoiseEvent(self.x, self.y, NOISE_SPRINT, NOISE_SPRINT_R, 1.8))
                self._noise_tmr = self.NOISE_INT
        elif moving and not self.sprinting and not self.hidden:
            self._walk_noise_tmr -= dt
            if self._walk_noise_tmr <= 0:
                noise_mul = getattr(self, '_walk_noise_mul', 1.0)
                walk_radius = self._tile * 0.35 * noise_mul
                if walk_radius > 1:
                    noise_events.append(
                        NoiseEvent(self.x, self.y, score=int(42*noise_mul), radius=walk_radius,
                                   lifetime=0.18, ambiguous=True, visual_only=False))
                self._walk_noise_tmr = self.WALK_NOISE_INT

    def _hit(self, px, py, walls, closed_doors, extra=None):
        r = self.RAD; t = self._tile
        blocked = walls | closed_doors
        if extra: blocked = blocked | extra
        for tx in range(int((px-r)//t), int((px+r)//t)+1):
            for ty in range(int((py-r)//t), int((py+r)//t)+1):
                if (tx,ty) in blocked:
                    nx2 = max(tx*t, min(px, tx*t+t))
                    ny2 = max(ty*t, min(py, ty*t+t))
                    if math.hypot(px-nx2, py-ny2) < r: return True
        return False

    @property
    def tile(self): return ptile(self.x, self.y, self._tile)


# ════════════════════════════════════════════════════════════════════════════
# Snitch  –  civilian informant driven entirely by GOAP
# ════════════════════════════════════════════════════════════════════════════
class Snitch:
    """
    Civilian informant.  Patrols waypoints, reacts to noise, spots the player,
    then sprints to the nearest live guard to file a URG_EMERGENCY report.
    Does NOT fight or chase — purely an alarm escalator.

    All behaviour decisions come from GOAPAgent.tick().
    The locomotion methods (_loco_*) are pure movement primitives with no
    decision logic; they return True when the primitive is "done".
    """

    SPD = {
        PATROL: 1.1, ALERT: 1.9, INSPECT: 0.0, SEARCH: 1.5,
        "running": 2.8, PANICKED: 1.5,
    }
    SIGHT     = 200
    SIGHT_SPR = 40
    FOV = {
        PATROL: math.radians(60), ALERT: math.radians(100),
        INSPECT: math.radians(80), SEARCH: math.radians(85),
        "running": math.radians(50), PANICKED: math.radians(100),
    }
    RAD = 11
    SUSP_RISE_NEAR = 2.0
    SUSP_RISE_FAR  = 0.6
    SUSP_FALL      = 0.7
    SUSP_NEAR_PX   = 120
    SUSP_ALERT_THR = 0.30
    WANDER_CHANCE  = 0.0003
    WANDER_RADIUS  = 3
    HOTSPOT_HEAT_CAP = 5

    def __init__(self, col, row, props=None, tile=TILE):
        p = props or {}
        self.col   = col
        self.row   = row
        self._tile = tile

        raw_wps  = p.get("waypoints",   [[col, row]])
        pause_f  = p.get("pause_flags", [False] * len(raw_wps))
        wp_data_ = p.get("wp_data",     [{}]    * len(raw_wps))
        while len(pause_f)  < len(raw_wps): pause_f.append(False)
        while len(wp_data_) < len(raw_wps): wp_data_.append({})
        self.waypoints   = [tc(w[0], w[1], tile) for w in raw_wps]
        self.pause_flags = pause_f
        self.wp_data     = wp_data_
        self.wp_idx      = 1 % len(self.waypoints)  # start targeting the NEXT waypoint

        self.x, self.y = float(self.waypoints[0][0]), float(self.waypoints[0][1])
        self.facing     = math.radians(p.get("facing", 0.0))
        self._rot_speed = math.radians(p.get("rotation_speed", 0.0))
        self.active     = p.get("active", True)
        self.sight_mul  = p.get("sight_mul", 1.0)
        self.fov_mul    = p.get("fov_mul",   1.0)
        self.knows_layout = bool(p.get("knows_layout", False))

        # state mirror – set from GOAP action each frame
        self.state   = PATROL
        self.dead    = False
        self.alerted = False   # True while in "running" state

        self.suspicion   = 0.0
        self.last_player = None
        self._last_seen  = None

        # locomotion
        self.path        = []
        self.path_idx    = 0
        self.target_px   = None   # current locomotion destination
        self._pause_t    = 0.0
        self._watch_target = None
        self._watch_t    = 0.0
        self.inspect_t   = 0.0

        # patrol A* cache
        self._patrol_path      = []
        self._patrol_path_idx  = 0
        self._patrol_wp_tile   = None
        self._recovery_path     = None
        self._recovery_path_idx = 0

        # wander / hotspot
        self._wander_target  = None
        self._hotspot_heat   = {}
        self._trap_targets   = []
        self._trap_idx       = 0
        self._trap_t         = 0.0

        # search
        self._search_pts  = []
        self._search_idx  = 0

        # panicked sweep
        self._panicked_pts  = []
        self._panicked_idx  = 0
        self._panicked_peek = 0.0

        # running-to-report
        self._run_target    = None
        self._run_stand_t   = 0.0
        self._run_walk_t    = 0.0
        self._run_delivered = False
        self._cooldown      = 0.0

        # discovery tracking
        self._discovered_tiles   = set()
        self._discovery_target   = None
        self._discovery_wander_t = 0.0

        # level intel
        self._vantage_points    = []
        self._bottleneck_points = []
        self._intel_scanned     = False

        # muffled noise
        self._muffled_heat  = {}
        self._muffled_decay = 0.0
        self.MUFFLED_THRESH = 120
        self.MUFFLED_WINDOW = 12.0

        # self-opened doors
        self._self_opened_doors: dict = {}

        # stuck detection
        self._last_pos     = (0.0, 0.0)
        self._stuck_t      = 0.0
        self._stuck_repath = 0.0

        # refs set by Game
        self.walls_ref      = set()
        self.windows_ref    = set()
        self._all_doors_ref = []
        self._cols          = 0
        self._rows          = 0

        # GOAP
        self._goap = GOAPAgent(SnitchActionSet())
        self._goap.set(
            suspicion_low=False, suspicion_full=False,
            player_visible=False, has_last_known=False,
            noise_dest_set=False, at_dest=False,
            search_done=False,
            body_found=False, guard_in_range=False, reported=False,
        )
        self._goap.add_goal(Goal("report_player", {"reported": True},      priority=3.0))
        self._goap.add_goal(Goal("calm_body",     {"body_found": False},    priority=2.5))
        self._goap.add_goal(Goal("clear_noise",   {"noise_dest_set": False, "at_dest": False}, priority=1.5))
        self._goap.add_goal(Goal("find_player",   {"search_done": True},   priority=1.2))

        self._noise_dest = None   # stored noise destination pixel

    # ── main update ───────────────────────────────────────────────────────

    def update(self, player, walls, windows, closed_doors, noise_events, dt,
               all_guards=None, game_time=0.0):
        if self.dead or not self.active:
            return
        all_guards = all_guards or []
        self.windows_ref = windows or set()

        self._game_time_ref = game_time

        # 1. Perception
        self._sense(player, walls, closed_doors, noise_events, all_guards, dt, windows)
        self._decay_muffled_heat(dt)
        if self._cooldown > 0:
            self._cooldown -= dt

        # 2. Push perception into GOAP world state
        self._sync_goap(player, all_guards)

        # 3. GOAP decides
        action_name = self._goap.tick()

        # 4. Map action name → FSM state label (for rendering/FOV)
        self._apply_state_label(action_name)

        # 5. Execute locomotion primitive
        done = self._execute(action_name, player, walls, closed_doors,
                             [], dt, all_guards)
        if done:
            self._goap.complete_action()

        # 6. Housekeeping
        self._check_stuck(walls, dt)

    def _sync_goap(self, player, all_guards):
        susp_full = self.suspicion >= 1.0
        susp_low  = (not susp_full) and self.suspicion > 0.05

        # guard_in_range: a live guard is within report range while running
        guard_close = False
        if susp_full or self.alerted:
            live = [g for g in all_guards if getattr(g, 'state', None) != DEAD]
            guard_close = any(dist(self.x, self.y, g.x, g.y) < self._tile * 2.0
                              for g in live)

        self._goap.set(
            suspicion_low   = susp_low,
            suspicion_full  = susp_full,
            player_visible  = (self.last_player is not None and
                               dist(self.x, self.y,
                                    self.last_player[0], self.last_player[1])
                               < self.SIGHT * self.sight_mul),
            has_last_known  = (self._last_seen is not None),
            noise_dest_set  = (self._noise_dest is not None),
            guard_in_range  = guard_close,
            reported        = self._run_delivered,
        )

    def _apply_state_label(self, action_name):
        label_map = {
            "patrol_walk":        PATROL,
            "investigate_noise":  ALERT,
            "inspect_spot":       INSPECT,
            "search_walk":        SEARCH,
            "search_inspect":     INSPECT,
            "end_search":         PATROL,
            "run_to_guard":       "running",
            "deliver_report":     "running",
            "cooldown_return":    PATROL,
            "panicked_sweep":     PANICKED,
        }
        new_state = label_map.get(action_name, self.state)
        self.state   = new_state
        self.alerted = (new_state == "running")

    def _execute(self, action_name, player, walls, closed_doors,
                 doors, dt, all_guards):
        """Run locomotion for the current action. Returns True when done."""
        if action_name == "patrol_walk":
            return self._loco_patrol(walls, doors, dt)

        if action_name == "investigate_noise":
            if self._noise_dest is None:
                return True
            self.target_px = self._noise_dest
            done = self._walk_path(walls, closed_doors, self.target_px,
                                   self.SPD[ALERT])
            if done:
                self._noise_dest = None
                self.inspect_t   = 1.5
            return done

        if action_name == "inspect_spot":
            self.inspect_t -= dt
            self.facing    += dt * 2.5
            return self.inspect_t <= 0

        if action_name == "search_walk":
            if not self._search_pts or self._search_idx >= len(self._search_pts):
                return True
            dest = self._search_pts[self._search_idx]
            done = self._walk_path(walls, closed_doors, dest, self.SPD[SEARCH])
            if done:
                self._search_idx += 1
                self.inspect_t = 1.0
            return done

        if action_name == "search_inspect":
            self.inspect_t -= dt
            self.facing    += dt * 2.0
            return self.inspect_t <= 0

        if action_name == "end_search":
            self._search_pts = []; self._search_idx = 0
            self._last_seen  = None
            self._rebuild_trap_targets()
            self._recover_patrol_path()
            return True

        if action_name == "run_to_guard":
            return self._loco_run_to_guard(walls, closed_doors, dt, all_guards)

        if action_name == "deliver_report":
            return self._loco_deliver_report(walls, dt, all_guards)

        if action_name == "cooldown_return":
            self._run_delivered = False
            self.alerted        = False
            self._last_seen     = None
            self.suspicion      = 0.0
            self._rebuild_trap_targets()
            self._recover_patrol_path()
            return True

        if action_name == "panicked_sweep":
            return self._loco_panicked(walls, closed_doors, dt)

        return False  # unknown action – stay still

    # ── locomotion primitives ─────────────────────────────────────────────

    def _loco_patrol(self, walls, doors, dt):
        """Walk the waypoint loop. Returns True on each waypoint arrival."""
        if self._pause_t > 0:
            self._pause_t -= dt
            if self._watch_target and self._watch_t > 0:
                wx, wy = self._watch_target
                ta = math.atan2(wy - self.y, wx - self.x)
                self.facing += adiff(ta, self.facing) * min(1.0, dt * 3.0)
                self._watch_t -= dt
            else:
                self.facing += dt * 0.8
            return False

        if self._recovery_path:
            self._walk_recovery(walls, [], self.SPD[PATROL])
            return False

        if self._wander_target:
            done = self._walk_path(walls, set(), self._wander_target,
                                   self.SPD[PATROL])
            if done:
                self._wander_target = None
                self._recover_patrol_path()
            return False

        self._trap_t = max(0.0, self._trap_t - dt)
        if self._trap_targets and self._trap_t <= 0 and random.random() < 0.08:
            self._trap_idx = (self._trap_idx + 1) % len(self._trap_targets)
            self._wander_target = self._trap_targets[self._trap_idx]
            self._trap_t = 45.0
            return False

        self._update_discovery(dt)
        return self._follow_patrol_wp(walls, [], dt)

    def _loco_wait(self, dt):
        """Idle at waypoint; returns True after pause expires."""
        if self._pause_t <= 0:
            return True
        self._pause_t -= dt
        self.facing   += dt * 0.4
        return self._pause_t <= 0

    def _loco_run_to_guard(self, walls, closed_doors, dt, all_guards):
        self._run_walk_t += dt
        if self._run_walk_t > 25.0:
            # timed out — give up
            self._run_delivered = True  # treat as done so GOAP moves on
            return True

        live = [g for g in all_guards if getattr(g, 'state', None) != DEAD]
        if not live:
            self._run_delivered = True
            return True

        if self._run_target is None or getattr(self._run_target, 'state', None) == DEAD:
            self._run_target = min(live, key=lambda g: dist(self.x, self.y, g.x, g.y))

        tgt  = self._run_target
        d    = dist(self.x, self.y, tgt.x, tgt.y)
        done = d < self._tile * 2.0
        if not done:
            tp = tc(ptile(tgt.x, tgt.y, self._tile)[0],
                    ptile(tgt.x, tgt.y, self._tile)[1], self._tile)
            self._walk_path(walls, closed_doors, tp, self.SPD["running"])
        return done

    def _loco_deliver_report(self, walls, dt, all_guards):
        self._run_stand_t += dt
        if self._run_target:
            ang = math.atan2(self._run_target.y - self.y, self._run_target.x - self.x)
            self.facing += adiff(ang, self.facing) * min(1.0, dt * 4.0)
        if self._run_stand_t >= 1.0:
            lp = self._last_seen or (self.x, self.y)
            if self._run_target:
                self._run_target._receive_briefing(self, URG_EMERGENCY, lp)
                if not getattr(self._run_target, '_brief_pending', False):
                    self._run_target._brief_pending = True
                    self._run_target._brief_msg     = (URG_SPOTTED, lp)
            self._run_delivered = True
            self._run_stand_t   = 0.0
            self._run_walk_t    = 0.0
            self._cooldown      = 14.0
            return True
        return False

    def _loco_panicked(self, walls, closed_doors, dt):
        spd = self.SPD[PANICKED]
        if self._panicked_peek > 0:
            self._panicked_peek -= dt
            self.facing += dt * 3.0
            return False
        if not self._panicked_pts or self._panicked_idx >= len(self._panicked_pts):
            self._rebuild_trap_targets()
            self._recover_patrol_path()
            return True
        done = self._walk_path(walls, closed_doors,
                               self._panicked_pts[self._panicked_idx], spd)
        if done:
            self._panicked_idx  += 1
            self._panicked_peek  = random.uniform(0.3, 0.7)
        return False

    def _follow_patrol_wp(self, walls, doors, dt, game_time=0.0):
        """A*-guided step toward current waypoint. Returns True on arrival."""
        if not self.waypoints:
            return False
        if len(self.waypoints) == 1:
            return False
        wp_idx = self.wp_idx
        wp     = self.waypoints[wp_idx]
        dx, dy = wp[0] - self.x, wp[1] - self.y
        d      = math.hypot(dx, dy)
        spd    = self.SPD[PATROL]

        if d < spd + 1:
            wd    = self.wp_data[wp_idx] if wp_idx < len(self.wp_data) else {}
            ntype = wd.get("type", "waypoint")
            pause = self.pause_flags[wp_idx] if self.pause_flags else False
            if ntype == "waitpoint" or pause:
                self._pause_t = random.uniform(wd.get("wait_min", 2.0),
                                               wd.get("wait_max", 4.5))
            elif ntype == "watch":
                lt = wd.get("look_time", 1.5)
                self._pause_t  = lt; self._watch_t = lt
                self._watch_target = (tuple(wd["watch_px"]) if "watch_px" in wd
                                      else (wp[0], wp[1]))
            elif ntype == "check":
                chance = wd.get("check_chance", 60) / 100.0
                if wd.get("always_check", False) or random.random() < chance:
                    self._pause_t  = wd.get("check_time", 2.0)
                    self.inspect_t = self._pause_t
            # curiosity wander
            if ntype not in ("watch", "check") and not self._wander_target:
                if random.random() < self.WANDER_CHANCE:
                    ox = random.randint(-self.WANDER_RADIUS, self.WANDER_RADIUS) * self._tile
                    oy = random.randint(-self.WANDER_RADIUS, self.WANDER_RADIUS) * self._tile
                    wx = max(self._tile, min((self._cols-1)*self._tile, wp[0]+ox))
                    wy = max(self._tile, min((self._rows-1)*self._tile, wp[1]+oy))
                    if ptile(wx, wy, self._tile) not in self.walls_ref:
                        self._wander_target = (wx, wy)
            self.wp_idx = (self.wp_idx + 1) % len(self.waypoints)
            self._patrol_path = []; self._patrol_path_idx = 0
            return True   # arrived — GOAP advances to patrol_wait if pausing
        else:
            wd = self.wp_data[wp_idx] if wp_idx < len(self.wp_data) else {}
            if wd.get("type") == "watch":
                trigger = wd.get("trigger_dist", 4) * self._tile
                if d <= trigger:
                    wx2, wy2 = wd.get("watch_px", wp)
                    ta = math.atan2(wy2 - self.y, wx2 - self.x)
                    self.facing += adiff(ta, self.facing) * min(1.0, dt * 2.0)
            wp_tile = ptile(wp[0], wp[1], self._tile)
            my_tile = ptile(self.x,  self.y,  self._tile)
            if (not self._patrol_path or
                    getattr(self, '_patrol_wp_tile', None) != wp_tile):
                self._patrol_path = (
                    astar(walls, my_tile, wp_tile, self._cols, self._rows) or [])
                self._patrol_path_idx = 0
                self._patrol_wp_tile  = wp_tile
            pp = self._patrol_path; pidx = self._patrol_path_idx
            if pp and pidx < len(pp):
                nt = pp[pidx]
                tx_px, ty_px = tc(nt[0], nt[1], self._tile)
                nd = dist(self.x, self.y, tx_px, ty_px)
                if nd < spd + 1:
                    self._patrol_path_idx = pidx + 1
                else:
                    ndx, ndy = (tx_px-self.x)/nd, (ty_px-self.y)/nd
                    self._step(ndx*spd, ndy*spd, walls, set())
                    self.facing = math.atan2(ndy, ndx)
            else:
                if d > 0:
                    self._step(dx/d*spd, dy/d*spd, walls, set())
                    self.facing = math.atan2(dy, dx)
        return False

    # ── sensing ───────────────────────────────────────────────────────────

    def _sense(self, player, walls, closed_doors, noise_events, all_guards, dt, windows):
        self._player_just_hid = getattr(player, '_just_hid', False)
        if not player.hidden:
            self._try_see(player, walls, closed_doors, all_guards, dt, windows)
        else:
            self._check_witness_hide(player, walls, closed_doors, all_guards, windows)
            self.suspicion = max(0.0, self.suspicion - 1.5 * dt)
        self._try_hear(noise_events, all_guards, walls, windows)

    def _try_see(self, player, walls, closed_doors, all_guards, dt, windows):
        sight = (self.SIGHT * self.sight_mul) + (self.SIGHT_SPR if player.sprinting else 0)
        d = dist(self.x, self.y, player.x, player.y)
        cur_fov = self.FOV.get(self.state, math.radians(60)) * self.fov_mul
        in_fov = False
        if d <= sight:
            ang = math.atan2(player.y - self.y, player.x - self.x)
            if abs(adiff(ang, self.facing)) <= cur_fov:
                in_fov = los_check(walls, self.x, self.y, player.x, player.y,
                                   closed_doors, windows)
        if in_fov:
            rate = self.SUSP_RISE_NEAR if d < self.SUSP_NEAR_PX else self.SUSP_RISE_FAR
            if player.sprinting: rate *= 2.0
            self.suspicion   = min(1.0, self.suspicion + rate * dt)
            self.last_player = (player.x, player.y)
            self._last_seen  = (player.x, player.y)
            # record hotspot
            ht = ptile(player.x, player.y, self._tile)
            self._hotspot_heat[ht] = self._hotspot_heat.get(ht, 0) + 1
        else:
            self.suspicion = max(0.0, self.suspicion - self.SUSP_FALL * dt)
            if self.suspicion < 0.05:
                self.last_player = None

    def _check_witness_hide(self, player, walls, closed_doors, all_guards, windows):
        if self.state in ("running", SEARCH): return
        if not getattr(self, '_player_just_hid', False): return
        sight = self.SIGHT * self.sight_mul
        d = dist(self.x, self.y, player.x, player.y)
        if d > sight: return
        ang = math.atan2(player.y - self.y, player.x - self.x)
        cur_fov = self.FOV.get(self.state, math.radians(60)) * self.fov_mul
        if abs(adiff(ang, self.facing)) > cur_fov: return
        if los_check(walls, self.x, self.y, player.x, player.y, closed_doors, windows):
            self.last_player = (player.x, player.y)
            self._last_seen  = (player.x, player.y)
            self.suspicion   = 1.0

    def _try_hear(self, noise_events, all_guards, walls, windows):
        if self.state in ("running", PANICKED): return
        NOISE_BASE_THRESH = 38
        for ne in noise_events:
            if ne.visual_only: continue
            d = dist(self.x, self.y, ne.x, ne.y)
            if d > ne.radius: continue
            wall_count = count_walls_between(walls, windows,
                                             self.x, self.y, ne.x, ne.y, self._tile)
            effective_score = ne.score * (WALL_DAMP_PER_WALL ** wall_count)
            if effective_score >= NOISE_BASE_THRESH:
                dest = (ne.x, ne.y)
                if ne.ambiguous:
                    jitter = self._tile * 3
                    dest = (ne.x + random.uniform(-jitter, jitter),
                            ne.y + random.uniform(-jitter, jitter))
                if self._noise_dest is None:
                    self._noise_dest = dest
                    ht = ptile(ne.x, ne.y, self._tile)
                    self._hotspot_heat[ht] = self._hotspot_heat.get(ht, 0) + 1
            elif wall_count > 0 and effective_score > 4:
                nt = ptile(ne.x, ne.y, self._tile)
                self._muffled_heat[nt] = self._muffled_heat.get(nt, 0) + effective_score
                if self._muffled_heat[nt] >= self.MUFFLED_THRESH:
                    if self._noise_dest is None:
                        self._noise_dest = (
                            ne.x + random.uniform(-self._tile, self._tile),
                            ne.y + random.uniform(-self._tile, self._tile))
                    self._muffled_heat[nt] = 0

    def _decay_muffled_heat(self, dt):
        self._muffled_decay -= dt
        if self._muffled_decay > 0: return
        self._muffled_decay = 2.0
        decay_rate = self.MUFFLED_THRESH / self.MUFFLED_WINDOW * 2.0
        dead = [k for k, v in self._muffled_heat.items() if v - decay_rate <= 0]
        for k in dead: del self._muffled_heat[k]
        for k in self._muffled_heat:
            self._muffled_heat[k] = max(0, self._muffled_heat[k] - decay_rate)

    # ── called by Game to trigger panicked sweep on body discovery ────────

    def go_panicked(self, body_pos, all_guards):
        if self.state == "running": return
        tile = self._tile; bx, by = body_pos; pts = []
        for dx in range(-3, 4):
            for dy in range(-3, 4):
                if abs(dx) + abs(dy) < 1: continue
                wx = bx + dx * tile; wy = by + dy * tile
                t2 = (int(wx // tile), int(wy // tile))
                if t2 not in self.walls_ref:
                    pts.append((wx, wy))
        random.shuffle(pts)
        self._panicked_pts   = pts[:10]
        self._panicked_idx   = 0
        self._panicked_peek  = 0.0
        self._goap.set(body_found=True)

    # ── helpers ───────────────────────────────────────────────────────────

    def _rebuild_trap_targets(self):
        self._trap_targets = [
            (px * self._tile + self._tile // 2, py * self._tile + self._tile // 2)
            for (px, py), heat in self._hotspot_heat.items()
            if heat >= self.HOTSPOT_HEAT_CAP
        ]

    def _recover_patrol_path(self):
        if not self.waypoints: return
        my_tile = ptile(self.x, self.y, self._tile)
        best_path = None; best_len = 9999
        for wp in self.waypoints:
            wp_tile = ptile(wp[0], wp[1], self._tile)
            p = astar(self.walls_ref, my_tile, wp_tile, self._cols, self._rows)
            if p and len(p) < best_len:
                best_path = p; best_len = len(p)
        if best_path:
            self._recovery_path     = best_path
            self._recovery_path_idx = 0
        else:
            self._recovery_path = None

    def _walk_recovery(self, walls, doors, spd):
        rp = self._recovery_path
        if self._recovery_path_idx >= len(rp):
            self._recovery_path = None; return
        nt = rp[self._recovery_path_idx]
        tx_px, ty_px = tc(nt[0], nt[1], self._tile)
        d = dist(self.x, self.y, tx_px, ty_px)
        if d < spd + 1:
            self._recovery_path_idx += 1
        else:
            dx2, dy2 = (tx_px-self.x)/d, (ty_px-self.y)/d
            self._step(dx2*spd, dy2*spd, walls, set())
            self.facing = math.atan2(dy2, dx2)
        if self._recovery_path_idx >= len(rp):
            self._recovery_path = None

    def _walk_path(self, walls, closed_doors, dest_px, spd, doors=None):
        if dest_px is None: return True
        dest_tile = ptile(dest_px[0], dest_px[1], self._tile)
        my_tile   = ptile(self.x, self.y, self._tile)
        if dest_tile in walls:
            best = None; best_d = 9999
            for dc in range(-2, 3):
                for dr in range(-2, 3):
                    cand = (dest_tile[0]+dc, dest_tile[1]+dr)
                    if cand not in walls:
                        cd = math.hypot(dc, dr)
                        if cd < best_d: best = cand; best_d = cd
            if best:
                dest_tile = best
                dest_px   = (best[0]*self._tile+self._tile//2,
                             best[1]*self._tile+self._tile//2)
            else: return True
        if not self.path or self.path_idx >= len(self.path):
            self.path = astar(walls, my_tile, dest_tile, self._cols, self._rows)
            self.path_idx = 0
        if self.path and self.path_idx < len(self.path):
            nt = self.path[self.path_idx]
            if nt in walls:
                self.path = astar(walls, my_tile, dest_tile, self._cols, self._rows)
                self.path_idx = 0
                if not self.path: return True
                nt = self.path[self.path_idx]
            tx_px, ty_px = tc(nt[0], nt[1], self._tile)
            d = dist(self.x, self.y, tx_px, ty_px)
            if d < spd + 1:
                self.path_idx += 1
            else:
                ddx, ddy = (tx_px-self.x)/d, (ty_px-self.y)/d
                self._step(ddx*spd, ddy*spd, walls, set())
                self.facing = math.atan2(ddy, ddx)
            return False
        return dist(self.x, self.y, dest_px[0], dest_px[1]) < self._tile * 0.7

    def _step(self, mx, my, walls, closed_doors):
        nx = self.x+mx; ny = self.y+my
        if ptile(nx, self.y, self._tile) not in walls: self.x = nx
        if ptile(self.x, ny, self._tile) not in walls: self.y = ny

    def _check_stuck(self, walls, dt):
        px, py = self.x, self.y
        moved = math.hypot(px-self._last_pos[0], py-self._last_pos[1])
        self._last_pos = (px, py)
        # Don't count CHASE as stuck — the guard may be spinning/adjusting near
        # the player, and wiping the path mid-chase is what causes the jitter.
        if moved < 0.5 and self.state in (PATROL, ALERT, SEARCH, "running"):
            self._stuck_t += dt
        else:
            self._stuck_t = 0.0
        self._stuck_repath = max(0.0, self._stuck_repath - dt)
        if self._stuck_t > 0.4 and self._stuck_repath <= 0:
            self.path = []; self.path_idx = 0
            self._patrol_path = []; self._patrol_path_idx = 0
            self._patrol_wp_tile = None
            self._stuck_t = 0.0; self._stuck_repath = 1.5

    def _update_discovery(self, dt):
        t = self._tile
        col = int(self.x // t); row = int(self.y // t)
        for dc in range(-2, 3):
            for dr in range(-2, 3):
                self._discovered_tiles.add((col+dc, row+dr))
        self._discovery_wander_t = max(0.0, self._discovery_wander_t - dt)

    def scan_level_intelligence(self, walls, cols, rows):
        if self._intel_scanned: return
        self._intel_scanned = True
        t = self._tile; vantages = []
        for col in range(cols):
            for row in range(rows):
                tile2 = (col, row)
                if tile2 in walls: continue
                wall_adj = sum(1 for dc2, dr2 in [(-1,0),(1,0),(0,-1),(0,1)]
                               if (col+dc2, row+dr2) in walls)
                open_8 = sum(1 for dc2 in (-1,0,1) for dr2 in (-1,0,1)
                             if (dc2 or dr2) and (col+dc2,row+dr2) not in walls
                             and 0 <= col+dc2 < cols and 0 <= row+dr2 < rows)
                if open_8 >= 5 and wall_adj >= 1:
                    vantages.append((open_8+wall_adj, col*t+t//2, row*t+t//2))
        vantages.sort(reverse=True)
        self._vantage_points = [(px, py) for _, px, py in vantages[:30]]

    def fov_pts(self, walls, windows, closed_doors, tile=TILE):
        half_fov = self.FOV.get(self.state, math.radians(60)) * self.fov_mul
        sight    = self.SIGHT * self.sight_mul
        return cast_fov_polygon(self.x, self.y, self.facing, half_fov,
                                sight, walls, windows, closed_doors, tile)

    def tile_pos(self): return (self.col, self.row)


# ════════════════════════════════════════════════════════════════════════════
# Sentry  –  stationary/roving civilian informant (alias: Snitch lightweight)
#   Sees player → runs to nearest live Guard to file an alert.
#   Does NOT fight. Simpler than Snitch: no GOAP, no waypoints, two states.
# ════════════════════════════════════════════════════════════════════════════
class Sentry:
    """Sentry / Snitch – sees player, then RUNS to nearest guard to report.
    Does NOT fight or raise alarm directly.
    """
    SIGHT    = 200
    RAD      = 11
    SPD_RUN  = 2.8

    def __init__(self, col, row, props=None, tile=TILE):
        p = props or {}
        self.col  = col; self.row  = row
        px, py    = tc(col, row, tile)
        self.x    = float(px); self.y = float(py)
        self._tile = tile
        self.sight_mul  = p.get("sight_mul", 1.0)
        self.fov_mul    = p.get("fov_mul",   1.0)
        self.facing     = math.radians(p.get("facing", 0.0))
        self._rot_speed = math.radians(p.get("rotation_speed", 0.0))
        self.active     = p.get("active", True)
        self.alerted    = False
        self.dead       = False
        self._cooldown  = 0.0
        self._state     = "idle"    # "idle" or "running"
        self._run_path  = []
        self._run_idx   = 0
        self._last_seen = None      # last known player position
        self.walls_ref  = set()     # set by Game after init
        self._cols      = 0
        self._rows      = 0

    def _can_see(self, player, walls, windows, closed_doors):
        if self.dead or not self.active: return False
        if player.hidden: return False
        if getattr(player, 'hidden_by_cloak', False): return False
        sight = self.SIGHT * self.sight_mul
        if dist(self.x, self.y, player.x, player.y) > sight: return False
        half_fov = math.radians(60) * self.fov_mul
        ang = math.atan2(player.y - self.y, player.x - self.x)
        if abs(adiff(ang, self.facing)) > half_fov: return False
        return los_check(walls, self.x, self.y, player.x, player.y,
                         closed_doors, windows)

    def update(self, player, walls, windows, closed_doors, noise_events, dt,
               all_guards=None):
        if self.dead or not self.active: return
        all_guards = all_guards or []

        if self._state == "idle":
            if self._rot_speed != 0.0:
                self.facing += self._rot_speed * dt
            if self._cooldown > 0:
                self._cooldown -= dt; return
            if self._can_see(player, walls, windows, closed_doors):
                self._last_seen = (player.x, player.y)
                live = [g for g in all_guards if g.state != DEAD]
                if not live:
                    noise_events.append(NoiseEvent(self.x, self.y, NOISE_GLOBAL,
                                                   9999, 1.0, ambiguous=False))
                    self._cooldown = 12.0
                    return
                tgt = min(live, key=lambda g: dist(self.x, self.y, g.x, g.y))
                my_t  = ptile(self.x, self.y, self._tile)
                tgt_t = ptile(tgt.x, tgt.y, self._tile)
                self._run_path = astar(walls, my_t, tgt_t, self._cols, self._rows) or []
                self._run_idx  = 0
                self._state    = "running"
                self.alerted   = True

        elif self._state == "running":
            live = [g for g in all_guards if g.state != DEAD]
            if not live:
                self._state = "idle"; self.alerted = False; return
            nearest = min(live, key=lambda g: dist(self.x, self.y, g.x, g.y))
            if dist(self.x, self.y, nearest.x, nearest.y) < self._tile * 1.8:
                lp = self._last_seen or (self.x, self.y)
                nearest._go_alert(lp, live, big=True)
                for g in live:
                    if g is not nearest and g.state not in (DEAD, CHASE):
                        if dist(self.x, self.y, g.x, g.y) < self._tile * 8:
                            g._go_alert(lp, live)
                noise_events.append(NoiseEvent(self.x, self.y, NOISE_GLOBAL,
                                               self._tile * 10, 1.2))
                self._state    = "idle"
                self.alerted   = False
                self._cooldown = 14.0
                return
            spd = self.SPD_RUN
            if self._run_path and self._run_idx < len(self._run_path):
                nt = self._run_path[self._run_idx]
                tx, ty = tc(nt[0], nt[1], self._tile)
                d = dist(self.x, self.y, tx, ty)
                if d < spd + 1:
                    self._run_idx += 1
                else:
                    nx2, ny2 = (tx - self.x) / d, (ty - self.y) / d
                    self.x += nx2 * spd
                    self.y += ny2 * spd
                    self.facing = math.atan2(ny2, nx2)
            else:
                my_t  = ptile(self.x, self.y, self._tile)
                tgt_t = ptile(nearest.x, nearest.y, self._tile)
                self._run_path = astar(walls, my_t, tgt_t, self._cols, self._rows) or []
                self._run_idx  = 0

    def fov_pts(self, walls, windows, closed_doors, tile=TILE):
        half_fov = math.radians(60) * self.fov_mul
        sight    = self.SIGHT * self.sight_mul
        return cast_fov_polygon(self.x, self.y, self.facing, half_fov,
                                sight, walls, windows, closed_doors, tile)

    def tile_pos(self): return (self.col, self.row)


# ════════════════════════════════════════════════════════════════════════════
# Guard  –  armed/unarmed NPC driven entirely by GOAP
# ════════════════════════════════════════════════════════════════════════════
class Guard:
    """
    Primary antagonist NPC.  All behaviour decisions come from GOAPAgent.tick().
    Locomotion primitives (_loco_*) are pure "walk here / wait / act" functions
    that return True when done, triggering complete_action() to advance the plan.

    Sensing writes into the GOAP world state each frame.
    The GOAP planner replans only when world state actually changes.
    """

    SPD = {PATROL:1.3, ALERT:2.2, CHASE:3.1, INSPECT:0.0,
           SEARCH:1.8, BRIEF:1.8, PANICKED:1.6, COMBAT:1.8}
    SIGHT     = 220
    SIGHT_SPR = 55
    FOV = {PATROL: math.radians(65),  ALERT:   math.radians(105),
           CHASE:  math.radians(130), INSPECT: math.radians(80),
           SEARCH: math.radians(90),  BRIEF:   math.radians(65),
           PANICKED: math.radians(110), COMBAT: math.radians(120)}

    SUSP_RISE_NEAR  = 2.5
    SUSP_RISE_FAR   = 0.8
    SUSP_RISE_NOLOS = 0.05
    SUSP_FALL       = 0.6
    SUSP_NEAR_PX    = 120
    SUSP_ALERT_THR  = 0.25

    NOISE_BASE_THRESH = 38
    RAD              = 13
    DOOR_VIEW_R      = 6

    MAX_RATCHET      = 3
    HOTSPOT_HEAT_CAP = 5
    WANDER_CHANCE    = 0.0003
    WANDER_RADIUS    = 3

    def __init__(self, waypoints, pause_flags, cols, rows, tile=TILE, wp_data=None):
        self.waypoints    = waypoints
        self.pause_flags  = pause_flags
        self.wp_data      = wp_data or [{}] * len(waypoints)
        self.cols         = cols
        self.rows         = rows
        self._tile        = tile
        self.door_check_r = tile * 5

        self.wp_idx    = 1 % len(waypoints)  # start targeting the NEXT waypoint
        self.x, self.y = float(waypoints[0][0]), float(waypoints[0][1])
        self.facing    = 0.0

        # state mirror – set from GOAP action name each frame
        self.state     = PATROL

        # suspicion / detection
        self.suspicion   = 0.0
        self.last_player = None   # pixel pos of last confirmed player position
        self._susp_mul   = 1.0   # ratchets up each chase

        # locomotion
        self.path        = []
        self.path_idx    = 0
        self.target_px   = None
        self._pause_t    = 0.0
        self._watch_target = None
        self._watch_t    = 0.0
        self.inspect_t   = 0.0

        # patrol A* cache
        self._patrol_path     = []
        self._patrol_path_idx = 0
        self._patrol_wp_tile  = None
        self._recovery_path     = None
        self._recovery_path_idx = 0

        # wander / hotspot memory
        self._wander_target  = None
        self._hotspot_heat   = {}
        self._trap_targets   = []
        self._trap_idx       = 0
        self._trap_t         = 0.0

        # search
        self._search_pts  = []
        self._search_idx  = 0

        # panicked sweep
        self._panicked_pts  = []
        self._panicked_idx  = 0
        self._panicked_peek = 0.0

        # combat
        self.has_gun            = False
        self._combat_t          = 0.0
        self._combat_last_shot  = 0.0
        self._cover_target      = None
        self._fired_shot        = False

        # briefing system
        self._brief_target    = None
        self._brief_stand_t   = 0.0
        self._brief_walk_t    = 0.0
        self._brief_t         = 0.0   # legacy alias
        self._brief_pending   = False
        self._brief_msg       = None
        self._brief_delivered = False
        self._brief_susp_bonus  = 0.0
        self._brief_wander_bonus= 0.0
        self._brief_check_bonus = 0.0
        self._briefed_by        = set()
        self.briefings_received = 0

        # radio hotspot (from chasing guard)
        self._radio_hotspot   = None
        self._radio_hotspot_t = 0.0

        # adaptive memory
        self._alert_count = 0

        # ambush
        self._ambush_target = None
        self._ambush_timer  = 0.0
        self._chase_lost_timer = 0.0   # how long guard has lost sight during chase
        self.knows_layout   = False
        self.ambusher       = False

        # muffled noise
        self._muffled_heat  = {}
        self._muffled_decay = 0.0
        self.MUFFLED_THRESH = 120
        self.MUFFLED_WINDOW = 12.0

        # doors
        self.known_door_states  = {}
        self.open_doors_seen    = []
        self.doors_to_close     = []
        self._door_close_timer  = 0.0
        self._self_opened_doors: dict = {}   # id(door) -> game_time opened
        self._doors_left_open:   dict = {}   # id(door) -> door obj (leaver left open)
        self._bashed_doors_seen: set  = set()  # id(door) -> already triggered search

        # ── Personality: "leaver" guards leave doors open and get suspicious if closed ──
        # ~30% chance; set at construction, can also be forced via level props
        self.is_leaver: bool = (random.random() < 0.30)
        # leaver close chance per encounter: low (~20%)
        self.LEAVER_CLOSE_CHANCE = 0.20

        # ── Personality: movement & combat preferences ─────────────────────────
        # walkaholic: prefers the longest patrol detour path (not during chase).
        #             15% chance. Can be forced via level obj prop "is_walkaholic".
        # brave:      gun guards only; barely uses cover, rushes player at full speed.
        #             10% chance among gun guards.
        # coward:     gun guards only; sprints to the FARTHEST cover they can find.
        #             10% chance among gun guards (exclusive with brave).
        # normal:     no flag — the common case.
        _walk_roll = random.random()
        self.is_walkaholic: bool = (_walk_roll < 0.15)
        _gun_roll = random.random()
        self.is_brave:  bool = (_gun_roll < 0.10)
        self.is_coward: bool = (not self.is_brave and _gun_roll < 0.20)

        # window-sighting chase detour: pixel position to route to before pursuing
        self._window_chase_target = None

        # watch node: tracks whether we've already triggered the look-pause this pass
        self._watch_node_triggered = False

        # stuck detection
        self._last_pos     = (0.0, 0.0)
        self._stuck_t      = 0.0
        self._stuck_repath = 0.0

        # noise destination
        self._noise_dest = None

        # refs set by Game
        self.walls_ref      = set()
        self.windows_ref    = set()
        self._all_doors_ref = []
        self._hides_ref     = set()

        # AI hint tile references (set by Game after construction)
        self.ai_cover_hints = set()   # preferred combat cover positions
        self.ai_choke_hints = set()   # positions to block/hold against player
        self.ai_avoid_hints = set()   # tiles guard should route around

        # game time reference – updated each tick via update(); initialised here
        # so code that runs before the first update() (e.g. door-closing logic)
        # always finds a valid value.
        self._game_time_ref = 0.0

        # callsign
        self.callsign = random.choice(GUARD_CALLSIGNS)

        # GOAP
        self._goap = GOAPAgent(GuardActionSet())
        self._goap.set(
            suspicion_low=False, suspicion_full=False,
            player_visible=False, player_near=False,
            has_last_known=False, noise_dest_set=False,
            at_dest=False,
            search_done=False, body_found=False,
            briefing_target=False, briefed=False,
            in_combat=False, player_caught=False,
            # team-up chase
            colleague_chasing=False, colleague_available=False,
            teammate_assigned=False, going_solo=False,
        )
        self._goap.add_goal(Goal("catch_player",   {"player_caught": True},  priority=3.0))
        self._goap.add_goal(Goal("end_combat",     {"in_combat": False},     priority=2.8))
        self._goap.add_goal(Goal("calm_body",      {"body_found": False},    priority=2.5))
        self._goap.add_goal(Goal("deliver_brief",  {"briefed": True},        priority=2.0))
        self._goap.add_goal(Goal("clear_noise",    {"noise_dest_set": False, "at_dest": False}, priority=1.5))
        self._goap.add_goal(Goal("find_player",    {"search_done": True},    priority=1.2))

        # team-up chase bookkeeping
        self._known_colleagues: set       = set()   # ids of guards this guard has seen
        self._chase_role:       str|None  = None    # "flanker" | "joiner" | "solo"
        self._chase_dest_tile:  object    = None    # last A* destination tile (jitter fix)
        self._flank_offset_t:   float     = 0.0     # timer to refresh flank angle

    # ── main update ───────────────────────────────────────────────────────

    def update(self, player, walls, closed_doors, noise_events,
               all_guards, doors, dt, search_points, windows=None,
               hides=None, game_time=0.0):
        self._all_doors_ref = doors
        self.windows_ref    = windows or set()
        self._hides_ref     = hides or set()
        self._game_time_ref = game_time

        # 1. Perception
        self._sense(player, walls, closed_doors, noise_events, all_guards, dt, windows)
        self._expire_self_opened_doors(game_time)
        self._decay_muffled_heat(dt)

        # Decay briefing bonuses slowly
        if self._brief_susp_bonus > 0:
            self._brief_susp_bonus   = max(0.0, self._brief_susp_bonus  - 0.008*dt)
        if self._brief_wander_bonus > 0:
            self._brief_wander_bonus = max(0.0, self._brief_wander_bonus - 0.005*dt)
        if self._brief_check_bonus > 0:
            self._brief_check_bonus  = max(0.0, self._brief_check_bonus  - 0.004*dt)

        # Radio hotspot decay
        if self._radio_hotspot_t > 0:
            self._radio_hotspot_t -= dt
            if self._radio_hotspot_t <= 0:
                self._radio_hotspot = None

        # 2. Push perception into GOAP world state
        self._sync_goap(player, all_guards, search_points)

        # 3. GOAP decides
        action_name = self._goap.tick()

        # 4. Map action name → FSM state label
        self._apply_state_label(action_name)

        # 5. Execute locomotion primitive
        done = self._execute(action_name, player, walls, closed_doors,
                             doors, dt, all_guards, search_points, game_time)
        if done:
            self._goap.complete_action()

        # 6. Scan for open/bashed doors AFTER _execute so self-opened doors are recorded
        self._scan_bashed_doors(doors, all_guards=all_guards)
        self._scan_open_doors(doors, all_guards=all_guards, game_time=game_time)

        # 7. Handle door closing & stuck detection
        self._handle_door_closing(doors, walls, dt)
        self._check_stuck(walls, dt)

    def _sync_goap(self, player, all_guards, search_points):
        susp_full = self.suspicion >= 1.0
        susp_low  = (not susp_full) and self.suspicion > self.SUSP_ALERT_THR

        player_near = (susp_full and self.last_player is not None and
                       dist(self.x, self.y,
                            self.last_player[0], self.last_player[1])
                       < self._tile * 1.5)

        # Brief: need a pending message and an available colleague
        brief_available = False
        if self._brief_pending and self._brief_msg:
            candidates = [g for g in all_guards
                          if g is not self
                          and g.state in (PATROL, ALERT, INSPECT)
                          and id(self) not in g._briefed_by]
            if candidates:
                if self._brief_target is None:
                    self._brief_target = min(
                        candidates, key=lambda g: dist(self.x, self.y, g.x, g.y))
                brief_available = True

        # Colleague awareness: register any guard in our discovered tile neighbourhood
        t = self._tile
        for g in all_guards:
            if g is self: continue
            if ptile(g.x, g.y, t) in self._discovered_tiles:
                self._known_colleagues.add(id(g))

        known_guards    = [g for g in all_guards
                           if g is not self and id(g) in self._known_colleagues]
        col_chasing     = any(g.state == CHASE for g in known_guards)
        col_available   = any(g.state in (PATROL, ALERT) for g in known_guards)

        # Reset team-up assignment whenever we leave CHASE so it's fresh next time
        if self.state != CHASE:
            self._goap.world["teammate_assigned"] = False
            self._goap.world["going_solo"]        = False
            self._chase_role   = None
            self._chase_dest_tile = None

        self._goap.set(
            suspicion_low   = susp_low,
            suspicion_full  = susp_full,
            player_visible  = (self.last_player is not None and susp_full),
            player_near     = player_near,
            has_last_known  = (self.last_player is not None),
            noise_dest_set  = (self._noise_dest is not None),
            body_found      = self._goap.get("body_found", False),
            briefing_target = brief_available,
            in_combat       = self._goap.get("in_combat", False),
            colleague_chasing  = col_chasing,
            colleague_available= col_available,
        )

    def _apply_state_label(self, action_name):
        label_map = {
            "patrol_walk":         PATROL,
            "investigate_sight":   ALERT,
            "investigate_noise":   ALERT,
            "inspect_spot":        INSPECT,
            "chase":               CHASE,
            "team_up_chase":       CHASE,
            "join_chase":          CHASE,
            "arrest":              CHASE,
            "search_walk":         SEARCH,
            "search_inspect":      INSPECT,
            "end_search":          PATROL,
            "panicked_sweep":      PANICKED,
            "combat_cover":        COMBAT,
            "combat_fire":         COMBAT,
            "combat_wait":         COMBAT,
            "brief_walk":          BRIEF,
            "brief_deliver":       BRIEF,
            "brief_done":          PATROL,
        }
        self.state = label_map.get(action_name, self.state)

    def _execute(self, action_name, player, walls, closed_doors,
                 doors, dt, all_guards, search_points, game_time):
        """Dispatch to locomotion primitives. Returns True when done."""

        if action_name == "patrol_walk":
            return self._loco_patrol(walls, doors, dt)

        if action_name == "investigate_sight":
            if self.last_player is None:
                return True
            # divert to radio hotspot first if present
            dest = self._radio_hotspot or self.last_player
            self.target_px = dest
            done = self._walk_path(walls, closed_doors, dest,
                                   self.SPD[ALERT], doors=doors)
            if done:
                self.inspect_t = 1.5
                # keep last_player known until inspect_spot clears it
            return done

        if action_name == "investigate_noise":
            if self._noise_dest is None:
                return True
            self.target_px = self._noise_dest
            done = self._walk_path(walls, closed_doors, self._noise_dest,
                                   self.SPD[ALERT], doors=doors)
            if done:
                self._noise_dest = None
                self.inspect_t   = 1.5
            return done

        if action_name == "inspect_spot":
            self.inspect_t -= dt
            self.facing    += dt * 2.5
            if self.inspect_t <= 0:
                # Learn current door states
                for d in self._all_doors_ref:
                    self.known_door_states[d.tile_pos()] = d.open
                return True
            return False

        if action_name in ("chase", "team_up_chase", "join_chase"):
            return self._loco_chase(player, walls, closed_doors, doors, dt, all_guards)

        if action_name == "arrest":
            # Terminal – the game loop checks player_caught in GOAP world state
            return True

        if action_name == "search_walk":
            if not self._search_pts:
                # Build search list from last known position + search_points
                pts = list(search_points)
                if self.last_player:
                    lp = self.last_player
                    near = sorted(pts, key=lambda p: dist(lp[0], lp[1], p[0], p[1]))
                    pts  = near
                random.shuffle(pts[:max(1, len(pts)//2)])
                self._search_pts = pts
                self._search_idx = 0
            if self._search_idx >= len(self._search_pts):
                return True
            dest = self._search_pts[self._search_idx]
            done = self._walk_path(walls, closed_doors, dest,
                                   self.SPD[SEARCH], doors=doors)
            if done:
                self._search_idx += 1
                self.inspect_t = 1.2
            return done

        if action_name == "search_inspect":
            self.inspect_t -= dt
            self.facing    += dt * 2.0
            return self.inspect_t <= 0

        if action_name == "end_search":
            self._search_pts  = []; self._search_idx = 0
            self.last_player  = None
            self._rebuild_trap_targets()
            self._recover_patrol_path()
            # Queue brief if pending
            if self._brief_pending and self._brief_msg:
                self._goap.set(briefing_target=True)
            return True

        if action_name == "panicked_sweep":
            return self._loco_panicked(walls, closed_doors, doors, dt)

        if action_name == "combat_cover":
            return self._loco_combat_cover(walls, closed_doors, doors, dt)

        if action_name == "combat_fire":
            self._combat_t -= dt
            if self._combat_t <= 0:
                self._goap.set(in_combat=False)
                self._combat_t = 0.0
                return True
            if self.last_player:
                px_, py_ = self.last_player
                target_ang = math.atan2(py_ - self.y, px_ - self.x)
                self.facing += adiff(target_ang, self.facing) * min(1.0, dt * 4.0)
                if self.has_gun:
                    self._combat_last_shot -= dt
                    if self._combat_last_shot <= 0:
                        self._combat_last_shot = 2.0 + random.uniform(0, 2.0)
                        self._fired_shot = True
            return False

        if action_name == "combat_wait":
            self._combat_t -= dt
            self.facing    += dt * 0.5
            if self._combat_t <= 0:
                self._goap.set(in_combat=False, at_dest=False)
                self._combat_t = 0.0
                return True
            return False

        if action_name == "brief_walk":
            return self._loco_brief_walk(walls, doors, dt, all_guards)

        if action_name == "brief_deliver":
            return self._loco_brief_deliver(walls, dt, all_guards)

        if action_name == "brief_done":
            self._brief_pending   = False
            self._brief_msg       = None
            self._brief_target    = None
            self._brief_delivered = True
            self.last_player      = None
            self._rebuild_trap_targets()
            self._recover_patrol_path()
            return True

        return False

    # ── locomotion primitives ─────────────────────────────────────────────

    def _loco_patrol(self, walls, doors, dt):
        """Walk the waypoint loop. Returns True on each waypoint arrival."""
        if self._pause_t > 0:
            self._pause_t -= dt
            if self._watch_target and self._watch_t > 0:
                wx, wy = self._watch_target
                ta = math.atan2(wy - self.y, wx - self.x)
                self.facing += adiff(ta, self.facing) * min(1.0, dt * 3.0)
                self._watch_t -= dt
            else:
                self.facing += dt * 0.8
            return False

        if self._recovery_path:
            self._walk_recovery(walls, doors, self.SPD[PATROL])
            return False

        # Radio hotspot detour
        if self._radio_hotspot and self._radio_hotspot_t > 0:
            done = self._walk_path(walls, set(), self._radio_hotspot,
                                   self.SPD[PATROL], doors=doors)
            if done: self._radio_hotspot = None
            return False

        if self._wander_target:
            done = self._walk_path(walls, set(), self._wander_target,
                                   self.SPD[PATROL], doors=doors)
            if done:
                self._wander_target = None
                self._recover_patrol_path()
            return False

        self._trap_t = max(0.0, self._trap_t - dt)
        if self._trap_targets and self._trap_t <= 0 and random.random() < 0.08:
            self._trap_idx = (self._trap_idx + 1) % len(self._trap_targets)
            self._wander_target = self._trap_targets[self._trap_idx]
            self._trap_t = 45.0
            return False

        return self._follow_patrol_wp(walls, doors, dt, game_time=getattr(self, "_game_time_ref", 0.0))

    def _loco_wait(self, dt):
        if self._pause_t <= 0:
            return True
        self._pause_t -= dt
        self.facing   += dt * 0.4
        return self._pause_t <= 0

    def _loco_chase(self, player, walls, closed_doors, doors, dt, all_guards):
        """Chase player. Jitter-fixed (path only rebuilt on destination tile change).
        GOAP-aware: assigns flanker/joiner/solo role on first tick; coordinates
        with known colleagues to bracket the player from different angles."""
        if self.last_player is None:
            return True   # lost — GOAP will transition to search

        # Window-sighting detour: route to the guard-side window tile first.
        wct = getattr(self, '_window_chase_target', None)
        if wct is not None:
            self.suspicion = 1.0
            done = self._walk_path(walls, closed_doors, wct,
                                   self.SPD[CHASE], doors=doors)
            if done:
                self._window_chase_target = None
            return False

        # Keep suspicion pinned and refresh last_player while player is visible
        in_sight = (
            dist(self.x, self.y, player.x, player.y) <= self.SIGHT and
            not player.hidden and
            los_check(walls, self.x, self.y, player.x, player.y,
                      closed_doors, self.windows_ref)
        )
        if in_sight:
            self.last_player = (player.x, player.y)
            self.suspicion = 1.0
            self._chase_lost_timer = 0.0
        else:
            self._chase_lost_timer += dt

        # ── Assign chase role via GOAP on first tick ──────────────────────────
        if self._chase_role is None:
            cur = self._goap.current_action()
            action_name = cur.name if cur else "chase"
            known_guards = [g for g in all_guards
                            if g is not self and id(g) in self._known_colleagues]

            if action_name == "team_up_chase" and not self._goap.get("teammate_assigned"):
                free = [g for g in known_guards if g.state in (PATROL, ALERT)]
                if free and self.last_player:
                    teammate = min(free, key=lambda g: dist(self.x, self.y, g.x, g.y))
                    teammate.last_player = self.last_player
                    teammate.suspicion   = 1.0
                    teammate._chase_role = "joiner"
                    teammate._known_colleagues.add(id(self))
                    if teammate.state != CHASE:
                        teammate._goap.set(suspicion_full=True, has_last_known=True)
                    self._chase_role = "flanker"
                    self._goap.world["teammate_assigned"] = True
                else:
                    self._chase_role = "solo"

            elif action_name == "join_chase":
                self._chase_role = "joiner"
                self._goap.world["teammate_assigned"] = True

            else:
                self._chase_role = "solo"

        # ── Pick movement target based on role ────────────────────────────────
        self._ambush_timer -= dt

        if self._chase_role == "flanker":
            self._flank_offset_t -= dt
            if self._ambush_target and self._flank_offset_t > 0:
                target = self._ambush_target
            else:
                self._flank_offset_t = 3.5 + abs(hash(id(self)) % 3)
                base = self._pick_ambush(player, walls, closed_doors) or self.last_player
                dx = base[0] - self.x;  dy = base[1] - self.y
                n  = math.hypot(dx, dy) or 1
                fx = max(0, min(self.cols*self._tile-1, base[0] + (-dy/n)*self._tile*4))
                fy = max(0, min(self.rows*self._tile-1, base[1] + ( dx/n)*self._tile*4))
                ft = ptile(fx, fy, self._tile)
                self._ambush_target = (fx, fy) if ft not in walls else base
            target = self._ambush_target or self.last_player

        elif self._chase_role == "joiner":
            if self._ambush_timer <= 0 and self.last_player:
                self._ambush_timer = 5.0 + abs(hash(id(self)) % 3)
                self._ambush_target = self._pick_ambush(player, walls, closed_doors)
            target = self._ambush_target or self.last_player

        else:  # solo — run straight at last known position, no prediction noise
            if self.ambusher or self.knows_layout:
                # Ambushers/layout-aware guards predict; update only when tile changes
                if self._ambush_timer <= 0:
                    interval = 4.0 + 2.0 * abs(hash(id(self)) % 3)
                    self._ambush_timer = interval * 0.4
                    new_amb = self._pick_ambush(player, walls, closed_doors)
                    if new_amb:
                        new_tile = ptile(new_amb[0], new_amb[1], self._tile)
                        cur_tile = ptile(*self._ambush_target, self._tile) if self._ambush_target else None
                        if new_tile != cur_tile:
                            self._ambush_target = new_amb
                target = self._ambush_target if self._ambush_target else self.last_player
            else:
                # Plain guard: beeline directly to last known player position.
                # No prediction — prediction is what causes the jitter.
                self._ambush_target = None
                target = self.last_player

        # ── Walk — only rebuild A* path when destination tile actually changes ─
        if target:
            new_dest_tile = ptile(target[0], target[1], self._tile)
            if self._chase_dest_tile != new_dest_tile:
                self._chase_dest_tile = new_dest_tile
                self.path = []; self.path_idx = 0
            done = self._walk_path(walls, closed_doors, target,
                                   self.SPD[CHASE], doors=doors)
            if done and target is self._ambush_target:
                self._ambush_target   = None
                self._chase_dest_tile = None

        # Lost player — keep running to last known spot for up to 8s.
        # Only give up once the guard actually arrives there (or timer expires
        # and there's nowhere left to go).
        if self._chase_lost_timer >= 8.0:
            at_last = (self.last_player is not None and
                       dist(self.x, self.y,
                            self.last_player[0], self.last_player[1]) < self._tile * 1.2)
            if at_last or self.last_player is None:
                self._chase_lost_timer = 0.0
                self._alert_count += 1
                self._goap.set(suspicion_full=False, player_near=False,
                               has_last_known=(self.last_player is not None))
                if self.last_player:
                    self._build_search_from(self.last_player)
        return False

    def _loco_combat_cover(self, walls, closed_doors, doors, dt):
        if self._cover_target is None:
            return True
        done = self._walk_path(walls, closed_doors, self._cover_target,
                               self.SPD[COMBAT] * 1.3, doors=doors)
        return done

    def _loco_brief_walk(self, walls, doors, dt, all_guards):
        if self._brief_target is None:
            return True
        if self._brief_target.state in (CHASE, BRIEF):
            # target busy — abort
            self._brief_pending = False; self._brief_msg = None
            return True
        tgt_tile = ptile(self._brief_target.x, self._brief_target.y, self._tile)
        tgt_px   = tc(tgt_tile[0], tgt_tile[1], self._tile)
        d = dist(self.x, self.y, self._brief_target.x, self._brief_target.y)
        if d < self._tile * 1.5:
            return True
        self._walk_path(walls, set(), tgt_px, self.SPD[BRIEF], doors=doors)
        # watchdog
        self._brief_walk_t += dt
        self._brief_t = self._brief_walk_t
        if self._brief_walk_t > 20.0:
            self._brief_pending = False; self._brief_msg = None
            self._brief_target  = None; self._brief_walk_t = 0.0
            return True
        return False

    def _loco_brief_deliver(self, walls, dt, all_guards):
        if self._brief_target is None:
            return True
        target_ang = math.atan2(self._brief_target.y - self.y,
                                self._brief_target.x - self.x)
        self.facing += adiff(target_ang, self.facing) * min(1.0, dt * 4.0)
        self._brief_stand_t += dt
        if self._brief_stand_t >= 1.5:
            urgency, last_pos = self._brief_msg
            self._brief_target._receive_briefing(self, urgency, last_pos)
            if urgency >= URG_SPOTTED and not self._brief_target._brief_pending:
                self._brief_target._brief_pending = True
                self._brief_target._brief_msg = (max(URG_SUSPICIOUS, urgency-1), last_pos)
            self._brief_stand_t = 0.0
            return True
        return False

    def _loco_panicked(self, walls, closed_doors, doors, dt):
        spd = self.SPD[PANICKED]
        if self._panicked_peek > 0:
            self._panicked_peek -= dt
            self.facing += dt * 3.5
            return False
        if not self._panicked_pts or self._panicked_idx >= len(self._panicked_pts):
            self._rebuild_trap_targets()
            self._recover_patrol_path()
            return True
        done = self._walk_path(walls, closed_doors,
                               self._panicked_pts[self._panicked_idx], spd, doors=doors)
        if done:
            self._panicked_idx  += 1
            self._panicked_peek  = random.uniform(0.3, 0.7)
        return False

    def _follow_patrol_wp(self, walls, doors, dt, game_time=0.0):
        """A*-guided step toward current waypoint. Returns True on arrival.

        Watch nodes are modifier waypoints — the guard does NOT walk to them.
        Instead, while within trigger_dist, the guard steers its facing toward
        watch_px and immediately advances wp_idx past the watch node so patrol
        flow continues uninterrupted.
        """
        if not self.waypoints: return False
        # Single-waypoint guard: just stand (or wander via hotspot/wander logic above)
        if len(self.waypoints) == 1:
            return False
        wp_idx = self.wp_idx
        wp     = self.waypoints[wp_idx]
        wd     = self.wp_data[wp_idx] if wp_idx < len(self.wp_data) else {}
        ntype  = wd.get("type", "waypoint")
        dx, dy = wp[0]-self.x, wp[1]-self.y
        d      = math.hypot(dx, dy)
        spd    = self.SPD[PATROL]

        # ── Watch node: don't walk to it; steer facing when in range then skip ──
        if ntype == "watch":
            trigger = wd.get("trigger_dist", 4) * self._tile
            if d <= trigger:
                # Face the watch target
                wx2, wy2 = wd.get("watch_px", wp)
                ta = math.atan2(wy2 - self.y, wx2 - self.x)
                self.facing += adiff(ta, self.facing) * min(1.0, dt * 3.0)
                # Schedule a brief look-pause on the current position, then advance
                if not getattr(self, '_watch_node_triggered', False):
                    self._watch_node_triggered = True
                    lt = wd.get("look_time", 1.5)
                    self._pause_t      = lt
                    self._watch_t      = lt
                    self._watch_target = (wx2, wy2)
                    # Advance past the watch node NOW so we don't walk to it
                    self.wp_idx = (wp_idx + 1) % len(self.waypoints)
                    self._patrol_path = []; self._patrol_path_idx = 0
                    return True
            else:
                # Haven't entered range yet — reset trigger flag and continue patrol
                self._watch_node_triggered = False
                # Skip this watch node and head to the next real waypoint
                self.wp_idx = (wp_idx + 1) % len(self.waypoints)
                self._patrol_path = []; self._patrol_path_idx = 0
            return False

        # Reset watch trigger flag when we move past a watch node
        self._watch_node_triggered = False

        if d < spd + 1:
            pause = self.pause_flags[wp_idx] if self.pause_flags else False
            if ntype == "waitpoint" or pause:
                self._pause_t = random.uniform(wd.get("wait_min", 2.5),
                                               wd.get("wait_max", 5.0))
            elif ntype == "check":
                base_chance = wd.get("check_chance", 60) / 100.0
                effective   = min(1.0, base_chance + self._brief_check_bonus)
                if wd.get("always_check", False) or random.random() < effective:
                    self._pause_t  = wd.get("check_time", 2.0)
                    self.inspect_t = self._pause_t
            # curiosity wander
            effective_wander = self.WANDER_CHANCE + self._brief_wander_bonus
            if (ntype not in ("watch", "check") and not self._wander_target
                    and random.random() < effective_wander and self._trap_t <= 0):
                ox = random.randint(-self.WANDER_RADIUS, self.WANDER_RADIUS) * self._tile
                oy = random.randint(-self.WANDER_RADIUS, self.WANDER_RADIUS) * self._tile
                wx = max(self._tile, min((self.cols-1)*self._tile, wp[0]+ox))
                wy = max(self._tile, min((self.rows-1)*self._tile, wp[1]+oy))
                if ptile(wx, wy, self._tile) not in self.walls_ref:
                    self._wander_target = (wx, wy)
            self.wp_idx = (self.wp_idx + 1) % len(self.waypoints)
            self._patrol_path = []; self._patrol_path_idx = 0
            return True
        else:
            wp_tile = ptile(wp[0], wp[1], self._tile)
            my_tile = ptile(self.x,  self.y,  self._tile)
            if (not self._patrol_path or
                    getattr(self, '_patrol_wp_tile', None) != wp_tile):
                # ai_avoid_hints: treat as extra blocked tiles for patrol routing
                _avoid = getattr(self, 'ai_avoid_hints', set())
                _walls_av = walls | _avoid if _avoid else walls
                if getattr(self, 'is_walkaholic', False):
                    self._patrol_path = (
                        astar_longest(_walls_av, my_tile, wp_tile, self.cols, self.rows) or [])
                else:
                    self._patrol_path = (
                        astar(_walls_av, my_tile, wp_tile, self.cols, self.rows) or [])
                self._patrol_path_idx = 0
                self._patrol_wp_tile  = wp_tile
            pp = self._patrol_path; pidx = self._patrol_path_idx
            if pp and pidx < len(pp):
                nt = pp[pidx]
                self._open_blocking_door(nt, doors, game_time)
                tx_px, ty_px = tc(nt[0], nt[1], self._tile)
                nd = dist(self.x, self.y, tx_px, ty_px)
                if nd < spd + 1:
                    self._patrol_path_idx = pidx + 1
                else:
                    ndx, ndy = (tx_px-self.x)/nd, (ty_px-self.y)/nd
                    self._step(ndx*spd, ndy*spd, walls, set())
                    self.facing = math.atan2(ndy, ndx)
            else:
                # A* failed or guard is on goal tile — nudge directly toward waypoint
                if d > 0:
                    self._step(dx/d*spd, dy/d*spd, walls, set())
                    self.facing = math.atan2(dy, dx)
                    # _check_stuck handles repath after 0.4 s if still stuck
        return False

    # ── sensing ───────────────────────────────────────────────────────────

    def _sense(self, player, walls, closed_doors, noise_events, all_guards, dt, windows):
        self._player_just_hid = getattr(player, '_just_hid', False)
        if not player.hidden:
            self._try_see(player, walls, closed_doors, all_guards, dt, windows)
        else:
            self._check_witness_hide(player, walls, closed_doors, all_guards, windows)
            self.suspicion = max(0.0, self.suspicion - 1.5 * dt)
        self._try_hear(noise_events, all_guards, walls, windows)

    def _try_see(self, player, walls, closed_doors, all_guards, dt, windows):
        sight = self.SIGHT + (self.SIGHT_SPR if player.sprinting else 0)
        d = dist(self.x, self.y, player.x, player.y)
        in_fov = False
        window_tiles_hit: set = set()
        if d <= sight:
            ang = math.atan2(player.y - self.y, player.x - self.x)
            if abs(adiff(ang, self.facing)) <= self.FOV.get(self.state, math.radians(65)):
                in_fov, window_tiles_hit = los_check_windows_hit(
                    walls, self.x, self.y, player.x, player.y,
                    closed_doors, windows)
        if in_fov:
            rate = self.SUSP_RISE_NEAR if d < self.SUSP_NEAR_PX else self.SUSP_RISE_FAR
            if player.sprinting: rate *= 2.0
            rate *= self._susp_mul
            self.suspicion   = min(1.0, self.suspicion + rate * dt)
            self.last_player = (player.x, player.y)
            # If the sighting ray passed through a window, remember the nearest
            # accessible tile on THIS side of the window so chase pathfinds to
            # where the guard can actually reach the player, not through glass.
            if window_tiles_hit:
                self._window_chase_target = self._pick_window_approach(
                    window_tiles_hit, walls)
            else:
                self._window_chase_target = None
            # Record hotspot
            ht = ptile(player.x, player.y, self._tile)
            self._hotspot_heat[ht] = self._hotspot_heat.get(ht, 0) + 1
            if self.suspicion >= 1.0:
                # Ratchet
                self._alert_count += 1
                ratchet = min(self._alert_count, self.MAX_RATCHET)
                self._susp_mul = 1.0 + ratchet * 0.25 + self._brief_susp_bonus
                # Alert nearby guards (quick shout)
                for g in all_guards:
                    if g is not self and g.state == PATROL:
                        if dist(self.x, self.y, g.x, g.y) < self._tile * 3:
                            g._goap.set(has_last_known=True)
                            g.last_player = self.last_player
                # Queue brief
                self._brief_pending = True
                self._brief_msg     = (URG_SPOTTED, self.last_player)
        else:
            self.suspicion = max(0.0, self.suspicion - self.SUSP_FALL * dt)
            if self.suspicion < 0.05:
                self.last_player = None
                self._window_chase_target = None

    def _pick_window_approach(self, window_tiles, walls):
        """Return the pixel-centre of the closest non-wall tile adjacent to any
        of the given window tiles, on the guard's side (nearest to self)."""
        tile = self._tile
        best_px = None
        best_d  = float('inf')
        for wt in window_tiles:
            wx, wy = wt
            for ddx, ddy in DIRS4:
                cand = (wx + ddx, wy + ddy)
                if cand in walls or cand in window_tiles:
                    continue
                if not (0 <= cand[0] < self.cols and 0 <= cand[1] < self.rows):
                    continue
                cpx = cand[0] * tile + tile // 2
                cpy = cand[1] * tile + tile // 2
                cd = dist(self.x, self.y, cpx, cpy)
                if cd < best_d:
                    best_d  = cd
                    best_px = (cpx, cpy)
        return best_px

    def _check_witness_hide(self, player, walls, closed_doors, all_guards, windows):
        if self.state in (CHASE, SEARCH): return
        if not getattr(self, '_player_just_hid', False): return
        d = dist(self.x, self.y, player.x, player.y)
        if d > self.SIGHT: return
        ang = math.atan2(player.y - self.y, player.x - self.x)
        if abs(adiff(ang, self.facing)) > self.FOV.get(self.state, math.radians(65)): return
        if los_check(walls, self.x, self.y, player.x, player.y, closed_doors, windows):
            self.last_player = (player.x, player.y)
            self.suspicion   = 1.0
            ratchet = min(self._alert_count, self.MAX_RATCHET)
            self._susp_mul   = 1.0 + ratchet * 0.25 + self._brief_susp_bonus

    def _try_hear(self, noise_events, all_guards, walls, windows):
        if self.state in (CHASE, PANICKED): return
        for ne in noise_events:
            if ne.visual_only: continue
            d = dist(self.x, self.y, ne.x, ne.y)
            if d > ne.radius: continue
            wall_count = count_walls_between(walls, windows,
                                             self.x, self.y, ne.x, ne.y, self._tile)
            effective_score = ne.score * (WALL_DAMP_PER_WALL ** wall_count)
            if effective_score >= self.NOISE_BASE_THRESH:
                dest = (ne.x, ne.y)
                if ne.ambiguous:
                    jitter = self._tile * 3
                    dest = (ne.x + random.uniform(-jitter, jitter),
                            ne.y + random.uniform(-jitter, jitter))
                if getattr(ne, 'is_gunshot', False):
                    self._trigger_combat(dest, all_guards)
                elif self._noise_dest is None:
                    self._noise_dest = dest
                    ht = ptile(ne.x, ne.y, self._tile)
                    self._hotspot_heat[ht] = self._hotspot_heat.get(ht, 0) + 1
                    if effective_score >= NOISE_GLOBAL:
                        for g in all_guards:
                            if g is not self and g.state == PATROL and g._noise_dest is None:
                                g._noise_dest = dest
            elif wall_count > 0 and effective_score > 4:
                nt = ptile(ne.x, ne.y, self._tile)
                self._muffled_heat[nt] = self._muffled_heat.get(nt, 0) + effective_score
                if self._muffled_heat[nt] >= self.MUFFLED_THRESH:
                    if self._noise_dest is None:
                        self._noise_dest = (
                            ne.x + random.uniform(-self._tile, self._tile),
                            ne.y + random.uniform(-self._tile, self._tile))
                    self._muffled_heat[nt] = 0

    def _trigger_combat(self, shot_origin, all_guards):
        self._combat_t = 12.0
        self._combat_last_shot = 0.0
        self._fired_shot = False

        tile = self._tile; my_t = ptile(self.x, self.y, tile)

        # ── Brave guards: skip cover entirely, rush straight at the player ──
        if getattr(self, 'is_brave', False):
            self._cover_target = None
            self._goap.set(in_combat=True, at_dest=False)
            if shot_origin:
                for g in all_guards:
                    if g is not self and g.state == PATROL:
                        if math.hypot(g.x - self.x, g.y - self.y) < tile * 8:
                            g.last_player = shot_origin
                            g._goap.set(in_combat=True, at_dest=False,
                                        has_last_known=True)
                            g._cover_target = None
                            g._combat_t = 10.0
            return

        # ── Score cover candidates ─────────────────────────────────────────
        # Normal: nearest tile with most adjacent walls.
        # Coward: farthest tile from shot origin with at least one adjacent wall.
        # ai_coverhint tiles receive a large bonus regardless of adjacency.
        is_coward = getattr(self, 'is_coward', False)
        search_r  = 8 if is_coward else 4
        sx = shot_origin[0] if shot_origin else self.x
        sy = shot_origin[1] if shot_origin else self.y
        _cover_hints = getattr(self, 'ai_cover_hints', set())

        best_cover = None
        best_score = -1
        for dc in range(-search_r, search_r + 1):
            for dr in range(-search_r, search_r + 1):
                cand = (my_t[0] + dc, my_t[1] + dr)
                if cand in self.walls_ref: continue
                if not (0 <= cand[0] < self.cols and 0 <= cand[1] < self.rows): continue
                wall_adj = sum(1 for dd in [(-1,0),(1,0),(0,-1),(0,1)]
                               if (cand[0]+dd[0], cand[1]+dd[1]) in self.walls_ref)
                # ai_coverhint bonus: treat as 8 extra adjacent walls
                hint_bonus = 8.0 * tile if cand in _cover_hints else 0.0
                if is_coward:
                    if wall_adj < 1 and cand not in _cover_hints: continue
                    far_d = math.hypot(cand[0]*tile - sx, cand[1]*tile - sy)
                    score = far_d + wall_adj * tile + hint_bonus
                else:
                    score = float(wall_adj) + hint_bonus
                if score > best_score:
                    best_score = score
                    best_cover = (cand[0]*tile + tile//2, cand[1]*tile + tile//2)

        self._cover_target = best_cover
        self._goap.set(in_combat=True, at_dest=False)
        if shot_origin:
            for g in all_guards:
                if g is not self and g.state == PATROL:
                    if math.hypot(g.x-self.x, g.y-self.y) < tile * 8:
                        g.last_player = shot_origin
                        g._goap.set(in_combat=True, at_dest=False,
                                    has_last_known=True)
                        g._cover_target = best_cover
                        g._combat_t = 10.0

    # ── called by Game for external triggers ──────────────────────────────

    def go_panicked(self, body_pos, all_guards):
        if self.state in (CHASE, PANICKED): return
        tile = self._tile; bx, by = body_pos; pts = []
        for dx in range(-3, 4):
            for dy in range(-3, 4):
                if abs(dx) + abs(dy) < 1: continue
                wx = bx + dx*tile; wy = by + dy*tile
                t2 = (int(wx//tile), int(wy//tile))
                if t2 not in self.walls_ref:
                    pts.append((wx, wy))
        random.shuffle(pts)
        self._panicked_pts  = pts[:12]
        self._panicked_idx  = 0
        self._panicked_peek = 0.0
        self._goap.set(body_found=True)

    def go_combat(self, shot_origin, all_guards):
        self._trigger_combat(shot_origin, all_guards)

    def go_search(self, search_points):
        pts = list(search_points); random.shuffle(pts)
        self._search_pts = pts; self._search_idx = 0
        self._goap.set(has_last_known=True, search_done=False,
                       suspicion_full=False)

    # ── briefing receive ──────────────────────────────────────────────────

    def _receive_briefing(self, sender, urgency, last_pos):
        if id(sender) in self._briefed_by: return
        self._briefed_by.add(id(sender))
        self.briefings_received += 1
        if last_pos:
            ht = ptile(last_pos[0], last_pos[1], self._tile)
            self._hotspot_heat[ht] = self._hotspot_heat.get(ht, 0) + urgency*2
            self._radio_hotspot   = last_pos
            self._radio_hotspot_t = 8.0 + urgency * 4.0
        if urgency >= URG_SUSPICIOUS:
            self._brief_susp_bonus   = min(0.5,  self._brief_susp_bonus  + 0.15)
            self._brief_wander_bonus = min(0.25, self._brief_wander_bonus + 0.08)
        if urgency >= URG_SPOTTED:
            self._brief_susp_bonus   = min(0.75, self._brief_susp_bonus  + 0.20)
            self._brief_wander_bonus = min(0.35, self._brief_wander_bonus + 0.10)
            self._brief_check_bonus  = min(0.4,  self._brief_check_bonus  + 0.15)
            if last_pos and self.state == PATROL:
                self._noise_dest = last_pos
                self._goap.set(noise_dest_set=True)
        if urgency >= URG_EMERGENCY:
            self._brief_susp_bonus   = min(1.0, self._brief_susp_bonus  + 0.30)
            self._brief_wander_bonus = min(0.5, self._brief_wander_bonus + 0.15)
            self._brief_check_bonus  = min(0.6, self._brief_check_bonus  + 0.20)
            if last_pos and self.state == PATROL:
                self._build_search_from(last_pos)
        self._susp_mul = max(self._susp_mul, 1.0 + self._brief_susp_bonus)

    def _build_search_from(self, pos):
        SWEEP_R = self._tile * 4
        hx, hy  = pos
        pts = []
        for dc in range(-3, 4):
            for dr in range(-3, 4):
                tc2 = (ptile(hx, hy, self._tile)[0]+dc,
                       ptile(hx, hy, self._tile)[1]+dr)
                if tc2 not in self.walls_ref:
                    px2, py2 = (tc2[0]*self._tile+self._tile//2,
                                tc2[1]*self._tile+self._tile//2)
                    if dist(hx, hy, px2, py2) <= SWEEP_R:
                        pts.append((px2, py2))
        if pts:
            random.shuffle(pts)
            self._search_pts = pts[:5]
            self._search_idx = 0
            self._goap.set(has_last_known=True, search_done=False, suspicion_full=False)

    # ── ambush prediction ─────────────────────────────────────────────────

    def _pick_ambush(self, player, walls, closed_doors):
        if not self.last_player: return None
        if self.knows_layout or self.ambusher:
            best_intercept = None; best_adv = -9999
            my_tile = ptile(self.x, self.y, self._tile)
            pl_tile = ptile(player.x, player.y, self._tile)
            for steps_ahead in range(3, 14, 2):
                fwd = player.SPD_SPRINT * steps_ahead * 4
                pred_x = player.x + math.cos(player.facing) * fwd
                pred_y = player.y + math.sin(player.facing) * fwd
                pred_x = max(0, min(self.cols*self._tile-1, pred_x))
                pred_y = max(0, min(self.rows*self._tile-1, pred_y))
                pred_tile = ptile(pred_x, pred_y, self._tile)
                if pred_tile in walls: continue
                gp = astar(walls, my_tile, pred_tile, self.cols, self.rows)
                pp = astar(walls, pl_tile, pred_tile, self.cols, self.rows)
                if gp is None or pp is None: continue
                adv = len(pp) - len(gp)
                if adv > best_adv:
                    best_adv = adv; best_intercept = (pred_x, pred_y)
            if best_intercept and best_adv >= -2:
                return best_intercept
            return self.last_player
        fwd = player.SPD_SPRINT * 90
        pred_x = player.x + math.cos(player.facing)*fwd
        pred_y = player.y + math.sin(player.facing)*fwd
        pred_x = max(0, min(self.cols*self._tile-1, pred_x))
        pred_y = max(0, min(self.rows*self._tile-1, pred_y))
        pt = ptile(pred_x, pred_y, self._tile)
        if pt in walls or pt in closed_doors: return self.last_player
        return (pred_x, pred_y)

    # ── door logic ────────────────────────────────────────────────────────

    def _scan_bashed_doors(self, doors, all_guards=None):
        """Run every frame regardless of state — bashed doors trigger immediate search."""
        t = self._tile
        my_col, my_row = ptile(self.x, self.y, t)
        for d in doors:
            if not getattr(d, 'bashed', False): continue
            if id(d) in self._bashed_doors_seen: continue
            dpx, dpy = tc(d.col, d.row, t)
            in_range = (abs(d.col - my_col) <= self.DOOR_VIEW_R and
                        abs(d.row - my_row) <= self.DOOR_VIEW_R)
            if not in_range: continue
            has_los = los_check(self.walls_ref, self.x, self.y, dpx, dpy,
                                windows=self.windows_ref)
            if not has_los: continue
            self._bashed_doors_seen.add(id(d))
            self._build_search_from((dpx, dpy))
            self._goap.set(has_last_known=True, search_done=False)
            for g in (all_guards or []):
                if g is not self and g.state == PATROL:
                    if dist(self.x, self.y, g.x, g.y) < t * 8:
                        g._build_search_from((dpx, dpy))
                        g._goap.set(has_last_known=True, search_done=False)

    def _scan_open_doors(self, doors, all_guards=None, game_time=0.0):
        if self.state != PATROL: return
        all_guards = all_guards or []
        t = self._tile
        my_col, my_row = ptile(self.x, self.y, t)

        # Collect door ids any guard opened (including self) — skip those
        guard_opened_ids = set()
        for g in all_guards:
            guard_opened_ids |= set(g._self_opened_doors.keys())

        for d in doors:
            if d.original_open: continue            # always-open doors are fine
            if d in self.open_doors_seen or d in self.doors_to_close: continue

            dpx, dpy = tc(d.col, d.row, t)
            in_range = (abs(d.col-my_col) <= self.DOOR_VIEW_R and
                        abs(d.row-my_row) <= self.DOOR_VIEW_R)
            has_los  = (in_range and
                        los_check(self.walls_ref, self.x, self.y, dpx, dpy,
                                  windows=self.windows_ref))

            # ── Bashed door: handled by _scan_bashed_doors every frame ──
            if getattr(d, 'bashed', False):
                continue   # never close or further inspect a bashed door

            if d.open:
                # ── Door is open ──────────────────────────────────────────
                # Ignore if any guard opened it (guards always open doors in their path)
                if id(d) in guard_opened_ids: continue
                if id(d) in self._self_opened_doors: continue

                # Only notice if within LOS
                if not has_los: continue

                if self.is_leaver:
                    # Leavers: record it and decide whether to close
                    if id(d) not in self._doors_left_open:
                        self._doors_left_open[id(d)] = d
                    # Occasionally decide to close (~20% chance when first noticed)
                    if random.random() < self.LEAVER_CLOSE_CHANCE:
                        self.open_doors_seen.append(d)
                    # else: leave it — they don't care
                else:
                    # Normal guard: close any open door they can see
                    self.open_doors_seen.append(d)
                    if self._noise_dest is None:
                        self._noise_dest = (dpx, dpy)

            else:
                # ── Door is closed ────────────────────────────────────────
                # Leaver suspicious check: did I leave this door open?
                if self.is_leaver and id(d) in self._doors_left_open:
                    # Only notice if in LOS
                    if not has_los: continue
                    # Not suspicious if a colleague is visibly near the door
                    colleague_nearby = False
                    for g in all_guards:
                        if g is self: continue
                        if dist(g.x, g.y, dpx, dpy) > t * 3: continue
                        # Colleague must be in this guard's LOS
                        if los_check(self.walls_ref, self.x, self.y, g.x, g.y,
                                     windows=self.windows_ref):
                            colleague_nearby = True
                            break
                    if not colleague_nearby:
                        # Someone closed my door — suspicious!
                        del self._doors_left_open[id(d)]
                        self._goap.set(noise_dest_set=True)
                        self._noise_dest = (dpx, dpy)
                    else:
                        # Colleague probably closed it — forget about it
                        del self._doors_left_open[id(d)]

        # Queue doors to close (non-leavers only close; leavers rarely do)
        if self.open_doors_seen and not self.doors_to_close and self.state == PATROL:
            self.doors_to_close  = list(self.open_doors_seen)
            self.open_doors_seen = []
            self._door_close_timer = 1.2

    def _expire_self_opened_doors(self, game_time):
        EXPIRY = 30.0   # remember for longer so guard doesn't re-alert own doors
        expired = [k for k, t in self._self_opened_doors.items()
                   if game_time - t > EXPIRY]
        for k in expired:
            del self._self_opened_doors[k]
        # Clean up _doors_left_open for doors that no longer exist or are back to original
        stale = [k for k, d in self._doors_left_open.items()
                 if d.original_open or not d.open]
        for k in stale:
            self._doors_left_open.pop(k, None)

    def _handle_door_closing(self, doors, walls, dt):
        if not self.doors_to_close: return
        self._door_close_timer -= dt
        if self._door_close_timer > 0: return
        d = self.doors_to_close[0]
        dpx, dpy = tc(d.col, d.row, self._tile)
        if dist(self.x, self.y, dpx, dpy) < self._tile * 1.2:
            if d.open:
                d.open = False
                if d._linked_partner is not None:
                    d._linked_partner.open = False
            self.known_door_states[d.tile_pos()] = False
            # Remember we closed this door so we don't re-alert on it
            self._self_opened_doors[id(d)] = self._game_time_ref
            # If leaver, remove from left_open tracking (we chose to close this one)
            self._doors_left_open.pop(id(d), None)
            self.doors_to_close.pop(0)
            self._door_close_timer = 0.9
            self.target_px = None; self.path = []
        else:
            self._walk_path(walls, set(), (dpx, dpy), self.SPD[PATROL], doors=doors)

    def _open_blocking_door(self, next_tile, doors, game_time=0.0):
        for d in doors:
            if d.tile_pos() == next_tile and not d.open:
                if not d.def_.get("flags", {}).get("guard_opens", True):
                    continue
                d.open = True
                if d._linked_partner is not None:
                    d._linked_partner.open = True
                self._self_opened_doors[id(d)] = game_time
                return True
        return False

    # ── path / movement helpers ───────────────────────────────────────────

    def _rebuild_trap_targets(self):
        self._trap_targets = [
            (px * self._tile + self._tile//2, py * self._tile + self._tile//2)
            for (px, py), heat in self._hotspot_heat.items()
            if heat >= self.HOTSPOT_HEAT_CAP
        ]

    def _recover_patrol_path(self):
        if not self.waypoints: return
        my_tile = ptile(self.x, self.y, self._tile)
        best_path = None; best_len = 9999
        for wp in self.waypoints:
            wp_tile = ptile(wp[0], wp[1], self._tile)
            p = astar(self.walls_ref, my_tile, wp_tile, self.cols, self.rows)
            if p and len(p) < best_len:
                best_path = p; best_len = len(p)
        if best_path:
            self._recovery_path     = best_path
            self._recovery_path_idx = 0
        else:
            self._recovery_path = None

    def _walk_recovery(self, walls, doors, spd, game_time=0.0):
        rp = self._recovery_path
        if self._recovery_path_idx >= len(rp):
            self._recovery_path = None; return
        nt = rp[self._recovery_path_idx]
        self._open_blocking_door(nt, doors, game_time)
        tx_px, ty_px = tc(nt[0], nt[1], self._tile)
        d = dist(self.x, self.y, tx_px, ty_px)
        if d < spd + 1:
            self._recovery_path_idx += 1
        else:
            dx2, dy2 = (tx_px-self.x)/d, (ty_px-self.y)/d
            self._step(dx2*spd, dy2*spd, walls, set())
            self.facing = math.atan2(dy2, dx2)
        if self._recovery_path_idx >= len(rp):
            self._recovery_path = None

    def _walk_path(self, walls, closed_doors, dest_px, spd, doors=None, game_time=0.0):
        if dest_px is None: return True
        dest_tile = ptile(dest_px[0], dest_px[1], self._tile)
        my_tile   = ptile(self.x, self.y, self._tile)
        if dest_tile in walls:
            best = None; best_d = 9999
            for dc in range(-2, 3):
                for dr in range(-2, 3):
                    cand = (dest_tile[0]+dc, dest_tile[1]+dr)
                    if cand not in walls:
                        cd = math.hypot(dc, dr)
                        if cd < best_d: best = cand; best_d = cd
            if best:
                dest_tile = best
                dest_px = (best[0]*self._tile+self._tile//2,
                           best[1]*self._tile+self._tile//2)
            else: return True
        if not self.path or self.path_idx >= len(self.path):
            self.path = astar(walls, my_tile, dest_tile, self.cols, self.rows)
            self.path_idx = 0
        if self.path and self.path_idx < len(self.path):
            nt = self.path[self.path_idx]
            if nt in walls and nt not in (closed_doors or set()):
                self.path = astar(walls, my_tile, dest_tile, self.cols, self.rows)
                self.path_idx = 0
                if not self.path: return True
                nt = self.path[self.path_idx]
            if doors: self._open_blocking_door(nt, doors, game_time)
            tx_px, ty_px = tc(nt[0], nt[1], self._tile)
            d = dist(self.x, self.y, tx_px, ty_px)
            if d < spd+1:
                self.path_idx += 1
            else:
                dx2, dy2 = (tx_px-self.x)/d, (ty_px-self.y)/d
                self._step(dx2*spd, dy2*spd, walls, set())
                self.facing = math.atan2(dy2, dx2)
            return False
        return dist(self.x, self.y, dest_px[0], dest_px[1]) < self._tile*0.7

    def _step(self, mx, my, walls, closed_doors):
        nx = self.x+mx; ny = self.y+my
        if (ptile(nx, self.y, self._tile) not in walls and
                ptile(nx, self.y, self._tile) not in closed_doors): self.x = nx
        if (ptile(self.x, ny, self._tile) not in walls and
                ptile(self.x, ny, self._tile) not in closed_doors): self.y = ny

    def _check_stuck(self, walls, dt):
        px, py = self.x, self.y
        moved = math.hypot(px-self._last_pos[0], py-self._last_pos[1])
        self._last_pos = (px, py)
        if moved < 0.5 and self.state in (PATROL, ALERT, CHASE, SEARCH, BRIEF):
            self._stuck_t += dt
        else:
            self._stuck_t = 0.0
        self._stuck_repath = max(0.0, self._stuck_repath - dt)
        if self._stuck_t > 0.4 and self._stuck_repath <= 0:
            self.path = []; self.path_idx = 0
            self._patrol_path = []; self._patrol_path_idx = 0
            self._patrol_wp_tile = None
            self._stuck_t = 0.0; self._stuck_repath = 1.5

    def _decay_muffled_heat(self, dt):
        self._muffled_decay -= dt
        if self._muffled_decay > 0: return
        self._muffled_decay = 2.0
        decay_rate = self.MUFFLED_THRESH / self.MUFFLED_WINDOW * 2.0
        dead = [k for k, v in self._muffled_heat.items() if v - decay_rate <= 0]
        for k in dead: del self._muffled_heat[k]
        for k in self._muffled_heat:
            self._muffled_heat[k] = max(0, self._muffled_heat[k] - decay_rate)

    # ── FOV ───────────────────────────────────────────────────────────────

    def fov_pts(self, player_sprinting, walls, windows, closed_doors):
        sight = self.SIGHT + (self.SIGHT_SPR if player_sprinting else 0)
        fov   = self.FOV.get(self.state, math.radians(65))
        return cast_fov_polygon(self.x, self.y, self.facing, fov, sight,
                                walls, windows, closed_doors, TILE, rays=32)






class Camera:
    SMOOTH = 5.0   # lerp speed – override via level visuals "camera_smooth"

    def __init__(self, view_w, view_h, world_w, world_h, smooth=None):
        self.vw = view_w; self.vh = view_h
        self.ww = world_w; self.wh = world_h
        self.x = 0.0; self.y = 0.0
        self._smooth = smooth if smooth is not None else self.SMOOTH

    def update(self, target_x, target_y, dt):
        cx = target_x - self.vw / 2
        cy = target_y - self.vh / 2
        cx = max(0, min(self.ww - self.vw, cx))
        cy = max(0, min(self.wh - self.vh, cy))
        t = min(1.0, self._smooth * dt)
        self.x += (cx - self.x) * t
        self.y += (cy - self.y) * t

    def world_to_screen(self, wx, wy):
        return wx - self.x, wy - self.y

    def screen_to_world(self, sx, sy):
        return sx + self.x, sy + self.y

    def apply_rect(self, wx, wy, w, h):
        return int(wx - self.x), int(wy - self.y), w, h


# ════════════════════════════════════════════════════════════════════════════
# Level loader
# ════════════════════════════════════════════════════════════════════════════
def _autolink(door_list):
    """Auto-link adjacent same-type door pairs so they toggle in sync.
    Components of exactly 2 touching tiles get mutual _linked_partner refs.
    Components of 1 or 3+ tiles stay independent (partner = None).
    Only runs if the type's JSON flag linked_by_adjacency is True.
    """
    if not door_list:
        return
    # Check flag from registry using first instance's def_
    if not door_list[0].def_.get("flags", {}).get("linked_by_adjacency", True):
        return
    pos_map = {d.tile_pos(): d for d in door_list}
    visited = set()
    for start_pos in list(pos_map):
        if start_pos in visited:
            continue
        component = []
        queue = [start_pos]
        while queue:
            pos = queue.pop()
            if pos in visited:
                continue
            visited.add(pos)
            component.append(pos_map[pos])
            c, r = pos
            for nc, nr in ((c+1,r),(c-1,r),(c,r+1),(c,r-1)):
                if (nc, nr) in pos_map and (nc, nr) not in visited:
                    queue.append((nc, nr))
        if len(component) == 2:
            a, b = component
            a._linked_partner = b
            b._linked_partner = a


# ══════════════════════════════════════════════════════════════════════════════
# Bundle file format  (.ler / .lep as folders) – same convention as keyring
# ══════════════════════════════════════════════════════════════════════════════

def _ler_json_path(path: str) -> str:
    """Return actual JSON inside a .ler bundle folder, or the path itself.
    Checks for room.ler directly to avoid isdir() permission issues on Windows.
    """
    if path.lower().endswith(".ler"):
        inner = os.path.join(path, "room.ler")
        if os.path.isfile(inner):
            return inner
        try:
            if os.path.isdir(path):
                for f in os.listdir(path):
                    if f.lower().endswith(".ler"):
                        return os.path.join(path, f)
        except OSError:
            pass
    return path

def _lep_json_path(path: str) -> str:
    """Return actual JSON inside a .lep bundle folder, or the path itself.

    Priority inside a bundle:
      1. File whose stem matches the bundle folder name (e.g. chapter1.lep
         inside chapter1.lep/) -- this is the authoritative project file.
      2. Any other non-'project' .lep in the folder.
      3. project.lep as last resort (some bundles use it as an empty stub).
    """
    if os.path.isdir(path) and path.lower().endswith(".lep"):
        bundle_stem = os.path.splitext(os.path.basename(path))[0].lower()
        candidates = [f for f in os.listdir(path) if f.lower().endswith(".lep")]
        # 1. Prefer file whose stem matches the bundle folder name
        for f in candidates:
            if os.path.splitext(f)[0].lower() == bundle_stem:
                return os.path.join(path, f)
        # 2. Any non-project .lep
        for f in candidates:
            if f.lower() != "project.lep":
                return os.path.join(path, f)
        # 3. Fallback to project.lep
        fallback = os.path.join(path, "project.lep")
        if os.path.isfile(fallback):
            return fallback
    return path

def _lep_base(path: str) -> str:
    """Return the directory that sibling .ler room bundles live in, relative to a .lep.

    A .lep bundle is a folder whose name ends in .lep.  Room .ler bundles are
    SIBLINGS of that folder, not children.  So the correct base for resolving
    room paths is the PARENT of the bundle dir, not the bundle dir itself.

    Accepts any of:
      - the bundle dir itself   (levels/story/chapter1.lep/)
      - the inner JSON file     (levels/story/chapter1.lep/chapter1.lep)
      - a flat .lep file        (legacy single-file, base = dirname)
    """
    p = os.path.abspath(path)
    if p.lower().endswith(".lep"):
        if os.path.isdir(p):
            # given the bundle folder → parent is the sibling root
            return os.path.dirname(p)
        elif os.path.isfile(p):
            parent = os.path.dirname(p)
            if parent.lower().endswith(".lep") and os.path.isdir(parent):
                # given the inner JSON → grandparent is the sibling root
                return os.path.dirname(parent)
            # flat .lep file
            return parent
    return os.path.dirname(p)


def _find_room_bundle(raw_path: str, lep_base_dir: str) -> str:
    """Resolve a room path from a .lep project entry to an actual .ler bundle path.

    Search order:
      1. raw_path as-is (absolute path — direct hit).
      2. Relative to lep_base_dir (sibling of the .lep bundle) — normal case.
      3. Relative to _PROJECT_ROOT/levels/ and all its immediate subdirectories
         — covers duostory whose rooms live in the SP levels/story/ folder even
         when mplevels/ is on a completely different drive.
      4. Walk _PROJECT_ROOT/levels/ recursively looking for a bundle whose name
         matches the basename of raw_path — last-resort discovery.

    Returns the first existing path found, or the raw sibling-resolved path as
    a best-effort fallback (caller checks os.path.exists).
    """
    # 1. Absolute path — use directly
    if os.path.isabs(raw_path):
        return raw_path

    # 2. Relative to lep_base_dir (sibling resolution)
    sibling = os.path.normpath(os.path.join(lep_base_dir, raw_path))
    if os.path.exists(sibling):
        return sibling

    # 3. Search inside _PROJECT_ROOT/levels/ and immediate subdirs
    target_name = os.path.basename(raw_path)
    levels_root = os.path.join(_PROJECT_ROOT, "levels")
    search_dirs = [levels_root]
    try:
        for entry in os.scandir(levels_root):
            if entry.is_dir():
                search_dirs.append(entry.path)
    except OSError:
        pass
    for d in search_dirs:
        candidate = os.path.normpath(os.path.join(d, target_name))
        if os.path.exists(candidate):
            return candidate

    # 4. Recursive walk — expensive but only reached when layout is unusual
    try:
        for dirpath, dirnames, filenames in os.walk(levels_root):
            # Check for bundle dir match
            for dn in dirnames:
                if dn.lower() == target_name.lower():
                    candidate = os.path.join(dirpath, dn)
                    if os.path.exists(candidate):
                        return candidate
            # Check for flat file match
            for fn in filenames:
                if fn.lower() == target_name.lower():
                    return os.path.join(dirpath, fn)
    except OSError:
        pass

    # Fallback: return the sibling path (caller will log missing)
    return sibling


def _save_ler_bundle(data: dict, bundle_path: str) -> None:
    """Write level JSON into a .ler bundle folder."""
    os.makedirs(bundle_path, exist_ok=True)
    with open(os.path.join(bundle_path, "room.ler"), "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def _is_lep(path: str) -> bool:
    """True if path is a .lep file or a .lep bundle folder."""
    return path.lower().endswith(".lep")

def _is_ler(path: str) -> bool:
    """True if path is a .ler file or a .ler bundle folder."""
    return path.lower().endswith(".ler")


def load_level(path):
    real = _ler_json_path(path)
    with open(real, encoding="utf-8") as f: data = json.load(f)
    # Store the bundle path (folder) as level_path so assets resolve from there
    data["level_path"] = path
    # ── Use pre-declared required_tiles from .ler file if available ───────
    # This allows level authors to declare exactly which tiles their level uses.
    # We always also compute from objects as a safety net.
    declared_required = set(data.get("required_tiles", []))
    computed_required = _collect_required_tiles(data)
    all_required = declared_required | computed_required

    # ── Integrity check: verify all required tile assets exist ───────────
    missing_msgs = _check_level_integrity(path, data)
    if missing_msgs:
        print(f"[integrity] Level '{os.path.basename(path)}' is missing tile assets:")
        for m in missing_msgs:
            print(m)
        level_stem = os.path.splitext(os.path.basename(path))[0]
        print(f"[integrity] Run  python build_{level_stem}.py  to create them.")
        # Store the missing info so the Game can show an error screen
        data["_missing_assets"]  = missing_msgs
        data["_build_script"]    = f"build_{level_stem}.py"
    tile = data.get("tile_size", TILE)
    cols = data["cols"]; rows = data["rows"]
    walls=[]; loot=[]; mini_loot=[]; main_loot=[]; hides=[]; doors_raw=[]
    crashdoors_raw=[]; oiled_doors_raw=[]; wall_doors_raw=[]
    windows_raw=[]; noisemakers_raw=[]; fences_raw=[]; pits_raw=[]
    creak_floors_raw=[]; snitches_raw=[]; cameras_raw=[]
    io_transmit_raw=[]; io_receive_raw=[]; timers_raw=[]; thin_walls_raw=[]; thin_door_raw=[]
    invis_walls=[]; guard_objs=[]; player_start=None; player2_start=None; exit_pos=None
    regions_raw=[]; item_piles_raw=[]; buy_items_raw=[]; shop_leaves_raw=[]
    detail_imgs_raw=[]; detail_txts_raw=[]

    for obj in data.get("objects", []):
        t = obj["type"]; c = obj["col"]; r = obj["row"]
        if   t == "wall":           walls.append((c, r))
        elif t == "invisible_wall":
            walls.append((c, r))       # solid collision
            invis_walls.append((c, r)) # tracked so renderer skips drawing
        elif t == "thin_wall":
            walls.append((c, r))                           # solid collision
            thin_walls_raw.append(obj)                     # keep for rendering
        elif t == "thin_door":
            thin_door_raw.append(obj)                      # keep for rendering; walls managed by ThinDoor
        elif t in ("bob","player"): player_start = (c, r)
        elif t == "player2":        player2_start = (c, r)
        elif t == "exit":           exit_pos  = (c, r)
        elif t == "loot":           loot.append((c, r))
        elif t == "mini_loot":      mini_loot.append((c, r))
        elif t == "main_loot":      main_loot.append((c, r))
        elif t == "hide":           hides.append((c, r))
        elif t == "door":           doors_raw.append(obj)
        elif t == "oiled_door":     oiled_doors_raw.append(obj)
        elif t == "wall_door":      wall_doors_raw.append(obj)
        elif t == "crashdoor":      crashdoors_raw.append(obj)
        elif t == "fence":          fences_raw.append((c, r))
        elif t == "pit":            pits_raw.append((c, r))
        elif t == "creak_floor":    creak_floors_raw.append(obj)
        elif t == "item_pile":      item_piles_raw.append(obj)
        elif t == "buy_item":       buy_items_raw.append(obj)
        elif t == "shop_leave":     shop_leaves_raw.append(obj)
        elif t == "detail_img":     detail_imgs_raw.append(obj)
        elif t == "detail_txt":     detail_txts_raw.append(obj)
        elif t == "window":         windows_raw.append((c, r))
        elif t == "noisemaker":     noisemakers_raw.append(obj)
        elif t == "snitch":         snitches_raw.append(obj)
        elif t == "camera":         cameras_raw.append(obj)
        elif t in ("input_node","transmit_node"):  io_transmit_raw.append(obj)
        elif t in ("output_node","receive_node"):  io_receive_raw.append(obj)
        elif t == "timer_node":     timers_raw.append(obj)
        elif t == "guard":          guard_objs.append(obj)
        # ai hint tiles – collected separately below (same pass as regions)
        # regions are collected separately below

    # Collect region objects (after main loop to avoid type dispatch clutter)
    for obj in data.get("objects", []):
        t2 = obj.get("type", "")
        if t2 in ("region", "region_inbetween", "region_inbetween_doorway"):
            regions_raw.append(obj)

    # Collect AI hint tile objects
    ai_cover_raw  = []   # ai_coverhint  – preferred combat cover positions
    ai_choke_raw  = []   # ai_chokehint  – positions to block / deny to player
    ai_avoid_raw  = []   # ai_avoidhint  – positions guards should route around
    for obj in data.get("objects", []):
        t3 = obj.get("type", "")
        if t3 == "ai_coverhint":  ai_cover_raw.append(obj)
        elif t3 == "ai_chokehint": ai_choke_raw.append(obj)
        elif t3 == "ai_avoidhint": ai_avoid_raw.append(obj)

    walls_set = set(walls)
    # Fences block player movement but guards see through them (not in walls for LOS)
    fence_set = set(fences_raw)
    # los_walls is used by guard FOV / LOS – excludes fences (transparent to guards)
    los_walls_set = walls_set | set(windows_raw)
    walls_set |= fence_set
    # Windows block physical movement (solid glass) but are transparent to LOS
    walls_set |= set(windows_raw)

    # Validate player_start – fall back to first open tile if walled in
    ps = player_start or (1, 1)
    if ps in walls_set:
        found = False
        for r2 in range(1, rows - 1):
            for c2 in range(1, cols - 1):
                if (c2, r2) not in walls_set:
                    ps = (c2, r2); found = True; break
            if found: break
        print(f"[LockESC] Warning: player_start {player_start} is inside a wall – "
              f"moved to {ps}")

    # Rule 6: Validate guard waypoints – warn if any land inside a wall
    for obj in guard_objs:
        raw_wps = obj.get("waypoints", [[obj["col"], obj["row"]]])
        for (wc, wr) in raw_wps:
            if (wc, wr) in walls_set:
                fixed = None
                for r2 in range(max(0,wr-2), min(rows,wr+3)):
                    for c2 in range(max(0,wc-2), min(cols,wc+3)):
                        if (c2, r2) not in walls_set:
                            fixed = (c2, r2); break
                    if fixed: break
                if fixed:
                    wc, wr = fixed
                print(f"[LockESC] Warning: guard waypoint ({obj['col']},{obj['row']}) "
                      f"has wp ({wc},{wr}) inside a wall – snapped to nearest open tile")

    return {
        "tile": tile, "cols": cols, "rows": rows,
        "W": cols*tile, "H": rows*tile,
        "walls":            walls_set,
        "los_walls":        los_walls_set,
        "fences_set":       fence_set,
        "loot":             loot,
        "mini_loot":        mini_loot,
        "main_loot":        main_loot,
        "hides":            set(hides),
        "doors_raw":        doors_raw,
        "oiled_doors_raw":  oiled_doors_raw,
        "wall_doors_raw":   wall_doors_raw,
        "crashdoors_raw":   crashdoors_raw,
        "fences_raw":       fences_raw,
        "pits_raw":         pits_raw,
        "creak_floors_raw": creak_floors_raw,
        "item_piles_raw":   item_piles_raw,
        "buy_items_raw":    buy_items_raw,
        "shop_leaves_raw":  shop_leaves_raw,
        "detail_imgs_raw":  detail_imgs_raw,
        "detail_txts_raw":  detail_txts_raw,
        "windows_raw":      windows_raw,
        "noisemakers_raw":  noisemakers_raw,
        "snitches_raw":     snitches_raw,
        "cameras_raw":      cameras_raw,
        "io_transmit_raw":  io_transmit_raw,
        "io_receive_raw":   io_receive_raw,
        "timers_raw":       timers_raw,
        "thin_walls_raw":   thin_walls_raw,
        "thin_door_raw":    thin_door_raw,
        "invis_walls":      set(invis_walls),
        "player_start":     ps,
        "player2_start":    player2_start,
        "exit_pos":         exit_pos or (cols-2, rows-2),
        "guard_objs":       guard_objs,
        "name":             data.get("name", os.path.basename(path)),
        "visuals":          data.get("visuals", {}),
        "level_path":       os.path.abspath(path),
        "next_level":       data.get("next_level"),
        "is_shop":          data.get("is_shop", False),
        "regions_raw":      regions_raw,
        "ai_cover_raw":     ai_cover_raw,
        "ai_choke_raw":     ai_choke_raw,
        "ai_avoid_raw":     ai_avoid_raw,
        "required_tiles":   all_required,
        "missing_assets":   data.get("_missing_assets", []),
        "build_script":     data.get("_build_script", ""),
    }


def make_default_level_json():
    cols, rows = 22, 16
    objs = []
    for c in range(cols):
        objs += [{"type":"wall","col":c,"row":0},
                 {"type":"wall","col":c,"row":rows-1}]
    for r in range(1, rows-1):
        objs += [{"type":"wall","col":0,"row":r},
                 {"type":"wall","col":cols-1,"row":r}]
    for r in range(2,9):  objs.append({"type":"wall","col":6,"row":r})
    for c in range(6,15): objs.append({"type":"wall","col":c,"row":8})
    for r in range(8,rows-1): objs.append({"type":"wall","col":14,"row":r})
    objs.append({"type":"door","col":6, "row":5,"open":False})
    objs.append({"type":"door","col":14,"row":11,"open":False})
    objs.append({"type":"window","col":6,"row":3})
    objs.append({"type":"crashdoor","col":10,"row":8})
    objs.append({"type":"noisemaker","col":18,"row":5,
                 "radius":240,"score":65,"interval":5.0,"ambiguous":True})
    objs += [
        {"type":"player",    "col":2,       "row":2},
        {"type":"exit",      "col":cols-2,  "row":rows-2},
        {"type":"main_loot", "col":11,      "row":4},
        {"type":"loot",      "col":9,       "row":3},
        {"type":"loot",      "col":17,      "row":3},
        {"type":"loot",      "col":3,       "row":12},
        {"type":"loot",      "col":18,      "row":12},
        {"type":"hide",      "col":8,       "row":5},
        {"type":"hide",      "col":11,      "row":11},
        {"type":"guard","col":9,"row":3,
         "waypoints":[[9,3],[16,3],[16,6],[9,6]],
         "pause_flags":[False,True,False,True]},
        {"type":"guard","col":3,"row":10,
         "waypoints":[[3,10],[12,10],[12,14],[3,14]],
         "pause_flags":[False,False,False,False]},
        {"type":"guard","col":17,"row":9,
         "waypoints":[[17,9],[20,9],[20,14],[17,14]],
         "pause_flags":[False,False,True,False]},
    ]
    return {"name":"Default","tile_size":TILE,"cols":cols,"rows":rows,"objects":objs}


# ════════════════════════════════════════════════════════════════════════════
# Audio  –  real files when available, procedural fallback
# ════════════════════════════════════════════════════════════════════════════

def _gen_sfx():
    """
    Build the sfx dict.  Scans integrity/sounds/ and loads any file whose stem
    matches a known key mapping.  Everything else is generated procedurally.
    Returns a dict of pygame.mixer.Sound, or {} on any failure.
    """
    import array as _array

    # Use the already-correct _PROJECT_ROOT so the path is always reliable
    _sounds_dir = os.path.join(_PROJECT_ROOT, "integrity", "sounds")

    # stem → sfx key  (any extension accepted: .ogg .wav .mp3)
    _STEM_TO_KEY = {
        "door_close":  "door",
        "door_creak":  "creak",
        "door_slam":   "crash",
        "door_unlock": "unlock",
    }

    # Scan folder and build stem→path map
    _file_map = {}
    if os.path.isdir(_sounds_dir):
        for fname in os.listdir(_sounds_dir):
            stem, ext = os.path.splitext(fname)
            if ext.lower() in (".ogg", ".wav", ".mp3") and stem in _STEM_TO_KEY:
                _file_map[stem] = os.path.join(_sounds_dir, fname)

    def _try_load(key):
        """Load sound file for this key by scanning _file_map. Returns Sound or None."""
        for stem, sfx_key in _STEM_TO_KEY.items():
            if sfx_key == key and stem in _file_map:
                try:
                    snd = pygame.mixer.Sound(_file_map[stem])
                    print(f"[sfx] loaded {key}: {_file_map[stem]}")
                    return snd
                except Exception as e:
                    print(f"[sfx] failed {key} ({_file_map[stem]}): {e}")
        return None

    RATE  = 44100
    CHANS = pygame.mixer.get_init()[2] if pygame.mixer.get_init() else 2

    def _buf(samples):
        clipped = [max(-32767, min(32767, int(s * 32767))) for s in samples]
        if CHANS == 2:
            interleaved = []
            for v in clipped:
                interleaved.append(v); interleaved.append(v)
            raw = _array.array('h', interleaved)
        else:
            raw = _array.array('h', clipped)
        return pygame.mixer.Sound(buffer=raw)

    def _tone(freq, dur, env='exp', vol=0.4):
        n = int(RATE * dur)
        out = []
        for i in range(n):
            t = i / RATE
            s = math.sin(2 * math.pi * freq * t)
            if env == 'exp':  e = math.exp(-6 * t / dur)
            elif env == 'lin': e = max(0.0, 1.0 - t / dur)
            else:              e = 1.0
            out.append(s * e * vol)
        return out

    def _noise(dur, smooth=0.4, vol=0.3):
        n = int(RATE * dur)
        prev = 0.0; out = []
        for i in range(n):
            t = i / RATE
            prev = prev * smooth + random.uniform(-1, 1) * (1 - smooth)
            e = math.exp(-5 * t / dur)
            out.append(prev * e * vol)
        return out

    def _try_load(key):
        """Try to load a real file for this key. Returns Sound or None."""
        for fname in _sfx_files.get(key, []):
            path = os.path.join(_sounds_dir, fname)
            if os.path.isfile(path):
                try:
                    snd = pygame.mixer.Sound(path)
                    print(f"[sfx] loaded {key}: {path}")
                    return snd
                except Exception as e:
                    print(f"[sfx] failed {key} ({path}): {e}")
        print(f"[sfx] no file found for {key} in {_sounds_dir}")
        return None

    try:
        sfx = {}

        # ── Procedural sounds (never replaced by files) ───────────────────
        sfx['step']   = _buf(_tone(80,  0.06, 'exp', 0.20) +
                              _tone(55,  0.05, 'exp', 0.12))
        sfx['alert']  = _buf(_tone(440, 0.07, 'lin', 0.45) +
                              _tone(660, 0.14, 'exp', 0.40))
        pulse = _tone(520, 0.06, 'exp', 0.45) + [0.0]*int(RATE*0.04)
        sfx['chase']  = _buf(pulse * 3)
        sfx['caught'] = _buf(_noise(0.07, 0.2, 0.55) +
                              _tone(120, 0.18, 'exp', 0.45) +
                              _tone(75,  0.22, 'exp', 0.28))
        sfx['escape'] = _buf(_tone(523, 0.14, 'lin', 0.38) +
                              _tone(659, 0.14, 'lin', 0.38) +
                              _tone(784, 0.28, 'exp', 0.48))
        sfx['loot']   = _buf(_tone(880,  0.05, 'exp', 0.32) +
                              _tone(1108, 0.08, 'exp', 0.28))
        sfx['brief']  = _buf(_tone(880, 0.06, 'exp', 0.18) +
                              _tone(1100,0.10, 'exp', 0.14) +
                              _tone(1320,0.16, 'lin', 0.10))

        # ── File-backed sounds (fall back to procedural if file missing) ──
        # door_close.mp3  →  "door"  (regular toggle open/close)
        sfx['door'] = (_try_load('door') or
                       _buf(_tone(220, 0.08, 'exp', 0.28) +
                            _tone(175, 0.12, 'lin', 0.18)))

        # door_slam.mp3   →  "crash"  (bash / crashdoor / shotgun impact)
        sfx['crash'] = (_try_load('crash') or
                        _buf(_noise(0.04, 0.15, 0.75) +
                             _noise(0.18, 0.40, 0.45) +
                             _tone(90,   0.22, 'exp', 0.38)))

        # door_creak.mp3  →  "creak"  (oiled/silent doors, guard door-close)
        sfx['creak'] = (_try_load('creak') or
                        _buf(_tone(180, 0.05, 'exp', 0.12) +
                             _tone(140, 0.10, 'lin', 0.08)))

        # door_unlock.wav →  "unlock"  (key use, lock interaction)
        sfx['unlock'] = (_try_load('unlock') or
                         _buf(_tone(660, 0.04, 'exp', 0.22) +
                              _tone(880, 0.06, 'exp', 0.18) +
                              _tone(1100,0.08, 'lin', 0.14)))

        return sfx
    except Exception:
        return {}


def _play(sfx, name, volume=1.0, fadein_ms=15):
    """Play a sound with near-instant fade-in and natural fade-out (via channel)."""
    try:
        s = sfx.get(name)
        if not s:
            return
        ch = s.play(fade_ms=fadein_ms)
        if ch:
            ch.set_volume(volume)
    except Exception:
        pass


# ════════════════════════════════════════════════════════════════════════════
# In-game level / project file browser (pygame overlay)
# ════════════════════════════════════════════════════════════════════════════
class LevelBrowser:
    """
    Fullscreen pygame file-browser overlay rooted at the levels/ folder.

    Behaviour:
    • Regular folders are shown with a ▶ prefix and can be entered.
    • Files/folders whose name ends in .ler or .lep are shown as leaf items
      (not navigable as folders) — they are the selectable level bundles.
    • Double-click or Enter on a .ler/.lep item returns its path.
    • Backspace / Left arrow goes up one directory.
    • ESC cancels and returns None.
    """

    _BG      = (14,  16,  24)
    _HDR     = (22,  28,  40)
    _SEL     = (36,  72, 120)
    _HOV     = (28,  40,  64)
    _FG      = (192, 210, 240)
    _FG_DIM  = (90,  105, 130)
    _FG_LEP  = (160, 220, 140)   # .lep project entries
    _FG_LER  = (160, 190, 240)   # .ler room entries
    _BORDER  = (50,   65,  95)
    _ROW_H   = 32
    _PAD_X   = 22
    _SCROLL_SPEED = 3

    def __init__(self, screen, clock, root_dir=None, exclude_names=None):
        self.screen = screen
        self.clock  = clock
        W, H = screen.get_size()
        self.W, self.H = W, H
        self.root = os.path.abspath(
            root_dir or os.path.join(_PROJECT_ROOT, "levels"))
        if not os.path.isdir(self.root):
            os.makedirs(self.root, exist_ok=True)
        self.cwd    = self.root
        self.items  = []     # list of (display_name, abs_path, is_bundle)
        self.sel    = 0
        self.scroll = 0      # first visible row index
        # Names (case-insensitive) to hide from the listing entirely
        self._exclude = {n.lower() for n in (exclude_names or [])}
        self._font_md = pygame.font.SysFont("consolas", 18, bold=True)
        self._font_sm = pygame.font.SysFont("consolas", 14)
        self._load_dir()

    # ── directory loading ─────────────────────────────────────────────────
    def _load_dir(self):
        self.items = []
        self.sel   = 0
        self.scroll = 0
        try:
            entries = sorted(os.scandir(self.cwd), key=lambda e: (
                not e.is_dir(),          # dirs first
                e.name.lower()
            ))
        except PermissionError:
            return
        for e in entries:
            name = e.name
            low  = name.lower()
            # Skip hidden, __pycache__, and caller-excluded names
            if name.startswith(".") or name.startswith("__"):
                continue
            stem = low.split(".")[0]   # bare name without extension
            if low in self._exclude or stem in self._exclude:
                continue
            is_ler = low.endswith(".ler")
            is_lep = low.endswith(".lep")
            is_bundle = is_ler or is_lep
            # Treat .ler/.lep entries as files regardless of whether they're dirs
            is_dir = e.is_dir() and not is_bundle
            abs_p  = e.path
            self.items.append((name, abs_p, is_bundle, is_dir))

    # ── visible rows ──────────────────────────────────────────────────────
    def _visible_rows(self):
        header_h = 64
        footer_h = 40
        usable   = self.H - header_h - footer_h
        return max(1, usable // self._ROW_H)

    # ── main run loop ─────────────────────────────────────────────────────
    def run(self):
        """Block until user selects a file or cancels. Returns abs path or None."""
        while True:
            dt = self.clock.tick(60) / 1000.0
            W, H = self.W, self.H

            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    return None
                if ev.type == pygame.KEYDOWN:
                    result = self._handle_key(ev.key)
                    if result is not False:
                        return result
                if ev.type == pygame.MOUSEBUTTONDOWN:
                    result = self._handle_click(ev.pos, ev.button)
                    if result is not False:
                        return result
                if ev.type == pygame.MOUSEWHEEL:
                    self.scroll = max(0, min(
                        len(self.items) - self._visible_rows(),
                        self.scroll - ev.y * self._SCROLL_SPEED))

            self._draw()
            pygame.display.flip()

    def _handle_key(self, key):
        rows = self._visible_rows()
        if key == pygame.K_ESCAPE:
            return None
        if key in (pygame.K_UP, pygame.K_w):
            self.sel = max(0, self.sel - 1)
            if self.sel < self.scroll:
                self.scroll = self.sel
        if key in (pygame.K_DOWN, pygame.K_s):
            self.sel = min(len(self.items) - 1, self.sel + 1)
            if self.sel >= self.scroll + rows:
                self.scroll = self.sel - rows + 1
        if key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            return self._activate(self.sel)
        if key in (pygame.K_BACKSPACE, pygame.K_LEFT):
            if self.cwd != self.root:
                self.cwd = os.path.dirname(self.cwd)
                self._load_dir()
        return False

    def _handle_click(self, pos, button):
        header_h = 64
        x, y = pos
        row_i = (y - header_h) // self._ROW_H + self.scroll
        if 0 <= row_i < len(self.items):
            if self.sel == row_i and button == 1:
                # second click = double-click open
                return self._activate(row_i)
            self.sel = row_i
        return False

    def _activate(self, idx):
        if idx < 0 or idx >= len(self.items):
            return False
        name, abs_p, is_bundle, is_dir = self.items[idx]
        if is_bundle:
            return abs_p
        if is_dir:
            self.cwd = abs_p
            self._load_dir()
            return False
        # plain file — only accept .ler/.lep
        low = name.lower()
        if low.endswith(".ler") or low.endswith(".lep"):
            return abs_p
        return False

    def _draw(self):
        W, H = self.W, self.H
        scr  = self.screen
        header_h = 64
        footer_h = 40
        rows = self._visible_rows()

        # Background
        scr.fill(self._BG)

        # Header
        pygame.draw.rect(scr, self._HDR, (0, 0, W, header_h))
        pygame.draw.line(scr, self._BORDER, (0, header_h), (W, header_h), 1)
        title_s = self._font_md.render("OPEN LEVEL / PROJECT", True, (130, 170, 230))
        scr.blit(title_s, (self._PAD_X, 10))
        # Breadcrumb
        rel = os.path.relpath(self.cwd, self.root)
        crumb = "levels/" + ("" if rel == "." else rel.replace("\\", "/"))
        c_s = self._font_sm.render(crumb, True, self._FG_DIM)
        scr.blit(c_s, (self._PAD_X, 38))
        # hint
        hint = "↑↓ navigate  ·  Enter / double-click open  ·  ← back  ·  ESC cancel"
        h_s  = self._font_sm.render(hint, True, self._FG_DIM)
        scr.blit(h_s, (W - h_s.get_width() - self._PAD_X, 44))

        # Rows
        for i in range(rows):
            ri = i + self.scroll
            if ri >= len(self.items):
                break
            name, abs_p, is_bundle, is_dir = self.items[ri]
            ry = header_h + i * self._ROW_H
            selected = (ri == self.sel)

            # Row bg
            if selected:
                pygame.draw.rect(scr, self._SEL, (0, ry, W, self._ROW_H))
            elif i % 2 == 0:
                pygame.draw.rect(scr, (18, 22, 34), (0, ry, W, self._ROW_H))

            # Icon + colour
            if is_bundle:
                low = name.lower()
                icon = "📦" if low.endswith(".lep") else "🗂"
                col  = self._FG_LEP if low.endswith(".lep") else self._FG_LER
                suffix = "  [project]" if low.endswith(".lep") else "  [room]"
            elif is_dir:
                icon = "▶"
                col  = self._FG
                suffix = "/"
            else:
                icon = " "
                col  = self._FG_DIM
                suffix = ""

            label = f"  {icon}  {name}{suffix}"
            lbl_s = self._font_md.render(label, True, col if selected else
                                         (col if is_bundle else (self._FG if is_dir else self._FG_DIM)))
            scr.blit(lbl_s, (self._PAD_X, ry + (self._ROW_H - lbl_s.get_height()) // 2))

        # Footer
        fy = H - footer_h
        pygame.draw.line(scr, self._BORDER, (0, fy), (W, fy), 1)
        pygame.draw.rect(scr, self._HDR, (0, fy, W, footer_h))
        n_s = self._font_sm.render(
            f"{len(self.items)} item{'s' if len(self.items)!=1 else ''}  in  {os.path.basename(self.cwd) or 'levels'}",
            True, self._FG_DIM)
        scr.blit(n_s, (self._PAD_X, fy + 12))



# ════════════════════════════════════════════════════════════════════════════
# Procedural UI symbols  (no Unicode — works with any font/platform)
# ════════════════════════════════════════════════════════════════════════════

def _draw_arrow(surf, cx, cy, size, col):
    """Filled right-pointing triangle, centred at (cx, cy)."""
    h = size
    w = int(size * 0.7)
    pts = [(cx - w//2, cy - h//2),
           (cx - w//2, cy + h//2),
           (cx + w//2, cy)]
    pygame.draw.polygon(surf, col, pts)

def _draw_hexagon(surf, cx, cy, r, col, width=2):
    """Regular hexagon outline, pointy-top, centred at (cx, cy)."""
    pts = []
    for i in range(6):
        ang = math.radians(60 * i - 30)
        pts.append((cx + r * math.cos(ang), cy + r * math.sin(ang)))
    pygame.draw.polygon(surf, col, pts, width)

def _draw_check(surf, cx, cy, size, col, width=2):
    """Small tick / checkmark centred at (cx, cy)."""
    s = size // 2
    p1 = (cx - s,     cy)
    p2 = (cx - s//2,  cy + s//2)
    p3 = (cx + s,     cy - s//2)
    pygame.draw.line(surf, col, p1, p2, width)
    pygame.draw.line(surf, col, p2, p3, width)

def _draw_back_arrow(surf, cx, cy, size, col):
    """Filled left-pointing triangle."""
    h = size
    w = int(size * 0.7)
    pts = [(cx + w//2, cy - h//2),
           (cx + w//2, cy + h//2),
           (cx - w//2, cy)]
    pygame.draw.polygon(surf, col, pts)

# ════════════════════════════════════════════════════════════════════════════
# DVD-bounce screensaver easter egg
# ════════════════════════════════════════════════════════════════════════════

class _DVDScreensaver:
    """
    Bouncing lockesc.ico screensaver.  Shown when the title screen has had
    zero input (keyboard, mouse buttons, or mouse movement) for IDLE_SECS.
    Any input instantly dismisses it.

    Usage (inside a run loop):
        _ss = _DVDScreensaver(screen)
        ...
        # each frame:
        if _ss.tick(dt, mx, my, any_event_this_frame):
            _ss.draw()
            pygame.display.flip()
            continue   # skip normal title draw
    """

    IDLE_SECS  = 150.0   # 2.5 minutes
    SPEED      = 120.0   # pixels per second
    LOGO_SIZE  = 64      # px — ico is scaled to this square

    # A small palette of tint colours that cycle on each wall bounce
    _TINTS = [
        (255, 60,  60 ),   # red
        (255, 160,  0 ),   # orange
        (255, 240,  0 ),   # yellow
        (60,  220, 60 ),   # green
        (60,  200, 255),   # cyan
        (100, 80,  255),   # blue
        (220, 60,  220),   # magenta
        (255, 255, 255),   # white
    ]

    def __init__(self, screen):
        self.screen      = screen
        self._idle       = 0.0
        self._active     = False
        self._mx_last    = -1
        self._my_last    = -1
        self._tint_idx   = 0

        W, H = screen.get_size()
        # Logo: try the real .ico first, fall back to a text render
        self._logo_raw   = None
        ico_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "lockesc.ico")
        if os.path.isfile(ico_path):
            try:
                raw = pygame.image.load(ico_path)
                self._logo_raw = pygame.transform.smoothscale(
                    raw, (self.LOGO_SIZE, self.LOGO_SIZE))
            except Exception:
                pass
        if self._logo_raw is None:
            # Fallback: render "L" in a bold font
            fnt = pygame.font.SysFont("consolas", self.LOGO_SIZE, bold=True)
            self._logo_raw = fnt.render("L", True, (255, 255, 255))
            self._logo_raw = pygame.transform.smoothscale(
                self._logo_raw,
                (self.LOGO_SIZE, self.LOGO_SIZE))

        # Starting position and velocity
        self._x   = float(W // 3)
        self._y   = float(H // 3)
        ang       = math.radians(37)   # non-round angle so it hits corners rarely
        self._vx  = math.cos(ang) * self.SPEED
        self._vy  = math.sin(ang) * self.SPEED

        self._logo = self._tinted_logo()   # current tinted surface

    # ── Public API ────────────────────────────────────────────────────────────

    def tick(self, dt: float, mx: int, my: int, had_event: bool) -> bool:
        """
        Call every frame.  Returns True if the screensaver is now active
        (caller should draw it and skip normal rendering).

        dt         : seconds since last frame
        mx, my     : current mouse position
        had_event  : True if any pygame event was processed this frame
        """
        # Detect any input activity
        moved   = (mx != self._mx_last or my != self._my_last)
        self._mx_last = mx
        self._my_last = my

        activity = moved or had_event

        if self._active:
            if activity:
                self._active = False
                self._idle   = 0.0
            else:
                self._update_pos(dt)
            return self._active

        # Not yet active — accumulate idle time
        if activity:
            self._idle = 0.0
        else:
            self._idle += dt
            if self._idle >= self.IDLE_SECS:
                self._activate()

        return self._active

    def draw(self):
        scr = self.screen
        W, H = scr.get_size()
        scr.fill((0, 0, 0))
        scr.blit(self._logo, (int(self._x), int(self._y)))

    # ── Internal ──────────────────────────────────────────────────────────────

    def _activate(self):
        self._active  = True
        W, H = self.screen.get_size()
        # Randomise starting corner slightly so it's not always the same
        import random
        self._x  = float(random.randint(0, max(0, W - self.LOGO_SIZE)))
        self._y  = float(random.randint(0, max(0, H - self.LOGO_SIZE)))
        ang      = math.radians(random.choice([37, 53, 143, 217, 307]))
        spd      = self.SPEED * random.uniform(0.85, 1.15)
        self._vx = math.cos(ang) * spd
        self._vy = math.sin(ang) * spd
        self._tint_idx = 0
        self._logo     = self._tinted_logo()

    def _update_pos(self, dt: float):
        W, H  = self.screen.get_size()
        S     = self.LOGO_SIZE
        bounced = False

        self._x += self._vx * dt
        self._y += self._vy * dt

        if self._x <= 0:
            self._x  = 0.0
            self._vx = abs(self._vx)
            bounced  = True
        elif self._x + S >= W:
            self._x  = float(W - S)
            self._vx = -abs(self._vx)
            bounced  = True

        if self._y <= 0:
            self._y  = 0.0
            self._vy = abs(self._vy)
            bounced  = True
        elif self._y + S >= H:
            self._y  = float(H - S)
            self._vy = -abs(self._vy)
            bounced  = True

        if bounced:
            self._tint_idx = (self._tint_idx + 1) % len(self._TINTS)
            self._logo     = self._tinted_logo()

    def _tinted_logo(self):
        """Return a copy of the raw logo surface with the current tint applied."""
        surf = self._logo_raw.copy()
        tint = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
        r, g, b = self._TINTS[self._tint_idx]
        tint.fill((r, g, b, 0))   # zero alpha — use BLEND_RGB_MULT
        # Multiply blend: white areas take the tint, dark areas stay dark
        surf.blit(tint, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
        return surf


# ════════════════════════════════════════════════════════════════════════════
# Mode-select screen  (shown before TitleScreen)
# ════════════════════════════════════════════════════════════════════════════

class ModeSelectScreen:
    """
    Shown once at launch, before the title screen.
    Two options: SINGLEPLAYER and MULTIPLAYER.

    Returns:
        "singleplayer"  → show TitleScreen as normal
        "multiplayer"   → hand off to MULTIPLAYER/lobby.py MPTitleScreen
        "quit"          → exit
    """

    def __init__(self, screen, clock):
        self.screen = screen
        self.clock  = clock
        self.tick   = 0
        self._sel   = 0   # 0 = singleplayer, 1 = multiplayer
        self.font_xl = pygame.font.SysFont("consolas", 60, bold=True)
        self.font_lg = pygame.font.SysFont("consolas", 28, bold=True)
        self.font_md = pygame.font.SysFont("consolas", 18, bold=True)
        self.font_sm = pygame.font.SysFont("consolas", 13)

    _ITEMS = [
        ("SINGLEPLAYER", "singleplayer", (0, 200, 255),  "story  ·  custom levels  ·  classic"),
        ("MULTIPLAYER",  "multiplayer",  (0, 220, 180),  "co-op  ·  same PC  ·  LAN"),
    ]

    def run(self):
        W, H = self.screen.get_size()
        rects = [None, None]
        _ss   = _DVDScreensaver(self.screen)   # idle screensaver

        while True:
            dt = self.clock.tick(FPS) / 1000.0
            self.tick += 1
            mx, my = pygame.mouse.get_pos()

            # Hover
            for i, r in enumerate(rects):
                if r and r.collidepoint(mx, my):
                    self._sel = i

            had_event = False
            for ev in pygame.event.get():
                had_event = True
                if ev.type == pygame.QUIT:
                    return "quit"
                if ev.type == pygame.KEYDOWN:
                    if ev.key == pygame.K_ESCAPE:
                        return "quit"
                    if ev.key in (pygame.K_UP, pygame.K_w, pygame.K_LEFT):
                        self._sel = (self._sel - 1) % 2
                    if ev.key in (pygame.K_DOWN, pygame.K_s, pygame.K_RIGHT):
                        self._sel = (self._sel + 1) % 2
                    if ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                        return self._ITEMS[self._sel][1]
                if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                    # Website button (top-left)
                    _wb_r = pygame.Rect(10, 10, 160, 28)
                    if _wb_r.collidepoint(ev.pos):
                        import webbrowser
                        webbrowser.open("https://GoodPltheSniperer.github.io/LockESC/index.html")
                    for i, r in enumerate(rects):
                        if r and r.collidepoint(ev.pos):
                            return self._ITEMS[i][1]

            # Screensaver — if active, skip normal draw entirely
            if _ss.tick(dt, mx, my, had_event):
                _ss.draw()
                pygame.display.flip()
                continue

            # ── Draw ──────────────────────────────────────────────────────────
            scr = self.screen
            t   = self.tick
            scr.fill(C_TITLE_BG)

            # Scrolling grid (same as TitleScreen)
            grid = pygame.Surface((W, H), pygame.SRCALPHA)
            off  = (t * 0.4) % TILE
            for x in range(-TILE, W + TILE, TILE):
                pygame.draw.line(grid, (20, 40, 80, 60), (int(x + off), 0), (int(x + off), H))
            for y in range(-TILE, H + TILE, TILE):
                pygame.draw.line(grid, (20, 40, 80, 60), (0, int(y + off)), (W, int(y + off)))
            scr.blit(grid, (0, 0))

            # Glow
            for radius in range(160, 50, -28):
                alpha = int(16 * (1 - radius / 180))
                gs = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
                pygame.draw.circle(gs, (0, 140, 220, alpha), (radius, radius), radius)
                scr.blit(gs, (W // 2 - radius, H // 2 - 240 - radius))

            # Title
            letters  = "LOCKESC"
            letter_w = 66
            total_w  = letter_w * len(letters)
            start_x  = W // 2 - total_w // 2
            colours  = [(0,200,255),(0,180,240),(0,160,220),(80,220,255),
                        (0,200,255),(255,60,80),(255,80,100)]
            title_y  = H // 2 - 230
            for i, (ch, col) in enumerate(zip(letters, colours)):
                wave = math.sin(t * 0.08 + i * 0.6) * 8
                cx   = start_x + i * letter_w + letter_w // 2
                cy   = int(title_y + wave)
                sh   = self.font_xl.render(ch, True, (0, 0, 0))
                scr.blit(sh, sh.get_rect(center=(cx + 3, cy + 3)))
                s = self.font_xl.render(ch, True, col)
                scr.blit(s, s.get_rect(center=(cx, cy)))

            sub_a = int(180 + 75 * math.sin(t * 0.05))
            sub_s = self.font_md.render("STEALTH  ·  STRATEGY  ·  ESCAPE",
                                         True, (sub_a, sub_a, sub_a))
            scr.blit(sub_s, sub_s.get_rect(center=(W // 2, H // 2 - 152)))

            # Prompt
            p_a  = int(140 + 80 * math.sin(t * 0.07))
            p_s  = self.font_sm.render("SELECT MODE", True, (p_a, p_a, min(255, p_a + 40)))
            scr.blit(p_s, p_s.get_rect(center=(W // 2, H // 2 - 44)))

            # Mode buttons
            btn_w, btn_h, btn_gap = 340, 60, 14
            total_bh = 2 * btn_h + btn_gap
            btn_top  = H // 2 - 16

            for i, (label, value, col, hint) in enumerate(self._ITEMS):
                iy   = btn_top + i * (btn_h + btn_gap)
                ix   = W // 2 - btn_w // 2
                rect = pygame.Rect(ix, iy, btn_w, btn_h)
                rects[i] = rect
                sel  = (i == self._sel)

                # Background
                bg_a = 200 if sel else 140
                bg   = (*[int(c * 0.25) for c in col], bg_a) if sel else (10, 18, 44, 140)
                bs   = pygame.Surface((btn_w, btn_h), pygame.SRCALPHA)
                bs.fill(bg)
                scr.blit(bs, (ix, iy))

                # Border + left accent
                border_col = col if sel else (30, 55, 100)
                border_w   = 2 if sel else 1
                pygame.draw.rect(scr, border_col, rect, border_w)
                if sel:
                    pygame.draw.rect(scr, col, (ix, iy, 4, btn_h))

                # Pulse glow when selected
                if sel:
                    pulse = int(40 + 20 * math.sin(t * 0.12))
                    gs2  = pygame.Surface((btn_w + 20, btn_h + 20), pygame.SRCALPHA)
                    pygame.draw.rect(gs2, (*col, pulse),
                                     (0, 0, btn_w + 20, btn_h + 20), border_radius=4)
                    scr.blit(gs2, (ix - 10, iy - 10))
                    pygame.draw.rect(scr, border_col, rect, border_w)

                # Arrow cursor (procedural)
                if sel:
                    _draw_arrow(scr, ix + 18, iy + btn_h // 2, 14, col)

                # Label
                lbl_col = (255, 255, 255) if sel else (100, 130, 180)
                lbl     = self.font_lg.render(label, True, lbl_col)
                scr.blit(lbl, (ix + 36, iy + btn_h // 2 - lbl.get_height() // 2 - 6))

                # Sub-hint
                hint_col = col if sel else (40, 65, 100)
                h_s      = self.font_sm.render(hint, True, hint_col)
                scr.blit(h_s, (ix + 38, iy + btn_h // 2 + 8))

            nav_s = self.font_sm.render("↑ ↓  or  mouse    ENTER  confirm    ESC  quit",
                                         True, (40, 65, 100))
            scr.blit(nav_s, nav_s.get_rect(center=(W // 2, btn_top + total_bh + 28)))

            # ── Website button (top-left) ──────────────────────────────────────
            wb_w, wb_h = 160, 28
            wb_rect = pygame.Rect(10, 10, wb_w, wb_h)
            wb_hov  = wb_rect.collidepoint(mx, my)
            wb_surf = pygame.Surface((wb_w, wb_h), pygame.SRCALPHA)
            wb_surf.fill((0, 180, 255, 60) if wb_hov else (0, 100, 160, 40))
            scr.blit(wb_surf, (10, 10))
            wb_col = (0, 220, 255) if wb_hov else (0, 140, 200)
            pygame.draw.rect(scr, wb_col, wb_rect, 1)
            wb_lbl = self.font_sm.render("🌐  lockesc.github.io", True, wb_col)
            scr.blit(wb_lbl, wb_lbl.get_rect(midleft=(18, 24)))

            pygame.display.flip()


# ════════════════════════════════════════════════════════════════════════════
# Title screen
# ════════════════════════════════════════════════════════════════════════════
class TitleScreen:
    # Menu items: (label, return_value)
    _MENU_ITEMS = [
        ("PLAY STORY",   "story"),
        ("PLAY MAIN",    "play"),
        ("PLAY CUSTOM",  "custom"),
    ]
    _ITEM_H   = 52   # height of each menu row
    _ITEM_PAD = 12   # horizontal padding inside row

    def __init__(self, screen, clock, levels_root=None):
        self.screen       = screen
        self.clock        = clock
        self.tick         = 0
        self._levels_root = levels_root   # forwarded to LevelBrowser
        self.font_xl = pygame.font.SysFont("consolas", 72, bold=True)
        self.font_lg = pygame.font.SysFont("consolas", 36, bold=True)
        self.font_md = pygame.font.SysFont("consolas", 20, bold=True)
        self.font_sm = pygame.font.SysFont("consolas", 14)
        W, H = screen.get_size()
        self.scanlines = pygame.Surface((W, H), pygame.SRCALPHA)
        for y in range(0, H, 2):
            pygame.draw.line(self.scanlines, (0,0,0,40), (0,y), (W,y))
        self._sel     = 0           # currently highlighted menu index
        self._rects   = []          # menu item rects, rebuilt each draw

    def _pick_custom_lep(self):
        """Open the in-game level browser. Returns path or None."""
        # Exclude the built-in story/ subfolder — players reach story via PLAY STORY
        browser = LevelBrowser(self.screen, self.clock, root_dir=self._levels_root,
                               exclude_names={"story"})
        return browser.run()

    def run(self):
        W, H = self.screen.get_size()
        _ss  = _DVDScreensaver(self.screen)   # idle screensaver
        while True:
            dt = self.clock.tick(FPS) / 1000.0
            self.tick += 1
            mx, my = pygame.mouse.get_pos()

            # Mouse hover – update selection
            for i, r in enumerate(self._rects):
                if r and r.collidepoint(mx, my):
                    self._sel = i

            had_event = False
            for ev in pygame.event.get():
                had_event = True
                if ev.type == pygame.QUIT:
                    return "quit"
                if ev.type == pygame.KEYDOWN:
                    if ev.key == pygame.K_ESCAPE:
                        return "quit"
                    if ev.key in (pygame.K_UP, pygame.K_w):
                        self._sel = (self._sel - 1) % len(self._MENU_ITEMS)
                    if ev.key in (pygame.K_DOWN, pygame.K_s):
                        self._sel = (self._sel + 1) % len(self._MENU_ITEMS)
                    if ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                        result = self._MENU_ITEMS[self._sel][1]
                        if result == "custom":
                            path = self._pick_custom_lep()
                            if path:
                                return ("custom", path)
                            # cancelled – stay on title
                        else:
                            return result
                if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                    for i, r in enumerate(self._rects):
                        if r and r.collidepoint(ev.pos):
                            result = self._MENU_ITEMS[i][1]
                            if result == "custom":
                                path = self._pick_custom_lep()
                                if path:
                                    return ("custom", path)
                            else:
                                return result

            # Screensaver — if active, skip normal draw entirely
            if _ss.tick(dt, mx, my, had_event):
                _ss.draw()
                pygame.display.flip()
                continue

            self._draw(W, H)
            pygame.display.flip()

    def _draw(self, W, H):
        scr = self.screen
        scr.fill(C_TITLE_BG)
        t = self.tick
        # Scrolling grid
        grid_surf = pygame.Surface((W, H), pygame.SRCALPHA)
        off = (t * 0.4) % TILE
        for x in range(-TILE, W+TILE, TILE):
            pygame.draw.line(grid_surf, (20,40,80,60), (int(x+off),0), (int(x+off),H))
        for y in range(-TILE, H+TILE, TILE):
            pygame.draw.line(grid_surf, (20,40,80,60), (0,int(y+off)), (W,int(y+off)))
        scr.blit(grid_surf, (0,0))
        # Glow behind title
        for radius in range(180, 60, -30):
            alpha = int(18 * (1 - radius/200))
            gs = pygame.Surface((radius*2, radius*2), pygame.SRCALPHA)
            pygame.draw.circle(gs, (0, 160, 255, alpha), (radius, radius), radius)
            scr.blit(gs, (W//2-radius, H//2-180-radius))
        # Animated title letters
        title_y = H//2 - 180
        letters  = "LOCKESC"
        letter_w = 74
        total_w  = letter_w * len(letters)
        start_x  = W//2 - total_w//2
        colours  = [(0,200,255),(0,180,240),(0,160,220),(80,220,255),
                    (0,200,255),(255,60,80),(255,80,100)]
        for i, (ch, col) in enumerate(zip(letters, colours)):
            wave = math.sin(t * 0.08 + i * 0.6) * 8
            cx   = start_x + i * letter_w + letter_w//2
            cy   = int(title_y + wave)
            sh = self.font_xl.render(ch, True, (0,0,0))
            scr.blit(sh, sh.get_rect(center=(cx+3, cy+3)))
            s = self.font_xl.render(ch, True, col)
            scr.blit(s, s.get_rect(center=(cx, cy)))
        sub_alpha = int(180 + 75*math.sin(t*0.05))
        sub_surf  = self.font_md.render("STEALTH  ·  STRATEGY  ·  ESCAPE", True,
                                         (sub_alpha, sub_alpha, sub_alpha))
        scr.blit(sub_surf, sub_surf.get_rect(center=(W//2, H//2 - 100)))

        # ── Menu list ────────────────────────────────────────────────────────
        menu_w   = 320
        n        = len(self._MENU_ITEMS)
        total_mh = n * self._ITEM_H + (n - 1) * 8
        menu_top = H//2 - 30
        self._rects = []
        for i, (label, _) in enumerate(self._MENU_ITEMS):
            iy      = menu_top + i * (self._ITEM_H + 8)
            ix      = W//2 - menu_w//2
            rect    = pygame.Rect(ix, iy, menu_w, self._ITEM_H)
            self._rects.append(rect)
            sel     = (i == self._sel)
            # Background fill
            bg_col  = (0, 60, 120, 220) if sel else (10, 20, 50, 160)
            bg_surf = pygame.Surface((menu_w, self._ITEM_H), pygame.SRCALPHA)
            bg_surf.fill(bg_col)
            scr.blit(bg_surf, (ix, iy))
            # Border
            border  = (0, 200, 255) if sel else (30, 70, 140)
            bw      = 2 if sel else 1
            pygame.draw.rect(scr, border, rect, bw)
            # Highlight bar on left edge
            if sel:
                pygame.draw.rect(scr, (0, 220, 255), (ix, iy, 4, self._ITEM_H))
            # Cursor arrow (procedural — no Unicode needed)
            if sel:
                _draw_arrow(scr, ix + 16, iy + self._ITEM_H//2, 12, (0, 220, 255))
            # Label text
            lbl_col = (255, 255, 255) if sel else (120, 150, 200)
            lbl_s   = self.font_md.render(label, True, lbl_col)
            scr.blit(lbl_s, (ix + 34, iy + self._ITEM_H//2 - lbl_s.get_height()//2))
            # Sub-hint for custom
            if label.endswith("CUSTOM"):
                hint_col = (60, 100, 160) if not sel else (80, 160, 220)
                hint_s   = self.font_sm.render(".lep / .ler file", True, hint_col)
                scr.blit(hint_s, (ix + menu_w - hint_s.get_width() - 10,
                                   iy + self._ITEM_H - hint_s.get_height() - 4))

        # Navigation hint
        nav_s = self.font_sm.render("↑ ↓  navigate    ENTER  select", True, (50, 80, 130))
        scr.blit(nav_s, nav_s.get_rect(center=(W//2, menu_top + total_mh + 26)))

        # Controls reference (compact)
        dw = 320
        ref_y = menu_top + total_mh + 56
        pygame.draw.line(scr, (20, 50, 90), (W//2-dw//2, ref_y), (W//2+dw//2, ref_y), 1)
        hints = [
            ("WASD",        "Move (quiet)"),
            ("SHIFT",       "Sprint"),
            ("E",           "Use door"),
            ("H",           "Hide"),
            ("ESC",         "Pause / menu"),
            ("F11",         "Fullscreen"),
        ]
        col_x = [W//2 - 200, W//2 + 20]
        for i, (key, desc) in enumerate(hints):
            row = i // 2; col = i % 2
            ky  = ref_y + 10 + row * 22
            kx  = col_x[col]
            ks  = self.font_sm.render(f"[{key}]", True, (0, 160, 200))
            ds  = self.font_sm.render(desc,        True, (80, 100, 130))
            scr.blit(ks, (kx, ky))
            scr.blit(ds, (kx + 80, ky))

        vs = self.font_sm.render("v7  –  KeyRing editor  |  rooms: .ler  |  projects: .lep", True, (40,50,65))
        scr.blit(vs, (10, H-22))
        scr.blit(self.scanlines, (0,0))


# ════════════════════════════════════════════════════════════════════════════
# Game
# ════════════════════════════════════════════════════════════════════════════
# Viewport dimensions – overwritten by Game.__init__ based on display resolution
VIEW_W = 900
VIEW_H = 600


# ════════════════════════════════════════════════════════════════════════════
# Procedural draw helpers – driven by ObjectRegistry visuals dicts
# ════════════════════════════════════════════════════════════════════════════
def _col(v, key, default):
    """Pull a color from a visuals dict, returning tuple or default."""
    val = v.get(key, default)
    return tuple(val) if isinstance(val, list) else (val if val else default)

def _draw_bevel_door(surf, d, sx, sy, tile, vis_global, font_sm):
    """Standard door: filled rect with bevel highlights and knob."""
    v = d.def_["visuals"]
    if d.bashed:
        col = _col(v, "bashed_color", (90, 30, 10))
    elif d.open:
        col = _col(v, "open_color", (140, 100, 40))
    else:
        col = _col(v, "closed_color", (75, 50, 18))
    pygame.draw.rect(surf, col, (sx, sy, tile, tile))
    bl = _col(v, "bevel_light", (180, 140, 70))
    bd = _col(v, "bevel_dark",  (50,  35,  10))
    pygame.draw.line(surf, bl, (sx+1, sy+1),      (sx+tile-1, sy+1),      2)
    pygame.draw.line(surf, bl, (sx+1, sy+1),      (sx+1,      sy+tile-1), 2)
    pygame.draw.line(surf, bd, (sx+1, sy+tile-1), (sx+tile-1, sy+tile-1), 2)
    pygame.draw.line(surf, bd, (sx+tile-1, sy+1), (sx+tile-1, sy+tile-1), 2)
    if not d.bashed:
        kx, ky = sx+tile-6, sy+tile//2
        pygame.draw.circle(surf, _col(v, "knob_color", (255, 200, 80)), (kx, ky), 3)
    lbl = v.get("label_bashed", "BASH") if d.bashed else (
          v.get("label_open",   "▭")   if d.open  else
          v.get("label_closed", "▬"))
    lc = _col(v, "label_color", (180, 140, 80))
    if d.bashed: lc = _col(v, "bash_x_color", (220, 60, 0))
    elif d.changed: lc = _col(v, "changed_color", (255, 180, 50))
    draw_text(surf, lbl, sx+tile//2, sy+tile//2, font_sm, lc, "center")
    if d.bashed:
        xc = _col(v, "bash_x_color", (220, 60, 0))
        pad = max(3, tile//8)
        pygame.draw.line(surf, xc, (sx+pad, sy+pad), (sx+tile-pad, sy+tile-pad), 2)
        pygame.draw.line(surf, xc, (sx+tile-pad, sy+pad), (sx+pad, sy+tile-pad), 2)
    elif d.changed and not d.open:
        pygame.draw.circle(surf, _col(v, "changed_color", (255, 100, 0)), (sx+tile-6, sy+6), 4)
    # Linked-pair teal dot
    if d._linked_partner is not None:
        pygame.draw.circle(surf, (60, 200, 200), (sx+5, sy+5), 3)

def _draw_oiled_door(surf, d, sx, sy, tile, font_md):
    """Oiled door: plain rect + green silent indicator."""
    v = d.def_["visuals"]
    col = _col(v, "open_color",   (140, 100, 40)) if d.open else _col(v, "closed_color", (75, 50, 18))
    pygame.draw.rect(surf, col, (sx, sy, tile, tile))
    pygame.draw.rect(surf, _col(v, "border_color", (35, 52, 95)), (sx, sy, tile, tile), 2)
    lbl = v.get("label_open", "▭") if d.open else v.get("label_closed", "▬")
    draw_text(surf, lbl, sx+tile//2, sy+tile//2, font_md, _col(v, "label_color", (150, 155, 175)), "center")
    ic  = _col(v, "indicator_color", (80, 220, 100))
    ii  = _col(v, "indicator_inner", (160, 255, 160))
    pygame.draw.circle(surf, ic, (sx+tile-6, sy+6), 4)
    pygame.draw.circle(surf, ii, (sx+tile-6, sy+6), 2)
    if d._linked_partner is not None:
        pygame.draw.circle(surf, (60, 200, 200), (sx+5, sy+5), 3)

def _draw_wall_door(surf, d, sx, sy, tile, vis_global, font_md, _vc_fn):
    """Wall door: invisible when closed, visible when open."""
    v = d.def_["visuals"]
    if d.open:
        col = _col(v, "open_color",  (90, 70, 140))
        pygame.draw.rect(surf, col, (sx, sy, tile, tile))
        pygame.draw.rect(surf, _col(v, "open_border", (120, 100, 200)), (sx, sy, tile, tile), 2)
        draw_text(surf, v.get("label_open", "▭"), sx+tile//2, sy+tile//2, font_md,
                  _col(v, "label_color", (180, 150, 255)), "center")
    else:
        wc  = _col(v, "wall_color",  _vc_fn(vis_global, "wall_color",      (18, 26, 52)))
        we  = _col(v, "wall_edge",   _vc_fn(vis_global, "wall_edge_color",  (35, 52, 95)))
        wl1 = _col(v, "wall_line1",  (45, 68, 115))
        wl2 = _col(v, "wall_line2",  (28, 44, 78))
        rect = pygame.Rect(sx, sy, tile, tile)
        pygame.draw.rect(surf, wc, rect)
        pygame.draw.rect(surf, we, rect, 2)
        pygame.draw.line(surf, wl1, rect.topleft,  rect.topright,   2)
        pygame.draw.line(surf, wl2, rect.topleft,  rect.bottomleft, 1)
    if d._linked_partner is not None:
        pygame.draw.circle(surf, (60, 200, 200), (sx+5, sy+5), 3)

def _draw_crash_door(surf, cd, sx, sy, tile, spr, font_sm):
    """Crash door: bold X when closed, translucent when open."""
    v = cd.def_["visuals"]
    if spr:
        _cds = spr.copy()
        if cd.open: _cds.set_alpha(v.get("open_alpha", 160))
        surf.blit(_cds, (sx, sy))
    else:
        if cd.open:
            col = _col(v, "open_color", (180, 60, 20))
            s_cd = pygame.Surface((tile, tile), pygame.SRCALPHA)
            s_cd.fill((*col, v.get("open_alpha", 120)))
            surf.blit(s_cd, (sx, sy))
            pygame.draw.rect(surf, _col(v, "border_color", (200, 80, 30)), (sx, sy, tile, tile), 2)
        else:
            col = _col(v, "closed_color", (90, 30, 10))
            pygame.draw.rect(surf, col, (sx, sy, tile, tile))
            bc  = _col(v, "border_color", (220, 80, 40))
            bw  = v.get("border_width", 3)
            xw  = v.get("x_width", 3)
            pygame.draw.rect(surf, bc, (sx, sy, tile, tile), bw)
            pad = max(3, tile//8)
            pygame.draw.line(surf, _col(v, "x_color", (220, 80, 40)),
                             (sx+pad, sy+pad), (sx+tile-pad, sy+tile-pad), xw)
            pygame.draw.line(surf, _col(v, "x_color", (220, 80, 40)),
                             (sx+tile-pad, sy+pad), (sx+pad, sy+tile-pad), xw)
    if cd._linked_partner is not None:
        pygame.draw.circle(surf, (60, 200, 200), (sx+5, sy+5), 3)

class Game:
    def __init__(self, level_path=None, levels_root=None):
        pygame.init()
        # Bootstrap object registry from .let files (falls back to hardcoded defs).
        ObjectRegistry.load()
        # levels_root: directory that LevelBrowser, story mode, and default level use.
        # Defaults to <project>/levels/ for SP; pass ~/mplevels/ for MP.
        self._levels_root = os.path.abspath(
            levels_root if levels_root
            else os.path.join(_PROJECT_ROOT, "levels")
        )
        # Load tile visual definitions from per-tile _lockesc.lev files.
        _load_lev_defs()
        # Load state visual definitions from state_lockesc.lev.
        _load_state_vis_defs()
        pygame.display.set_caption("LockESC")
        _ico = os.path.join(os.path.dirname(os.path.abspath(__file__)), "lockesc.ico")
        if os.path.isfile(_ico):
            try:
                pygame.display.set_icon(pygame.image.load(_ico))
            except Exception:
                pass

        # ── Audio ─────────────────────────────────────────────────────────────
        self.sfx = {}
        try:
            pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
            self.sfx = _gen_sfx()
        except Exception:
            pass   # no audio hardware – silently continue

        if level_path:
            level_path = os.path.abspath(level_path)
            if os.path.exists(level_path):
                if _is_lep(level_path):
                    # .lep project – defer to _load_project after display init
                    self._pending_lep = level_path
                    self.lvl = self._make_default_lvl()
                else:
                    self.lvl = load_level(level_path)
            else:
                print(f"[LockESC] Level not found: {level_path} – loading default")
                self.lvl = self._make_default_lvl()
        else:
            self.lvl = self._make_default_lvl()

        # ── Display – borderless fullscreen (stays open when other apps focused) ──
        global VIEW_W, VIEW_H
        info = pygame.display.Info()
        VIEW_W = info.current_w
        VIEW_H = info.current_h - 50   # reserve 50px for HUD bar
        # NOFRAME gives a borderless window that doesn't force focus — other
        # applications can be clicked without LockESC minimising or yielding.
        self.screen = pygame.display.set_mode(
            (info.current_w, info.current_h), pygame.NOFRAME)
        self.clock   = pygame.time.Clock()
        self.font_lg = pygame.font.SysFont("consolas", 34, bold=True)
        self.font_md = pygame.font.SysFont("consolas", 20, bold=True)
        self.font_sm = pygame.font.SysFont("consolas", 14)
        self.tick    = 0

        # ── Guard state badges – procedural dot-plot from original art ────────
        # Coordinates are normalised (0-1) ink points extracted from the source
        # PNGs (64×80, white ink on transparent bg).  We scale to 20×25 (4:5).
        _BW, _BH = 20, 25
        _DOT = 1   # radius of each ink dot in pixels

        _INK = {
            "Alert":   [(0.734,0.125),(0.797,0.138),(0.828,0.15),(0.484,0.175),(0.859,0.175),(0.656,0.188),(0.625,0.2),(0.641,0.2),(0.734,0.2),(0.75,0.2),(0.609,0.213),(0.766,0.213),(0.469,0.225),(0.594,0.225),(0.781,0.225),(0.516,0.238),(0.188,0.263),(0.453,0.275),(0.859,0.288),(0.203,0.3),(0.844,0.313),(0.438,0.325),(0.828,0.338),(0.219,0.35),(0.422,0.363),(0.813,0.363),(0.797,0.375),(0.781,0.388),(0.234,0.4),(0.609,0.4),(0.688,0.4),(0.406,0.413),(0.25,0.438),(0.391,0.463),(0.266,0.488),(0.375,0.513),(0.281,0.538),(0.625,0.55),(0.359,0.563),(0.297,0.575),(0.391,0.6),(0.719,0.6),(0.266,0.7),(0.594,0.713),(0.266,0.738),(0.797,0.738),(0.313,0.763),(0.188,0.788),(0.203,0.788),(0.219,0.8),(0.766,0.8),(0.781,0.8),(0.234,0.813),(0.75,0.813),(0.25,0.825),(0.734,0.825),(0.266,0.838),(0.719,0.838),(0.281,0.85),(0.703,0.85),(0.297,0.863),(0.688,0.863),(0.313,0.875),(0.672,0.875),(0.328,0.888),(0.656,0.888),(0.344,0.9),(0.641,0.9),(0.359,0.913),(0.625,0.913),(0.375,0.925),(0.609,0.925),(0.391,0.938),(0.578,0.938),(0.563,0.95),(0.422,0.963),(0.438,0.963),(0.547,0.963),(0.453,0.975),(0.531,0.975),(0.469,0.988)],
            "AuthorityMock": [(0.609,0.163),(0.641,0.175),(0.672,0.188),(0.375,0.275),(0.344,0.288),(0.359,0.288),(0.609,0.288),(0.328,0.3),(0.594,0.3),(0.625,0.3),(0.641,0.3),(0.391,0.313),(0.313,0.325),(0.656,0.325),(0.297,0.338),(0.578,0.338),(0.672,0.338),(0.688,0.35),(0.188,0.363),(0.703,0.363),(0.563,0.388),(0.406,0.413),(0.422,0.463),(0.438,0.488),(0.547,0.488),(0.453,0.525),(0.531,0.538),(0.469,0.588),(0.516,0.588),(0.484,0.6),(0.563,0.625),(0.438,0.725),(0.266,0.738),(0.797,0.738),(0.313,0.763),(0.188,0.788),(0.203,0.788),(0.219,0.8),(0.766,0.8),(0.781,0.8),(0.234,0.813),(0.75,0.813),(0.25,0.825),(0.734,0.825),(0.266,0.838),(0.719,0.838),(0.281,0.85),(0.703,0.85),(0.297,0.863),(0.688,0.863),(0.313,0.875),(0.672,0.875),(0.328,0.888),(0.656,0.888),(0.344,0.9),(0.641,0.9),(0.359,0.913),(0.625,0.913),(0.375,0.925),(0.609,0.925),(0.391,0.938),(0.578,0.938),(0.563,0.95),(0.422,0.963),(0.438,0.963),(0.547,0.963),(0.453,0.975),(0.531,0.975),(0.469,0.988)],
            "BodyFound": [(0.406,0.113),(0.391,0.163),(0.375,0.175),(0.938,0.175),(0.172,0.188),(0.359,0.188),(0.344,0.2),(0.203,0.213),(0.328,0.213),(0.453,0.213),(0.313,0.225),(0.922,0.225),(0.297,0.238),(0.109,0.25),(0.281,0.25),(0.5,0.25),(0.625,0.25),(0.688,0.25),(0.125,0.263),(0.266,0.263),(0.375,0.263),(0.141,0.275),(0.391,0.275),(0.25,0.288),(0.406,0.288),(0.422,0.288),(0.703,0.288),(0.594,0.3),(0.609,0.3),(0.906,0.3),(0.563,0.313),(0.547,0.325),(0.719,0.325),(0.891,0.338),(0.188,0.363),(0.203,0.363),(0.469,0.363),(0.875,0.375),(0.172,0.388),(0.219,0.388),(0.453,0.388),(0.484,0.388),(0.5,0.4),(0.734,0.4),(0.156,0.413),(0.234,0.413),(0.438,0.413),(0.25,0.425),(0.516,0.425),(0.859,0.425),(0.141,0.438),(0.266,0.438),(0.375,0.438),(0.531,0.438),(0.281,0.45),(0.547,0.45),(0.75,0.45),(0.844,0.463),(0.078,0.475),(0.766,0.488),(0.828,0.513),(0.781,0.525),(0.859,0.538),(0.516,0.588),(0.563,0.6),(0.609,0.613),(0.641,0.625),(0.75,0.625),(0.281,0.638),(0.672,0.638),(0.141,0.65),(0.453,0.65),(0.516,0.663),(0.531,0.663),(0.547,0.675),(0.563,0.675),(0.578,0.688),(0.266,0.738),(0.797,0.738),(0.313,0.763),(0.188,0.788),(0.203,0.788),(0.219,0.8),(0.766,0.8),(0.781,0.8),(0.234,0.813),(0.75,0.813),(0.25,0.825),(0.734,0.825),(0.266,0.838),(0.719,0.838),(0.281,0.85),(0.703,0.85),(0.297,0.863),(0.688,0.863),(0.313,0.875),(0.672,0.875),(0.328,0.888),(0.656,0.888),(0.344,0.9),(0.641,0.9),(0.359,0.913),(0.625,0.913),(0.375,0.925),(0.609,0.925),(0.391,0.938),(0.578,0.938),(0.563,0.95),(0.422,0.963),(0.438,0.963),(0.547,0.963),(0.453,0.975),(0.531,0.975),(0.469,0.988)],
            "Chasing": [(0.313,0.175),(0.938,0.175),(0.656,0.2),(0.063,0.225),(0.922,0.225),(0.297,0.25),(0.641,0.25),(0.688,0.25),(0.281,0.288),(0.359,0.288),(0.703,0.288),(0.078,0.3),(0.625,0.3),(0.906,0.3),(0.266,0.325),(0.375,0.325),(0.719,0.325),(0.094,0.338),(0.891,0.338),(0.609,0.35),(0.109,0.375),(0.391,0.375),(0.875,0.375),(0.594,0.388),(0.25,0.4),(0.734,0.4),(0.125,0.425),(0.406,0.425),(0.859,0.425),(0.578,0.438),(0.234,0.45),(0.75,0.45),(0.141,0.463),(0.422,0.463),(0.844,0.463),(0.219,0.488),(0.563,0.488),(0.766,0.488),(0.156,0.513),(0.438,0.513),(0.828,0.513),(0.172,0.525),(0.781,0.525),(0.25,0.538),(0.547,0.538),(0.859,0.538),(0.453,0.563),(0.531,0.588),(0.469,0.6),(0.0,0.625),(0.563,0.625),(0.438,0.725),(0.266,0.738),(0.797,0.738),(0.313,0.763),(0.188,0.788),(0.203,0.788),(0.219,0.8),(0.766,0.8),(0.781,0.8),(0.234,0.813),(0.75,0.813),(0.25,0.825),(0.734,0.825),(0.266,0.838),(0.719,0.838),(0.281,0.85),(0.703,0.85),(0.297,0.863),(0.688,0.863),(0.313,0.875),(0.672,0.875),(0.328,0.888),(0.656,0.888),(0.344,0.9),(0.641,0.9),(0.359,0.913),(0.625,0.913),(0.375,0.925),(0.609,0.925),(0.391,0.938),(0.578,0.938),(0.563,0.95),(0.422,0.963),(0.438,0.963),(0.547,0.963),(0.453,0.975),(0.531,0.975),(0.469,0.988)],
            "Combat":   [(0.578,0.15),(0.594,0.175),(0.938,0.175),(0.125,0.188),(0.609,0.188),(0.156,0.2),(0.359,0.2),(0.922,0.225),(0.688,0.25),(0.313,0.275),(0.5,0.275),(0.109,0.288),(0.125,0.288),(0.281,0.288),(0.297,0.288),(0.359,0.288),(0.375,0.288),(0.484,0.288),(0.531,0.288),(0.703,0.288),(0.141,0.3),(0.391,0.3),(0.906,0.3),(0.719,0.325),(0.891,0.338),(0.047,0.375),(0.594,0.375),(0.875,0.375),(0.734,0.4),(0.859,0.425),(0.063,0.438),(0.578,0.45),(0.75,0.45),(0.844,0.463),(0.078,0.488),(0.766,0.488),(0.563,0.513),(0.828,0.513),(0.781,0.525),(0.547,0.538),(0.859,0.538),(0.094,0.55),(0.531,0.575),(0.109,0.588),(0.125,0.613),(0.516,0.613),(0.266,0.625),(0.75,0.625),(0.141,0.638),(0.5,0.638),(0.156,0.65),(0.0,0.663),(0.484,0.663),(0.188,0.675),(0.203,0.688),(0.469,0.688),(0.219,0.7),(0.438,0.7),(0.453,0.7),(0.234,0.713),(0.375,0.713),(0.297,0.725),(0.266,0.738),(0.797,0.738),(0.313,0.763),(0.188,0.788),(0.203,0.788),(0.219,0.8),(0.766,0.8),(0.781,0.8),(0.234,0.813),(0.75,0.813),(0.25,0.825),(0.734,0.825),(0.266,0.838),(0.719,0.838),(0.281,0.85),(0.703,0.85),(0.297,0.863),(0.688,0.863),(0.313,0.875),(0.672,0.875),(0.328,0.888),(0.656,0.888),(0.344,0.9),(0.641,0.9),(0.359,0.913),(0.625,0.913),(0.375,0.925),(0.609,0.925),(0.391,0.938),(0.578,0.938),(0.563,0.95),(0.422,0.963),(0.438,0.963),(0.547,0.963),(0.453,0.975),(0.531,0.975),(0.469,0.988)],
            "Confused": [(0.578,0.15),(0.641,0.163),(0.672,0.175),(0.5,0.213),(0.469,0.225),(0.484,0.225),(0.578,0.225),(0.594,0.225),(0.453,0.238),(0.609,0.238),(0.438,0.25),(0.625,0.25),(0.359,0.263),(0.703,0.313),(0.688,0.338),(0.672,0.363),(0.656,0.388),(0.641,0.4),(0.625,0.413),(0.453,0.425),(0.531,0.425),(0.469,0.575),(0.563,0.625),(0.266,0.738),(0.438,0.738),(0.797,0.738),(0.313,0.763),(0.188,0.788),(0.203,0.788),(0.219,0.8),(0.766,0.8),(0.781,0.8),(0.234,0.813),(0.75,0.813),(0.25,0.825),(0.734,0.825),(0.266,0.838),(0.719,0.838),(0.281,0.85),(0.703,0.85),(0.297,0.863),(0.688,0.863),(0.313,0.875),(0.672,0.875),(0.328,0.888),(0.656,0.888),(0.344,0.9),(0.641,0.9),(0.359,0.913),(0.625,0.913),(0.375,0.925),(0.609,0.925),(0.391,0.938),(0.578,0.938),(0.563,0.95),(0.422,0.963),(0.438,0.963),(0.547,0.963),(0.453,0.975),(0.531,0.975),(0.469,0.988)],
            "Exclaiming": [(0.656,0.2),(0.641,0.25),(0.359,0.288),(0.625,0.3),(0.375,0.325),(0.609,0.35),(0.391,0.375),(0.594,0.388),(0.406,0.425),(0.578,0.438),(0.422,0.463),(0.563,0.488),(0.438,0.513),(0.547,0.538),(0.453,0.563),(0.531,0.588),(0.469,0.6),(0.563,0.625),(0.438,0.725),(0.266,0.738),(0.797,0.738),(0.313,0.763),(0.188,0.788),(0.203,0.788),(0.219,0.8),(0.766,0.8),(0.781,0.8),(0.234,0.813),(0.75,0.813),(0.25,0.825),(0.734,0.825),(0.266,0.838),(0.719,0.838),(0.281,0.85),(0.703,0.85),(0.297,0.863),(0.688,0.863),(0.313,0.875),(0.672,0.875),(0.328,0.888),(0.656,0.888),(0.344,0.9),(0.641,0.9),(0.359,0.913),(0.625,0.913),(0.375,0.925),(0.609,0.925),(0.391,0.938),(0.578,0.938),(0.563,0.95),(0.422,0.963),(0.438,0.963),(0.547,0.963),(0.453,0.975),(0.531,0.975),(0.469,0.988)],
            "Process":  [(0.266,0.738),(0.797,0.738),(0.313,0.763),(0.188,0.788),(0.203,0.788),(0.219,0.8),(0.766,0.8),(0.781,0.8),(0.234,0.813),(0.75,0.813),(0.25,0.825),(0.734,0.825),(0.266,0.838),(0.719,0.838),(0.281,0.85),(0.703,0.85),(0.297,0.863),(0.688,0.863),(0.313,0.875),(0.672,0.875),(0.328,0.888),(0.656,0.888),(0.344,0.9),(0.641,0.9),(0.359,0.913),(0.625,0.913),(0.375,0.925),(0.609,0.925),(0.391,0.938),(0.578,0.938),(0.563,0.95),(0.422,0.963),(0.438,0.963),(0.547,0.963),(0.453,0.975),(0.531,0.975),(0.469,0.988)],
            "Search":   [(0.266,0.738),(0.797,0.738),(0.313,0.763),(0.188,0.788),(0.203,0.788),(0.219,0.8),(0.766,0.8),(0.781,0.8),(0.234,0.813),(0.75,0.813),(0.25,0.825),(0.734,0.825),(0.266,0.838),(0.719,0.838),(0.281,0.85),(0.703,0.85),(0.297,0.863),(0.688,0.863),(0.313,0.875),(0.672,0.875),(0.328,0.888),(0.656,0.888),(0.344,0.9),(0.641,0.9),(0.359,0.913),(0.625,0.913),(0.375,0.925),(0.609,0.925),(0.391,0.938),(0.578,0.938),(0.563,0.95),(0.422,0.963),(0.438,0.963),(0.547,0.963),(0.453,0.975),(0.531,0.975),(0.469,0.988)],
        }

        def _make_badge(ink_key):
            surf = pygame.Surface((_BW, _BH), pygame.SRCALPHA)
            surf.fill((0, 0, 0, 0))
            pts = _INK.get(ink_key, [])
            for fx, fy in pts:
                px = int(fx * _BW)
                py = int(fy * _BH)
                pygame.draw.circle(surf, (255, 255, 255, 230), (px, py), _DOT)
            return surf

        self._char_icons = {
            ALERT:    _make_badge("Alert"),
            CHASE:    _make_badge("Chasing"),
            INSPECT:  _make_badge("Process"),
            BRIEF:    _make_badge("Exclaiming"),
            PANICKED: _make_badge("BodyFound"),
            COMBAT:   _make_badge("Combat"),
            SEARCH:   _make_badge("Search"),
        }

        # ── Mode select → SP title  or  MP lobby ─────────────────────────────
        mode_sel = ModeSelectScreen(self.screen, self.clock)
        mode     = mode_sel.run()
        if mode == "quit":
            pygame.quit(); sys.exit()

        if mode == "multiplayer":
            # MPLobby IS the multiplayer title screen — go straight to it.
            self._levels_root = os.path.join(os.path.expanduser("~"), "mplevels")
            os.makedirs(self._levels_root, exist_ok=True)
            try:
                from integrity.functions.lockesc.MULTIPLAYER.mp_game import MPGame
                from integrity.functions.lockesc.MULTIPLAYER.lobby import MPLobby
                self.__class__ = MPGame
                MPGame.__mp_init_extra__(self)
            except ImportError:
                pass   # MULTIPLAYER module absent – fall through as plain SP
            else:
                while True:
                    lobby = MPLobby(self.screen, self.clock)
                    cfg   = lobby.run()
                    if cfg is None:
                        # User backed all the way out — return to mode select
                        pygame.quit(); sys.exit()
                    self._mp_mode  = cfg["mode"]
                    self._lan_port = cfg["lan_port"]
                    self._host_ip  = cfg["host_ip"]
                    _lp = cfg["level_path"]
                    if _is_lep(_lp):
                        self._load_project(_lp)   # .lep bundle → load first room
                    else:
                        self.lvl = load_level(_lp)
                    break
                self.reset()
                # Show dual loadout screen — P2 state exists after reset()
                _inv2  = getattr(self, "inventory2",  self.inventory)
                _eq2   = getattr(self, "equipment2",  self.equipment)
                eq_screen = MPEquipScreen(
                    self.screen, self.clock,
                    self.equipment, self.inventory,
                    _eq2, _inv2,
                    getattr(self, '_gold', 0), post_level=False)
                eq_screen.run()
                return   # boot complete; run() takes over from here

        # ── Singleplayer: normal TitleScreen ──────────────────────────────────
        while True:
            title  = TitleScreen(self.screen, self.clock, levels_root=self._levels_root)
            result = title.run()
            if result == "quit":
                pygame.quit(); sys.exit()
            if result == "story":
                self._boot_story_mode(); break
            elif isinstance(result, tuple) and result[0] == "custom":
                self._load_via_path(result[1]); break
            else:
                break   # "play" / any other value

        self.reset()
        # Show pre-level equip screen (equipment state initialised in reset())
        eq_screen = EquipScreen(
            self.screen, self.clock, self.equipment, self.inventory,
            getattr(self, '_gold', 0), post_level=False)
        eq_screen.run()


    def _load_visuals(self):
        """Pre-load/cache sprites and build background surface."""
        SpriteCache.clear()
        v  = self.visuals
        bd = self.level_dir   # resolve relative paths against level file
        # background surface (built once, blitted every frame)
        bg_img = SpriteCache.get(v.get("background_image"), base_dir=bd)
        if bg_img:
            self._bg_surf = pygame.Surface((VIEW_W, VIEW_H))
            # tile the image across the surface
            iw, ih = bg_img.get_size()
            for ty in range(0, VIEW_H + ih, ih):
                for tx in range(0, VIEW_W + iw, iw):
                    self._bg_surf.blit(bg_img, (tx, ty))
        else:
            self._bg_surf = None  # use procedural checkerboard

    def _boot_story_mode(self):
        """Load story/chapter1.lep from the active levels root."""
        story_path = os.path.join(self._levels_root, "story", "chapter1.lep")
        if os.path.exists(story_path):
            try:
                self._load_project(story_path)
            except Exception as e:
                print(f"[Story] Could not load {story_path}: {e}")
        else:
            print(f"[Story] chapter1.lep not found at {story_path} – starting default level")

    def _load_project(self, path):
        """Load the first room of a .lep project file or bundle."""
        try:
            real = _lep_json_path(path)
            with open(real, encoding="utf-8") as f:
                proj = json.load(f)
            base = _lep_base(real)
            rooms = proj.get("rooms", [])
            if rooms:
                raw = rooms[0].get("path", "")
                abs_room = _find_room_bundle(raw, base)
                if os.path.exists(abs_room):
                    self.lvl = load_level(abs_room)
                    return
            print(f"[LockESC] Project has no valid rooms: {path}")
        except Exception as e:
            print(f"[LockESC] Failed to load project {path}: {e}")

    def _make_default_lvl(self):
        pdir = self._levels_root
        os.makedirs(pdir, exist_ok=True)
        bundle = os.path.join(pdir, "level_01.ler")
        # Migrate old flat file into bundle if needed
        old_flat = os.path.join(pdir, "level_01_flat.ler")
        for old_name in ("level_01.ler",):
            flat = os.path.join(pdir, old_name)
            if os.path.isfile(flat):
                # It's a flat file — move it into a bundle folder
                import tempfile, shutil
                tmp = flat + "._tmp"
                os.rename(flat, tmp)
                os.makedirs(bundle, exist_ok=True)
                shutil.move(tmp, os.path.join(bundle, "room.ler"))
                break
        for old_ext in (".lep", ".json"):
            old_p = os.path.join(pdir, f"level_01{old_ext}")
            if not os.path.exists(bundle) and os.path.exists(old_p):
                os.makedirs(bundle, exist_ok=True)
                import shutil
                shutil.move(old_p, os.path.join(bundle, "room.ler"))
                break
        if not os.path.exists(bundle):
            _save_ler_bundle(make_default_level_json(), bundle)
        return load_level(bundle)

    def reset(self):
        lvl = self.lvl
        self.walls      = set(lvl["walls"])
        self.los_walls  = set(lvl.get("los_walls", lvl["walls"]))
        self.loot       = set(map(tuple, lvl["loot"]))
        self.mini_loot  = set(map(tuple, lvl.get("mini_loot", [])))
        self.main_loot  = set(map(tuple, lvl["main_loot"]))
        self.main_loot_taken   = False
        self.main_loot_noticed = False
        self.hides      = set(lvl["hides"])
        self.windows    = set(lvl["windows_raw"])
        self.fences      = set(lvl.get("fences_raw", []))
        self.pits        = set(map(tuple, lvl.get("pits_raw", [])))
        self.thin_walls  = lvl.get("thin_walls_raw", [])
        self.total_loot = len(self.loot) + len(self.main_loot)   # mini_loot not counted
        self.exit_pos   = tuple(lvl["exit_pos"])
        self.tile       = lvl["tile"]
        self.visuals    = lvl.get("visuals", {})
        # level_path is the bundle folder (myroom.ler/) or a flat .ler file.
        # For bundles (isdir): level_dir = the bundle folder itself so that
        #   images/  and  tiles/  sub-folders resolve correctly.
        # For flat files: level_dir = dirname of the file (legacy behaviour).
        lp = lvl.get("level_path") or os.path.abspath(__file__)
        if os.path.isdir(lp):
            self.level_dir = lp                   # bundle folder
        else:
            self.level_dir = os.path.dirname(lp)  # flat file legacy
        # Per-bundle custom tile visual defs (override global _load_lev_defs)
        self._bundle_tile_defs = (
            _load_bundle_tile_defs(self.level_dir) if os.path.isdir(self.level_dir) else {}
        )
        self._bg_surf   = None
        self._load_visuals()
        self.state      = "play"
        self.death_cause = None   # "guard", "pit", etc.
        self.score      = 0
        self.tick       = 0
        self.noise_events = []
        self._search_alarm_t = 0.0
        self._game_time = 0.0
        self._ev_door_used    = False
        self._ev_door_bashed  = False
        self._ev_loot         = False
        self._ev_main_loot    = False
        self._ev_briefing     = False
        self._ev_guard_states = {"alert": False, "chase": False}
        self._run_sprinted    = False
        self._run_detected    = False
        self._no_guards_level = len(lvl.get("guard_objs", [])) == 0

        self.doors        = [Door(d["col"], d["row"], d.get("open", False))
                             for d in lvl["doors_raw"]]
        self.oiled_doors  = [OiledDoor(d["col"], d["row"], d.get("open", False))
                             for d in lvl.get("oiled_doors_raw", [])]
        self.wall_doors   = [WallDoor(d["col"], d["row"], d.get("open", False),
                                       d.get("allow_manual", True), d.get("channel", 0))
                             for d in lvl.get("wall_doors_raw", [])]
        self.crashdoors   = [CrashDoor(d["col"], d["row"])
                             for d in lvl["crashdoors_raw"]]
        # Auto-link adjacent same-type door pairs per each type's linked_by_adjacency flag
        _autolink(self.doors)
        _autolink(self.oiled_doors)
        _autolink(self.wall_doors)
        _autolink(self.crashdoors)
        self.noisemakers  = [Noisemaker(n["col"], n["row"], n)
                             for n in lvl["noisemakers_raw"]]
        self.creak_floors = [CreakFloor(n["col"], n["row"], n)
                             for n in lvl.get("creak_floors_raw", [])]
        self.item_piles   = [ItemPile(n["col"], n["row"], n)
                             for n in lvl.get("item_piles_raw", [])]
        self.buy_items    = [BuyItem(n["col"], n["row"], n)
                             for n in lvl.get("buy_items_raw", [])]
        self.shop_leaves  = [(n["col"], n["row"]) for n in lvl.get("shop_leaves_raw", [])]
        self._shop_menu   = None   # ShopMenu instance, set when player steps on buy_item
        self.detail_imgs  = [DetailImg(n["col"], n["row"], n)
                             for n in lvl.get("detail_imgs_raw", [])]
        self.detail_txts  = [DetailTxt(n["col"], n["row"], n)
                             for n in lvl.get("detail_txts_raw", [])]
        self.inventory    = Inventory()
        # Equipment persists across levels — only init if not already set
        if not hasattr(self, 'equipment'):
            self.equipment = EquipmentState()
        self.floor_hazards: list[BurningCloak] = []   # active floor hazards
        self.aiming       = False   # right-click aim mode
        self._dragging_body = None  # guard being dragged
        self._drag_toggle_active = False  # Z key toggles drag mode
        self.snitches     = [Snitch(n["col"], n["row"], n, self.tile)
                             for n in lvl.get("snitches_raw", [])]
        for _s in self.snitches:
            _s.walls_ref   = self.los_walls
            _s.windows_ref = self.windows
            _s._cols       = lvl["cols"]
            _s._rows       = lvl["rows"]
            _s._recovery_path     = None
            _s._recovery_path_idx = 0
            _s.scan_level_intelligence(self.los_walls, lvl["cols"], lvl["rows"])
        self.cameras      = [CameraEntity(n["col"], n["row"], n, self.tile)
                             for n in lvl.get("cameras_raw", [])]
        self.io_inputs    = [IOInput(n["col"], n["row"], n, self.tile)
                             for n in lvl.get("io_transmit_raw", [])]
        self.io_outputs   = [IOOutput(n["col"], n["row"], n)
                             for n in lvl.get("io_receive_raw", [])]
        # Give each output access to the scene objects it may act on
        for out in self.io_outputs:
            out.bind(self.doors, self.wall_doors, self.noisemakers)

        # ── Connection signal→slot map ─────────────────────────────────────
        # Built from the editor's visual wiring list.  Keyed by
        # (from_col, from_row, signal_name) → list of (to_col, to_row, slot).
        self._connections: dict = {}
        for c in lvl.get("connections", []):
            key = (c["from_col"], c["from_row"], c.get("from_signal", ""))
            self._connections.setdefault(key, []).append(
                (c["to_col"], c["to_row"], c.get("to_slot", "")))

        self.timers       = [TimerNode(n, self.tile)
                             for n in lvl.get("timers_raw", [])]
        self.thin_doors   = [ThinDoor(n, self.tile)
                             for n in lvl.get("thin_door_raw", [])]
        _autolink(self.thin_doors)
        self.invis_walls  = lvl.get("invis_walls", set())

        # ── Region system ─────────────────────────────────────────────────────
        # regions_data: dict of region_id -> set of (col, row) tile positions
        # tile_to_region: (col, row) -> region_id  (first match wins)
        # inbetween_tiles: set of (col,row) tiles that are plain connectors
        # doorway_data: list of dicts describing doorway connectors
        self.regions_data:    dict[int, set] = {}
        self.tile_to_region:  dict           = {}
        self.inbetween_tiles: set            = set()
        # doorway_data entries: {"tiles": set(col,row), "connects": set(rid)|None}
        # connects=None means auto-detect at runtime
        self.doorway_data:    list           = []

        for robj in lvl.get("regions_raw", []):
            rtype = robj.get("type", "region")
            rid   = robj.get("region_id", 1)
            tiles = [(t2[0], t2[1]) for t2 in robj.get("tiles", [])]

            if rtype == "region":
                if rid not in self.regions_data:
                    self.regions_data[rid] = set()
                for tc2 in tiles:
                    self.regions_data[rid].add(tc2)
                    if tc2 not in self.tile_to_region:
                        self.tile_to_region[tc2] = rid

            elif rtype == "region_inbetween":
                # Plain connector — tiles belong to no numbered region,
                # but if the player is in either bordering region both are lit,
                # and if the player stands in the inbetween itself both are lit.
                for tc2 in tiles:
                    self.inbetween_tiles.add(tc2)

            elif rtype == "region_inbetween_doorway":
                # Doorway connector — same as inbetween but also checks whether
                # any LOS-blocking openable sitting on/adjacent to the doorway
                # tile(s) is currently open.  If open → the far region stays lit.
                connects = robj.get("connects")  # optional explicit [rid_a, rid_b]
                self.doorway_data.append({
                    "tiles":    set(tiles),
                    "connects": set(connects) if connects else None,
                })
                for tc2 in tiles:
                    self.inbetween_tiles.add(tc2)

        # _region_alpha: dict of region_id -> float 0..1 (1=fully visible, 0=black)
        # We smooth-lerp this every frame
        self._region_alpha:    dict = {rid: 1.0 for rid in self.regions_data}
        self._regions_enabled       = bool(self.regions_data)
        # Thin doors start blocking movement; open ones are removed from walls
        for td in self.thin_doors:
            pt = td.tile_pos()
            self.walls.add(pt)
            if td.open:
                self.walls.discard(pt)

        # AI hint tile sets (tile coords; built from level objects)
        def _hint_tiles(raw):
            """Convert a list of hint objects to a set of (col,row) tile coords."""
            out = set()
            for obj in raw:
                for t2 in obj.get("tiles", []):
                    out.add((t2[0], t2[1]))
            return out
        self.ai_cover_tiles = _hint_tiles(lvl.get("ai_cover_raw", []))
        self.ai_choke_tiles = _hint_tiles(lvl.get("ai_choke_raw", []))
        self.ai_avoid_tiles = _hint_tiles(lvl.get("ai_avoid_raw", []))

        self.player = Player(*lvl["player_start"], tile=self.tile)
        if hasattr(self, "player") and self.player is not None:
            self.player.hp = 2  # 2 pistol hits or 1 shotgun hit = death

        self.guards = []
        for obj in lvl["guard_objs"]:
            raw_wps = obj.get("waypoints", [[obj["col"], obj["row"]]])
            pause_f = obj.get("pause_flags", [False]*len(raw_wps))
            wp_data = obj.get("wp_data",    [{}]*len(raw_wps))
            while len(pause_f) < len(raw_wps): pause_f.append(False)
            while len(wp_data) < len(raw_wps): wp_data.append({})
            pxwps = [tc(w[0], w[1], self.tile) for w in raw_wps]
            g = Guard(pxwps, pause_f, lvl["cols"], lvl["rows"],
                      tile=self.tile, wp_data=wp_data)
            g.walls_ref = self.los_walls
            g.windows_ref = self.windows
            g.ai_cover_hints  = self.ai_cover_tiles
            g.ai_choke_hints  = self.ai_choke_tiles
            g.ai_avoid_hints  = self.ai_avoid_tiles
            g.known_door_states = {d.tile_pos(): d.original_open for d in self.doors}
            g.knows_layout = bool(obj.get("knows_layout", False))
            g.ambusher     = bool(obj.get("ambusher",     False))
            # ambusher implies knows_layout for maximum effectiveness
            if g.ambusher:
                g.knows_layout = True
            g.has_gun  = bool(obj.get("has_gun",   False))
            # Leaver personality: level can force it; otherwise random 30%
            if "is_leaver" in obj:
                g.is_leaver = bool(obj["is_leaver"])
            # Walkaholic: level can force; otherwise random 15%
            if "is_walkaholic" in obj:
                g.is_walkaholic = bool(obj["is_walkaholic"])
            # Brave / coward: only meaningful for gun guards; level can force
            if "is_brave" in obj:
                g.is_brave  = bool(obj["is_brave"])
                g.is_coward = False
            if "is_coward" in obj:
                g.is_coward = bool(obj["is_coward"])
                g.is_brave  = False
            # Non-gun guards can't meaningfully be brave/coward
            if not g.has_gun:
                g.is_brave = False
                g.is_coward = False
            # else: random value already set in __init__
            g._recovery_path     = None
            g._recovery_path_idx = 0
            self.guards.append(g)

        callsign_pool = GUARD_CALLSIGNS[:]
        random.shuffle(callsign_pool)
        for i, g in enumerate(self.guards):
            g.callsign = callsign_pool[i % len(callsign_pool)]

        world_w = lvl["W"]; world_h = lvl["H"]
        cam_smooth = self.visuals.get("camera_smooth", None)
        if cam_smooth is not None:
            try: cam_smooth = float(cam_smooth)
            except Exception: cam_smooth = None
        self.camera = Camera(VIEW_W, VIEW_H, world_w, world_h, smooth=cam_smooth)
        self.camera.x = self.player.x - VIEW_W / 2
        self.camera.y = self.player.y - VIEW_H / 2

        pygame.display.set_caption(f"LockESC – {lvl['name']}")

    # ── search points ─────────────────────────────────────────────────────────
    @property
    def search_points(self):
        pts = []
        for (hc,hr) in self.lvl["hides"]:
            pts.append(tc(hc, hr, self.tile))
        for (mc,mr) in self.lvl["main_loot"]:
            pts.append(tc(mc, mr, self.tile))
        return pts

    def _fire_signal(self, col, row, signal):
        """Fire a named signal from tile (col,row), triggering any wired target slots."""
        for (to_col, to_row, slot) in self._connections.get((col, row, signal), []):
            # Find the target object and call the right action
            for out in self.io_outputs:
                if out.col == to_col and out.row == to_row:
                    out.trigger(); break
            # slot dispatch for non-receive_node targets
            if slot == "toggle_door":
                for d in self.doors:
                    if d.col == to_col and d.row == to_row:
                        d.open = not d.open
            elif slot == "open_door":
                for d in self.doors:
                    if d.col == to_col and d.row == to_row:
                        d.open = True
            elif slot in ("toggle_wall_door", "open_wall_door", "close_wall_door"):
                for wd in self.wall_doors:
                    if wd.col == to_col and wd.row == to_row:
                        if slot == "toggle_wall_door": wd.open = not wd.open
                        elif slot == "open_wall_door":  wd.open = True
                        elif slot == "close_wall_door": wd.open = False
            elif slot == "toggle_noisemaker":
                for nm in self.noisemakers:
                    if nm.col == to_col and nm.row == to_row:
                        nm.active = not nm.active

    def _trigger_search(self):
        if self.main_loot_noticed: return
        self.main_loot_noticed = True
        self._search_alarm_t   = 3.0
        sp = self.search_points
        for g in self.guards:
            if g.state not in (CHASE,):
                g.go_search(sp)

    def _trigger_witness_search(self):
        self._search_alarm_t = 2.0
        sp = self.search_points
        for g in self.guards:
            if g.state not in (CHASE, SEARCH):
                g.go_search(sp)

    @property
    def exit_open(self):
        if self.main_loot_taken: return True
        return not self.loot and not self.main_loot

    @property
    def closed_door_tiles(self):
        s = {d.tile_pos() for d in self.doors if not d.open}
        s |= {d.tile_pos() for d in self.crashdoors if not d.open}
        s |= {d.tile_pos() for d in self.oiled_doors if not d.open}
        s |= {d.tile_pos() for d in self.wall_doors if not d.open}
        return s

    @property
    def open_door_tiles(self):
        s = {d.tile_pos() for d in self.doors if d.open}
        s |= {d.tile_pos() for d in self.oiled_doors if d.open}
        s |= {d.tile_pos() for d in self.wall_doors if d.open}
        return s

    # ── pause menu ────────────────────────────────────────────────────────────
    _PAUSE_ITEMS = [
        ("Resume",  "resume"),
        ("Restart", "restart"),
        ("Title",   "title"),
        ("Quit",    "quit"),
    ]

    def _run_pause_menu(self):
        """Overlay pause menu with grayscale game view.
        Returns 'resume', 'restart', 'title', or 'quit'.
        Menu buttons are anchored bottom-left, ending at the middle-left.
        """
        W, H   = self.screen.get_size()
        clock  = self.clock
        items  = self._PAUSE_ITEMS

        font_h  = pygame.font.SysFont("consolas", 26, bold=True)
        font_s  = pygame.font.SysFont("consolas", 13)
        font_lg = pygame.font.SysFont("consolas", 36, bold=True)

        IH = 46
        IW = 220
        MARGIN = 18
        GAP = 7

        # ── Snapshot + grayscale the current screen ───────────────────────
        # Fast grayscale: scale down to 1px to get average colour (luma),
        # then use BLEND_RGB_MULT to desaturate. Avoids slow PixelArray loops.
        snap = self.screen.copy()
        try:
            # Scale to tiny surface to extract per-channel average, then
            # use transform.grayscale if available (pygame 2.4+), else fallback.
            if hasattr(pygame.transform, "grayscale"):
                gs = pygame.transform.grayscale(snap)
            else:
                # Fallback: convert surface to greyscale via BLEND_RGB_MULT trick.
                # Extract luminance by averaging R+G+B channels via a 1×1 scaled copy.
                tiny = pygame.transform.scale(snap, (1, 1))
                avg_col = tiny.get_at((0, 0))
                luma = int(avg_col[0] * 0.299 + avg_col[1] * 0.587 + avg_col[2] * 0.114)
                # Desaturate: blit a grey overlay with BLEND_RGB_MULT
                gs = snap.copy()
                grey_mask = pygame.Surface((W, H))
                grey_mask.fill((luma, luma, luma))
                # Proper channel-by-channel greyscale via surfarray if numpy is present
                try:
                    import numpy as np
                    arr = pygame.surfarray.pixels3d(gs)
                    luma_arr = (arr[:,:,0]*0.299 + arr[:,:,1]*0.587 + arr[:,:,2]*0.114).astype(np.uint8)
                    arr[:,:,0] = luma_arr
                    arr[:,:,1] = luma_arr
                    arr[:,:,2] = luma_arr
                    del arr
                except ImportError:
                    gs.blit(grey_mask, (0, 0), special_flags=pygame.BLEND_RGB_MULT)
        except Exception:
            gs = snap.copy()
        # Slight dark tint over the grayscale
        tint = pygame.Surface((W, H), pygame.SRCALPHA)
        tint.fill((0, 0, 0, 80))
        gs.blit(tint, (0, 0))

        # ── Layout: buttons bottom-left, ending at vertical midpoint ──────
        # Stack from bottom up so that the bottom of the last button sits at H//2
        total_h = len(items) * IH + (len(items) - 1) * GAP
        menu_bottom = H // 2      # bottom edge of the whole button stack
        menu_top    = menu_bottom - total_h
        menu_x      = MARGIN

        # Pre-build rects (index 0 = top = "Resume")
        rects = []
        for i in range(len(items)):
            ry = menu_top + i * (IH + GAP)
            rects.append(pygame.Rect(menu_x, ry, IW, IH))

        # "PAUSED" title sits above the buttons
        title_y = menu_top - 52

        sel = 0
        while True:
            clock.tick(FPS)
            mx, my = pygame.mouse.get_pos()

            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    return "quit"
                if ev.type == pygame.KEYDOWN:
                    if ev.key == pygame.K_ESCAPE:
                        return "resume"
                    if ev.key in (pygame.K_UP, pygame.K_w):
                        sel = (sel - 1) % len(items)
                    if ev.key in (pygame.K_DOWN, pygame.K_s):
                        sel = (sel + 1) % len(items)
                    if ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                        return items[sel][1]
                if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                    for i, r in enumerate(rects):
                        if r.collidepoint(ev.pos):
                            return items[i][1]

            # Mouse hover
            for i, r in enumerate(rects):
                if r.collidepoint(mx, my):
                    sel = i

            # ── Draw ──────────────────────────────────────────────────────
            self.screen.blit(gs, (0, 0))

            # PAUSED title
            title_s = font_lg.render("PAUSED", True, (220, 235, 255))
            shadow_s = font_lg.render("PAUSED", True, (0, 30, 70))
            self.screen.blit(shadow_s, (menu_x + 2, title_y + 2))
            self.screen.blit(title_s,  (menu_x, title_y))
            # Accent line under title
            pygame.draw.line(self.screen, (0, 140, 220),
                             (menu_x, title_y + title_s.get_height() + 4),
                             (menu_x + IW, title_y + title_s.get_height() + 4), 2)

            # Buttons
            for i, (label, _ret) in enumerate(items):
                rect   = rects[i]
                is_sel = (i == sel)
                # Button fill
                btn_bg = pygame.Surface((IW, IH), pygame.SRCALPHA)
                btn_bg.fill((0, 55, 110, 220) if is_sel else (10, 18, 40, 190))
                self.screen.blit(btn_bg, rect.topleft)
                # Border
                border_col = (0, 200, 255) if is_sel else (25, 55, 110)
                pygame.draw.rect(self.screen, border_col, rect, 2 if is_sel else 1)
                # Left accent bar
                if is_sel:
                    pygame.draw.rect(self.screen, (0, 220, 255),
                                     (rect.x, rect.y, 4, IH))
                # Label
                tc = (255, 255, 255) if is_sel else (90, 130, 180)
                ls = font_h.render(label, True, tc)
                self.screen.blit(ls, ls.get_rect(
                    midleft=(rect.x + 16, rect.centery)))

            # Hint
            hint_s = font_s.render(
                "↑↓  navigate   ·   ENTER  select   ·   ESC  resume",
                True, (35, 60, 100))
            self.screen.blit(hint_s, (menu_x, menu_bottom + 10))

            pygame.display.flip()


    def _show_missing_assets_screen(self):
        """Block the game with a clear error screen when required tile assets
        are missing, and tell the player how to fix it."""
        import textwrap
        scr   = self.screen
        clock = self.clock
        lvl   = self.lvl
        W, H  = scr.get_size()

        font_lg  = pygame.font.SysFont("monospace", 26, bold=True)
        font_md  = pygame.font.SysFont("monospace", 16, bold=False)
        font_sm  = pygame.font.SysFont("monospace", 13, bold=False)

        missing  = lvl.get("missing_assets", [])
        script   = lvl.get("build_script", "")
        lvl_name = lvl.get("name", "this level")

        while True:
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    pygame.quit(); sys.exit()
                if ev.type == pygame.KEYDOWN:
                    if ev.key == pygame.K_ESCAPE:
                        pygame.quit(); sys.exit()
                    if ev.key == pygame.K_q:
                        pygame.quit(); sys.exit()

            scr.fill((8, 6, 16))

            # Error title
            title_s = font_lg.render("⚠  MISSING TILE ASSETS", True, (255, 60, 60))
            scr.blit(title_s, title_s.get_rect(center=(W//2, 60)))

            # Level name
            sub_s = font_md.render(f"Level: {lvl_name}", True, (120, 100, 160))
            scr.blit(sub_s, sub_s.get_rect(center=(W//2, 100)))

            # Explanation
            lines = [
                "This level references tile types whose asset files are not",
                "present in  integrity/tiles/  or  integrity/tiles/CUSTOM/.",
                "The level cannot be played until they are created.",
                "",
                "Missing files:",
            ]
            y = 140
            for ln in lines:
                ls = font_sm.render(ln, True, (160, 140, 200))
                scr.blit(ls, ls.get_rect(center=(W//2, y)))
                y += 20

            # Missing file list
            for m in missing:
                ms = font_sm.render(m, True, (255, 130, 60))
                scr.blit(ms, ms.get_rect(center=(W//2, y)))
                y += 18

            y += 14
            if script:
                fix_lines = [
                    "A build script has been auto-generated in the level's folder.",
                    "Run it once to create placeholder asset files:",
                    "",
                    f"  python {script}",
                    "",
                    "Then edit the generated .let / .lev files in CUSTOM/ to",
                    "define the visual appearance of your custom tiles.",
                ]
                for ln in fix_lines:
                    col = (0, 200, 130) if ln.startswith("  python") else (100, 160, 180)
                    ls  = font_sm.render(ln, True, col)
                    scr.blit(ls, ls.get_rect(center=(W//2, y)))
                    y += 18

            # Dismiss hint
            hint = font_sm.render("Press ESC or Q to quit", True, (60, 60, 90))
            scr.blit(hint, hint.get_rect(center=(W//2, H - 30)))

            pygame.display.flip()
            clock.tick(30)

    # ── run loop ──────────────────────────────────────────────────────────────
    def run(self):
        # ── Integrity gate: block play if required tile assets are absent ──────
        if self.lvl.get("missing_assets"):
            self._show_missing_assets_screen()
        while True:
            dt = min(self.clock.tick(FPS)/1000.0, 0.05)
            self.tick += 1
            self._game_time += dt

            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    pygame.quit(); sys.exit()
                if ev.type == pygame.KEYDOWN:
                    # ── Shop menu takes priority over all other keys ───────────
                    if self._shop_menu is not None and not self._shop_menu.closed:
                        self._shop_menu.handle_key(ev.key, self.inventory)
                        if hasattr(self, '_gold'):
                            self._gold = self._shop_menu.player_gold
                        if self._shop_menu.closed:
                            self._shop_menu = None
                        continue
                    if ev.key == pygame.K_ESCAPE:
                        pr = self._run_pause_menu()
                        if pr == "quit":
                            pygame.quit(); sys.exit()
                        if pr == "restart":
                            self.reset()
                        elif pr == "title":
                            # Back to mode select (same flow as cold boot)
                            mode_sel2 = ModeSelectScreen(self.screen, self.clock)
                            mode2     = mode_sel2.run()
                            if mode2 == "quit":
                                pygame.quit(); sys.exit()
                            if mode2 == "multiplayer":
                                import os as _os
                                self._levels_root = _os.path.join(_os.path.expanduser("~"), "mplevels")
                                _os.makedirs(self._levels_root, exist_ok=True)
                                try:
                                    from integrity.functions.lockesc.MULTIPLAYER.mp_game import MPGame
                                    self.__class__ = MPGame
                                    MPGame.__mp_init_extra__(self)
                                except ImportError:
                                    pass
                            title = TitleScreen(self.screen, self.clock, levels_root=self._levels_root)
                            result = title.run()
                            if result == "quit":
                                pygame.quit(); sys.exit()
                            if result == "story":
                                self._boot_story_mode()
                            elif isinstance(result, tuple) and result[0] == "custom":
                                self._load_via_path(result[1])
                            self.reset()
                        continue
                    if ev.key == pygame.K_r: self.reset()
                    if ev.key == pygame.K_F11:
                        # Toggle between borderless-fullscreen and minimised
                        pygame.display.iconify()
                        SpriteCache.clear()
                        self._load_visuals()
                    if ev.key == pygame.K_n and self.state == "won":
                        self._advance_level()
                    if ev.key == pygame.K_h and self.state == "play":
                        self._toggle_hide()
                    if ev.key == pygame.K_e and self.state == "play":
                        self._use_door()
                    if self.state == "play":
                        # TAB = cycle gun slots (pri/sec)
                        if ev.key == pygame.K_TAB:
                            self.inventory.cycle_gun()
                        # ~ = cycle gear slot
                        if ev.key == pygame.K_BACKQUOTE:
                            self.equipment.cycle_gear()
                        # Q = use selected gear
                        if ev.key == pygame.K_q:
                            self.equipment.use_gear(self.player, self.noise_events, self.tile)
                        # Other-slot select: keys 1-4 (switches focus to other context)
                        if ev.key == pygame.K_1: self.inventory.other_sel = 0; self.inventory.active_slot = "other"
                        if ev.key == pygame.K_2: self.inventory.other_sel = 1; self.inventory.active_slot = "other"
                        if ev.key == pygame.K_3: self.inventory.other_sel = 2; self.inventory.active_slot = "other"
                        if ev.key == pygame.K_4: self.inventory.other_sel = 3; self.inventory.active_slot = "other"
                        # X = drop selected item (spawn pile at player tile)
                        if ev.key == pygame.K_x:
                            self._drop_item()
                        # Z = toggle body drag mode (only if a body is nearby)
                        if ev.key == pygame.K_z:
                            if self._drag_toggle_active:
                                self._drag_toggle_active = False
                                self._dragging_body = None
                            else:
                                body_nearby = any(
                                    g.state == DEAD and
                                    dist(self.player.x, self.player.y, g.x, g.y) < self.tile * 1.5
                                    for g in self.guards
                                )
                                if body_nearby:
                                    self._drag_toggle_active = True
                if ev.type == pygame.MOUSEBUTTONDOWN and self.state == "play":
                    if ev.button == 3:   # right-click: toggle aim
                        self.aiming = not self.aiming
                    if ev.button == 1 and self.aiming:   # left-click while aiming: shoot
                        self._shoot()
                    if ev.button == 4:   # scroll up / mouse5: cycle gun
                        self.inventory.cycle_gun()
                    if ev.button == 5:   # scroll down / mouse4: cycle gun
                        self.inventory.cycle_gun()

            if self.state == "play":
                self.update(dt)

            self.draw()
            pygame.display.flip()

    def _cast_bullet_ray(self, ox, oy, ang, silent=False):
        """Cast a single bullet ray; kills first guard/snitch hit.
        Closed doors block bullets just like walls.
        Emits is_gunshot noise at impact and whiz-by points so guards go COMBAT.
        silent=True for suppressed weapons (quieter, shorter-range noise).
        """
        step = 4
        wx, wy = ox, oy
        dxr = math.cos(ang) * step
        dyr = math.sin(ang) * step
        max_r = max(self.lvl["W"], self.lvl["H"])

        if silent:
            impact_score  = 30
            impact_radius = self.tile * 4
            whiz_score    = 18
            whiz_radius   = self.tile * 3
        else:
            impact_score  = 72
            impact_radius = self.tile * 10
            whiz_score    = 50
            whiz_radius   = self.tile * 6

        closed_doors = self.closed_door_tiles
        whiz_emitted = set()

        for _ in range(max_r // step):
            wx += dxr; wy += dyr
            tile_pos = (int(wx // self.tile), int(wy // self.tile))

            # Walls and closed doors both stop the bullet
            if tile_pos in self.walls or tile_pos in closed_doors:
                self.noise_events.append(
                    NoiseEvent(wx, wy, impact_score, impact_radius, 1.0,
                               ambiguous=False, visual_only=False,
                               is_gunshot=not silent))
                return False

            # Whiz-by noise for guards near the bullet path
            for g in self.guards:
                if g.state == DEAD or id(g) in whiz_emitted: continue
                if dist(wx, wy, g.x, g.y) <= self.tile * 2.2:
                    self.noise_events.append(
                        NoiseEvent(wx, wy, whiz_score, whiz_radius, 1.0,
                                   ambiguous=False, visual_only=False,
                                   is_gunshot=not silent))
                    whiz_emitted.add(id(g))

            # Whiz-by noise for snitches near the bullet path
            for s in self.snitches:
                if getattr(s, "dead", False) or id(s) in whiz_emitted: continue
                if dist(wx, wy, s.x, s.y) <= self.tile * 2.2:
                    self.noise_events.append(
                        NoiseEvent(wx, wy, whiz_score, whiz_radius, 1.0,
                                   ambiguous=False, visual_only=False,
                                   is_gunshot=not silent))
                    whiz_emitted.add(id(s))

            # NPC hit
            for g in self.guards:
                if g.state == DEAD: continue
                if dist(wx, wy, g.x, g.y) <= g.RAD + 4:
                    g.state = DEAD
                    self.noise_events.append(
                        NoiseEvent(g.x, g.y, impact_score, impact_radius, 1.0,
                                   ambiguous=False, visual_only=False,
                                   is_gunshot=not silent))
                    return True
            for s in self.snitches:
                if getattr(s, "dead", False): continue
                if dist(wx, wy, s.x, s.y) <= s.RAD + 4:
                    s.dead = True
                    self.noise_events.append(
                        NoiseEvent(s.x, s.y, impact_score, impact_radius, 1.0,
                                   ambiguous=False, visual_only=False,
                                   is_gunshot=not silent))
                    return True

        return False

    def _shoot(self):
        """Fire the selected gun. Shotgun: 6-pellet 25-degree spread."""
        item = self.inventory.selected_item()
        if item not in ("silenced_pistol", "1911", "shotgun", "m4a1"):
            return

        GUN_DATA = {
            "silenced_pistol": (8,  3, True),
            "1911":            (65, 8, False),
            "shotgun":         (95, 10, False),
            "m4a1":            (70, 8, False),
        }
        score, r_tiles, visual_only = GUN_DATA[item]
        radius = self.tile * r_tiles
        self.noise_events.append(
            NoiseEvent(self.player.x, self.player.y, score, radius, 1.2,
                       visual_only=visual_only, is_gunshot=not visual_only))
        if not visual_only:
            pass  # gun sounds handled separately (no door sfx for gunfire)

        # go_combat is now triggered via _try_hear when guards process the
        # is_gunshot noise event — no separate loop needed here.

        ang = self.player.facing
        if item == "shotgun":
            half = math.radians(25) / 2
            for _ in range(6):
                self._cast_bullet_ray(self.player.x, self.player.y,
                                      ang + random.uniform(-half, half),
                                      silent=visual_only)
        else:
            self._cast_bullet_ray(self.player.x, self.player.y, ang,
                                  silent=visual_only)
    def _drop_item(self):
        result = self.inventory.drop_selected()
        if result:
            item_key, _slot = result
            pc, pr = self.player.tile
            # Spawn a new pile at player tile with dropped item
            self.item_piles.append(ItemPile(pc, pr, {"contents": {item_key: 1}}))

    def _toggle_hide(self):
        pt = self.player.tile
        if pt in self.hides:
            was_hidden = self.player.hidden
            self.player.hidden = not self.player.hidden
            # Signal to guards that the player just hid this frame
            self.player._just_hid = (not was_hidden and self.player.hidden)
            if not was_hidden and self.player.hidden:
                for g in self.guards:
                    sight = g.SIGHT
                    d = dist(g.x, g.y, self.player.x, self.player.y)
                    if d <= sight:
                        ang = math.atan2(self.player.y-g.y, self.player.x-g.x)
                        if abs(adiff(ang, g.facing)) <= g.FOV[g.state]:
                            if los_check(self.los_walls, g.x, g.y,
                                         self.player.x, self.player.y,
                                         self.closed_door_tiles, self.windows):
                                g.last_player = (self.player.x, self.player.y)
                                g.suspicion   = 1.0
                                g._goap.set(suspicion_full=True, player_near=False,
                                            has_last_known=True)
                                g._alert_count += 1
                                g._brief_pending = True
                                g._brief_msg     = (URG_SPOTTED, g.last_player)
                                self._trigger_witness_search()

    def _toggle_door_obj(self, d, px, py, noise_score, sound_key="toggle"):
        """Toggle d and its linked partner, emit noise/sound per def_ flags."""
        d.toggle(self._game_time)
        if not d.open:
            self._pushout_from_tile(d.col, d.row)
        if d._linked_partner is not None:
            p2 = d._linked_partner
            p2.toggle(self._game_time)
            if not p2.open:
                self._pushout_from_tile(p2.col, p2.row)
        flags = d.def_.get("flags", {})
        noise_def = d.def_.get("noise", {})
        # Oiled/silent doors make no sound at all
        if not flags.get("silent", False):
            if d.open:
                _play(self.sfx, "creak")           # opening – full volume
            else:
                _play(self.sfx, "door", volume=0.45)  # closing – quieter
        if not flags.get("silent", False):
            rad = noise_def.get("radius_tiles", 3) * self.tile
            lt  = noise_def.get("lifetime_sec", 0.9)
            self.noise_events.append(
                NoiseEvent(px, py, score=noise_score, radius=rad,
                           lifetime=lt, ambiguous=(noise_score <= NOISE_DOOR_ONCE+2)))
        self._ev_door_used = True

    def _use_door(self):
        for d in self.doors:
            px, py = tc(d.col, d.row, self.tile)
            if dist(self.player.x, self.player.y, px, py) < self.player.use_dist:
                score = d.noise_score(self._game_time)
                self._toggle_door_obj(d, px, py, score, "toggle")
                return
        for d in self.oiled_doors:
            if not d.def_.get("flags", {}).get("openable", True): continue
            px, py = tc(d.col, d.row, self.tile)
            if dist(self.player.x, self.player.y, px, py) < self.player.use_dist:
                self._toggle_door_obj(d, px, py, 0, "toggle")
                return
        for d in self.wall_doors:
            if not d.allow_manual: continue
            px, py = tc(d.col, d.row, self.tile)
            if dist(self.player.x, self.player.y, px, py) < self.player.use_dist:
                score = d.def_.get("noise", {}).get("open_once_score", NOISE_DOOR_ONCE)
                self._toggle_door_obj(d, px, py, score, "toggle")
                return
        for d in self.thin_doors:
            px, py = tc(d.col, d.row, self.tile)
            if dist(self.player.x, self.player.y, px, py) < self.player.use_dist:
                score = d.noise_score()
                d.toggle(self._game_time)
                if d._linked_partner is not None:
                    p2 = d._linked_partner
                    p2.toggle(self._game_time)
                # Update collision walls for this door
                pt = d.tile_pos()
                if d.open: self.walls.discard(pt)
                else:       self.walls.add(pt); self._pushout_from_tile(*pt)
                # Update partner walls too
                if d._linked_partner is not None:
                    pt2 = d._linked_partner.tile_pos()
                    if d._linked_partner.open: self.walls.discard(pt2)
                    else: self.walls.add(pt2); self._pushout_from_tile(*pt2)
                flags = d.def_.get("flags", {})
                noise_def = d.def_.get("noise", {})
                if not flags.get("silent", False):
                    if d.open:
                        _play(self.sfx, "creak")
                    else:
                        _play(self.sfx, "door", volume=0.45)
                if not flags.get("silent", False):
                    rad = noise_def.get("radius_tiles", 3) * self.tile
                    lt  = noise_def.get("lifetime_sec", 0.9)
                    self.noise_events.append(
                        NoiseEvent(px, py, score=score, radius=rad, lifetime=lt,
                                   ambiguous=(score <= NOISE_DOOR_ONCE+2)))
                self._ev_door_used = True
                return


    def _pushout_from_tile(self, col, row):
        """If player center is inside the given tile, push them to the nearest edge."""
        t = self.tile
        px, py = self.player.x, self.player.y
        tx0, ty0 = col * t, row * t
        tx1, ty1 = tx0 + t, ty0 + t
        # Player must be at least partially inside the tile
        if not (tx0 < px < tx1 and ty0 < py < ty1):
            return
        # Find the closest edge and push outside
        dists = {
            "left":   (px - tx0,   tx0 - self.player.RAD - 1, py),
            "right":  (tx1 - px,   tx1 + self.player.RAD + 1, py),
            "top":    (py - ty0,   px, ty0 - self.player.RAD - 1),
            "bottom": (ty1 - py,   px, ty1 + self.player.RAD + 1),
        }
        best = min(dists, key=lambda k: dists[k][0])
        if best in ("left", "right"):
            self.player.x = dists[best][1]
        else:
            self.player.y = dists[best][2]
    def _check_crashdoor_ram(self, dx, dy):
        if not self.player.sprinting: return
        if dx == 0 and dy == 0: return
        for cd in self.crashdoors:
            if not cd.def_.get("flags", {}).get("crashable", True): continue
            if cd.open: continue
            px, py = tc(cd.col, cd.row, self.tile)
            if dist(self.player.x, self.player.y, px, py) < self.tile * 1.2:
                cd.open = True
                if cd._linked_partner is not None:
                    cd._linked_partner.open = True
                nd = cd.def_.get("noise", {})
                score = nd.get("crash_score", NOISE_CRASH)
                rad   = nd.get("radius_tiles", 8) * self.tile
                lt    = nd.get("lifetime_sec", 2.5)
                _play(self.sfx, "crash")           # crashdoor – full volume
                self.noise_events.append(
                    NoiseEvent(px, py, score=score, radius=rad, lifetime=lt, ambiguous=False))
                return

    def _check_door_bash(self, dx, dy):
        """Sprint-walking into a closed door bashes it open – loud, no E needed."""
        if not self.player.sprinting: return
        if dx == 0 and dy == 0: return
        for d in self.doors:
            if not d.def_.get("flags", {}).get("bashable", True): continue
            if d.open or d.bashed: continue
            px, py = tc(d.col, d.row, self.tile)
            if dist(self.player.x, self.player.y, px, py) < self.tile * 1.1:
                d.bash_open()
                if d._linked_partner is not None:
                    d._linked_partner.bash_open()
                nd  = d.def_.get("noise", {})
                _play(self.sfx, "crash", volume=0.5)  # door bash – quieter slam
                self._ev_door_bashed = True
                score = nd.get("bash_score", NOISE_BASH_DOOR)
                rad   = nd.get("radius_tiles", 6) * self.tile
                self.noise_events.append(
                    NoiseEvent(px, py, score=score, radius=rad, lifetime=2.0, ambiguous=False))
                return
        # Oiled doors and any silent bashable door: sprint-bash silently
        for d in self.oiled_doors:
            if not d.def_.get("flags", {}).get("bashable", True): continue
            if d.open: continue
            px, py = tc(d.col, d.row, self.tile)
            if dist(self.player.x, self.player.y, px, py) < self.tile * 1.1:
                d.toggle(self._game_time)
                if d._linked_partner is not None:
                    d._linked_partner.toggle(self._game_time)
                self._ev_door_used = True
                return

    # ── update ─────────────────────────────────────────────────────────────────
    def update(self, dt):
        # Reset per-frame event flags
        self._ev_door_used   = False
        self._ev_door_bashed = False
        self._ev_loot        = False
        self._ev_briefing    = False
        self._ev_guard_states = {"alert": False, "chase": False, "not_chased": False}
        self.player._just_hid = False  # cleared each frame; set by _toggle_hide for one frame

        eq = self.equipment

        keys = pygame.key.get_pressed()
        dx = (int(keys[pygame.K_d] or keys[pygame.K_RIGHT]) -
              int(keys[pygame.K_a] or keys[pygame.K_LEFT]))
        dy = (int(keys[pygame.K_s] or keys[pygame.K_DOWN]) -
              int(keys[pygame.K_w] or keys[pygame.K_UP]))
        # Only sprint if shift is held AND player is actually moving
        _shift = bool(keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT])
        self.player.sprinting = _shift and (dx != 0 or dy != 0)
        if self.player.sprinting:
            self._run_sprinted = True

        # ── Equipment speed modifier ──────────────────────────────────────────
        speed_mul = eq.speed_multiplier(self.player.sprinting)
        self.player._equip_speed_mul = speed_mul   # read by Player.speed property below

        closed = self.closed_door_tiles
        crashdoor_closed = {d.tile_pos() for d in self.crashdoors if not d.open}
        # Pits block the player when walking (careful), but not when sprinting (falls in)
        pit_block = self.pits if not self.player.sprinting else set()
        self.player._drag_slowed = self._drag_toggle_active and self._dragging_body is not None
        self.player.move(dx, dy, self.walls | pit_block, closed - crashdoor_closed, crashdoor_closed)
        _player_moving = (dx != 0 or dy != 0)

        # ── Equipment-aware noise emission ────────────────────────────────────
        self.player._walk_noise_mul = eq.walk_noise_multiplier()
        self.player._sprint_noise_suppressed = eq.sprint_noise_suppressed()
        self.player.emit_noise(dt, self.noise_events, moving=_player_moving)

        # Creased sneakers: random squeak on step
        wx = eq.worn_effects()
        if wx.get("squeak_chance", 0) > 0 and _player_moving:
            eq._squeak_step_timer -= dt
            if eq._squeak_step_timer <= 0:
                eq._squeak_step_timer = 0.25  # check roughly per step
                if random.random() < wx["squeak_chance"]:
                    self.noise_events.append(
                        NoiseEvent(self.player.x, self.player.y,
                                   score=wx.get("squeak_score", 55),
                                   radius=self.tile * 5, lifetime=1.5,
                                   ambiguous=False))

        # ── Equipment update (cloak, boost, EMP, decoys, smoke) ──────────────
        new_hazards = eq.update(dt, self.player, self.noise_events, self.tile)
        for h in new_hazards:
            self.floor_hazards.append(
                BurningCloak(h["x"], h["y"], self.tile))

        # Update floor hazards (burning cloaks)
        for fh in self.floor_hazards:
            fh.update(dt, self.noise_events, self.guards, self.walls)
        self.floor_hazards = [fh for fh in self.floor_hazards if not fh.dead]

        # EMP: disable cameras and noisemakers in radius
        if eq.emp_active:
            for cam in getattr(self, 'cameras', []):
                cx, cy = tc(cam.col, cam.row, self.tile)
                if dist(self.player.x, self.player.y, cx, cy) <= eq.emp_radius:
                    cam._emp_disabled = True
            for nm in self.noisemakers:
                nx_, ny_ = tc(nm.col, nm.row, self.tile)
                if dist(self.player.x, self.player.y, nx_, ny_) <= eq.emp_radius:
                    nm._emp_disabled = True
        else:
            for cam in getattr(self, 'cameras', []):
                cam._emp_disabled = False
            for nm in self.noisemakers:
                nm._emp_disabled = False

        # Cloak: player becomes invisible to guards
        self.player.hidden_by_cloak = eq.cloak_active

        # ── Aim mode: steer facing toward mouse ───────────────────────────────
        if self.aiming:
            mx, my = pygame.mouse.get_pos()
            bx, by = self.camera.world_to_screen(self.player.x, self.player.y)
            self.player.facing = math.atan2(my - by, mx - bx)

        # ── Body drag (Z toggles) ────────────────────────────────────────────────
        if self._drag_toggle_active:
            if self._dragging_body is None:
                for g in self.guards:
                    if g.state != DEAD: continue
                    if dist(self.player.x, self.player.y, g.x, g.y) < self.tile * 1.5:
                        self._dragging_body = g
                        break
            if self._dragging_body is not None:
                body = self._dragging_body
                player_moved = (dx != 0 or dy != 0)
                if player_moved:
                    bdx = self.player.x - body.x
                    bdy = self.player.y - body.y
                    d_to_player = math.hypot(bdx, bdy)
                    drag_radius = self.tile * 1.2
                    if d_to_player > drag_radius:
                        pull = d_to_player - drag_radius
                        norm_x = bdx / d_to_player
                        norm_y = bdy / d_to_player
                        body.x += norm_x * pull
                        body.y += norm_y * pull
                # Dump into hide tile – max 1 existing body per hide (2 total incl. player)
                if self.player.tile in self.hides:
                    hide_t = self.player.tile
                    bodies_here = sum(
                        1 for g in self.guards
                        if g.state == DEAD
                        and ptile(g.x, g.y, self.tile) == hide_t
                        and g is not body
                    )
                    if bodies_here < 1:
                        self.guards.remove(body)
                        self._dragging_body = None
                        self._drag_toggle_active = False
                    # else: hide full – can't dump here

        # Check crash-door ram and door bash
        self._check_crashdoor_ram(dx, dy)
        self._check_door_bash(dx, dy)

        # ── IO trigger system ─────────────────────────────────────────────────
        def _fire_channel(channel):
            for out in self.io_outputs:
                if out.channel != channel: continue
                act = out.action
                # find nearest door/wall_door/noisemaker to this output node
                if act in ("toggle_door","open_door","close_door"):
                    # try wall_doors first (channel-linked), then regular doors
                    for wd in self.wall_doors:
                        if wd.channel == channel:
                            if act == "toggle_door": wd.open = not wd.open
                            elif act == "open_door":  wd.open = True
                            elif act == "close_door": wd.open = False
                    # also affect regular door on same tile if any
                    op, oc = out.row, out.col
                    for rd in self.doors:
                        if rd.col == oc and rd.row == op:
                            if act == "toggle_door": rd.toggle(self._game_time)
                            elif act == "open_door":  rd.open = True
                            elif act == "close_door": rd.open = False
                elif act == "toggle_noisemaker":
                    for nm in self.noisemakers:
                        nm.active = not nm.active

        pt = self.player.tile
        for inp in self.io_inputs:
            inp.update(pt, dt, _fire_channel)

        # ── Creak floors ──────────────────────────────────────────────────────
        for cf in self.creak_floors:
            cf.update(dt)
            if pt == cf.tile_pos() and not self.player.hidden:
                cf.step(self.player.sprinting, self.noise_events, self.tile)

        # ── Item pile pickup ──────────────────────────────────────────────────
        for pile in self.item_piles:
            if not pile.picked_up and pt == pile.tile_pos():
                if pile.try_pickup(self.inventory):
                    self._fire_signal(pile.col, pile.row, "on_pickup")

        # ── Shop: buy_item step-on → open ShopMenu ────────────────────────────
        if self._shop_menu is None:
            for bi in self.buy_items:
                if bi.active and pt == bi.tile_pos():
                    self._shop_menu = ShopMenu(bi, getattr(self, '_gold', 0))
                    break

        # ── Shop: shop_leave → advance to next level ──────────────────────────
        if pt in self.shop_leaves and self._shop_menu is None:
            nxt = self.lvl.get("next_level")
            if nxt:
                self._advance_level()
            else:
                # No next level configured – treat like exit
                self._freeze_flash("won")

        # ── Pit check (sprint into pit = dead) / pushout when walking ──────
        if pt in self.pits:
            if self.player.sprinting and not self.player.hidden:
                _play(self.sfx, 'caught')
                self.death_cause = "pit"; self._freeze_flash("dead"); return
            else:
                # Player somehow walked/jammed into a pit – push them back out
                self._pushout_from_tile(pt[0], pt[1])

        # Update noisemakers
        for nm in self.noisemakers:
            nm.update(dt, self.noise_events)

        # Update timer nodes (fire IO channels on schedule)
        def _fire_channel(ch):
            for out in self.io_outputs:
                if out.channel == ch:
                    out.trigger()
        for tm in self.timers:
            tm.update(dt, _fire_channel)

        for ne in self.noise_events: ne.update(dt)
        self.noise_events = [ne for ne in self.noise_events if not ne.dead]

        if self._search_alarm_t > 0:
            self._search_alarm_t -= dt

        # ── Loot collection ───────────────────────────────────────────────────
        if pt in self.loot:
            self.loot.remove(pt); self.score += 100
            self._gold = getattr(self, '_gold', 0) + 1
            _play(self.sfx, 'loot')
            self._ev_loot = True
            self._fire_signal(pt[0], pt[1], "on_pickup")

        if pt in self.mini_loot:
            self.mini_loot.remove(pt); self.score += 25
            # mini_loot awards no tradeable (quarter-value collectible)
            _play(self.sfx, 'loot')
            self._ev_loot = True
            self._fire_signal(pt[0], pt[1], "on_pickup")

        if pt in self.main_loot:
            self.main_loot.remove(pt)
            self.main_loot_taken = True
            self.score += 500
            self._gold = getattr(self, '_gold', 0) + 5
            _play(self.sfx, 'loot')
            self._ev_loot = True
            self._ev_main_loot = True
            px, py = tc(pt[0], pt[1], self.tile)
            self.noise_events.append(
                NoiseEvent(px, py, score=30, radius=self.tile*4, lifetime=1.2))
            self._fire_signal(pt[0], pt[1], "on_pickup")
            self._fire_signal(pt[0], pt[1], "on_main_loot_pickup")

        if pt == self.exit_pos and self.exit_open:
            _play(self.sfx, 'escape')
            self.state = "won"; return

        sp = self.search_points
        prev_states = {id(g): g.state for g in self.guards}

        # ── Snitch and Camera entities ────────────────────────────────────────
        closed_set = self.closed_door_tiles
        for snitch in self.snitches:
            if getattr(snitch, "dead", False): continue
            snitch.update(self.player, self.los_walls, self.windows, closed_set,
                          self.noise_events, dt, all_guards=self.guards,
                          game_time=self._game_time)
        for cam in self.cameras:
            cam.update(self.player, self.los_walls, self.windows, closed_set,
                       self.noise_events, dt)

        # ── Body discovery: live guards that see a dead body trigger PANICKED ──
        # Includes dead guards AND dead snitches
        for g in self.guards:
            if g.state in (DEAD, PANICKED, CHASE): continue
            triggered = False
            for dead_g in self.guards:
                if dead_g.state != DEAD: continue
                d_to_body = dist(g.x, g.y, dead_g.x, dead_g.y)
                if d_to_body < self.tile * 2.5:
                    ang = math.atan2(dead_g.y - g.y, dead_g.x - g.x)
                    in_fov = abs(adiff(ang, g.facing)) <= g.FOV.get(g.state, math.radians(90))
                    if in_fov and los_check(self.los_walls, g.x, g.y,
                                            dead_g.x, dead_g.y, closed_set, self.windows):
                        g.go_panicked((dead_g.x, dead_g.y), self.guards)
                        triggered = True; break
            if triggered: continue
            for snitch in self.snitches:
                if not getattr(snitch, "dead", False): continue
                d_to_body = dist(g.x, g.y, snitch.x, snitch.y)
                if d_to_body < self.tile * 2.5:
                    ang = math.atan2(snitch.y - g.y, snitch.x - g.x)
                    in_fov = abs(adiff(ang, g.facing)) <= g.FOV.get(g.state, math.radians(90))
                    if in_fov and los_check(self.los_walls, g.x, g.y,
                                            snitch.x, snitch.y, closed_set, self.windows):
                        g.go_panicked((snitch.x, snitch.y), self.guards)
                        break
        # Snitches also panic when they see a dead guard or dead fellow snitch
        for snitch in self.snitches:
            if getattr(snitch, "dead", False): continue
            if getattr(snitch, "state", PATROL) in ("running", PANICKED): continue
            for dead_g in self.guards:
                if dead_g.state != DEAD: continue
                d_to_body = dist(snitch.x, snitch.y, dead_g.x, dead_g.y)
                if d_to_body < self.tile * 2.5:
                    ang = math.atan2(dead_g.y - snitch.y, dead_g.x - snitch.x)
                    cur_fov = snitch.FOV.get(snitch.state, math.radians(80))
                    in_fov = abs(adiff(ang, snitch.facing)) <= cur_fov
                    if in_fov and los_check(self.los_walls, snitch.x, snitch.y,
                                            dead_g.x, dead_g.y, closed_set, self.windows):
                        snitch.go_panicked((dead_g.x, dead_g.y), self.guards)
                        break

        for g in self.guards:
            if g.state == DEAD: continue
            g.update(self.player, self.los_walls, closed_set, self.noise_events,
                      self.guards, self.doors, dt, sp, self.windows,
                      hides=self.hides, game_time=self._game_time)

            # sound cue when a guard transitions into ALERT or CHASE
            prev = prev_states.get(id(g), g.state)
            if prev == PATROL and g.state == ALERT:
                _play(self.sfx, 'alert')
                self._ev_guard_states["alert"] = True
                self._run_detected = True
            elif prev != CHASE and g.state == CHASE:
                _play(self.sfx, 'chase')
                self._ev_guard_states["chase"] = True
                self._run_detected = True
            # Rule 13: briefing chime when a guard delivers a briefing
            if prev == BRIEF and g.state == PATROL:
                if g._brief_delivered:
                    _play(self.sfx, 'brief')
                    self._ev_briefing = True
                    self.noise_events.append(
                        NoiseEvent(g.x, g.y, score=0, radius=self.tile * 3,
                                   lifetime=1.0, ambiguous=False, visual_only=True))
                g._brief_delivered = False

            # guard notices empty main-loot pedestal
            if not self.main_loot_noticed and self.main_loot_taken:
                for (mc, mr) in self.lvl["main_loot"]:
                    px, py = tc(mc, mr, self.tile)
                    if dist(g.x, g.y, px, py) < g.SIGHT:
                        ang = math.atan2(py-g.y, px-g.x)
                        if abs(adiff(ang, g.facing)) <= g.FOV[g.state]:
                            if los_check(self.los_walls, g.x, g.y, px, py, closed_set, self.windows):
                                if (mc,mr) not in self.main_loot:
                                    self._trigger_search()

            # catch player
            if g.state == CHASE:
                if dist(g.x, g.y, self.player.x, self.player.y) < g.RAD + self.player.RAD + 8:
                    _play(self.sfx, 'caught')
                    self.death_cause = "guard"; self._freeze_flash("dead"); return
            if g.state == SEARCH:
                if self.player.hidden:
                    if dist(g.x, g.y, self.player.x, self.player.y) < self.tile * 1.2:
                        _play(self.sfx, 'caught')
                        self.death_cause = "guard"; self._freeze_flash("dead"); return

            # Armed guard COMBAT shot hits player
            if g.state == COMBAT and g._fired_shot:
                g._fired_shot = False
                if not self.player.hidden:
                    if los_check(self.los_walls, g.x, g.y,
                                 self.player.x, self.player.y,
                                 closed_set, self.windows):
                        self.player.hp -= 1
                        # Knockback: push player away from guard
                        kd = math.hypot(self.player.x - g.x, self.player.y - g.y) or 1
                        self.player.x += ((self.player.x - g.x) / kd) * 20
                        self.player.y += ((self.player.y - g.y) / kd) * 20
                        if self.player.hp <= 0:
                            _play(self.sfx, 'caught')
                            self.death_cause = "shot"; self._freeze_flash("dead"); return

        # Track not-chased transition (for guard_chase_escape sequence)
        any_chasing_now = any(g.state == CHASE for g in self.guards)
        any_was_chasing = any(prev_states.get(id(g)) == CHASE for g in self.guards)
        if any_was_chasing and not any_chasing_now:
            self._ev_guard_states["not_chased"] = True

        self._ev_main_loot = False

        # Update camera
        self.camera.update(self.player.x, self.player.y, dt)

        # ── Region visibility smooth update ───────────────────────────────────
        if self._regions_enabled:
            player_tile   = self.player.tile
            player_region = self.tile_to_region.get(player_tile, None)

            # Check if player is standing in an inbetween/doorway tile
            player_in_inbetween = player_tile in self.inbetween_tiles

            # ── Build set of "openable LOS-blockers" that are currently CLOSED ──
            # Anything that can open/close AND blocks LOS when closed counts.
            # We also need to know which tiles are openable AT ALL (even if open).
            closed_los_tiles: set = set()
            openable_los_tiles: set = set()
            for d in self.doors:
                pt = d.tile_pos()
                openable_los_tiles.add(pt)
                if not d.open: closed_los_tiles.add(pt)
            for d in self.oiled_doors:
                pt = d.tile_pos()
                openable_los_tiles.add(pt)
                if not d.open: closed_los_tiles.add(pt)
            for d in self.wall_doors:
                pt = d.tile_pos()
                openable_los_tiles.add(pt)
                if not d.open: closed_los_tiles.add(pt)
            for d in self.crashdoors:
                pt = d.tile_pos()
                openable_los_tiles.add(pt)
                if not d.open: closed_los_tiles.add(pt)
            for d in self.thin_doors:
                pt = d.tile_pos()
                openable_los_tiles.add(pt)
                if not d.open: closed_los_tiles.add(pt)
            # Windows always block LOS (not openable, but they're walls with no door)
            # — they are NOT included here as they never open.

            # ── Helper: find which numbered regions border a set of tiles ──────
            NEIGHBOURS = [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(1,-1),(-1,1),(1,1)]
            def _border_regions(tile_set: set) -> set:
                found = set()
                for (tc2, tr2) in tile_set:
                    for dx, dy in NEIGHBOURS:
                        nr = self.tile_to_region.get((tc2+dx, tr2+dy))
                        if nr is not None:
                            found.add(nr)
                return found

            # ── Compute visible regions ────────────────────────────────────────
            visible_regions: set = set()

            # 1. Player's own numbered region is always visible
            if player_region is not None:
                visible_regions.add(player_region)

            # 2. Player standing in a plain inbetween → light both bordering regions
            if player_in_inbetween:
                # Flood-fill the connected inbetween blob the player is in
                # (so corridors work even if made of multiple tiles)
                visited: set = set()
                stack = [player_tile]
                while stack:
                    cur = stack.pop()
                    if cur in visited: continue
                    visited.add(cur)
                    for dx, dy in [(-1,0),(1,0),(0,-1),(0,1)]:
                        nb = (cur[0]+dx, cur[1]+dy)
                        if nb in self.inbetween_tiles and nb not in visited:
                            stack.append(nb)
                # Light all numbered regions adjacent to this inbetween blob
                visible_regions |= _border_regions(visited)

            # 3. Open doors/openables between numbered regions propagate visibility
            all_closeable = (self.doors + self.oiled_doors + self.wall_doors
                             + list(self.thin_doors))
            # crashdoors: when open they no longer block, treat same
            all_closeable += list(self.crashdoors)

            for door in all_closeable:
                if not door.open:
                    continue
                dc, dr = door.tile_pos()
                door_nbrs = [(dc+dx, dr+dy)
                             for dx, dy in [(-1,0),(1,0),(0,-1),(0,1)]]
                # Find distinct regions touching this door
                touching: set = set()
                for nb in door_nbrs:
                    nr = self.tile_to_region.get(nb)
                    if nr is not None:
                        touching.add(nr)
                    elif nb in self.inbetween_tiles:
                        touching |= _border_regions({nb})
                if player_region in touching or player_in_inbetween:
                    visible_regions |= touching

            # 4. Doorway inbetweens — LOS-aware connectors
            for dway in self.doorway_data:
                dway_tiles   = dway["tiles"]
                connects     = dway["connects"] or _border_regions(dway_tiles)
                if not connects: continue

                # Is the player in one of the connected regions or the doorway?
                player_relevant = (
                    player_region in connects
                    or any(t in dway_tiles for t in [player_tile])
                )
                if not player_relevant: continue

                # Check whether any LOS-blocking openable sits ON the doorway tiles
                # OR directly adjacent to them and between two of the connected regions.
                #
                # "Can it block LOS?" → is there at least one closed openable that,
                # if closed, would prevent vision from crossing this doorway?
                # We use a simple rule: if every openable-capable tile touching the
                # doorway is currently OPEN (or there are no openable tiles at all),
                # then the doorway is "unsealed" and both regions see each other.
                #
                # Step A: collect candidate openable positions for this doorway.
                candidate_openable = set()
                for (tc2, tr2) in dway_tiles:
                    # The tile itself
                    if (tc2, tr2) in openable_los_tiles:
                        candidate_openable.add((tc2, tr2))
                    # 4-neighbours (door on edge of the inbetween tile)
                    for dx, dy in [(-1,0),(1,0),(0,-1),(0,1)]:
                        nb = (tc2+dx, tr2+dy)
                        if nb in openable_los_tiles:
                            # Only count it if it separates the two regions
                            # i.e. it borders both (or either) connected region
                            nb_adj_regions = _border_regions({nb})
                            if nb_adj_regions & connects:
                                candidate_openable.add(nb)

                if not candidate_openable:
                    # No openable covers this doorway — treat like plain inbetween:
                    # both connected regions are always lit when player is near
                    visible_regions |= connects
                    continue

                # Step B: are ALL candidate openables currently open?
                all_open = all(pos not in closed_los_tiles
                               for pos in candidate_openable)
                any_open = any(pos not in closed_los_tiles
                               for pos in candidate_openable)

                if all_open:
                    # Doorway is fully open — both regions see each other
                    visible_regions |= connects
                elif any_open:
                    # Partially open — only the regions adjacent to open openables
                    # become visible; closed sections remain dark
                    for pos in candidate_openable:
                        if pos not in closed_los_tiles:
                            # This openable is open — light regions adjacent to it
                            adj_regions = _border_regions({pos})
                            visible_regions |= (adj_regions & connects)
                # else: everything closed → no extra visibility from this doorway

            # ── Bug fix: when player is OUTSIDE all regions, dim all of them ───
            # Previously player_region=None caused all regions to stay lit.
            # Now: if player is outside all regions AND not in an inbetween,
            # we dim all regions (player is in an untracked area — treat as dark).
            outside_all = (player_region is None and not player_in_inbetween)

            REGION_LERP = 4.0   # how fast dimming transitions
            for rid in self.regions_data:
                if outside_all:
                    target = 0.0
                else:
                    target = 1.0 if rid in visible_regions else 0.0
                cur = self._region_alpha.get(rid, 1.0)
                self._region_alpha[rid] = cur + (target - cur) * min(1.0, REGION_LERP * dt)

    # ── draw ───────────────────────────────────────────────────────────────────
    def draw(self):
        lvl  = self.lvl
        tile = self.tile
        vis  = self.visuals
        W, H = lvl["W"], lvl["H"]
        cam  = self.camera

        # World surface
        world_surf = pygame.Surface((VIEW_W, VIEW_H))
        world_surf.fill(_vc(vis,"bg_color",C_BG))
        self._world_surf = world_surf   # expose for subclass draw hooks (e.g. MPGame P2)

        closed    = self.closed_door_tiles
        open_t    = self.open_door_tiles
        door_tiles = closed | open_t

        # Search alarm flash
        if self._search_alarm_t > 0:
            frac = min(1.0, self._search_alarm_t / 3.0)
            ov = pygame.Surface((VIEW_W, VIEW_H), pygame.SRCALPHA)
            ov.fill((160, 0, 200, int(35 * frac * abs(math.sin(self.tick*0.25)))))
            world_surf.blit(ov, (0,0))

        cx0, cy0 = cam.x, cam.y

        # Background / floor
        vis = self.visuals
        # ── resolve all sprite handles once ──────────────────────────────────
        _bd            = self.level_dir
        _spr_wall      = SpriteCache.get(vis.get("wall_sprite"),      (tile, tile), _bd)
        _spr_floor     = SpriteCache.get(vis.get("floor_sprite"),     (tile, tile), _bd)
        _spr_hide      = SpriteCache.get(vis.get("hide_sprite"),      (tile, tile), _bd)
        _spr_window    = SpriteCache.get(vis.get("window_sprite"),    (tile, tile), _bd)
        _spr_exit      = SpriteCache.get(vis.get("exit_sprite"),      (tile, tile), _bd)
        _spr_loot      = SpriteCache.get(vis.get("loot_sprite"),      (tile, tile), _bd)
        _spr_mloot     = SpriteCache.get(vis.get("main_loot_sprite"), (tile, tile), _bd)
        _spr_crashdoor = SpriteCache.get(vis.get("crashdoor_sprite"), (tile, tile), _bd)
        _spr_fence     = SpriteCache.get(vis.get("fence_sprite"),     (tile, tile), _bd)
        _spr_pit       = SpriteCache.get(vis.get("pit_sprite"),       (tile, tile), _bd)
        _spr_creak     = SpriteCache.get(vis.get("creak_floor_sprite"),(tile, tile), _bd)
        _spr_mini_loot = SpriteCache.get(vis.get("mini_loot_sprite"), (tile, tile), _bd)
        _spr_snitch    = SpriteCache.get(vis.get("snitch_sprite"),    (tile, tile), _bd)
        _spr_camera    = SpriteCache.get(vis.get("camera_sprite"),    (tile, tile), _bd)
        _spr_oileddoor = SpriteCache.get(vis.get("oiled_door_sprite"),(tile, tile), _bd)
        if self._bg_surf:
            # Scroll background with camera (parallax factor 1.0 = locked to world)
            bx_off = int(cam.x) % self._bg_surf.get_width()  if self._bg_surf.get_width()  > VIEW_W else 0
            by_off = int(cam.y) % self._bg_surf.get_height() if self._bg_surf.get_height() > VIEW_H else 0
            world_surf.blit(self._bg_surf, (-bx_off, -by_off))
        else:
            for r in range(lvl["rows"]):
                for c in range(lvl["cols"]):
                    if (c,r) not in self.walls and (c,r) not in door_tiles:
                        sx, sy = cam.world_to_screen(c*tile, r*tile)
                        if -tile <= sx <= VIEW_W and -tile <= sy <= VIEW_H:
                            if _spr_floor:
                                world_surf.blit(_spr_floor, (sx, sy))
                            else:
                                # Use explicit floor colors from visuals, or checkerboard
                                if "floor_color_a" in vis or "floor_color_b" in vis:
                                    col = _vc(vis,"floor_color_a",C_FLOOR_A) if (c+r)%2==0 else _vc(vis,"floor_color_b",C_FLOOR_B)
                                    pygame.draw.rect(world_surf, col, (sx, sy, tile, tile))
                                else:
                                    col = C_FLOOR_A if (c+r)%2==0 else C_FLOOR_B
                                    pygame.draw.rect(world_surf, col, (sx, sy, tile, tile))

        # Hide spots
        for (hc,hr) in self.hides:
            sx, sy = cam.world_to_screen(hc*tile, hr*tile)
            here = (self.player.tile == (hc,hr))
            col  = _vc(vis,"hide_active_color",C_HIDE_ON) if here else _vc(vis,"hide_color",C_HIDE)
            if _spr_hide:
                _h = _spr_hide.copy(); _h.set_alpha(200 if here else 140)
                world_surf.blit(_h, (sx, sy))
            else:
                s = pygame.Surface((tile,tile), pygame.SRCALPHA)
                s.fill((*col, 70)); world_surf.blit(s,(sx,sy))
                pygame.draw.rect(world_surf, col, (sx,sy,tile,tile), 2)
                draw_text(world_surf,"HIDE",sx+tile//2,sy+tile//2,self.font_sm,col,"center")

        # Windows – translucent glass look (match editor)
        for (wc,wr) in self.windows:
            sx, sy = cam.world_to_screen(wc*tile, wr*tile)
            if _spr_window:
                world_surf.blit(_spr_window, (sx, sy))
            else:
                _wcol = _vc(vis,"window_color",C_WINDOW)
                # Translucent fill
                s = pygame.Surface((tile,tile), pygame.SRCALPHA)
                s.fill((*_wcol, 50))
                world_surf.blit(s,(sx,sy))
                # Double-line border (glass pane feel)
                pygame.draw.rect(world_surf, _wcol, (sx,sy,tile,tile), 2)
                pygame.draw.rect(world_surf, (*_wcol[:3],120) if len(_wcol)==3 else _wcol, (sx+3,sy+3,tile-6,tile-6), 1)

        # top_surf: walls and closed doors are drawn here so they composite above
        # FOV cones (which are drawn later).  Must be created BEFORE the Walls
        # section below which is the first place it is used.
        top_surf = pygame.Surface((VIEW_W, VIEW_H), pygame.SRCALPHA)

        # Walls
        thin_wall_set   = {(o["col"], o["row"]) for o in self.thin_walls}
        thin_door_set   = {(o.col, o.row) for o in self.thin_doors}
        invis_wall_set  = self.invis_walls          # skip drawing these
        for (c,r) in self.walls:
            if (c,r) in self.fences:     continue  # fences rendered separately below
            if (c,r) in thin_wall_set:   continue  # thin walls rendered separately below
            if (c,r) in thin_door_set:   continue  # thin doors rendered separately below
            if (c,r) in invis_wall_set:  continue  # invisible walls – never drawn
            if (c,r) in self.windows:    continue  # windows rendered separately above
            sx, sy = cam.world_to_screen(c*tile, r*tile)
            if -tile <= sx <= VIEW_W and -tile <= sy <= VIEW_H:
                if _spr_wall:
                    top_surf.blit(_spr_wall, (sx, sy))
                else:
                    if not _draw_lev_tile_pygame(top_surf, "wall", sx, sy, tile, obj=None, vis=vis, extra_defs=self._bundle_tile_defs):
                        rect = pygame.Rect(sx,sy,tile,tile)
                        pygame.draw.rect(top_surf, _vc(vis,"wall_color",C_WALL), rect)
                        pygame.draw.rect(top_surf, _vc(vis,"wall_edge_color",C_WALL_EDGE), rect, 2)
                        pygame.draw.line(top_surf,(45,68,115),rect.topleft,rect.topright,2)
                        pygame.draw.line(top_surf,(28,44,78), rect.topleft,rect.bottomleft,1)

        # Thin walls – line-shaped walls
        C_THIN = _vc(vis, "thin_wall_color", (160, 185, 240))
        lw = max(2, tile // 9)
        for obj in self.thin_walls:
            c, r   = obj["col"], obj["row"]
            sx, sy = cam.world_to_screen(c*tile, r*tile)
            if not (-tile <= sx <= VIEW_W and -tile <= sy <= VIEW_H):
                continue
            shape = obj.get("shape", "straight")
            rot   = obj.get("rotation", 0) % 360
            cx2, cy2 = sx + tile//2, sy + tile//2
            mg = max(2, tile // 8)
            top    = (cx2,        sy + mg)
            bottom = (cx2,        sy + tile - mg)
            left   = (sx + mg,    cy2)
            right  = (sx + tile - mg, cy2)
            ctr    = (cx2, cy2)
            def _seg(a, b): pygame.draw.line(top_surf, C_THIN, a, b, lw)
            if shape == "straight":
                if rot in (0, 180): _seg(left, right)
                else:               _seg(top, bottom)
            elif shape == "corner":
                pairs = [(top,ctr,right), (right,ctr,bottom),
                         (bottom,ctr,left), (left,ctr,top)]
                a1, m1, b1 = pairs[(rot//90)%4]
                _seg(a1, m1); _seg(m1, b1)
            elif shape == "t":
                segs4 = [
                    [(left,right),(top,ctr)],
                    [(top,bottom),(ctr,right)],
                    [(left,right),(ctr,bottom)],
                    [(top,bottom),(left,ctr)],
                ]
                for a2,b2 in segs4[(rot//90)%4]: _seg(a2, b2)
            else:  # plus
                _seg(left, right); _seg(top, bottom)

        # Thin doors – line-shaped hinged doors that swing open
        C_TDOOR_C = _vc(vis, "thin_door_closed_color", (200, 160,  80))
        C_TDOOR_O = _vc(vis, "thin_door_open_color",   (120, 200, 100))
        lw_td = max(3, tile // 7)
        for td in self.thin_doors:
            c2, r2 = td.col, td.row
            sx, sy = cam.world_to_screen(c2*tile, r2*tile)
            if not (-tile <= sx <= VIEW_W and -tile <= sy <= VIEW_H):
                continue
            # Build a minimal obj dict for the lev renderer
            _td_obj = {"open": td.open, "rotation": td.rot}
            if not _draw_lev_tile_pygame(top_surf, "thin_door", sx, sy, tile, obj=_td_obj, vis=vis, extra_defs=self._bundle_tile_defs):
                # Fallback: old center-based line
                col_td = C_TDOOR_O if td.open else C_TDOOR_C
                cx2, cy2 = sx + tile//2, sy + tile//2
                mg = max(2, tile // 8)
                top    = (cx2,           sy + mg)
                bottom = (cx2,           sy + tile - mg)
                left   = (sx + mg,       cy2)
                right  = (sx + tile - mg, cy2)
                vrot = td.current_rot() % 360
                if vrot in (0, 180):
                    pygame.draw.line(top_surf, col_td, left, right, lw_td)
                else:
                    pygame.draw.line(top_surf, col_td, top, bottom, lw_td)
                hinge_r = max(2, tile // 10)
                if vrot in (0, 180):
                    hinge_pt = left if (td.rot in (0, 180)) else right
                else:
                    hinge_pt = top if td.rot in (90,) else bottom
                pygame.draw.circle(top_surf, col_td, hinge_pt, hinge_r)
            lbl = "▭" if td.open else "▬"
            draw_text(top_surf, lbl, sx+tile//2, sy+tile//2, self.font_sm,
                      C_TDOOR_O if td.open else C_TDOOR_C, "center")

        # Doors – rendered via ObjectRegistry visuals / draw helpers
        for d in self.doors:
            sx, sy = cam.world_to_screen(d.col*tile, d.row*tile)
            _dspr = SpriteCache.get(d.def_["visuals"].get("sprite_key"), (tile, tile), _bd)
            if _dspr and d.open:
                top_surf.blit(_dspr, (sx, sy))
            else:
                _draw_bevel_door(top_surf, d, sx, sy, tile, vis, self.font_sm)

        # Oiled doors – rendered via ObjectRegistry visuals
        for d in self.oiled_doors:
            sx, sy = cam.world_to_screen(d.col*tile, d.row*tile)
            _ospr = SpriteCache.get(d.def_["visuals"].get("sprite_key"), (tile, tile), _bd)
            if _ospr and d.open:
                top_surf.blit(_ospr, (sx, sy))
            else:
                _draw_oiled_door(top_surf, d, sx, sy, tile, self.font_md)

        # Wall doors – rendered via ObjectRegistry visuals
        for d in self.wall_doors:
            sx, sy = cam.world_to_screen(d.col*tile, d.row*tile)
            _draw_wall_door(top_surf, d, sx, sy, tile, vis, self.font_md, _vc)

        # Pits – dark void
        for (pc,pr) in self.pits:
            sx, sy = cam.world_to_screen(pc*tile, pr*tile)
            if _spr_pit:
                world_surf.blit(_spr_pit, (sx, sy))
            else:
                if not _draw_lev_tile_pygame(world_surf, "pit", sx, sy, tile, vis=vis, extra_defs=self._bundle_tile_defs):
                    pit_col = _vc(vis, "pit_color", C_PIT)
                    pygame.draw.rect(world_surf, pit_col, (sx,sy,tile,tile))
                    s = pygame.Surface((tile,tile), pygame.SRCALPHA)
                    for i in range(0, tile, 8):
                        pygame.draw.line(s, (20,25,50,120), (i,0), (0,i), 1)
                        pygame.draw.line(s, (20,25,50,120), (tile,i), (i,tile), 1)
                    world_surf.blit(s,(sx,sy))
                    draw_text(world_surf,"○",sx+tile//2,sy+tile//2,self.font_sm,(30,35,65),"center")

        # Creak floors – intentionally invisible in-game (surprise factor)
        # Only render if a sprite is explicitly provided by the level designer
        for cf in self.creak_floors:
            if _spr_creak:
                sx, sy = cam.world_to_screen(cf.col*tile, cf.row*tile)
                _cs = _spr_creak.copy(); _cs.set_alpha(160)
                world_surf.blit(_cs, (sx, sy))

        # Detail images / texts – layer 0 (behind items, above floor)
        for di in self.detail_imgs:
            if di.layer == 0:
                di.draw(world_surf, cam, tile, self.level_dir)
        for dt in self.detail_txts:
            if dt.layer == 0:
                dt.draw(world_surf, cam, tile, self.font_sm, self.font_md)

        # Item piles – gold diamond on floor
        for pile in self.item_piles:
            if pile.picked_up: continue
            sx, sy = cam.world_to_screen(pile.col*tile, pile.row*tile)
            cx, cy = sx + tile//2, sy + tile//2
            # Pulsing glow
            pulse = 0.7 + 0.3*math.sin(self.tick*0.09 + pile.col)
            rl = int(tile * 0.22 * pulse)
            gs = pygame.Surface((tile*2, tile*2), pygame.SRCALPHA)
            pygame.draw.circle(gs, (200, 170, 80, int(55*pulse)), (tile, tile), rl+6)
            world_surf.blit(gs, (cx-tile, cy-tile))
            # Diamond shape
            half = int(tile * 0.28)
            pts = [(cx, cy-half), (cx+half, cy), (cx, cy+half), (cx-half, cy)]
            pygame.draw.polygon(world_surf, (200, 170, 80), pts)
            pygame.draw.polygon(world_surf, (255, 220, 120), pts, 2)
            # Label: first item in pile
            first = next(iter(pile.contents), None)
            label = {"silenced_pistol": "~P", "1911": "19", "shotgun": "SG",
                     "m4a1": "M4", "keycard": "KC"}.get(first, "?")
            draw_text(world_surf, label, cx, cy, self.font_sm, (30, 27, 20), "center")

        # ── Shop buy_item tiles ────────────────────────────────────────────────
        for bi in getattr(self, 'buy_items', []):
            if not bi.active: continue
            sx, sy = cam.world_to_screen(bi.col*tile, bi.row*tile)
            cx, cy = sx + tile//2, sy + tile//2
            pulse2 = 0.7 + 0.3*math.sin(self.tick*0.07 + bi.col + 1.5)
            gs2 = pygame.Surface((tile*2, tile*2), pygame.SRCALPHA)
            pygame.draw.circle(gs2, (80, 160, 255, int(50*pulse2)), (tile, tile), int(tile*0.25)+4)
            world_surf.blit(gs2, (cx-tile, cy-tile))
            half2 = int(tile * 0.24)
            shop_pts = [(cx, cy-half2), (cx+half2, cy), (cx, cy+half2), (cx-half2, cy)]
            pygame.draw.polygon(world_surf, (80, 160, 255), shop_pts)
            pygame.draw.polygon(world_surf, (160, 210, 255), shop_pts, 2)
            draw_text(world_surf, "$", cx, cy, self.font_sm, (10, 20, 40), "center")

        # ── Shop leave tiles ──────────────────────────────────────────────────
        for (slc, slr) in getattr(self, 'shop_leaves', []):
            sx, sy = cam.world_to_screen(slc*tile, slr*tile)
            cx, cy = sx + tile//2, sy + tile//2
            arrow_pts = [(cx, cy-tile//3), (cx+tile//3, cy), (cx, cy+tile//3), (cx-tile//3, cy)]
            pygame.draw.polygon(world_surf, (80, 220, 80), arrow_pts)
            pygame.draw.polygon(world_surf, (160, 255, 160), arrow_pts, 2)
            draw_text(world_surf, "→", cx, cy, self.font_sm, (10, 40, 10), "center")

        # Fences – partial visual blocker
        for (fc,fr) in self.fences:
            sx, sy = cam.world_to_screen(fc*tile, fr*tile)
            if _spr_fence:
                world_surf.blit(_spr_fence, (sx, sy))
            else:
                if not _draw_lev_tile_pygame(world_surf, "fence", sx, sy, tile, vis=vis, extra_defs=self._bundle_tile_defs):
                    fnc_col = _vc(vis, "fence_color", C_FENCE)
                    pygame.draw.rect(world_surf, fnc_col, (sx,sy,tile,tile), 2)
                    for i in range(4, tile, 10):
                        pygame.draw.line(world_surf, fnc_col, (sx+i, sy+2), (sx+i, sy+tile-2), 2)
                    pygame.draw.line(world_surf, fnc_col, (sx+2, sy+tile//2), (sx+tile-2, sy+tile//2), 1)

        # Crash-doors – rendered via ObjectRegistry visuals
        for cd in self.crashdoors:
            sx, sy = cam.world_to_screen(cd.col*tile, cd.row*tile)
            _cdspr = SpriteCache.get(cd.def_["visuals"].get("sprite_key"), (tile, tile), _bd)
            _draw_crash_door(world_surf, cd, sx, sy, tile, _cdspr, self.font_sm)

        # Noisemakers
        for nm in self.noisemakers:
            sx, sy = cam.world_to_screen(nm.col*tile, nm.row*tile)
            if not _draw_lev_tile_pygame(world_surf, "noisemaker", sx, sy, tile, vis=vis, extra_defs=self._bundle_tile_defs):
                pulse = 0.7 + 0.3*math.sin(self.tick*0.12)
                r = int(tile*0.3*pulse)
                pygame.draw.circle(world_surf, _vc(vis,"noisemaker_color",C_NOISEMAKER),
                                   (sx+tile//2, sy+tile//2), r)
                pygame.draw.circle(world_surf, C_WHITE,
                                   (sx+tile//2, sy+tile//2), r, 2)
                draw_text(world_surf,"♪",sx+tile//2,sy+tile//2,self.font_sm,C_WHITE,"center")

        # Main loot pedestals
        for (mc,mr) in lvl["main_loot"]:
            sx, sy = cam.world_to_screen(mc*tile, mr*tile)
            px, py = sx+tile//2, sy+tile//2
            taken  = (mc,mr) not in self.main_loot
            rl = int(tile*0.28)
            if taken:
                pygame.draw.circle(world_surf, C_MLOOT_GONE, (px,py), rl)
                pygame.draw.circle(world_surf, (120,50,20), (px,py), rl, 2)
                draw_text(world_surf,"✗",px,py,self.font_sm,(80,40,15),"center")
            else:
                pulse = 0.7 + 0.3*math.sin(self.tick*0.10)
                gr = int(rl*1.6*pulse)
                gs = pygame.Surface((gr*2,gr*2), pygame.SRCALPHA)
                pygame.draw.circle(gs,(*_vc(vis,"main_loot_color",C_MLOOT),int(55*pulse)),(gr,gr),gr)
                world_surf.blit(gs,(px-gr,py-gr))
                if _spr_mloot:
                    _ms = pygame.transform.rotozoom(_spr_mloot, self.tick*1.2, 0.85+0.15*pulse)
                    world_surf.blit(_ms, _ms.get_rect(center=(px,py)))
                else:
                    pygame.draw.circle(world_surf, _vc(vis,"main_loot_color",C_MLOOT),  (px,py), rl)
                    pygame.draw.circle(world_surf, _vc(vis,"main_loot_glow_color",C_MLOOT_G),(px,py), max(1,rl-5))
                    pygame.draw.circle(world_surf, C_WHITE,  (px,py), rl, 2)
                    draw_text(world_surf,"★",px,py,self.font_sm,C_BG,"center")

        # Detail images / texts – layer 1 (above items, below player)
        for di in self.detail_imgs:
            if di.layer == 1:
                di.draw(world_surf, cam, tile, self.level_dir)
        for dt in self.detail_txts:
            if dt.layer == 1:
                dt.draw(world_surf, cam, tile, self.font_sm, self.font_md)

        # FOV surface
        fov_surf = pygame.Surface((VIEW_W, VIEW_H), pygame.SRCALPHA)
        # top_surf was already created above before the Walls section

        # Patrol waypoint paths
        # watch/check nodes are modifiers, not patrol stops – skip them from the path line
        _MODIFIER_TYPES = {"watch", "check", "ignore"}
        for g in self.guards:
            # Build patrol-stop indices (waypoints that are actual movement targets)
            stop_wps = []
            for i, wp in enumerate(g.waypoints):
                wd = g.wp_data[i] if i < len(g.wp_data) else {}
                if wd.get("type", "waypoint") not in _MODIFIER_TYPES:
                    stop_wps.append((i, wp))
            # Draw patrol loop lines between stops only
            if len(stop_wps) > 1:
                for j in range(len(stop_wps)):
                    _, a = stop_wps[j]; _, b = stop_wps[(j+1) % len(stop_wps)]
                    ax, ay = cam.world_to_screen(a[0], a[1])
                    bx, by = cam.world_to_screen(b[0], b[1])
                    pygame.draw.line(fov_surf,(*_vc(vis,"waypoint_color",C_WAYPT),45),(int(ax),int(ay)),(int(bx),int(by)),2)
            # Draw all waypoint dots (stops + modifiers, each with their own style)
            for i, wp in enumerate(g.waypoints):
                wx, wy = cam.world_to_screen(wp[0], wp[1])
                wd = g.wp_data[i] if i < len(g.wp_data) else {}
                wt = wd.get("type", "waypoint")
                is_pause = g.pause_flags[i] if g.pause_flags and i < len(g.pause_flags) else False
                if wt == "waitpoint" or is_pause:
                    _wpc = _vc(vis,"waitpoint_color",C_WAYPT_PAUSE)
                    pygame.draw.circle(world_surf, _wpc, (int(wx),int(wy)), 6, 2)
                    pygame.draw.circle(world_surf, C_WHITE, (int(wx),int(wy)), 6, 1)
                elif wt == "watch":
                    # Eye-shaped indicator – small cyan dot
                    pygame.draw.circle(world_surf, (80,210,130), (int(wx),int(wy)), 5, 2)
                    pygame.draw.circle(world_surf, (140,255,180), (int(wx),int(wy)), 2)
                elif wt == "check":
                    # Orange diamond
                    r_c = 5
                    pts = [(int(wx),int(wy)-r_c),(int(wx)+r_c,int(wy)),(int(wx),int(wy)+r_c),(int(wx)-r_c,int(wy))]
                    pygame.draw.polygon(world_surf, (220,120,60), pts, 2)
                elif wt == "ignore":
                    # Faded X
                    r_i = 4
                    pygame.draw.line(world_surf,(120,120,120),(int(wx)-r_i,int(wy)-r_i),(int(wx)+r_i,int(wy)+r_i),2)
                    pygame.draw.line(world_surf,(120,120,120),(int(wx)+r_i,int(wy)-r_i),(int(wx)-r_i,int(wy)+r_i),2)
                else:
                    pygame.draw.circle(world_surf, _vc(vis,"waypoint_color",C_WAYPT), (int(wx),int(wy)), 4)
                    pygame.draw.circle(world_surf, C_WHITE, (int(wx),int(wy)), 4, 1)

        # A* path debug
        for g in self.guards:
            if g.state == DEAD: continue
            if g.state in (ALERT,CHASE,SEARCH) and g.path:
                gcol = {CHASE:(255,50,50,50), ALERT:(255,150,0,40),
                        SEARCH:(180,50,255,45)}.get(g.state,(200,200,0,35))
                for i in range(g.path_idx, min(len(g.path)-1,g.path_idx+25)):
                    a = cam.world_to_screen(*tc(g.path[i][0],   g.path[i][1],   tile))
                    b = cam.world_to_screen(*tc(g.path[i+1][0], g.path[i+1][1], tile))
                    pygame.draw.line(fov_surf, gcol, a, b, 2)

        # FOV cones – wall-clipped and transparent
        for g in self.guards:
            if g.state == DEAD: continue
            world_pts = g.fov_pts(self.player.sprinting, self.los_walls, self.windows, closed)
            # Offset to screen space
            screen_pts = [cam.world_to_screen(px, py) for px, py in world_pts]
            if len(screen_pts) >= 3:
                fi,fe = {
                    CHASE:   ((*_vc(vis,"guard_chase_color",C_GUARD_CH),40), (*_vc(vis,"guard_chase_color",C_GUARD_CH),70)),
                    ALERT:   ((*_vc(vis,"guard_alert_color",C_GUARD_AL),35), (*_vc(vis,"guard_alert_color",C_GUARD_AL),60)),
                    INSPECT: ((*_vc(vis,"guard_inspect_color",C_GUARD_INS),35), (*_vc(vis,"guard_inspect_color",C_GUARD_INS),60)),
                    SEARCH:  ((*_vc(vis,"guard_search_color",C_GUARD_SRC),38), (*_vc(vis,"guard_search_color",C_GUARD_SRC),65)),
                    BRIEF:   ((100,200,255,25), (100,200,255,50)),
                    PANICKED:((255,140,200,35), (255,140,200,60)),
                    COMBAT:  ((255,80,0,40),    (255,80,0,70)),
                }.get(g.state, (_vc(vis,"fov_patrol_fill",C_GUARD)+(20,), _vc(vis,"fov_patrol_fill",C_GUARD)+(45,)))
                pygame.draw.polygon(fov_surf, fi, screen_pts)
                pygame.draw.polygon(fov_surf, fe, screen_pts, 1)

        # Snitches – patrol like guards but run to report; state-aware rendering
        for snitch in self.snitches:
            sx, sy = cam.world_to_screen(snitch.x, snitch.y)
            sx, sy = int(sx), int(sy)
            if getattr(snitch, "dead", False):
                pygame.draw.circle(world_surf, (70, 70, 70), (sx, sy), snitch.RAD)
                pygame.draw.circle(world_surf, (110, 110, 110), (sx, sy), snitch.RAD, 2)
                d2 = int(snitch.RAD * 0.65)
                pygame.draw.line(world_surf, (160,160,160), (sx-d2,sy-d2), (sx+d2,sy+d2), 2)
                pygame.draw.line(world_surf, (160,160,160), (sx+d2,sy-d2), (sx-d2,sy+d2), 2)
                continue
            s_state = getattr(snitch, "state", PATROL)
            running = (s_state == "running")
            col = {
                "running": (255, 200, 40),
                ALERT:     (255, 160, 30),
                SEARCH:    (220, 120, 255),
                PANICKED:  (255, 140, 200),
                INSPECT:   (120, 220, 255),
            }.get(s_state, (80, 220, 200))
            if not running:
                world_pts = snitch.fov_pts(self.walls, self.windows, self.closed_door_tiles)
                scr_pts = [cam.world_to_screen(px2,py2) for px2,py2 in world_pts]
                if len(scr_pts) >= 3:
                    fov_col = {
                        ALERT:    (255, 160, 30, 25),
                        SEARCH:   (220, 120, 255, 20),
                        PANICKED: (255, 140, 200, 30),
                    }.get(s_state, (80, 220, 200, 20))
                    pygame.draw.polygon(fov_surf, fov_col, scr_pts)
                    pygame.draw.polygon(fov_surf, fov_col[:3] + (50,), scr_pts, 1)
            pygame.draw.circle(world_surf, col, (sx,sy), snitch.RAD)
            pygame.draw.circle(world_surf, C_WHITE, (sx,sy), snitch.RAD, 2)
            draw_text(world_surf,"SN",sx,sy,self.font_sm,C_BG,"center")
            badges = {"running": ">>RUN<<", ALERT: "?!", INSPECT: "...",
                      SEARCH: "??", PANICKED: "!BODY!"}
            badge = badges.get(s_state)
            if badge:
                draw_text(world_surf, badge, sx, sy-snitch.RAD-14,
                          self.font_md, (255,200,40) if running else (255,200,80), "center")

        # Camera entities – teal-green, sweep cone (FOV on shared fov_surf)
        for cam_ent in self.cameras:
            sx, sy = cam.world_to_screen(cam_ent.x, cam_ent.y)
            sx, sy = int(sx), int(sy)
            col = (255,80,0) if cam_ent.alerted else _vc(vis, "camera_color", C_CAMERA)
            world_pts = cam_ent.fov_pts(self.walls, self.windows, self.closed_door_tiles)
            scr_pts = [cam.world_to_screen(px2,py2) for px2,py2 in world_pts]
            if len(scr_pts) >= 3:
                fi = _vc(vis, "fov_camera_fill", (*C_CAMERA, 22)) if not cam_ent.alerted else (255,80,0,30)
                pygame.draw.polygon(fov_surf, fi if len(fi)==4 else (*fi,22), scr_pts)
                pygame.draw.polygon(fov_surf, (*col, 45), scr_pts, 1)
            pygame.draw.circle(world_surf, col, (sx,sy), cam_ent.RAD)
            pygame.draw.circle(world_surf, C_WHITE, (sx,sy), cam_ent.RAD, 2)
            pygame.draw.circle(world_surf, C_BG, (sx,sy), 4)
            pygame.draw.circle(world_surf, C_WHITE, (sx,sy), 4, 1)
            if cam_ent.alerted:
                draw_text(world_surf,"!!!",sx,sy-cam_ent.RAD-14,self.font_md,(255,80,0),"center")

        world_surf.blit(fov_surf,(0,0))
        # Walls and closed doors drawn on top of FOV cones
        world_surf.blit(top_surf,(0,0))

        # Noise rings
        _nc = _vc(vis,"noise_ring_color",C_NOISE_C)
        for ne in self.noise_events:
            ne.draw(world_surf, cam.x, cam.y, ring_col=_nc)

        # Exit
        ex, ey = cam.world_to_screen(*tc(*self.exit_pos, tile))
        pulse = 0.55+0.45*math.sin(self.tick*0.07)
        re    = int(tile*0.38*pulse)
        ecol  = _vc(vis,"exit_open_color",C_EXIT) if self.exit_open else _vc(vis,"exit_locked_color",C_EXIT_OFF)
        _exit_sx, _exit_sy = cam.world_to_screen(self.exit_pos[0]*tile, self.exit_pos[1]*tile)
        if _spr_exit:
            _es = _spr_exit.copy()
            if not self.exit_open: _es.set_alpha(100)
            _ep = pygame.transform.rotozoom(_es, math.sin(self.tick*0.04)*8, 1.0)
            world_surf.blit(_ep, _ep.get_rect(center=(int(ex),int(ey))))
        else:
            pygame.draw.circle(world_surf,ecol,(int(ex),int(ey)),re)
            pygame.draw.circle(world_surf,C_WHITE,(int(ex),int(ey)),re,2)
            draw_text(world_surf,"OUT" if self.exit_open else "...",
                      int(ex),int(ey),self.font_sm,C_WHITE,"center")

        # Regular loot
        for (lc,lr) in self.loot:
            sx, sy = cam.world_to_screen(*tc(lc,lr,tile))
            bd = dist(self.player.x, self.player.y, lc*tile+tile//2, lr*tile+tile//2)
            glow = max(0.0,1.0-bd/140)
            if glow>0:
                gs = pygame.Surface((64,64),pygame.SRCALPHA)
                pygame.draw.circle(gs,(*_vc(vis,"loot_color",C_LOOT),int(60*glow)),(32,32),int(32*glow))
                world_surf.blit(gs,(sx-32,sy-32))
            rl = int(tile*0.20)
            if _spr_loot:
                _ls = pygame.transform.rotozoom(_spr_loot, math.sin(self.tick*0.06+lc)*5, 0.9+0.1*math.sin(self.tick*0.04+lr))
                world_surf.blit(_ls, _ls.get_rect(center=(int(sx),int(sy))))
            elif not _draw_lev_tile_pygame(world_surf, "loot", sx - tile//2, sy - tile//2, tile, vis=vis, extra_defs=self._bundle_tile_defs):
                pygame.draw.circle(world_surf,_vc(vis,"loot_color",C_LOOT),(int(sx),int(sy)),rl)
                pygame.draw.circle(world_surf,_vc(vis,"loot_glow_color",C_LOOT_G),(int(sx),int(sy)),max(1,rl-3))
                draw_text(world_surf,"$",int(sx),int(sy),self.font_sm,C_BG,"center")

        # Mini loot – smaller, dimmer
        for (mc,mr) in self.mini_loot:
            sx, sy = cam.world_to_screen(*tc(mc,mr,tile))
            if _spr_mini_loot:
                world_surf.blit(_spr_mini_loot, (sx - tile//2, sy - tile//2))
            elif not _draw_lev_tile_pygame(world_surf, "mini_loot", sx - tile//2, sy - tile//2, tile, vis=vis, extra_defs=self._bundle_tile_defs):
                rl = int(tile*0.13)
                ml_col = _vc(vis, "mini_loot_color", C_MINI_LOOT)
                pygame.draw.circle(world_surf, ml_col, (int(sx),int(sy)), rl)
                pygame.draw.circle(world_surf, (240,220,100), (int(sx),int(sy)), max(1,rl-2))
                draw_text(world_surf,"¢",int(sx),int(sy),self.font_sm,C_BG,"center")


        # IO Input nodes – cyan triangles
        for inp in self.io_inputs:
            sx, sy = cam.world_to_screen(inp.col*tile, inp.row*tile)
            cx, cy = sx+tile//2, sy+tile//2
            r = tile//3
            inp_col = _vc(vis, "transmit_node_color", C_INPUT)
            pts = [(cx+r,cy),(cx-r//2,cy-r//2*2),(cx-r//2,cy+r//2*2)]
            s2 = pygame.Surface((tile,tile), pygame.SRCALPHA)
            pygame.draw.polygon(s2, (*inp_col,60), [(p[0]-sx,p[1]-sy) for p in pts])
            world_surf.blit(s2,(sx,sy))
            pygame.draw.polygon(world_surf, inp_col, pts, 2)
            draw_text(world_surf,f"▶{inp.channel}",cx,cy,self.font_sm,inp_col,"center")

        # IO Output nodes – amber triangles pointing left
        for out in self.io_outputs:
            sx, sy = cam.world_to_screen(out.col*tile, out.row*tile)
            cx, cy = sx+tile//2, sy+tile//2
            r = tile//3
            out_col = _vc(vis, "receive_node_color", C_OUTPUT)
            pts = [(cx-r,cy),(cx+r//2,cy-r//2*2),(cx+r//2,cy+r//2*2)]
            s2 = pygame.Surface((tile,tile), pygame.SRCALPHA)
            pygame.draw.polygon(s2, (*out_col,60), [(p[0]-sx,p[1]-sy) for p in pts])
            world_surf.blit(s2,(sx,sy))
            pygame.draw.polygon(world_surf, out_col, pts, 2)
            draw_text(world_surf,f"◀{out.channel}",cx,cy,self.font_sm,out_col,"center")

        # ── Floor hazards (burning cloaks) ───────────────────────────────────
        for fh in self.floor_hazards:
            fx, fy = cam.world_to_screen(fh.x, fh.y)
            fx, fy = int(fx), int(fy)
            life_frac = max(0, fh.life / 25.0)
            # Outer glow – ember orange, fades as it burns out
            glow_r = int(tile * 0.7 * life_frac + 4)
            if glow_r > 0:
                gs2 = pygame.Surface((glow_r*2+1, glow_r*2+1), pygame.SRCALPHA)
                alpha = int(80 * life_frac)
                pygame.draw.circle(gs2, (255, 120, 30, alpha), (glow_r, glow_r), glow_r)
                world_surf.blit(gs2, (fx - glow_r, fy - glow_r))
            # Core blanket shape
            core_r = max(4, int(tile * 0.28))
            col_a = int(220 * life_frac)
            pygame.draw.circle(world_surf, (200, 100, 20), (fx, fy), core_r)
            pygame.draw.circle(world_surf, (255, 200, 60), (fx, fy), max(2, core_r-3))
            # Smell warning pulse when about to emit
            if not fh.smell_emitted and fh.smell_timer < 4.0:
                pulse = abs(math.sin(self._game_time * 4))
                pr = int(tile * 1.2 * pulse)
                if pr > 0:
                    ps = pygame.Surface((pr*2, pr*2), pygame.SRCALPHA)
                    pygame.draw.circle(ps, (200, 80, 20, int(60*pulse)), (pr, pr), pr)
                    world_surf.blit(ps, (fx-pr, fy-pr))
            draw_text(world_surf, "🔥", fx, fy - core_r - 8, self.font_sm, (255, 160, 40), "center")

        # ── Smoke clouds (smoke pellet) ───────────────────────────────────────
        for sc in self.equipment.smoke_clouds:
            sx_w, sy_w = cam.world_to_screen(sc["x"], sc["y"])
            r_px = int(sc["radius"] * (self.camera.zoom if hasattr(self.camera, 'zoom') else 1.0))
            r_px = max(8, min(r_px, sc["radius"]))   # fallback: use world radius directly
            frac = min(1.0, sc["timer"] / 0.5)   # fade in
            alpha = int(140 * min(1.0, sc["timer"]))
            if alpha > 0:
                sm_s = pygame.Surface((r_px*2, r_px*2), pygame.SRCALPHA)
                pygame.draw.circle(sm_s, (180, 190, 200, alpha), (r_px, r_px), r_px)
                world_surf.blit(sm_s, (int(sx_w)-r_px, int(sy_w)-r_px))

        # Guards
        g_spr_path = vis.get("guard_sprite")
        g_spr = SpriteCache.get(g_spr_path, (tile, tile), _bd) if g_spr_path else None
        for g in self.guards:
            gx, gy = cam.world_to_screen(g.x, g.y)
            gx, gy = int(gx), int(gy)
            r = g.RAD

            # ── Dead guard: grayscale body + X, skip normal rendering ──────
            if g.state == DEAD:
                pygame.draw.circle(world_surf, (70, 70, 70), (gx, gy), r)
                pygame.draw.circle(world_surf, (110, 110, 110), (gx, gy), r, 2)
                d2 = int(r * 0.65)
                pygame.draw.line(world_surf, (160, 160, 160), (gx-d2, gy-d2), (gx+d2, gy+d2), 2)
                pygame.draw.line(world_surf, (160, 160, 160), (gx+d2, gy-d2), (gx-d2, gy+d2), 2)
                if g is self._dragging_body:
                    pygame.draw.circle(world_surf, (200, 200, 100), (gx, gy), r + 5, 1)
                continue

            body = {PATROL:_vc(vis,"guard_patrol_color",C_GUARD), ALERT:_vc(vis,"guard_alert_color",C_GUARD_AL), CHASE:_vc(vis,"guard_chase_color",C_GUARD_CH),
                    INSPECT:_vc(vis,"guard_inspect_color",C_GUARD_INS), SEARCH:_vc(vis,"guard_search_color",C_GUARD_SRC),
                    BRIEF:(100,200,255)}.get(g.state, C_GUARD)
            if g.state in (CHASE, SEARCH):
                gc = C_RED if g.state==CHASE else C_GUARD_SRC
                gs2 = pygame.Surface((r*4,r*4),pygame.SRCALPHA)
                pygame.draw.circle(gs2,(*gc,35),(r*2,r*2),r*2)
                world_surf.blit(gs2,(gx-r*2,gy-r*2))
            if g_spr:
                angle_deg = -math.degrees(g.facing) - 90
                rotated   = pygame.transform.rotate(g_spr, angle_deg)
                rr        = rotated.get_rect(center=(gx, gy))
                tinted = rotated.copy()
                if g.state != PATROL:
                    tint = pygame.Surface(tinted.get_size(), pygame.SRCALPHA)
                    tc_col = {ALERT:(255,130,0,60), CHASE:(255,40,40,80),
                              INSPECT:(80,180,255,50), SEARCH:(200,60,255,60),
                              BRIEF:(100,200,255,55)}.get(g.state,(0,0,0,0))
                    tint.fill(tc_col)
                    tinted.blit(tint, (0,0), special_flags=pygame.BLEND_RGBA_ADD)
                world_surf.blit(tinted, rr)
            else:
                pygame.draw.circle(world_surf,body,(gx,gy),r)
                pygame.draw.circle(world_surf,C_WHITE,(gx,gy),r,2)
                ex2 = gx+int(math.cos(g.facing)*(r+8))
                ey2 = gy+int(math.sin(g.facing)*(r+8))
                pygame.draw.line(world_surf,C_WHITE,(gx,gy),(ex2,ey2),3)
                pygame.draw.circle(world_surf,C_WHITE,(ex2,ey2),3)
                for side in (-1,1):
                    ea = g.facing+side*0.38
                    pygame.draw.circle(world_surf,C_BG,
                        (gx+int(math.cos(ea)*(r-4)),gy+int(math.sin(ea)*(r-4))),3)
            # Character state badge (20×25, centred above guard dot)
            _icon = self._char_icons.get(g.state)
            if _icon:
                world_surf.blit(_icon, _icon.get_rect(center=(gx, gy - r - 20)))
            # Show briefing-received heat on guard (small cyan dot for each briefing)
            if g.briefings_received > 0 and g.state == PATROL:
                for bi in range(min(g.briefings_received, 3)):
                    bxi = gx - 8 + bi * 8
                    pygame.draw.circle(world_surf, (80,180,255), (bxi, gy-r-6), 3)
            if g.suspicion>0.05 and g.state!=CHASE:
                bw = r*2; bx0 = gx-r; by0 = gy-r-28
                pygame.draw.rect(world_surf,(40,30,10),(bx0,by0,bw,4),border_radius=2)
                sw = int(bw*g.suspicion)
                sc2 = (int(50+205*g.suspicion),int(200*(1-g.suspicion)),0)
                if sw>0:
                    pygame.draw.rect(world_surf,sc2,(bx0,by0,sw,4),border_radius=2)
            # Pause indicator
            if g._pause_t > 0:
                draw_text(world_surf,"⏸",gx,gy-r-36,self.font_sm,(200,200,100),"center")

        # Player
        bx, by = cam.world_to_screen(self.player.x, self.player.y)
        bx, by = int(bx), int(by)
        r = self.player.RAD
        p_spr_path = vis.get("player_sprite")
        p_spr = SpriteCache.get(p_spr_path, (tile, tile), _bd) if p_spr_path else None
        if p_spr and not self.player.hidden:
            # rotate sprite to face direction
            angle_deg = -math.degrees(self.player.facing) - 90
            rotated   = pygame.transform.rotate(p_spr, angle_deg)
            rr        = rotated.get_rect(center=(bx, by))
            alpha     = 80 if self.player.hidden else 255
            p_spr_a   = rotated.copy()
            p_spr_a.set_alpha(alpha)
            if self.player.sprinting:
                gs = pygame.Surface((r*4,r*4),pygame.SRCALPHA)
                pygame.draw.circle(gs,(*_vc(vis,"player_sprint_color",C_PLAYER_SPR),30),(r*2,r*2),r*2)
                world_surf.blit(gs,(bx-r*2,by-r*2))
            world_surf.blit(p_spr_a, rr)
        else:
            cloaked = getattr(self.player, 'hidden_by_cloak', False)
            if cloaked:
                pcol = (60, 200, 240)   # cyan shimmer for cloaked
            else:
                pcol = _vc(vis,"player_hidden_color",C_PLAYER_HID) if self.player.hidden else \
                       _vc(vis,"player_sprint_color",C_PLAYER_SPR) if self.player.sprinting else _vc(vis,"player_color",C_PLAYER)
            if self.player.sprinting and not self.player.hidden:
                gs = pygame.Surface((r*4,r*4),pygame.SRCALPHA)
                pygame.draw.circle(gs,(*_vc(vis,"player_sprint_color",C_PLAYER_SPR),30),(r*2,r*2),r*2)
                world_surf.blit(gs,(bx-r*2,by-r*2))
            if cloaked:
                # Draw as semi-transparent shimmer only player can see
                clk_s = pygame.Surface((r*3, r*3), pygame.SRCALPHA)
                pulse = abs(math.sin(self._game_time * 3))
                clk_a = int(60 + 40 * pulse)
                pygame.draw.circle(clk_s, (60, 200, 240, clk_a), (r+r//2, r+r//2), r)
                pygame.draw.circle(clk_s, (120, 240, 255, clk_a//2), (r+r//2, r+r//2), r, 2)
                world_surf.blit(clk_s, (bx - r - r//2, by - r - r//2))
            else:
                pygame.draw.circle(world_surf,pcol,(bx,by),r)
                pygame.draw.circle(world_surf,C_WHITE,(bx,by),r,2)
            fx = bx+int(math.cos(self.player.facing)*(r-3))
            fy = by+int(math.sin(self.player.facing)*(r-3))
            pygame.draw.circle(world_surf,_vc(vis,"bg_color",C_BG),(fx,fy),4)
        lbl = "CLOAKED" if getattr(self.player, 'hidden_by_cloak', False) else \
              "HIDDEN" if self.player.hidden else \
              "SPRINT!" if self.player.sprinting else ""
        if lbl:
            lc = (60, 200, 240) if lbl == "CLOAKED" else \
                 _vc(vis,"hide_active_color",C_HIDE_ON) if self.player.hidden else _vc(vis,"player_sprint_color",C_PLAYER_SPR)
            draw_text(world_surf,lbl,bx,by-r-16,self.font_sm,lc,"center")

        # ── Aim line (right-click mode) ────────────────────────────────────────
        if self.aiming and not self.player.hidden:
            ang = self.player.facing
            step = 4
            ax, ay = float(bx), float(by)
            dx_a = math.cos(ang) * step
            dy_a = math.sin(ang) * step
            max_len = max(VIEW_W, VIEW_H)
            hit_x = hit_y = None
            _closed_doors_aim = self.closed_door_tiles
            # Build screen-space circles for guards and snitches to check against
            _blockers = []
            for g in self.guards:
                if g.state == DEAD: continue
                gsx, gsy = cam.world_to_screen(g.x, g.y)
                _blockers.append((gsx, gsy, g.RAD + 4))
            for s in self.snitches:
                if getattr(s, "dead", False): continue
                ssx, ssy = cam.world_to_screen(s.x, s.y)
                _blockers.append((ssx, ssy, s.RAD + 4))
            for _ in range(max_len // step):
                ax += dx_a; ay += dy_a
                # Check guards/snitches first (circle hit)
                stopped = False
                for (ex, ey, er) in _blockers:
                    if math.hypot(ax - ex, ay - ey) <= er:
                        hit_x, hit_y = int(ax), int(ay)
                        stopped = True
                        break
                if stopped: break
                # Convert screen pos back to world tile for wall + closed door check
                wx = ax + cam.x; wy = ay + cam.y
                tc_x = int(wx // tile); tc_y = int(wy // tile)
                if (tc_x, tc_y) in self.walls or (tc_x, tc_y) in _closed_doors_aim:
                    hit_x, hit_y = int(ax), int(ay)
                    break
                if ax < 0 or ax > VIEW_W or ay < 0 or ay > VIEW_H:
                    hit_x, hit_y = int(ax), int(ay)
                    break
            if hit_x is None: hit_x, hit_y = int(ax), int(ay)
            pygame.draw.line(world_surf, (255, 80, 60, 160), (bx, by), (hit_x, hit_y), 1)
            pygame.draw.circle(world_surf, (255, 80, 60), (hit_x, hit_y), 4, 1)

        # Detail images / texts – layer 2 (above player / guards)
        for di in self.detail_imgs:
            if di.layer == 2:
                di.draw(world_surf, cam, tile, self.level_dir)
        for dt in self.detail_txts:
            if dt.layer == 2:
                dt.draw(world_surf, cam, tile, self.font_sm, self.font_md)

        # State overlay
        if self.state in ("dead","won"):
            ov = pygame.Surface((VIEW_W,VIEW_H),pygame.SRCALPHA)
            ov.fill((200,0,0,55) if self.state=="dead" else (0,140,60,45))
            world_surf.blit(ov,(0,0))

        # ── Region dim overlay ────────────────────────────────────────────────
        # For each tile in a non-visible region, draw a dark overlay with smooth alpha
        if self._regions_enabled:
            _reg_surf = pygame.Surface((VIEW_W, VIEW_H), pygame.SRCALPHA)
            for rid, tiles_set in self.regions_data.items():
                alpha_f = self._region_alpha.get(rid, 1.0)
                if alpha_f >= 0.99:
                    continue  # fully visible, skip
                # Darkness alpha: 0 = no region (fully visible) → 220 = fully dark
                dark_alpha = int((1.0 - alpha_f) * 220)
                if dark_alpha < 2:
                    continue
                for (tc2, tr2) in tiles_set:
                    sx, sy = cam.world_to_screen(tc2 * tile, tr2 * tile)
                    if -tile <= sx <= VIEW_W and -tile <= sy <= VIEW_H:
                        _reg_surf.fill((0, 0, 0, dark_alpha),
                                       (int(sx), int(sy), tile, tile))
            world_surf.blit(_reg_surf, (0, 0))

        # Blit world to screen
        self.screen.blit(world_surf, (0, 0))

        # ── Inventory panel (top-right) ───────────────────────────────────────
        inv = self.inventory
        slot_sz  = 44    # square slot size px
        slot_gap = 4
        panel_x  = VIEW_W - slot_sz - 12
        panel_y  = 12
        slot_bg      = (18, 20, 32)
        slot_border  = (50, 55, 80)
        slot_active  = (200, 170, 80)
        slot_sec_col = (80, 140, 200)
        text_col     = (200, 210, 230)
        dim_col      = (80, 85, 100)

        def _draw_slot(label_top, item_key, active, color, y_pos):
            rect = pygame.Rect(panel_x, y_pos, slot_sz, slot_sz)
            pygame.draw.rect(self.screen, slot_bg, rect, border_radius=4)
            border_col = color if active else slot_border
            pygame.draw.rect(self.screen, border_col, rect, 2, border_radius=4)
            # slot label (Pri/Sec/1-4)
            draw_text(self.screen, label_top, panel_x + slot_sz//2, y_pos + 3,
                      self.font_sm, (color if active else dim_col), "midtop")
            if item_key:
                short = {"silenced_pistol": "~PSTL", "1911": "1911",
                         "shotgun": "SHTGN", "m4a1": "M4A1",
                         "keycard": "KEYCD"}.get(item_key, item_key[:5].upper())
                draw_text(self.screen, short, panel_x + slot_sz//2, y_pos + slot_sz//2,
                          self.font_sm, text_col if active else dim_col, "center")
            else:
                draw_text(self.screen, "—", panel_x + slot_sz//2, y_pos + slot_sz//2,
                          self.font_sm, dim_col, "center")

        y = panel_y
        pri_active = (inv.active_slot == "primary")
        _draw_slot("PRI", inv.primary, pri_active, slot_active, y)
        y += slot_sz + slot_gap
        sec_active = (inv.active_slot == "secondary")
        _draw_slot("SEC", inv.secondary, sec_active, slot_sec_col, y)
        y += slot_sz + slot_gap * 3   # small gap before other section

        for i, item in enumerate(inv.other):
            oth_active = (inv.active_slot == "other" and i == inv.other_sel)
            _draw_slot(str(i+1), item, oth_active, (100, 200, 140), y)
            y += slot_sz + slot_gap

        # Aim indicator badge
        if self.aiming:
            draw_text(self.screen, "[ AIM ]", panel_x + slot_sz//2, y + 4,
                      self.font_sm, (255, 80, 60), "midtop")

        # ── HUD ──────────────────────────────────────────────────────────────
        hy = VIEW_H
        pygame.draw.rect(self.screen,_vc(vis,"hud_bg_color",C_TITLE_BG),(0,hy,VIEW_W,50))
        pygame.draw.line(self.screen,_vc(vis,"wall_edge_color",C_WALL_EDGE),(0,hy),(VIEW_W,hy),2)

        collected = (self.total_loot - len(self.loot) - len(self.main_loot))
        main_col = C_MLOOT if not self.main_loot_taken else C_GREEN
        main_str = "★ SECURED" if self.main_loot_taken else "★ TARGET"
        draw_text(self.screen,f"$ {collected}/{self.total_loot}  SCORE {self.score}  T:{getattr(self,'_gold',0)}",
                  12,hy+6,self.font_md,C_LOOT)
        draw_text(self.screen,main_str,12,hy+28,self.font_sm,main_col)

        mstr = "HIDDEN" if self.player.hidden else \
               "SPRINTING" if self.player.sprinting else "SNEAKING"
        mc   = _vc(vis,"hide_active_color",C_HIDE_ON) if self.player.hidden else \
               _vc(vis,"player_sprint_color",C_PLAYER_SPR) if self.player.sprinting else C_GRAY
        draw_text(self.screen,mstr,VIEW_W//2,hy+8,self.font_md,mc,"midtop")

        if self.main_loot_noticed:
            salpha = min(255, int(200*abs(math.sin(self.tick*0.15))))
            ss = self.font_sm.render("⚠  GUARDS SEARCHING", True, (salpha,0,salpha))
            self.screen.blit(ss, ss.get_rect(midtop=(VIEW_W//2, hy+30)))

        draw_text(self.screen,"WASD=Move SHIFT=Sprint E=Door H=Hide R=Restart  TAB=Gun  ~=Gear  Q=Use  1-4=Other  X=Drop  Z=Drag  RMB=Aim  ESC=Pause",
                  VIEW_W-10,hy+8,self.font_sm,(58,62,95),"topright")

        # ── Gear HUD (top-right, shifted left of the gun/inventory panel) ──────
        eq = self.equipment
        # Gun inventory panel occupies the last (slot_sz+12) = 56px of the right edge.
        # Leave a 16px gap so gear slots sit clear of it.
        _INV_PANEL_W = 56 + 16   # slot_sz(44) + panel margin(12) + gap(16)
        gx0 = VIEW_W - _INV_PANEL_W - 204; gy0 = 8
        gw  = 200; gh = 28
        # Worn slot
        worn_lbl = ""
        if eq.worn:
            defn = EQUIPMENT_DEFS.get(eq.worn, {})
            worn_lbl = defn.get("label", eq.worn)[:18]
            worn_col = defn.get("color", (180, 200, 220))
            wpanel = pygame.Surface((gw, 20), pygame.SRCALPHA)
            wpanel.fill((10, 14, 22, 180))
            self.screen.blit(wpanel, (gx0, gy0))
            pygame.draw.circle(self.screen, worn_col, (gx0+8, gy0+10), 4)
            draw_text(self.screen, f"WEAR: {worn_lbl}", gx0+16, gy0+2,
                      self.font_sm, worn_col)
            gy0 += 24

        # Gear slots
        for si in range(3):
            key = eq.gear[si]
            active = (si == eq.gear_sel)
            bx = gx0 + si * 68; by = gy0
            bg_col = (40, 70, 120, 200) if active else (14, 18, 28, 180)
            bp = pygame.Surface((64, 26), pygame.SRCALPHA)
            bp.fill(bg_col)
            self.screen.blit(bp, (bx, by))
            bord = (100, 160, 255) if active else (40, 55, 80)
            pygame.draw.rect(self.screen, bord, (bx, by, 64, 26), 1, border_radius=3)

            if key:
                defn   = EQUIPMENT_DEFS.get(key, {})
                dot_c  = defn.get("color", (160, 180, 200))
                pygame.draw.circle(self.screen, dot_c, (bx+8, by+13), 4)
                ch = eq.gear_charges.get(key, EQUIPMENT_DEFS.get(key, {}).get("charges", 1))
                ch_str = f"×{ch}" if (ch is not None and ch >= 0) else "∞"
                lbl_str = defn.get("label", key)[:7]
                lbl_c = (220, 240, 255) if active else (140, 160, 200)
                draw_text(self.screen, lbl_str, bx+14, by+3, self.font_sm, lbl_c)
                draw_text(self.screen, ch_str, bx+14, by+14, self.font_sm,
                          (200, 170, 80) if active else (100, 110, 130))
            else:
                draw_text(self.screen, "empty", bx+8, by+7, self.font_sm, (50, 60, 80))

            # Active cloak timer bar
            if active and key == "invisi_cloak" and eq.cloak_active:
                frac = eq.cloak_timer / EQUIPMENT_DEFS["invisi_cloak"]["effects"]["cloak_duration"]
                pygame.draw.rect(self.screen, (20, 200, 240),
                                 (bx+1, by+24, int(62*frac), 2))

            # Boost timer bar
            if active and key == "adrenaline_shot" and eq.boost_active:
                frac = eq.boost_timer / EQUIPMENT_DEFS["adrenaline_shot"]["effects"]["boost_duration"]
                pygame.draw.rect(self.screen, (255, 120, 60),
                                 (bx+1, by+24, int(62*frac), 2))

        if self.total_loot:
            bw=150; bx0=VIEW_W//2-bw//2
            pygame.draw.rect(self.screen,(32,35,55),(bx0,hy+34,bw,6),border_radius=3)
            fill=int(bw*collected/self.total_loot)
            if fill: pygame.draw.rect(self.screen,C_LOOT,(bx0,hy+34,fill,6),border_radius=3)

        nscore=sum(ne.score for ne in self.noise_events)
        if nscore>0:
            frac=min(1.0,nscore/NOISE_GLOBAL)
            aw=int(88*frac)
            acol=(255,180,0) if frac<0.75 else C_RED
            nx0=VIEW_W//2+82
            pygame.draw.rect(self.screen,(32,24,10),(nx0,hy+34,88,6),border_radius=3)
            pygame.draw.rect(self.screen,acol,(nx0,hy+34,aw,6),border_radius=3)
            draw_text(self.screen,"NOISE",nx0,hy+24,self.font_sm,acol)

        if self.state in ("dead","won"):
            if self.state == "dead":
                if self.death_cause == "pit":
                    title_txt = "FALLEN!"
                else:
                    title_txt = "CAUGHT!"
            else:
                title_txt = f"SCORE: {self.score}"
            if self.state == "dead":
                sub_txt = "Press R to retry"
            elif self.lvl.get("next_level"):
                sub_txt = "Escaped!  N for next level  ·  R to retry"
            else:
                sub_txt = "Escaped!  R to play again"
            col = C_RED if self.state=="dead" else C_GREEN
            self._panel(self.screen,title_txt,sub_txt,col,VIEW_W,VIEW_H)

        # Drag mode indicator
        if self._drag_toggle_active:
            drag_lbl = "DRAGGING BODY" if self._dragging_body is not None else "DRAG MODE  [Z to cancel]"
            drag_col = (255, 180, 60) if self._dragging_body is not None else (180, 180, 80)
            draw_text(self.screen, drag_lbl, VIEW_W // 2, VIEW_H - 28, self.font_md, drag_col, "center")

        # ── Shop menu overlay (drawn on top of everything) ────────────────────
        if getattr(self, '_shop_menu', None) is not None and not self._shop_menu.closed:
            self._shop_menu.draw(self.screen, VIEW_W, VIEW_H, self.font_md)
            pygame.display.flip()
            return   # skip normal flip – already flipped above

    def _advance_level(self):
        """Load the next level in a sequence (defined by 'next_level' key in .ler)."""
        nxt = self.lvl.get("next_level")
        if not nxt: return
        base = os.path.dirname(self.lvl.get("level_path", ""))
        nxt_path = os.path.normpath(os.path.join(base, nxt))
        if not os.path.exists(nxt_path):
            print(f"[LockESC] next_level not found: {nxt_path}")
            return
        # Show post-level equip screen (dual if MP)
        _inv2 = getattr(self, "inventory2", None)
        _eq2  = getattr(self, "equipment2", None)
        if _inv2 is not None and _eq2 is not None:
            eq_screen = MPEquipScreen(
                self.screen, self.clock,
                self.equipment, self.inventory,
                _eq2, _inv2,
                getattr(self, '_gold', 0), post_level=True,
                score=self.score, has_next=True)
        else:
            eq_screen = EquipScreen(
                self.screen, self.clock, self.equipment, self.inventory,
                getattr(self, '_gold', 0), post_level=True,
                score=self.score, has_next=True)
        eq_screen.run()
        # If we're inside a project, advance via _load_project_room so the
        # next_level chain is injected for every subsequent room (not just room 1->2).
        if hasattr(self, "_project_rooms") and self._project_rooms:
            next_idx = getattr(self, "_project_room_idx", 0) + 1
            if next_idx < len(self._project_rooms):
                self._load_project_room(next_idx)
                return
        # Standalone .ler sequence (no project context) - load directly.
        self.lvl = load_level(nxt_path)
        self.reset()

    def _freeze_flash(self, new_state):
        """
        Brief freeze + colour flash on death or escape, then set game state.
        Renders 8 frames of a fading overlay before returning control.
        """
        col = (220, 0, 0) if new_state == "dead" else (0, 180, 80)
        for i in range(8):
            alpha = int(180 * (1.0 - i / 8))
            ov = pygame.Surface((VIEW_W, VIEW_H + 50), pygame.SRCALPHA)
            ov.fill((*col, alpha))
            self.screen.blit(ov, (0, 0))
            pygame.display.flip()
            pygame.time.wait(28)
        self.state = new_state

    def _panel(self,scr,title,sub,colour,W,H):
        cx,cy=W//2,H//2
        p=pygame.Surface((490,155),pygame.SRCALPHA); p.fill((6,8,20,225))
        scr.blit(p,(cx-245,cy-77))
        pygame.draw.rect(scr,colour,(cx-245,cy-77,490,155),3,border_radius=6)
        draw_text(scr,title,cx,cy-30,self.font_lg,colour,"center")
        draw_text(scr,sub,  cx,cy+26,self.font_md,C_GRAY, "center")

    def _load_via_path(self, path):
        """Load a .lep or .ler (bundle or flat) directly by path."""
        if not path:
            return
        path = os.path.abspath(path)
        if _is_lep(path):
            self._load_project(path)
            return
        try:
            new_lvl = load_level(path)
        except Exception as ex:
            print(f"[LockESC] Failed to load '{path}': {ex}"); return
        self.lvl = new_lvl
        self.reset()
        if self.lvl.get("missing_assets"):
            self._show_missing_assets_screen()

    def _load_via_dialog(self):
        """Open the in-game level browser and load the chosen level."""
        browser = LevelBrowser(self.screen, self.clock, exclude_names={"story"})
        path = browser.run()
        if not path:
            return
        self._load_via_path(path)
    def _load_project(self, lep_path):
        """Load a .lep project (bundle or flat) and let the player choose which room to play."""
        import tkinter as tk
        try:
            real = _lep_json_path(lep_path)
            with open(real) as f:
                data = json.load(f)
        except Exception as ex:
            print(f"[LockESC] Failed to read project '{lep_path}': {ex}"); return

        base = _lep_base(real)
        rooms = []
        for r in data.get("rooms", []):
            raw = r.get("path", "")
            abs_p = _find_room_bundle(raw, base)
            rooms.append({"name": r.get("name", os.path.basename(abs_p)), "path": abs_p})

        if not rooms:
            print(f"[LockESC] Project '{lep_path}' has no rooms."); return

        # Store project info so N key can advance rooms
        self._project_rooms   = rooms
        self._project_visuals = data.get("default_visuals", {})

        # If there's only one room, just load it
        if len(rooms) == 1:
            self._load_project_room(0)
            return

        # Show a simple room-picker dialog using Tk
        root = tk.Tk()
        root.title(f"Project: {data.get('name','Untitled')} – Choose Room")
        root.attributes("-topmost", True)
        root.configure(bg="#1a1c24")

        tk.Label(root, text=f"Project: {data.get('name','Untitled')}",
                 bg="#1a1c24", fg="#c0c8d8", font=("Consolas", 12, "bold")).pack(pady=(12,4), padx=16)
        tk.Label(root, text="Select a room to play:",
                 bg="#1a1c24", fg="#808898", font=("Consolas", 10)).pack(padx=16)

        lb = tk.Listbox(root, bg="#0e1018", fg="#c8d4e8", font=("Consolas", 11),
                        selectbackground="#2e5080", relief="flat", bd=0, width=40)
        for i, r in enumerate(rooms):
            lb.insert(tk.END, f"  {i+1}.  {r['name']}")
        lb.selection_set(0)
        lb.pack(padx=16, pady=8, fill="both", expand=True)

        chosen = [0]
        def on_ok():
            sel = lb.curselection()
            chosen[0] = sel[0] if sel else 0
            root.destroy()
        def on_cancel():
            chosen[0] = -1
            root.destroy()

        btn_row = tk.Frame(root, bg="#1a1c24")
        btn_row.pack(pady=(0, 12))
        tk.Button(btn_row, text=" Play ", bg="#2a5080", fg="#ffffff",
                  font=("Consolas", 11, "bold"), relief="flat",
                  command=on_ok).pack(side="left", padx=6)
        tk.Button(btn_row, text="Cancel", bg="#383848", fg="#a0a8c0",
                  font=("Consolas", 10), relief="flat",
                  command=on_cancel).pack(side="left", padx=6)
        lb.bind("<Double-Button-1>", lambda e: on_ok())
        root.bind("<Return>", lambda e: on_ok())
        root.bind("<Escape>", lambda e: on_cancel())

        root.update_idletasks()
        root.mainloop()
        if chosen[0] < 0: return
        self._load_project_room(chosen[0])

    def _load_project_room(self, idx):
        """Load room by index from the current project."""
        if not hasattr(self, "_project_rooms") or not self._project_rooms: return
        r = self._project_rooms[idx]
        try:
            new_lvl = load_level(r["path"])
        except Exception as ex:
            print(f"[LockESC] Failed to load room '{r['path']}': {ex}"); return
        # Merge project-wide default visuals (room's own visuals take priority)
        merged_vis = dict(self._project_visuals)
        merged_vis.update(new_lvl.get("visuals", {}))
        new_lvl["visuals"] = merged_vis
        # Store next room index so N key works across rooms
        next_idx = idx + 1
        if next_idx < len(self._project_rooms):
            next_room = self._project_rooms[next_idx]
            new_lvl["next_level"] = next_room["path"]
        self._project_room_idx = idx
        self.lvl = new_lvl
        self.reset()


# ════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else None
    Game(path).run()
