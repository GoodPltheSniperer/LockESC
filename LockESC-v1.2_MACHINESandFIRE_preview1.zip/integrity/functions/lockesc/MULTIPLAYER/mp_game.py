"""
mp_game.py  –  MPGame  (two-player cooperative stealth)
=========================================================
Subclasses the original Game from integrity.functions.lockesc.core.

What changes versus single-player:
  - A second Player object (self.player2) is created alongside self.player.
  - Both players share the same guards, noise system, inventory tracking.
  - In SAME_PC mode:  LocalP2Input drives player2 from this process.
  - In LAN_HOST mode: LANHost receives P2 input over UDP;
                       LANHost broadcasts world state each tick.
  - In LAN_JOIN mode: LANClient sends P2 input to host;
                       host world state is used to drive non-authoritative
                       rendering (guards/loot/doors from host packet, P2
                       driven locally, P1 rendered from host position).

Level loading uses mplevels/ instead of levels/.
  lockesc_mp.py passes a path under ~/mplevels/.

Win condition: EITHER player reaches the exit tile carrying the main loot,
  OR both players are at the exit together (cooperative clear).
Death: a player dies independently; if both die the run resets.
"""

import os
import math
import pygame

# Import everything from the existing single-player core
from integrity.functions.lockesc.core import (
    Game, Player, Camera, NoiseEvent,
    tc, ptile, dist, VIEW_W, VIEW_H, FPS, TILE,
    _play, _gen_sfx, _vc, draw_text, SpriteCache,
    C_BG, C_WHITE, DEAD,
    ModeSelectScreen, TitleScreen,
    Inventory, EquipmentState, ItemPile,
)

from .input_local import LocalP2Input
from .input_lan   import LANHost, LANClient

# Mode constants
MODE_SAME_PC  = "same_pc"
MODE_LAN_HOST = "lan_host"
MODE_LAN_JOIN = "lan_join"

# Player 2 colour accent (HUD / badge)
C_P2 = (80, 200, 255)


class MPGame(Game):
    """
    Two-player cooperative extension of Game.

    Usage:
        game = MPGame(level_path, mode=MODE_SAME_PC)
        game.run()

        # LAN host:
        game = MPGame(level_path, mode=MODE_LAN_HOST, lan_port=7890)

        # LAN join:
        game = MPGame(level_path, mode=MODE_LAN_JOIN, host_ip="192.168.1.x")
    """

    @staticmethod
    def __mp_init_extra__(instance):
        """
        Called when Game.__init__ patches self.__class__ = MPGame mid-boot.
        Sets the MP-specific instance vars that MPGame.__init__ would normally set.
        The display, audio, fonts and _levels_root are already set by Game.__init__.
        """
        instance._mp_mode    = MODE_SAME_PC
        instance._lan_port   = 7890
        instance._host_ip    = ""
        instance._lan_host   = None
        instance._lan_client = None
        instance._p2_input   = None
        instance._world_buf  = None
        pygame.display.set_caption("LockESC  [MULTIPLAYER]")

    def __init__(self, level_path=None, mode=MODE_SAME_PC,
                 lan_port=7890, host_ip="127.0.0.1"):
        self._mp_mode    = mode
        self._lan_port   = lan_port
        self._host_ip    = host_ip
        self._lan_host   = None
        self._lan_client = None
        self._p2_input   = None
        self._world_buf  = None   # LAN join: last received host state

        # Let parent __init__ set everything up (display, audio, levels, etc.)
        super().__init__(level_path)

        # Override caption
        pygame.display.set_caption(f"LockESC  [MP – {mode.upper().replace('_',' ')}]")

    # ── LAN setup (called after display is ready) ─────────────────────────────

    def _setup_lan(self):
        """Called from run() before the game loop when mode is LAN."""
        if self._mp_mode == MODE_LAN_HOST:
            self._lan_host = LANHost(port=self._lan_port)
            self._lan_host.start()
            # Show waiting screen until peer joins
            self._wait_for_peer_screen()

        elif self._mp_mode == MODE_LAN_JOIN:
            self._lan_client = LANClient(self._host_ip, port=self._lan_port)
            self._connecting_screen()

    def _wait_for_peer_screen(self):
        ip   = self._lan_host.local_ip()
        font = pygame.font.SysFont("consolas", 18, bold=True)
        sm   = pygame.font.SysFont("consolas", 13)
        clock = self.clock
        level_stem = os.path.basename(getattr(self, "_level_stem", "level"))
        while True:
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT: pygame.quit(); import sys; sys.exit()
                if ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE:
                    pygame.quit(); import sys; sys.exit()
            self.screen.fill((6, 8, 18))
            draw_text(self.screen, "LockESC  MULTIPLAYER",
                      VIEW_W//2, 80, font, (60, 120, 200), "center")
            draw_text(self.screen, "Waiting for Player 2...",
                      VIEW_W//2, 140, sm, (160, 180, 220), "center")
            draw_text(self.screen, f"Your IP:  {ip}:{self._lan_port}",
                      VIEW_W//2, 190, sm, (100, 220, 160), "center")
            draw_text(self.screen, f"Level:  {level_stem}",
                      VIEW_W//2, 230, sm, (100, 140, 180), "center")
            draw_text(self.screen, "ESC = cancel",
                      VIEW_W//2, 560, sm, (50, 60, 80), "center")
            pygame.display.flip()
            clock.tick(30)

            if self._lan_host.wait_for_join(level_stem, timeout=0.01):
                # Tell member what level to load, then signal start
                self._lan_host.send_launch(level_stem)
                self._lan_host.send_start()
                return

    def _connecting_screen(self):
        font = pygame.font.SysFont("consolas", 18, bold=True)
        sm   = pygame.font.SysFont("consolas", 13)
        clock = self.clock
        dots  = 0
        timer = 0.0
        connected = self._lan_client.connect(timeout=30.0)
        if not connected:
            draw_text(self.screen, "Could not connect to host.",
                      VIEW_W//2, 300, font, (220, 60, 60), "center")
            pygame.display.flip()
            pygame.time.wait(2000)
            pygame.quit(); import sys; sys.exit()

    # ── Override reset to also create player2 ────────────────────────────────

    def reset(self):
        super().reset()
        # Spawn player2 near player1 (offset by 1 tile right, or at second spawn
        # if defined in the level). Falls back to player1's position + offset.
        lvl = self.lvl
        p2_spawn = lvl.get("player2_start") or lvl.get("player2_spawn")
        if p2_spawn:
            tx, ty = p2_spawn
        else:
            sp = lvl.get("player_start", (1, 1))
            tx, ty = sp[0] + 1, sp[1]
        self.player2 = Player(tx, ty, tile=self.tile)
        self.player2.hp = 2
        self._p2_dead = False
        self._p2_input = LocalP2Input()
        # P2 gets their own independent inventory and equipment
        # Preserve across resets if already created (so gear survives room transitions)
        if not hasattr(self, "inventory2"):
            self.inventory2  = Inventory()
        if not hasattr(self, "equipment2"):
            self.equipment2  = EquipmentState()
            # Mirror P1's starting loadout so P2 starts equally equipped
            self.equipment2.worn = self.equipment.worn
            self.equipment2.gear = list(self.equipment.gear)
            self.equipment2.gear_charges = dict(self.equipment.gear_charges)
        # Mirror P1's inventory items too (same starting kit)
        if not hasattr(self, "_p2_inv_initialised"):
            self.inventory2.primary   = self.inventory.primary
            self.inventory2.secondary = self.inventory.secondary
            self.inventory2.other     = list(self.inventory.other)
            self._p2_inv_initialised  = True

    # ── Override run to wire MP ───────────────────────────────────────────────

    def run(self):
        import os as _os, sys as _sys
        if self._mp_mode in (MODE_LAN_HOST, MODE_LAN_JOIN):
            self._setup_lan()

        # Store stem for LAN use
        self._level_stem = _os.path.basename(
            getattr(self, "filepath", "") or "level").split(".")[0]

        # ── Own run loop (replaces super().run()) so we can inject P2 each tick ──
        if self.lvl.get("missing_assets"):
            self._show_missing_assets_screen()

        while True:
            dt = min(self.clock.tick(FPS)/1000.0, 0.05)
            self.tick += 1
            self._game_time += dt

            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    pygame.quit(); _sys.exit()
                if ev.type == pygame.KEYDOWN:
                    # Shop menu takes priority
                    if self._shop_menu is not None and not self._shop_menu.closed:
                        self._shop_menu.handle_key(ev.key, self.inventory)
                        if hasattr(self, "_gold"):
                            self._gold = self._shop_menu.player_gold
                        if self._shop_menu.closed:
                            self._shop_menu = None
                        continue

                    # P2 KEYDOWN (same-PC) — handle P2 keys exclusively so they
                    # don't bleed into P1 bindings. If the key belongs to P2,
                    # store the actions and skip the rest of the P1 handler.
                    if self.state == "play" and self._mp_mode == MODE_SAME_PC:
                        if self._p2_input.is_p2_key(ev.key):
                            p2_actions = self.handle_p2_keydown(ev.key)
                            self._p2_pending_actions = p2_actions
                            continue   # don't let P1 also process this key

                    if ev.key == pygame.K_ESCAPE:
                        pr = self._run_pause_menu()
                        if pr == "quit":
                            pygame.quit(); _sys.exit()
                        if pr == "restart":
                            self.reset()
                        elif pr == "title":
                            from integrity.functions.lockesc.core import ModeSelectScreen, TitleScreen
                            mode_sel2 = ModeSelectScreen(self.screen, self.clock)
                            mode2 = mode_sel2.run()
                            if mode2 == "quit":
                                pygame.quit(); _sys.exit()
                            title = TitleScreen(self.screen, self.clock, levels_root=self._levels_root)
                            result = title.run()
                            if result == "quit":
                                pygame.quit(); _sys.exit()
                            if result == "story":
                                self._boot_story_mode()
                            elif isinstance(result, tuple) and result[0] == "custom":
                                self._load_via_path(result[1])
                            self.reset()
                        continue

                    if ev.key == pygame.K_r:
                        self.reset()
                    if ev.key == pygame.K_n and self.state == "won":
                        self._advance_level()
                    if ev.key == pygame.K_h and self.state == "play":
                        self._toggle_hide()
                    if ev.key == pygame.K_e and self.state == "play":
                        self._use_door()
                    if self.state == "play":
                        if ev.key == pygame.K_TAB:
                            self.inventory.cycle_gun()
                        if ev.key == pygame.K_BACKQUOTE:
                            self.equipment.cycle_gear()
                        if ev.key == pygame.K_q:
                            self.equipment.use_gear(self.player, self.noise_events, self.tile)
                        if ev.key == pygame.K_1: self.inventory.other_sel = 0; self.inventory.active_slot = "other"
                        if ev.key == pygame.K_2: self.inventory.other_sel = 1; self.inventory.active_slot = "other"
                        if ev.key == pygame.K_3: self.inventory.other_sel = 2; self.inventory.active_slot = "other"
                        if ev.key == pygame.K_4: self.inventory.other_sel = 3; self.inventory.active_slot = "other"
                        if ev.key == pygame.K_x:
                            self._drop_item()
                        if ev.key == pygame.K_z:
                            if self._drag_toggle_active:
                                self._drag_toggle_active = False
                                self._dragging_body = None
                            else:
                                body_nearby = any(
                                    g.state == DEAD and
                                    dist(self.player.x, self.player.y, g.x, g.y) < self.tile * 1.5
                                    for g in self.guards
                                )
                                if body_nearby:
                                    self._drag_toggle_active = True

                if ev.type == pygame.MOUSEBUTTONDOWN and self.state == "play":
                    if ev.button == 3:
                        self.aiming = not self.aiming
                    if ev.button == 1 and self.aiming:
                        self._shoot()
                    if ev.button in (4, 5):
                        self.inventory.cycle_gun()

            if self.state == "play":
                self.update(dt)
                # Flush pending P2 actions from KEYDOWN events this frame
                pending = getattr(self, "_p2_pending_actions", {})
                self._p2_pending_actions = {}
                self._update_mp_input_with_actions(dt, pending)
                self._check_p2_detected()
                if self._check_win():
                    self.state = "won"
                self._lan_sync()

            self.draw()
            pygame.display.flip()

    def update(self, dt):
        """Override Game.update to stop P1 responding to arrow keys in same-PC mode.
        In SAME_PC mode P2 owns the arrow keys exclusively.
        """
        if self._mp_mode == MODE_SAME_PC:
            # Temporarily monkey-patch key.get_pressed to mask arrow keys for P1.
            # We store the real function, call it, zero the arrow slots, and restore.
            _real_gp = pygame.key.get_pressed

            def _masked_gp():
                ks = list(_real_gp())
                ks[pygame.K_UP]    = 0
                ks[pygame.K_DOWN]  = 0
                ks[pygame.K_LEFT]  = 0
                ks[pygame.K_RIGHT] = 0
                ks[pygame.K_RSHIFT] = 0   # P2 sprint key — don't let P1 sprint on it
                return ks

            pygame.key.get_pressed = _masked_gp
            try:
                super().update(dt)
            finally:
                pygame.key.get_pressed = _real_gp
        else:
            super().update(dt)

    def _update_mp_input_with_actions(self, dt, pending_actions):
        """Read continuous P2 input and apply it, merging any KEYDOWN actions."""
        if self._p2_dead:
            return
        frame = self._p2_input.read_frame(dt) if self._mp_mode in (MODE_SAME_PC, MODE_LAN_JOIN) else {}
        if self._mp_mode == MODE_LAN_HOST:
            pkt = self._lan_host.poll_p2_input(self.tick) or {}
            frame = {
                "dx":        pkt.get("dx", 0),
                "dy":        pkt.get("dy", 0),
                "sprint":    pkt.get("sprint", False),
                "aim_mode":  pkt.get("aim_mode", False),
                "aim_angle": pkt.get("aim_angle", self.player2.facing),
            }
            pending_actions = pkt.get("actions", {})
        elif self._mp_mode == MODE_LAN_JOIN:
            # join: send our input to host, apply locally for responsiveness
            self._lan_client.send_p2_input(self.tick, frame, pending_actions)
        self._apply_p2(dt, frame, pending_actions)

    # ── Override per-frame update to include P2 logic ────────────────────────

    def _update_mp_input(self, dt):
        """
        Read P2 input and move player2.  Called from the patched run loop.
        Returns a dict of P2 single-frame actions.
        """
        if self._p2_dead:
            return {}

        if self._mp_mode == MODE_SAME_PC:
            frame   = self._p2_input.read_frame(dt)
            actions = {}   # filled by KEYDOWN in event loop

        elif self._mp_mode == MODE_LAN_HOST:
            pkt = self._lan_host.poll_p2_input(self.tick) or {}
            frame = {
                "dx":        pkt.get("dx", 0),
                "dy":        pkt.get("dy", 0),
                "sprint":    pkt.get("sprint", False),
                "aim_mode":  pkt.get("aim_mode", False),
                "aim_angle": pkt.get("aim_angle", self.player2.facing),
            }
            actions = pkt.get("actions", {})

        elif self._mp_mode == MODE_LAN_JOIN:
            # On the join side, P2 is this player — drive from local input
            frame   = self._p2_input.read_frame(dt)
            actions = {}
            # P1 position is rendered from last host packet (read in draw)
        else:
            return {}

        self._apply_p2(dt, frame, actions)
        return actions

    def _apply_p2(self, dt, frame: dict, actions: dict):
        """Apply one frame of P2 input to player2."""
        p2   = self.player2
        inv2 = getattr(self, "inventory2", self.inventory)
        eq2  = getattr(self, "equipment2", self.equipment)
        dx = frame.get("dx", 0)
        dy = frame.get("dy", 0)

        # Sprint
        p2.sprinting = bool(frame.get("sprint", False)) and (dx != 0 or dy != 0)

        # Equipment speed modifier
        p2._equip_speed_mul = eq2.speed_multiplier(p2.sprinting)

        # Hide toggle
        if actions.get("hide_toggle") and not p2.sprinting:
            p2.hidden = not p2.hidden

        # Clear hide if moving while not in a hide tile
        if (dx != 0 or dy != 0) and p2.hidden:
            tile_pos = ptile(p2.x, p2.y, self.tile)
            if tile_pos not in self.hides:
                p2.hidden = False

        # Aim
        if frame.get("aim_mode") and not p2.hidden:
            p2.facing = frame.get("aim_angle", p2.facing)
        elif dx != 0 or dy != 0:
            p2.facing = math.atan2(dy, dx)

        # Move
        closed = self.closed_door_tiles
        crashdoor_closed = {d.tile_pos() for d in self.crashdoors if not d.open}
        pit_block = self.pits if not p2.sprinting else set()
        p2._drag_slowed = False
        p2.move(dx, dy, self.walls | pit_block, closed - crashdoor_closed, crashdoor_closed)

        # Noise
        p2._walk_noise_mul = eq2.walk_noise_multiplier()
        p2._sprint_noise_suppressed = eq2.sprint_noise_suppressed()
        p2.emit_noise(dt, self.noise_events, moving=(dx != 0 or dy != 0))

        # Equipment update (cloak, boost, gear etc.)
        eq2.update(dt, p2, self.noise_events, self.tile)

        # Use gear (Q equivalent on numpad)
        if actions.get("use_gear"):
            eq2.use_gear(p2, self.noise_events, self.tile)

        # Cycle gun
        if actions.get("cycle_gun"):
            inv2.cycle_gun()

        # Cycle gear
        if actions.get("cycle_gear"):
            eq2.cycle_gear()

        # Fire
        if actions.get("fire") and frame.get("aim_mode") and not p2.hidden:
            if self._mp_mode in (MODE_SAME_PC, MODE_LAN_HOST):
                self._shoot_from_p2(p2, inv2)

        # Use door
        if actions.get("use_door"):
            self._use_door_for(p2)

        # Drop
        if actions.get("drop"):
            self._drop_item_for_p2(p2, inv2)

        # Other slot selection
        sel = actions.get("other_sel")
        if sel is not None:
            inv2.other_sel = sel
            inv2.active_slot = "other"

        # Pickup from floor (same pass as P1)
        for pile in list(self.item_piles):
            if dist(p2.x, p2.y, pile.x, pile.y) < self.tile:
                if pile.try_pickup(inv2):
                    break

    def _shoot_from(self, player_obj):
        """Fire using P1's inventory (backwards compat)."""
        self._shoot_from_p2(player_obj, self.inventory)

    def _shoot_from_p2(self, player_obj, inv):
        """Fire a bullet from player_obj using their own inventory."""
        item = inv.selected_item()
        if item not in ("silenced_pistol", "1911", "shotgun", "m4a1"):
            return
        GUN_DATA = {
            "silenced_pistol": (8,  3, True),
            "1911":            (65, 8, False),
            "shotgun":         (95, 10, False),
            "m4a1":            (70, 8, False),
        }
        score, r_tiles, visual_only = GUN_DATA[item]
        radius = self.tile * r_tiles
        self.noise_events.append(
            NoiseEvent(player_obj.x, player_obj.y, score, radius, 1.2,
                       ambiguous=False, visual_only=visual_only))
        silent = (item == "silenced_pistol")
        if item == "shotgun":
            import random
            for _ in range(6):
                spread = math.radians(random.uniform(-12.5, 12.5))
                ang = player_obj.facing + spread
                self._cast_bullet_ray(player_obj.x, player_obj.y, ang, silent=silent)
        else:
            self._cast_bullet_ray(player_obj.x, player_obj.y, player_obj.facing,
                                  silent=silent)

    def _use_door_for(self, player_obj):
        """Toggle nearest door for a given player object."""
        use_dist = self.tile * 1.5
        for d in self.doors + self.oiled_doors + self.wall_doors + self.thin_doors:
            dc, dr = d.col, d.row
            dx_, dy_ = tc(dc, dr, self.tile)
            if dist(player_obj.x, player_obj.y, dx_, dy_) < use_dist:
                if d.open:
                    d.close()
                    _play(self.sfx, "door", volume=0.45)
                else:
                    d.open_door()
                    _play(self.sfx, "door")
                self._update_door_tiles()
                break

    def _drop_item_for(self, player_obj):
        """Drop P1's item (backwards compat)."""
        self._drop_item()

    def _drop_item_for_p2(self, player_obj, inv):
        """Drop P2's selected item from their own inventory."""
        dropped = inv.drop_selected()
        if not dropped:
            return
        item_key, slot = dropped
        # Spawn an item pile at P2's tile position
        tx = int(player_obj.x // self.tile)
        ty = int(player_obj.y // self.tile)
        px, py = tc(tx, ty, self.tile)
        pile = ItemPile(px, py, item_key, slot)
        self.item_piles.append(pile)

    # ── Override draw to add P2 rendering ────────────────────────────────────

    def draw(self):
        # Let parent draw world + P1 onto _world_surf, then blit to screen.
        # We intercept after _world_surf is populated but before the HUD flip.
        super().draw()

        # _world_surf is now already blitted to self.screen inside super().draw().
        # Draw P2 directly onto self.screen on top of everything.
        if not self._p2_dead:
            self._draw_player2()

        # P2 HP badge
        self._draw_p2_hud()

    def _draw_player2(self):
        """Render P2 using the same pipeline as P1 but in cyan tones."""
        p2  = self.player2
        cam = self.camera
        sx, sy = cam.world_to_screen(p2.x, p2.y)
        if sx < -TILE*2 or sy < -TILE*2 or sx > VIEW_W+TILE*2 or sy > VIEW_H+TILE*2:
            return

        # Draw directly onto screen (called after parent blit)
        world_surf = self.screen
        cx, cy = int(sx), int(sy)
        r = p2.RAD
        vis = self.visuals
        tile = self.tile

        # P2 colour palette (cyan/teal to distinguish from P1 red)
        C_P2_BODY   = (40, 180, 240)
        C_P2_HID    = (20, 70, 110)
        C_P2_SPR    = (80, 220, 255)
        C_P2_BORDER = (10, 40, 80)

        # Sprint shimmer
        if p2.sprinting and not p2.hidden:
            gs2 = pygame.Surface((r*4, r*4), pygame.SRCALPHA)
            pygame.draw.circle(gs2, (*C_P2_SPR, 30), (r*2, r*2), r*2)
            world_surf.blit(gs2, (cx - r*2, cy - r*2))

        # Try player sprite, tinted cyan
        p_spr_path = vis.get("player_sprite")
        p_spr = SpriteCache.get(p_spr_path, (tile, tile), self.level_dir) if p_spr_path else None
        if p_spr and not p2.hidden:
            angle_deg = -math.degrees(p2.facing) - 90
            rotated   = pygame.transform.rotate(p_spr, angle_deg)
            rr        = rotated.get_rect(center=(cx, cy))
            tinted    = rotated.copy()
            # Apply cyan tint so P2 looks distinct
            tint_surf = pygame.Surface(tinted.get_size(), pygame.SRCALPHA)
            tint_surf.fill((0, 140, 255, 80))
            tinted.blit(tint_surf, (0, 0), special_flags=pygame.BLEND_RGBA_ADD)
            world_surf.blit(tinted, rr)
        else:
            # Procedural: same look as P1 but cyan
            pcol = C_P2_HID if p2.hidden else C_P2_SPR if p2.sprinting else C_P2_BODY
            pygame.draw.circle(world_surf, pcol, (cx, cy), r)
            pygame.draw.circle(world_surf, C_WHITE, (cx, cy), r, 2)
            # Facing dot (same style as P1)
            fdx = cx + int(math.cos(p2.facing) * (r - 3))
            fdy = cy + int(math.sin(p2.facing) * (r - 3))
            pygame.draw.circle(world_surf, _vc(vis, "bg_color", C_BG), (fdx, fdy), 4)

        # Status label (matches P1's label style)
        lbl = "HIDDEN" if p2.hidden else "SPRINT!" if p2.sprinting else ""
        if lbl:
            lc = C_P2_HID if p2.hidden else C_P2_SPR
            draw_text(world_surf, lbl, cx, cy - r - 16, self.font_sm, lc, "center")

        # "P2" marker above label so you can always tell who is who
        draw_text(world_surf, "P2", cx, cy - r - 28, self.font_sm, C_P2_BODY, "center")

    def _draw_p2_hud(self):
        """Small P2 status badge below the main HUD."""
        if not hasattr(self, "player2"):
            return
        p2  = self.player2
        scr = self.screen
        fnt = pygame.font.SysFont("consolas", 12, bold=True)
        hy  = VIEW_H + 50   # below main HUD bar

        if self._mp_mode == MODE_SAME_PC:
            mode_str = "P2 ↑↓←→ / NP"
        elif self._mp_mode == MODE_LAN_HOST:
            name = getattr(self._lan_host, "peer_name", "P2")
            mode_str = f"P2 [{name}]"
        else:
            mode_str = "P2 [you]"

        status = "HIDDEN" if p2.hidden else ("SPRINT" if p2.sprinting else "SNEAK")
        hp_col = (80, 200, 255) if p2.hp > 1 else (255, 100, 60)
        text   = f"{mode_str}  HP:{p2.hp}  {status}"
        draw_text(scr, text, 12, hy + 2, fnt, hp_col)

        if self._p2_dead:
            draw_text(scr, "P2 DEAD", VIEW_W//2, hy + 2, fnt, (220, 60, 60), "center")

    # ── LAN per-frame sync ────────────────────────────────────────────────────

    def _lan_sync(self):
        """Call once per tick after all simulation."""
        if self._mp_mode == MODE_LAN_HOST and self._lan_host and self._lan_host.connected:
            open_d   = list(self.open_door_tiles)
            closed_d = list(self.closed_door_tiles)
            self._lan_host.broadcast_state(
                self.tick, self.player, self.guards,
                self.noise_events, self.loot, self.main_loot,
                open_d, closed_d
            )
        elif self._mp_mode == MODE_LAN_JOIN and self._lan_client:
            frame   = self._p2_input.read_frame(0)
            actions = getattr(self, "_p2_last_actions", {})
            self._lan_client.send_p2_input(self.tick, frame, actions)
            # Update world from host packet (non-authoritative rendering)
            ws = self._lan_client.poll_world_state()
            if ws:
                self._apply_host_world(ws)

    def _apply_host_world(self, ws: dict):
        """
        On the join client: update world state from host packet.
        Only used for rendering — guard positions, loot visibility, door states.
        """
        p1_data = ws.get("p1", {})
        if p1_data:
            self.player.x        = p1_data.get("x", self.player.x)
            self.player.y        = p1_data.get("y", self.player.y)
            self.player.facing   = p1_data.get("facing", self.player.facing)
            self.player.hidden   = p1_data.get("hidden", self.player.hidden)
            self.player.sprinting= p1_data.get("sprinting", self.player.sprinting)
            self.player.hp       = p1_data.get("hp", self.player.hp)

        for i, g_data in enumerate(ws.get("guards", [])):
            if i < len(self.guards):
                g = self.guards[i]
                g.x         = g_data.get("x", g.x)
                g.y         = g_data.get("y", g.y)
                g.state     = g_data.get("state", g.state)
                g.suspicion = g_data.get("susp", g.suspicion)

        self.loot      = set(map(tuple, ws.get("loot", [])))
        self.main_loot = set(map(tuple, ws.get("mloot", [])))

    # ── P2 guard detection  (called from parent update guard loop) ────────────

    def _check_p2_detected(self):
        """Check whether any guard can see or catch player2."""
        if not hasattr(self, "player2") or self._p2_dead:
            return
        p2 = self.player2
        for g in self.guards:
            if g.state == DEAD:
                continue
            if dist(g.x, g.y, p2.x, p2.y) < g.RAD + p2.RAD + 2:
                p2.hp -= 1
                if p2.hp <= 0:
                    self._p2_dead = True
                    _play(self.sfx, "caught")
                    return

    # ── P2 KEYDOWN event handling (same-PC) ──────────────────────────────────

    def handle_p2_keydown(self, key: int):
        """
        Pass KEYDOWN events to P2 local input when in SAME_PC mode.
        Returns dict of single-frame actions.
        """
        if self._mp_mode != MODE_SAME_PC or self._p2_dead:
            return {}
        return self._p2_input.handle_keydown(
            key,
            getattr(self, "inventory", None),
            getattr(self, "equipment", None),
        )

    # ── Win condition override ────────────────────────────────────────────────

    def _check_win(self):
        """
        Cooperative win: P1 OR P2 at exit with main loot collected,
        OR both at exit (loot optional — cooperative clear).
        """
        ex, ey = self.exit_pos
        exit_px = tc(ex, ey, self.tile)
        p1_at_exit = dist(self.player.x,  self.player.y,  *exit_px) < self.tile
        p2_at_exit = (not self._p2_dead and
                      dist(self.player2.x, self.player2.y, *exit_px) < self.tile)

        loot_done = self.main_loot_taken or not self.main_loot
        if loot_done and (p1_at_exit or p2_at_exit):
            return True
        if p1_at_exit and p2_at_exit:
            return True
        return False
