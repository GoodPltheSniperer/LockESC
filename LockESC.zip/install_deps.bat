@echo off
:: ============================================================
::  LockESC + KeyRing  –  Dependency Installer
::  Run once before launching lockesc.py or keyring.py
:: ============================================================

echo.
echo  ===================================================
echo   LockESC + KeyRing  ^|  Installing dependencies...
echo  ===================================================
echo.

:: -- Core game engine (lockesc.py) ---------------------------
:: pygame: rendering, input, audio
pip install pygame

:: -- Level editor + Integrity Editor (keyring.py) ------------
:: PyQt6: all editor UI widgets, layouts, dialogs
pip install PyQt6

:: PyQt6-Qt6Svg: QSvgRenderer used in _pixmap_for_path()
:: to rasterise SVG thumbnails inside the Integrity Editor.
:: On some systems this ships with PyQt6; installing explicitly
:: guarantees it is present.
pip install PyQt6-Qt6Svg

:: -- Optional: SVG support in the game engine (lockesc.py) ---
:: cairosvg: rasterises .svg sprites at runtime via _load_svg_surface().
:: Falls back to rsvg-convert / Inkscape CLI if not installed.
:: Remove this line if you never use SVG sprites.
pip install cairosvg

echo.
echo  ===================================================
echo   All done!  You can now run:
echo     python lockesc.py
echo     python keyring.py
echo  ===================================================
echo.
pause
