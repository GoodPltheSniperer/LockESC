"""
dev.py  –  LockESC Story Dev Panel
=====================================
Story-mode special interaction authoring, integrated directly into the
KeyRing editor.  Only accessible if this file exists; not surfaced in
custom level editing or any public documentation.

Usage from keyring core:
    from integrity.functions.misc.dev import StoryDevPanel, STORY_TILE_TYPES

StoryDevPanel is a QWidget docked into EditorWindow.
STORY_TILE_TYPES is the list of tile types only available through this panel.

Story tile types placed here write standard tile JSON into the level model
like any other tile — the game will honour them in story mode.  In custom
levels they simply won't trigger (no story-state engine to read them), so
there's no crash risk if someone manually edits them in.

Planned interaction types (scaffold only — none produce output yet):
  - guard_dialogue     Bark lines attached to a guard entity
  - interrogation      Branching Q&A sequence, triggered by proximity/flag
  - cutscene_beat      Scripted entity move + overlay, non-interactive
  - objective_flag     Set / check story-state variables mid-level
"""

import os

try:
    from PyQt6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
        QFrame, QScrollArea, QSizePolicy, QMessageBox, QDialog,
        QDialogButtonBox, QFormLayout, QLineEdit, QSpinBox,
        QComboBox, QTextEdit, QCheckBox,
    )
    from PyQt6.QtCore import Qt, pyqtSignal
    from PyQt6.QtGui import QFont, QColor
except ImportError:
    raise ImportError("PyQt6 required for the Story Dev Panel")

# ── Story-exclusive tile types ────────────────────────────────────────────────
# These are added to the editor's tile palette only when dev.py is loaded.
# The game engine recognises them in story mode; in custom levels they are
# inert (no story-state machine to process them).

STORY_TILE_TYPES = [
    "guard_dialogue",
    "interrogation",
    "cutscene_beat",
    "objective_flag",
]

# Metadata for each story tile — used to populate the panel cards and the
# PropertyDialog-equivalent that will be built when each type is implemented.
_STORY_TILE_META = {
    "guard_dialogue": {
        "label":    "Guard Dialogue",
        "icon":     "💬",
        "color":    "#3a6a3a",
        "desc":     "Ambient bark or patrol chatter line attached to a guard entity.",
        "fields":   [],   # (name, widget_type, default) — populated when implemented
    },
    "interrogation": {
        "label":    "Interrogation",
        "icon":     "❓",
        "color":    "#6a3a20",
        "desc":     "Branching question/answer sequence. Triggered by proximity or objective flag. "
                    "Used in Chapter 1 story mode.",
        "fields":   [],
    },
    "cutscene_beat": {
        "label":    "Cutscene Beat",
        "icon":     "▶",
        "color":    "#1a3a6a",
        "desc":     "Scripted entity movement + dialogue overlay. Non-interactive.",
        "fields":   [],
    },
    "objective_flag": {
        "label":    "Objective Flag",
        "icon":     "⚑",
        "color":    "#5a3a6a",
        "desc":     "Set or check story-state variables mid-level. "
                    "Gates doors, triggers events, branches narrative.",
        "fields":   [],
    },
}

# ═════════════════════════════════════════════════════════════════════════════
# Story Dev Panel  (QWidget docked into EditorWindow's side panel area)
# ═════════════════════════════════════════════════════════════════════════════

class StoryDevPanel(QWidget):
    """
    Panel injected into EditorWindow when dev.py is present.

    Exposes story-only tile types as placeable tools (same as the normal
    tile toolbar, but gated here).  Each card will eventually open a
    purpose-built property dialog for that interaction type.

    Signals:
        story_tile_selected(str)  — emitted when user picks a story tile type;
                                    EditorWindow should set canvas.current_tool
                                    to that string like any other tile.
    """

    story_tile_selected = pyqtSignal(str)

    # Palette mirrors keyring dark theme
    _BG     = "#0d0f14"
    _BG2    = "#131720"
    _BG3    = "#1a1e2a"
    _BORDER = "#252a38"
    _TEXT   = "#b0bcd0"
    _DIM    = "#4a5468"
    _WARN   = "#c05040"

    def __init__(self, editor_ref=None, parent=None):
        super().__init__(parent)
        self._editor = editor_ref   # weak ref to EditorWindow — set after init if needed
        self.setMinimumWidth(210)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
        self.setStyleSheet(self._make_style())
        self._build_ui()

    def set_editor(self, editor):
        """Call after EditorWindow is fully built to wire the back-reference."""
        self._editor = editor

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 10, 8, 10)
        root.setSpacing(8)

        # Header
        hdr = QLabel("◈  STORY DEV")
        hdr.setFont(QFont("Consolas", 10, QFont.Weight.Bold))
        hdr.setStyleSheet("color: #7060c0; letter-spacing: 1px;")
        root.addWidget(hdr)

        sub = QLabel("story-mode interactions only")
        sub.setStyleSheet(f"color: {self._DIM}; font-size: 9px;")
        root.addWidget(sub)

        sep = QFrame(); sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet(f"color: {self._BORDER};")
        root.addWidget(sep)

        # Scrollable card area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")

        inner = QWidget()
        inner.setStyleSheet("background: transparent;")
        card_layout = QVBoxLayout(inner)
        card_layout.setContentsMargins(0, 0, 0, 0)
        card_layout.setSpacing(6)

        for tile_type in STORY_TILE_TYPES:
            card_layout.addWidget(self._make_card(tile_type))

        card_layout.addStretch()
        scroll.setWidget(inner)
        root.addWidget(scroll, 1)

        # Footer note
        note = QLabel("tiles write standard JSON\ncustom levels: inert")
        note.setStyleSheet(f"color: {self._DIM}; font-size: 9px; padding-top: 4px;")
        note.setAlignment(Qt.AlignmentFlag.AlignCenter)
        root.addWidget(note)

    def _make_card(self, tile_type: str) -> QFrame:
        meta = _STORY_TILE_META[tile_type]
        card = QFrame()
        card.setObjectName("storycard")
        card.setStyleSheet(
            f"QFrame#storycard {{ background: {self._BG2}; "
            f"border: 1px solid {self._BORDER}; border-radius: 5px; }}"
            f"QFrame#storycard:hover {{ border-color: {meta['color']}; }}"
        )

        col = QVBoxLayout(card)
        col.setContentsMargins(8, 7, 8, 7)
        col.setSpacing(3)

        # Title row
        title_row = QHBoxLayout()
        title_row.setSpacing(5)

        icon_lbl = QLabel(meta["icon"])
        icon_lbl.setStyleSheet(f"color: {meta['color']}; font-size: 14px; background: transparent;")
        title_row.addWidget(icon_lbl)

        name_lbl = QLabel(meta["label"])
        name_lbl.setFont(QFont("Consolas", 10, QFont.Weight.Bold))
        name_lbl.setStyleSheet(f"color: {self._TEXT}; background: transparent;")
        title_row.addWidget(name_lbl, 1)
        col.addLayout(title_row)

        # Description
        desc_lbl = QLabel(meta["desc"])
        desc_lbl.setWordWrap(True)
        desc_lbl.setStyleSheet(f"color: {self._DIM}; font-size: 9px; background: transparent;")
        col.addWidget(desc_lbl)

        # Place button
        btn_row = QHBoxLayout()
        btn_row.setContentsMargins(0, 2, 0, 0)

        place_btn = QPushButton("Place")
        place_btn.setStyleSheet(
            f"QPushButton {{ background: {self._BG3}; color: {meta['color']}; "
            f"border: 1px solid {meta['color']}40; border-radius: 3px; "
            f"font-size: 10px; padding: 3px 10px; }}"
            f"QPushButton:hover {{ background: {meta['color']}22; }}"
            f"QPushButton:pressed {{ background: {meta['color']}44; }}"
        )
        place_btn.clicked.connect(lambda _, t=tile_type: self._on_place(t))
        btn_row.addWidget(place_btn)

        props_btn = QPushButton("…")
        props_btn.setToolTip("Edit default properties for this interaction type")
        props_btn.setStyleSheet(
            f"QPushButton {{ background: {self._BG3}; color: {self._DIM}; "
            f"border: 1px solid {self._BORDER}; border-radius: 3px; "
            f"font-size: 10px; padding: 3px 7px; max-width: 24px; }}"
            f"QPushButton:hover {{ color: {self._TEXT}; border-color: #4a5468; }}"
        )
        props_btn.clicked.connect(lambda _, t=tile_type: self._on_edit_props(t))
        btn_row.addWidget(props_btn)

        btn_row.addStretch()
        col.addLayout(btn_row)

        return card

    # ── Slot handlers ─────────────────────────────────────────────────────────

    def _on_place(self, tile_type: str):
        """Switch the editor canvas to place this story tile type."""
        # Emit first — EditorWindow._on_story_tile_selected handles canvas + status bar
        self.story_tile_selected.emit(tile_type)

    def _on_edit_props(self, tile_type: str):
        """Open properties dialog for this story tile type (stub)."""
        meta = _STORY_TILE_META[tile_type]
        dlg = _StoryPropsStubDialog(tile_type, meta, parent=self)
        dlg.exec()

    def _make_style(self) -> str:
        return f"""
            QWidget {{
                background: {self._BG};
                color: {self._TEXT};
                font-family: Consolas, monospace;
                font-size: 11px;
            }}
            QScrollBar:vertical {{
                background: {self._BG};
                width: 6px;
                margin: 0;
            }}
            QScrollBar::handle:vertical {{
                background: {self._BORDER};
                border-radius: 3px;
                min-height: 20px;
            }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
                height: 0;
            }}
        """


# ═════════════════════════════════════════════════════════════════════════════
# Stub property dialog  (placeholder until each type is implemented)
# ═════════════════════════════════════════════════════════════════════════════

class _StoryPropsStubDialog(QDialog):
    def __init__(self, tile_type: str, meta: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"{meta['label']} Properties")
        self.setModal(True)
        self.resize(340, 200)
        self.setStyleSheet("""
            QDialog { background: #0d0f14; color: #b0bcd0; font-family: Consolas; }
            QLabel  { color: #b0bcd0; }
            QPushButton {
                background: #1a1e2a; color: #7060c0;
                border: 1px solid #252a38; border-radius: 4px;
                padding: 5px 14px;
            }
            QPushButton:hover { background: #252a38; }
        """)

        v = QVBoxLayout(self)
        v.setContentsMargins(20, 16, 20, 16)
        v.setSpacing(10)

        icon_lbl = QLabel(f"{meta['icon']}  {meta['label']}")
        icon_lbl.setFont(QFont("Consolas", 13, QFont.Weight.Bold))
        icon_lbl.setStyleSheet(f"color: {meta['color']};")
        v.addWidget(icon_lbl)

        note = QLabel("Properties not yet implemented for this interaction type.\n"
                       "Tiles placed will be written as bare JSON objects;\n"
                       "fields will be editable once the type is built out.")
        note.setWordWrap(True)
        note.setStyleSheet("color: #4a5468; font-size: 10px;")
        v.addWidget(note)

        v.addStretch()

        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok)
        bb.accepted.connect(self.accept)
        bb.setStyleSheet("QPushButton { min-width: 70px; }")
        v.addWidget(bb)


# ── Public helper called by keyring core to register story tiles ──────────────

def register_story_tiles(tile_types_list: list, tile_icons_dict: dict,
                          tile_tooltips_dict: dict):
    """
    Called by keyring's _apply_let_defs (or directly at startup) to inject
    STORY_TILE_TYPES into the editor's runtime tile registry.

    tile_types_list   : TILE_TYPES list from keyring core (mutated in-place)
    tile_icons_dict   : TILE_ICONS dict from keyring core (mutated in-place)
    tile_tooltips_dict: TILE_TOOLTIP_LONG dict from keyring core (mutated in-place)
    """
    for tt in STORY_TILE_TYPES:
        if tt not in tile_types_list:
            tile_types_list.append(tt)
        meta = _STORY_TILE_META[tt]
        if tt not in tile_icons_dict:
            tile_icons_dict[tt] = meta["icon"]
        if tt not in tile_tooltips_dict:
            tile_tooltips_dict[tt] = (
                f"<b>{meta['label'].upper()}</b><br>"
                f"<i>story mode only</i><br>{meta['desc']}"
            )
