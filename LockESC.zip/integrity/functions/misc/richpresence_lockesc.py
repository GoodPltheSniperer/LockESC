"""
richpresence_lockesc.py  –  Discord Rich Presence for LockESC
Place at: integrity/functions/misc/richpresence_lockesc.py
Requires: pip install pypresence
Setup: paste your Discord app's numeric Client ID into LOCKESC_APP_ID
"""
import time, threading

LOCKESC_APP_ID = "YOUR_LOCKESC_APP_ID_HERE"

_GUARD_PRIORITY = ["combat","chase","panicked","search","alert","brief","inspect","patrol","dead"]
_GUARD_LABELS   = {
    "patrol":"Guards patrolling","alert":"Guard alerted!","chase":"Being chased!",
    "inspect":"Guard inspecting area","search":"Guards searching","brief":"Guards coordinating",
    "dead":"Guard down","panicked":"Guard panicked","combat":"Under fire!",
}

def _highest_threat(guards):
    if not guards: return None
    states = {g.state for g in guards}
    for p in _GUARD_PRIORITY:
        if p in states: return _GUARD_LABELS.get(p)
    return None

def _build_details(game) -> str:
    state = getattr(game, "state", "play")
    if state == "dead":
        cause = getattr(game, "death_cause", "guard")
        if cause == "pit":   return "Fell into a pit"
        if cause == "shot":  return "Shot by a guard"
        return "Caught by a guard"
    if state == "won":
        return f"Escaped!  Score: {getattr(game, 'score', 0)}"
    player = getattr(game, "player", None)
    if player is None: return "In a level"
    if player.hidden:   return "Hiding"
    if player.sprinting: return "Sprinting"
    return "Sneaking"

def _build_state(game) -> str:
    try:    lvl_name = game.lvl.get("name", "Level")
    except: lvl_name = "Level"
    total     = getattr(game, "total_loot", 0)
    remaining = len(getattr(game,"loot",set())) + len(getattr(game,"main_loot",set()))
    collected = total - remaining
    loot_str  = f"{collected}/{total} loot" if total else ""
    threat    = _highest_threat(getattr(game, "guards", []))
    parts     = [lvl_name]
    if loot_str: parts.append(loot_str)
    if threat:   parts.append(threat)
    return "  ·  ".join(parts)

class LockEscPresence:
    def __init__(self, app_id=LOCKESC_APP_ID):
        self._app_id=app_id; self._rpc=None; self._connected=False
        self._last_payload={}; self._start_time=int(time.time()); self._lock=threading.Lock()

    def start(self):
        try:
            from pypresence import Presence
            self._rpc = Presence(self._app_id); self._rpc.connect()
            self._connected = True; print("[RichPresence] LockESC connected to Discord")
        except Exception as e:
            print(f"[RichPresence] LockESC could not connect: {e}"); self._connected=False

    def stop(self):
        if self._connected and self._rpc:
            try: self._rpc.close()
            except: pass
        self._connected = False

    def update(self, game):
        if not self._connected: return
        details=_build_details(game); state=_build_state(game)
        payload={"details":details,"state":state}
        with self._lock:
            if payload==self._last_payload: return
            self._last_payload=dict(payload)
        try:
            self._rpc.update(details=details, state=state, start=self._start_time,
                             large_image="lockesc_logo", large_text="LockESC")
        except Exception as e:
            print(f"[RichPresence] LockESC update failed: {e}"); self._connected=False