"""
LockESC Door classes - All door types
Door, CrashDoor, OiledDoor, WallDoor, ThinDoor
"""

from .. import core

# Re-export door classes
Door = core.Door
CrashDoor = core.CrashDoor
OiledDoor = core.OiledDoor
WallDoor = core.WallDoor
ThinDoor = core.ThinDoor

__all__ = ['Door', 'CrashDoor', 'OiledDoor', 'WallDoor', 'ThinDoor']
