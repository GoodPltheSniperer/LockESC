"""
LockESC Character classes - Player, Guard, Snitch
All characters and NPCs are defined here.
"""

# Lazy imports to avoid circular dependency: core.py defines these classes
# inline, and also imports from this package. Accessing the names at function
# call time (rather than at module load time) breaks the cycle.

def __getattr__(name):
    if name in ('Guard', 'Player', 'Snitch'):
        from .. import core as _core
        return getattr(_core, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = ['Guard', 'Player', 'Snitch']
