# Stub: all code lives in the canonical lockesc/core.py.
# This file is kept for import-path compatibility only.
from ..core import *  # noqa: F401, F403
