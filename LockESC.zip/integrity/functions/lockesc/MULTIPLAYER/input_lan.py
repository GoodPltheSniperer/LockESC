"""
input_lan.py  –  LAN Networking (UDP)
======================================
Peer-to-peer over LAN.  One player hosts, one joins.

Protocol (all packets are JSON + newline, sent over UDP):

  HOST → JOIN each frame (< 1 KB):
    { "t": "state", "tick": N,
      "p1": { "x": f, "y": f, "facing": f, "hidden": b, "sprinting": b, "hp": i },
      "guards": [ {state, x, y, suspicion} ... ],
      "noise": [ {x, y, score, radius} ... ],
      "loot": [ [c,r] ... ],
      "doors": { "open": [[c,r]...], "closed": [[c,r]...] } }

  JOIN → HOST each frame (< 200 B):
    { "t": "p2", "tick": N,
      "dx": i, "dy": i, "sprint": b,
      "aim_mode": b, "aim_angle": f,
      "actions": { "hide_toggle": b, "use_door": b, "fire": b,
                   "cycle_gun": b, "drop": b, "drag": b, "other_sel": i|null } }

  Handshake (before game loop):
    JOIN → HOST: { "t": "hello", "name": str }
    HOST → JOIN: { "t": "welcome", "level": str }   (level path stem)
    JOIN → HOST: { "t": "ready" }
    HOST → JOIN: { "t": "start" }

Buffer / timing:
  - UDP, so packets can arrive out of order or drop.
  - We keep a 3-tick input buffer on host.  Stale P2 input (> 5 ticks old) is ignored
    and P2's last known position is held frozen.
  - The join client interpolates P1 + world state from the last received host packet.
  - No TCP reliability: this is intended for LAN where drop rate ≈ 0.

Usage:
    host = LANHost(port=7890)
    host.start()          # begins listening; blocks briefly for JOIN hello
    p2_input = host.poll_p2_input(tick)  # returns dict or None

    client = LANClient(host_ip, port=7890)
    client.connect()
    client.send_p2_input(tick, frame_dict)
    world = client.poll_world_state()    # returns dict or None
"""

import json
import socket
import threading
import time

DEFAULT_PORT    = 7890
_TICK_TOLERANCE = 5     # ignore P2 packets older than this many ticks
_SOCKET_TIMEOUT = 0.001  # 1 ms non-blocking poll

# ── Packet helpers ────────────────────────────────────────────────────────────

def _encode(obj: dict) -> bytes:
    return (json.dumps(obj, separators=(",", ":")) + "\n").encode("utf-8")

def _decode(data: bytes) -> dict | None:
    try:
        return json.loads(data.decode("utf-8").strip())
    except Exception:
        return None


# ═════════════════════════════════════════════════════════════════════════════
# LANHost  –  runs on the machine that loaded the level
# ═════════════════════════════════════════════════════════════════════════════

class LANHost:
    """
    Binds a UDP socket, waits for a single JOIN peer, then drives the sync loop.
    Call from MPGame (host side).
    """

    def __init__(self, port: int = DEFAULT_PORT):
        self.port        = port
        self._sock       = None
        self._peer_addr  = None   # (ip, port) of JOIN client
        self._p2_buf     = {}     # tick -> input dict
        self._lock       = threading.Lock()
        self._running    = False
        self._recv_thread = None
        self.connected   = False
        self.peer_name   = "P2"

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def start(self):
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind(("", self.port))
        self._sock.settimeout(_SOCKET_TIMEOUT)
        self._running = True
        self._recv_thread = threading.Thread(target=self._recv_loop, daemon=True)
        self._recv_thread.start()

    def stop(self):
        self._running = False
        if self._sock:
            try: self._sock.close()
            except Exception: pass

    def local_ip(self) -> str:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    # ── Handshake  ────────────────────────────────────────────────────────────

    def wait_for_join(self, level_stem: str, timeout: float = 60.0) -> bool:
        """
        Block until a JOIN peer says hello, or timeout expires.
        Returns True if a peer connected.
        """
        deadline = time.time() + timeout
        while time.time() < deadline:
            with self._lock:
                if self._peer_addr and not self.connected:
                    self._send({"t": "welcome", "level": level_stem})
                    self.connected = True
                    return True
            time.sleep(0.05)
        return False

    def send_start(self):
        self._send({"t": "start"})

    def send_launch(self, level_stem: str):
        """Broadcast to member that host has chosen a level and is launching."""
        self._send({"t": "launch", "level": level_stem})

    # ── Per-frame ─────────────────────────────────────────────────────────────

    def broadcast_state(self, tick: int, p1, guards, noise_events, loot,
                        main_loot, open_doors, closed_doors):
        """Send authoritative world state to JOIN peer."""
        if not self.connected or not self._peer_addr:
            return
        pkt = {
            "t": "state",
            "tick": tick,
            "p1": {
                "x": round(p1.x, 1), "y": round(p1.y, 1),
                "facing": round(p1.facing, 3),
                "hidden": p1.hidden, "sprinting": p1.sprinting,
                "hp": p1.hp,
            },
            "guards": [
                {"state": g.state, "x": round(g.x, 1), "y": round(g.y, 1),
                 "susp": round(g.suspicion, 2)}
                for g in guards
            ],
            "noise": [
                {"x": round(n.x, 1), "y": round(n.y, 1),
                 "score": n.score, "radius": round(n.radius, 1)}
                for n in noise_events[:16]   # cap to avoid oversized packets
            ],
            "loot": list(loot),
            "mloot": list(main_loot),
            "open": [list(t) for t in open_doors],
            "closed": [list(t) for t in closed_doors],
        }
        self._send(pkt)

    def poll_p2_input(self, tick: int) -> dict | None:
        """
        Return the most recent P2 input dict for `tick`, or None if nothing
        arrived within tolerance.
        """
        with self._lock:
            # Purge stale entries
            self._p2_buf = {t: v for t, v in self._p2_buf.items()
                            if t >= tick - _TICK_TOLERANCE}
            # Prefer exact tick, then nearest available
            if tick in self._p2_buf:
                return self._p2_buf[tick]
            if self._p2_buf:
                return self._p2_buf[max(self._p2_buf)]
        return None

    # ── Internal ──────────────────────────────────────────────────────────────

    def _send(self, obj: dict):
        if self._peer_addr and self._sock:
            try:
                self._sock.sendto(_encode(obj), self._peer_addr)
            except Exception:
                pass

    def _recv_loop(self):
        while self._running:
            try:
                data, addr = self._sock.recvfrom(4096)
            except socket.timeout:
                continue
            except Exception:
                break
            pkt = _decode(data)
            if pkt is None:
                continue
            t = pkt.get("t")
            if t == "hello":
                with self._lock:
                    if self._peer_addr is None:
                        self._peer_addr = addr
                        self.peer_name  = pkt.get("name", "P2")
            elif t == "p2":
                tick = pkt.get("tick", 0)
                with self._lock:
                    self._p2_buf[tick] = pkt
            elif t == "ready":
                with self._lock:
                    self.connected = True


# ═════════════════════════════════════════════════════════════════════════════
# LANClient  –  runs on the machine that joined
# ═════════════════════════════════════════════════════════════════════════════

class LANClient:
    """
    Connects to a LANHost, receives world state, sends P2 inputs.
    """

    def __init__(self, host_ip: str, port: int = DEFAULT_PORT,
                 player_name: str = "P2"):
        self.host_ip     = host_ip
        self.port        = port
        self.name        = player_name
        self._sock       = None
        self._host_addr  = (host_ip, port)
        self._world_buf  = None   # last received world state
        self._lock       = threading.Lock()
        self._running    = False
        self._recv_thread = None
        self.connected   = False
        self.level_stem  = None
        self.launch_level = None   # set when host broadcasts "launch" packet

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def connect(self, timeout: float = 15.0) -> bool:
        """Send hello, wait for welcome. Returns True on success."""
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.settimeout(_SOCKET_TIMEOUT)
        self._running = True
        self._recv_thread = threading.Thread(target=self._recv_loop, daemon=True)
        self._recv_thread.start()

        self._send({"t": "hello", "name": self.name})
        deadline = time.time() + timeout
        while time.time() < deadline:
            with self._lock:
                if self.level_stem is not None:
                    self._send({"t": "ready"})
                    self.connected = True
                    return True
            time.sleep(0.05)
        return False

    def stop(self):
        self._running = False
        if self._sock:
            try: self._sock.close()
            except Exception: pass

    # ── Per-frame ─────────────────────────────────────────────────────────────

    def send_p2_input(self, tick: int, frame: dict, actions: dict):
        """Send P2 input to host."""
        pkt = {
            "t": "p2",
            "tick": tick,
            "dx": frame.get("dx", 0),
            "dy": frame.get("dy", 0),
            "sprint": bool(frame.get("sprint", False)),
            "aim_mode": bool(frame.get("aim_mode", False)),
            "aim_angle": round(float(frame.get("aim_angle", 0.0)), 3),
            "actions": actions,
        }
        self._send(pkt)

    def poll_world_state(self) -> dict | None:
        """Return the last received host world state, or None."""
        with self._lock:
            return self._world_buf

    # ── Internal ──────────────────────────────────────────────────────────────

    def _send(self, obj: dict):
        if self._sock:
            try:
                self._sock.sendto(_encode(obj), self._host_addr)
            except Exception:
                pass

    def _recv_loop(self):
        while self._running:
            try:
                data, _ = self._sock.recvfrom(8192)
            except socket.timeout:
                continue
            except Exception:
                break
            pkt = _decode(data)
            if pkt is None:
                continue
            t = pkt.get("t")
            if t == "welcome":
                with self._lock:
                    self.level_stem = pkt.get("level", "")
            elif t == "launch":
                with self._lock:
                    self.launch_level = pkt.get("level", "")
                    self.connected = True
            elif t == "start":
                with self._lock:
                    self.connected = True
            elif t == "state":
                with self._lock:
                    self._world_buf = pkt
