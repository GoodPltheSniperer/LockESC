"""
LockESC MULTIPLAYER
===================
Two-player cooperative stealth.  Loaded by lockesc_mp.py at the project root.

Submodules:
  input_local   – Same-PC split controls (P2 uses arrow/numpad/RShift)
  input_lan     – LAN networking (UDP, host/join)
  mp_game       – MPGame subclass of Game; owns second Player + split rendering
  lobby         – Mode-select + LAN lobby screen shown before the game starts
"""

from .mp_game import MPGame
from .lobby   import MPLobby

__all__ = ["MPGame", "MPLobby"]
