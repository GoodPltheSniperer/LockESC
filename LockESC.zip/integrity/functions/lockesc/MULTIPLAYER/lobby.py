"""
MULTIPLAYER/lobby.py
=====================
MPLobby  – the multiplayer title screen.  Launched directly when the player
            picks MULTIPLAYER on the ModeSelectScreen; replaces the normal
            TitleScreen entirely for the multiplayer path.
LANDiscovery   – UDP broadcast advertising / scanning for hosts on the LAN

Flow (new):
  1. Mode select – picking a config (Same PC / LAN Host / LAN Join) sets a
     *pending* mode and highlights it with a checkmark.  No immediate level jump.
  2. Play section – Story / Custom / (Back) buttons appear *after* a mode is
     confirmed.  Pressing Story or Custom now uses the pending mode.
  3. LAN HOST: start beacon, pick level → wait for peer → launch
     LAN JOIN: server browser → waiting screen (host picks level) → launch
     SAME PC:  pick level → launch immediately

All symbols are drawn procedurally via helpers in core.py — no Unicode icons.
"""

import os
import sys
import glob
import socket
import threading
import time
import json
import math
import pygame

from integrity.functions.lockesc.core import (
    FPS, TILE, C_TITLE_BG,
    _draw_arrow, _draw_hexagon, _draw_check, _draw_back_arrow,
)
from .mp_game import MPGame, MODE_SAME_PC, MODE_LAN_HOST, MODE_LAN_JOIN

# ── Colours (matching TitleScreen palette) ────────────────────────────────────
_CYAN   = (0, 200, 255)
_TEAL   = (0, 220, 180)
_TEAL2  = (0, 140, 120)
_WHITE  = (255, 255, 255)
_GREY   = (120, 150, 200)
_DIM    = (50, 80, 130)
_DIM2   = (30, 50, 90)
_WARN   = (220, 80, 60)
_GREEN  = (60, 200, 120)
_BG_SEL = (0, 60, 120, 220)
_BG_NRM = (10, 20, 50, 160)

# Row geometry — identical to TitleScreen
_IH  = 52   # item height
_IP  =  8   # inter-item padding
_MW  = 360  # menu width

# LAN discovery
_DISC_PORT    = 7891          # separate from game port 7890
_DISC_MAGIC   = b"LOCKESC_HOST_ANNOUNCE"
_DISC_INTERVAL = 1.0          # host broadcasts every second
_DISC_TIMEOUT  = 4.0          # servers expire after this

DUO_STORY_PATH = os.path.join(os.path.expanduser("~"), "mplevels",
                               "duostory", "chapter1.lep")

def _mplevels_dir():
    return os.path.join(os.path.expanduser("~"), "mplevels")

def _list_levels():
    d = _mplevels_dir()
    if not os.path.isdir(d):
        return []
    paths = []
    for ext in ("*.ler", "*.lep"):
        paths.extend(sorted(glob.glob(os.path.join(d, ext))))
    for item in sorted(os.listdir(d)):
        full = os.path.join(d, item)
        if os.path.isdir(full) and item.endswith(".ler"):
            paths.append(full)
    # exclude duostory folder entries (shown as a dedicated menu item)
    return [p for p in dict.fromkeys(paths)
            if "duostory" not in p.replace("\\", "/")]

def _local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80)); ip = s.getsockname()[0]; s.close(); return ip
    except Exception:
        return "127.0.0.1"


# ═════════════════════════════════════════════════════════════════════════════
# LAN discovery helpers
# ═════════════════════════════════════════════════════════════════════════════

class _HostBeacon:
    """Broadcasts host presence on the LAN until stopped."""

    def __init__(self, game_port: int, host_name: str):
        self._port      = game_port
        self._name      = host_name
        self._running   = False
        self._thread    = None

    def start(self):
        self._running = True
        self._thread  = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def _loop(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        payload = json.dumps({
            "magic": _DISC_MAGIC.decode(),
            "port":  self._port,
            "name":  self._name,
            "ip":    _local_ip(),
        }).encode()
        while self._running:
            try:
                sock.sendto(payload, ("<broadcast>", _DISC_PORT))
            except Exception:
                pass
            time.sleep(_DISC_INTERVAL)
        sock.close()


class _ServerScanner:
    """Listens for host beacons and maintains a fresh list."""

    def __init__(self):
        self._servers  = {}   # ip -> {ip, port, name, last_seen}
        self._lock     = threading.Lock()
        self._running  = False
        self._thread   = None

    def start(self):
        self._running = True
        self._thread  = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def servers(self):
        now = time.time()
        with self._lock:
            return [v for v in self._servers.values()
                    if now - v["last_seen"] < _DISC_TIMEOUT]

    def _loop(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind(("", _DISC_PORT))
        except Exception:
            return
        sock.settimeout(0.5)
        while self._running:
            try:
                data, addr = sock.recvfrom(512)
                pkt = json.loads(data.decode())
                if pkt.get("magic") == _DISC_MAGIC.decode():
                    ip = pkt.get("ip") or addr[0]
                    with self._lock:
                        self._servers[ip] = {
                            "ip":        ip,
                            "port":      pkt.get("port", 7890),
                            "name":      pkt.get("name", ip),
                            "last_seen": time.time(),
                        }
            except socket.timeout:
                pass
            except Exception:
                pass
        sock.close()


# ═════════════════════════════════════════════════════════════════════════════
# Shared row drawing  (matches TitleScreen._draw exactly)
# ═════════════════════════════════════════════════════════════════════════════

def _row(scr, ix, iy, w, label, hint, sel, teal=False, active=False,
         font_md=None, font_sm=None):
    """Draw one menu row. Returns the pygame.Rect."""
    accent = _TEAL if teal else _CYAN

    bg = pygame.Surface((w, _IH), pygame.SRCALPHA)
    if sel:
        bg.fill((0, 60, 55, 220) if teal else _BG_SEL)
    else:
        bg.fill(_BG_NRM)
    scr.blit(bg, (ix, iy))

    rect = pygame.Rect(ix, iy, w, _IH)
    pygame.draw.rect(scr, accent if sel else _DIM, rect, 2 if sel else 1)

    if sel:
        pygame.draw.rect(scr, accent, (ix, iy, 4, _IH))
        _draw_arrow(scr, ix + 16, iy + _IH // 2, 12, accent)

    if active and not sel:
        # subtle left tick for currently active (not just nav-focused)
        _draw_check(scr, ix + 16, iy + _IH // 2, 10, accent)

    lbl_col = (200, 255, 245) if (sel and teal) else (_WHITE if sel else _GREY)
    lbl = font_md.render(label, True, lbl_col)
    scr.blit(lbl, (ix + 34, iy + _IH // 2 - lbl.get_height() // 2))

    if hint and font_sm:
        hc = _TEAL2 if (sel and teal) else (_DIM if not sel else (80, 160, 220))
        hs = font_sm.render(hint, True, hc)
        scr.blit(hs, (ix + w - hs.get_width() - 10, iy + _IH - hs.get_height() - 4))

    return rect


def _bg(scr, W, H, t, tile):
    """Draw the shared title-screen background (grid + glow)."""
    scr.fill(C_TITLE_BG)
    gs = pygame.Surface((W, H), pygame.SRCALPHA)
    off = (t * 0.4) % tile
    for x in range(-tile, W + tile, tile):
        pygame.draw.line(gs, (20, 40, 80, 60), (int(x + off), 0), (int(x + off), H))
    for y in range(-tile, H + tile, tile):
        pygame.draw.line(gs, (20, 40, 80, 60), (0, int(y + off)), (W, int(y + off)))
    scr.blit(gs, (0, 0))
    for radius in range(180, 60, -30):
        alpha = int(18 * (1 - radius / 200))
        glow = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
        pygame.draw.circle(glow, (0, 160, 255, alpha), (radius, radius), radius)
        scr.blit(glow, (W // 2 - radius, H // 2 - 180 - radius))


def _title_letters(scr, W, H, t, font_xl, font_md):
    """Draw animated LOCKESC title — identical to TitleScreen."""
    title_y  = H // 2 - 180
    letters  = "LOCKESC"
    letter_w = 74
    start_x  = W // 2 - letter_w * len(letters) // 2
    colours  = [(0,200,255),(0,180,240),(0,160,220),(80,220,255),
                (0,200,255),(255,60,80),(255,80,100)]
    for i, (ch, col) in enumerate(zip(letters, colours)):
        wave = math.sin(t * 0.08 + i * 0.6) * 8
        cx   = start_x + i * letter_w + letter_w // 2
        cy   = int(title_y + wave)
        sh   = font_xl.render(ch, True, (0, 0, 0))
        scr.blit(sh, sh.get_rect(center=(cx + 3, cy + 3)))
        s = font_xl.render(ch, True, col)
        scr.blit(s, s.get_rect(center=(cx, cy)))
    sub_a = int(180 + 75 * math.sin(t * 0.05))
    sub_s = font_md.render("MULTIPLAYER CONFIG", True, (sub_a, sub_a, sub_a))
    scr.blit(sub_s, sub_s.get_rect(center=(W // 2, H // 2 - 100)))


# ═════════════════════════════════════════════════════════════════════════════
# MPLobby  —  two-phase: pick config → then pick what to play
# ═════════════════════════════════════════════════════════════════════════════

class MPLobby:
    """
    Entry point: MPLobby(screen, clock).run()

    Returns config dict on launch or None on back.

    Phase 1 – Config select:
      Choose SAME PC / LAN HOST / LAN JOIN.  Selecting one highlights it with a
      checkmark but does NOT immediately open a level picker.  A confirmation
      row (CONFIRM CONFIG) becomes active once a mode is highlighted.

    Phase 2 – Play select (host only):
      After confirming a mode the host sees: Story / Custom Level / Back.
      Pressing Story or Custom actually starts the session.

    LAN JOIN path:
      After confirming JOIN mode the screen shows a live server browser.
      Selecting a server enters a waiting room until the host launches.

    LAN HOST path:
      After picking story/level, the screen shows "Waiting for Player 2…"
      with the host's IP. The game starts once a peer connects.
    """

    _MODES = [
        (MODE_SAME_PC,  "SAME PC",   "two players, one keyboard"),
        (MODE_LAN_HOST, "LAN HOST",  "host a game on your network"),
        (MODE_LAN_JOIN, "LAN JOIN",  "browse servers on your network"),
    ]

    def __init__(self, screen, clock):
        self.screen = screen
        self.clock  = clock
        self.W, self.H = screen.get_size()
        self.font_xl = pygame.font.SysFont("consolas", 72, bold=True)
        self.font_lg = pygame.font.SysFont("consolas", 36, bold=True)
        self.font_md = pygame.font.SysFont("consolas", 20, bold=True)
        self.font_sm = pygame.font.SysFont("consolas", 14)
        self.scanlines = pygame.Surface((self.W, self.H), pygame.SRCALPHA)
        for y in range(0, self.H, 2):
            pygame.draw.line(self.scanlines, (0, 0, 0, 40), (0, y), (self.W, y))

        self._pending_mode = None   # confirmed mode (set in phase 1)
        self._levels    = _list_levels()
        self._level_idx = 0
        self._sel       = 0
        self._rects     = {}
        self._nav       = []
        self._tick      = 0
        self._error     = ""

    # ── Top-level flow ────────────────────────────────────────────────────────

    def run(self):
        """Phase 1: config select.  Phase 2: play select / join flow."""
        beacon = None
        try:
            while True:
                confirmed = self._run_config_select()
                if confirmed is None:
                    return None

                self._pending_mode = confirmed

                # Auto-start LAN beacon the moment LAN HOST is confirmed so
                # potential members can see this host in their server browser
                # immediately, before the host even picks a level.
                if confirmed == MODE_LAN_HOST:
                    if beacon is not None:
                        beacon.stop()
                    import socket as _sock_mod
                    try:
                        _hn = _sock_mod.gethostname()
                    except Exception:
                        _hn = "LockESC Host"
                    beacon = _HostBeacon(game_port=7890, host_name=_hn)
                    beacon.start()
                else:
                    if beacon is not None:
                        beacon.stop()
                        beacon = None

                if confirmed == MODE_LAN_JOIN:
                    cfg = self._run_join_flow()
                    if cfg is None:
                        self._pending_mode = None
                        continue
                    return cfg
                else:
                    cfg = self._run_play_select(confirmed)
                    if cfg is None:
                        self._pending_mode = None
                        if beacon is not None:
                            beacon.stop()
                            beacon = None
                        continue
                    return cfg
        finally:
            # Always clean up beacon (game takes over LAN from here)
            if beacon is not None:
                beacon.stop()

    # ── Phase 1: Config select ────────────────────────────────────────────────

    def _run_config_select(self):
        """
        Show the three config rows.  Clicking/entering a row *highlights* it
        (checkmark) without immediately advancing.  A "CONFIRM" row appears
        once a mode is highlighted.  Returns the confirmed mode or None (back).
        """
        self._sel = 0
        highlighted = None   # mode that's been clicked once (pending confirm)

        while True:
            self._tick += 1
            self.clock.tick(FPS)
            mx, my = pygame.mouse.get_pos()

            # Hover
            for i, key in enumerate(self._nav):
                r = self._rects.get(key)
                if r and r.collidepoint(mx, my):
                    self._sel = i

            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:   pygame.quit(); sys.exit()
                if ev.type == pygame.KEYDOWN:
                    if ev.key == pygame.K_ESCAPE:
                        return None
                    if ev.key in (pygame.K_UP, pygame.K_w):
                        self._sel = (self._sel - 1) % max(1, len(self._nav))
                    if ev.key in (pygame.K_DOWN, pygame.K_s):
                        self._sel = (self._sel + 1) % max(1, len(self._nav))
                    if ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        result = self._activate_config(highlighted)
                        if result == "back":
                            return None
                        if result == "confirm":
                            return highlighted
                        if result is not None:   # a mode was highlighted
                            highlighted = result
                if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                    for i, key in enumerate(self._nav):
                        rect = self._rects.get(key)
                        if rect and rect.collidepoint(ev.pos):
                            self._sel = i
                            result = self._activate_config(highlighted)
                            if result == "back":
                                return None
                            if result == "confirm":
                                return highlighted
                            if result is not None:
                                highlighted = result

            self._draw_config_select(highlighted)
            pygame.display.flip()

    def _activate_config(self, highlighted):
        """
        Returns:
          a mode constant  – user clicked a mode row (highlight it)
          "confirm"        – user clicked the confirm row
          "back"           – user clicked back
          None             – nothing actionable
        """
        if self._sel >= len(self._nav):
            return None
        key = self._nav[self._sel]
        if key == "back":
            return "back"
        if key == "confirm":
            return "confirm"
        if isinstance(key, tuple) and key[0] == "mode":
            return key[1]
        return None

    def _draw_config_select(self, highlighted):
        scr = self.screen
        W, H, t = self.W, self.H, self._tick
        _bg(scr, W, H, t, TILE)
        _title_letters(scr, W, H, t, self.font_xl, self.font_md)

        menu_top = H // 2 - 40
        self._nav   = []
        self._rects = {}
        row = 0

        # Sub-heading
        sub = self.font_sm.render("choose a multiplayer config", True, _DIM)
        scr.blit(sub, sub.get_rect(center=(W // 2, H // 2 - 95)))

        def add(key, label, hint, teal=False, active=False):
            nonlocal row
            iy  = menu_top + row * (_IH + _IP)
            ix  = W // 2 - _MW // 2
            sel = (row == self._sel)
            r   = _row(scr, ix, iy, _MW, label, hint, sel, teal=teal,
                       active=active, font_md=self.font_md, font_sm=self.font_sm)
            self._nav.append(key)
            self._rects[key] = r
            row += 1

        for mode, label, hint in self._MODES:
            teal   = (mode != MODE_SAME_PC)
            active = (mode == highlighted)
            add(("mode", mode), label, hint, teal=teal, active=active)

        # Confirm row — only shown when a mode is highlighted
        if highlighted is not None:
            row += 0  # no gap; confirm sits right below modes
            confirm_iy = menu_top + row * (_IH + _IP)
            confirm_ix = W // 2 - _MW // 2
            confirm_sel = (row == self._sel)
            confirm_r = pygame.Rect(confirm_ix, confirm_iy, _MW, _IH)
            bg = pygame.Surface((_MW, _IH), pygame.SRCALPHA)
            bg.fill((0, 80, 60, 220) if confirm_sel else (0, 30, 25, 160))
            scr.blit(bg, (confirm_ix, confirm_iy))
            pygame.draw.rect(scr, _TEAL if confirm_sel else _TEAL2, confirm_r,
                             2 if confirm_sel else 1)
            if confirm_sel:
                pygame.draw.rect(scr, _TEAL, (confirm_ix, confirm_iy, 4, _IH))
                _draw_arrow(scr, confirm_ix + 16, confirm_iy + _IH // 2, 12, _TEAL)
            mode_name = {MODE_SAME_PC: "SAME PC", MODE_LAN_HOST: "LAN HOST",
                         MODE_LAN_JOIN: "LAN JOIN"}.get(highlighted, highlighted.upper())
            cl  = (200, 255, 245) if confirm_sel else _TEAL
            cls = self.font_md.render(f"CONFIRM  [{mode_name}]", True, cl)
            scr.blit(cls, (confirm_ix + 34, confirm_iy + _IH // 2 - cls.get_height() // 2))
            self._nav.append("confirm")
            self._rects["confirm"] = confirm_r
            row += 1

        # Divider + back
        div_y = menu_top + row * (_IH + _IP) - 2
        pygame.draw.line(scr, _DIM2, (W//2 - _MW//2, div_y), (W//2 + _MW//2, div_y), 1)

        back_iy = menu_top + row * (_IH + _IP)
        back_ix = W // 2 - _MW // 2
        back_sel = (row == self._sel)
        back_r = pygame.Rect(back_ix, back_iy, _MW, _IH)
        bg = pygame.Surface((_MW, _IH), pygame.SRCALPHA)
        bg.fill(_BG_SEL if back_sel else _BG_NRM)
        scr.blit(bg, (back_ix, back_iy))
        pygame.draw.rect(scr, _CYAN if back_sel else _DIM, back_r, 2 if back_sel else 1)
        if back_sel:
            pygame.draw.rect(scr, _CYAN, (back_ix, back_iy, 4, _IH))
            _draw_back_arrow(scr, back_ix + 16, back_iy + _IH // 2, 12, _CYAN)
        bl = self.font_md.render("BACK", True, _WHITE if back_sel else _GREY)
        scr.blit(bl, (back_ix + 34, back_iy + _IH // 2 - bl.get_height() // 2))
        self._nav.append("back")
        self._rects["back"] = back_r

        hint_text = "click a config to select it    CONFIRM to proceed    ESC back"
        nav_s = self.font_sm.render(hint_text, True, _DIM2)
        scr.blit(nav_s, nav_s.get_rect(center=(W // 2, back_iy + _IH + 20)))
        scr.blit(self.scanlines, (0, 0))

    # ── Phase 2 (host): pick story or custom level ────────────────────────────

    def _run_play_select(self, mode):
        """
        After confirming SAME_PC or LAN_HOST, show exactly three rows:
          • STORY   → loads ~/mplevels/duostory/chapter1.lep
          • CUSTOM  → opens the LevelBrowser rooted at ~/mplevels/
          • BACK
        Returns config dict or None (go back to config select).
        """
        self._sel = 0
        has_duo = os.path.exists(DUO_STORY_PATH)

        while True:
            self._tick += 1
            self.clock.tick(FPS)
            mx, my = pygame.mouse.get_pos()

            # Rebuild nav each frame (done in _draw) before hover check
            self._draw_play_select(mode, has_duo)
            pygame.display.flip()

            # Hover: update sel based on current mouse pos after draw populates _rects
            for i, key in enumerate(self._nav):
                r = self._rects.get(key)
                if r and r.collidepoint(mx, my):
                    self._sel = i
                    break

            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:   pygame.quit(); sys.exit()
                if ev.type == pygame.KEYDOWN:
                    if ev.key == pygame.K_ESCAPE:
                        return None
                    if ev.key in (pygame.K_UP, pygame.K_w):
                        self._sel = (self._sel - 1) % max(1, len(self._nav))
                    if ev.key in (pygame.K_DOWN, pygame.K_s):
                        self._sel = (self._sel + 1) % max(1, len(self._nav))
                    if ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        r = self._activate_play(mode, has_duo)
                        if r == "back": return None
                        if isinstance(r, dict): return r
                if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                    # On click: update sel to clicked row, then activate
                    for i, key in enumerate(self._nav):
                        rect = self._rects.get(key)
                        if rect and rect.collidepoint(ev.pos):
                            self._sel = i
                            r = self._activate_play(mode, has_duo)
                            if r == "back": return None
                            if isinstance(r, dict): return r
                            break

    def _activate_play(self, mode, has_duo):
        if self._sel >= len(self._nav):
            return None
        key = self._nav[self._sel]
        if key == "back":
            return "back"
        if key == "story":
            if not has_duo:
                return None   # greyed — no action
            # Show chapter select for the duo story directory
            from integrity.functions.lockesc.core import ChapterSelectScreen
            duo_story_dir = os.path.join(os.path.expanduser("~"), "mplevels", "duostory")
            sel = ChapterSelectScreen(
                self.screen, self.clock, duo_story_dir,
                title="DUO STORY").run()
            if sel is None:
                return None   # player ESC'd — stay on play select
            return {"mode": mode, "level_path": sel,
                    "lan_port": 7890, "host_ip": ""}
        if key == "custom":
            # Open the LevelBrowser rooted at ~/mplevels/
            # Exclude "duostory" — it has its own dedicated STORY button
            from integrity.functions.lockesc.core import LevelBrowser
            browser = LevelBrowser(self.screen, self.clock,
                                   root_dir=_mplevels_dir(),
                                   exclude_names={"duostory"})
            path = browser.run()
            if path:
                return {"mode": mode, "level_path": path,
                        "lan_port": 7890, "host_ip": ""}
            return None   # user cancelled browser; stay in play select
        return None

    def _draw_play_select(self, mode, has_duo):
        scr = self.screen
        W, H, t = self.W, self.H, self._tick
        _bg(scr, W, H, t, TILE)
        _title_letters(scr, W, H, t, self.font_xl, self.font_md)

        menu_top = H // 2 - 20
        self._nav   = []
        self._rects = {}
        row = 0

        mode_label = {MODE_SAME_PC: "SAME PC",
                      MODE_LAN_HOST: "LAN HOST"}.get(mode, mode.upper())
        sub = self.font_sm.render(
            f"config: {mode_label}   choose what to play",
            True, _DIM)
        scr.blit(sub, sub.get_rect(center=(W // 2, H // 2 - 95)))

        def add(key, label, hint="", teal=False, active=False):
            nonlocal row
            iy  = menu_top + row * (_IH + _IP)
            ix  = W // 2 - _MW // 2
            sel = (row == self._sel)
            r   = _row(scr, ix, iy, _MW, label, hint, sel, teal=teal,
                       active=active, font_md=self.font_md, font_sm=self.font_sm)
            self._nav.append(key)
            self._rects[key] = r
            row += 1

        # ── STORY row ──────────────────────────────────────────────────────────
        if has_duo:
            add("story", "STORY",
                "duo story  \u00b7  ~/mplevels/duostory/chapter1.lep", teal=True)
        else:
            # Greyed-out non-interactive story row
            iy  = menu_top + row * (_IH + _IP)
            ix  = W // 2 - _MW // 2
            bg  = pygame.Surface((_MW, _IH), pygame.SRCALPHA)
            bg.fill((10, 10, 20, 120))
            scr.blit(bg, (ix, iy))
            pygame.draw.rect(scr, (30, 40, 60), pygame.Rect(ix, iy, _MW, _IH), 1)
            ls = self.font_md.render("STORY", True, (40, 55, 80))
            scr.blit(ls, (ix + 34, iy + _IH // 2 - ls.get_height() // 2))
            ms = self.font_sm.render(
                "no duostory \u00b7 add ~/mplevels/duostory/chapter1.lep",
                True, (35, 50, 70))
            scr.blit(ms, (ix + _MW - ms.get_width() - 10,
                          iy + _IH - ms.get_height() - 4))
            # Still register in nav (click does nothing — _activate_play guards it)
            self._nav.append("story")
            self._rects["story"] = pygame.Rect(ix, iy, _MW, _IH)
            row += 1

        # ── CUSTOM row ─────────────────────────────────────────────────────────
        add("custom", "CUSTOM",
            "browse levels in ~/mplevels/", teal=False)

        div_y = menu_top + row * (_IH + _IP) - 2
        pygame.draw.line(scr, _DIM2,
                         (W//2 - _MW//2, div_y), (W//2 + _MW//2, div_y), 1)

        # ── BACK row ───────────────────────────────────────────────────────────
        back_iy = menu_top + row * (_IH + _IP)
        back_ix = W // 2 - _MW // 2
        back_sel = (row == self._sel)
        back_r = pygame.Rect(back_ix, back_iy, _MW, _IH)
        bg = pygame.Surface((_MW, _IH), pygame.SRCALPHA)
        bg.fill(_BG_SEL if back_sel else _BG_NRM)
        scr.blit(bg, (back_ix, back_iy))
        pygame.draw.rect(scr, _CYAN if back_sel else _DIM, back_r, 2 if back_sel else 1)
        if back_sel:
            pygame.draw.rect(scr, _CYAN, (back_ix, back_iy, 4, _IH))
            _draw_back_arrow(scr, back_ix + 16, back_iy + _IH // 2, 12, _CYAN)
        bl = self.font_md.render("BACK", True, _WHITE if back_sel else _GREY)
        scr.blit(bl, (back_ix + 34, back_iy + _IH // 2 - bl.get_height() // 2))
        self._nav.append("back")
        self._rects["back"] = back_r

        if mode == MODE_LAN_HOST:
            ip_s = self.font_sm.render(
                f"your IP:  {_local_ip()}  (port 7890)", True, _GREEN)
            scr.blit(ip_s, ip_s.get_rect(center=(W // 2, back_iy + _IH + 20)))
            note_s = self.font_sm.render(
                "members join after you choose a level", True, _DIM)
            scr.blit(note_s, note_s.get_rect(center=(W // 2, back_iy + _IH + 40)))

        nav_s = self.font_sm.render(
            "navigate  arrows / mouse    select  ENTER    back  ESC",
            True, _DIM2)
        scr.blit(nav_s, nav_s.get_rect(center=(W // 2, back_iy + _IH + 62)))
        scr.blit(self.scanlines, (0, 0))

    # ── Join: server list then waiting room ───────────────────────────────────

    def _run_join_flow(self):
        """Server browser → waiting room → returns config or None (back)."""
        scanner = _ServerScanner()
        scanner.start()
        try:
            result = self._run_server_list(scanner)
        finally:
            scanner.stop()

        if result is None:
            return None

        # Connect the LAN client NOW so we receive the host's "launch" packet.
        from .input_lan import LANClient
        client = LANClient(result["ip"], port=result["port"])
        connected = client.connect(timeout=10.0)
        if not connected:
            # Show brief error and go back to server list
            self._draw_error_screen("Could not connect to host.")
            return None

        # Waiting room — blocks until host sends "launch" or user presses ESC
        launched_level = self._run_member_waiting_room(result, client)
        client.stop()

        if launched_level is None:
            return None   # user cancelled

        return {"mode": MODE_LAN_JOIN,
                "level_path": launched_level,
                "lan_port": result["port"],
                "host_ip":  result["ip"]}

    def _draw_error_screen(self, msg):
        self.screen.fill((10, 8, 18))
        s = self.font_md.render(msg, True, _WARN)
        self.screen.blit(s, s.get_rect(center=(self.W // 2, self.H // 2)))
        pygame.display.flip()
        pygame.time.wait(1800)

    def _run_member_waiting_room(self, server, client):
        """
        Shown to LAN JOIN members after connecting to a host.
        Polls the LANClient for a "launch" packet from the host.
        Returns the level path string when host launches, or None if ESC.
        """
        tick  = 0
        clock = self.clock
        font  = self.font_md
        sm    = self.font_sm
        scr   = self.screen
        W, H  = self.W, self.H

        while True:
            dt = clock.tick(FPS) / 1000.0
            tick += 1

            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    pygame.quit(); sys.exit()
                if ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE:
                    return None   # member cancelled

            # Check if host has launched — auto-follow immediately
            if client.launch_level is not None:
                # Resolve the level path from stem under ~/mplevels/
                stem = client.launch_level
                lvl_path = self._resolve_level_stem(stem)
                return lvl_path

            _bg(scr, W, H, tick, TILE)
            _title_letters(scr, W, H, tick, self.font_xl, self.font_md)

            pulse = int(160 + 80 * math.sin(tick * 0.07))
            host_s  = font.render(
                f"Connected to:  {server['name']}", True,
                (pulse, pulse, min(255, pulse + 30)))
            scr.blit(host_s, host_s.get_rect(center=(W // 2, H // 2 - 20)))

            ip_s = sm.render(
                f"{server['ip']}:{server['port']}", True, _TEAL2)
            scr.blit(ip_s, ip_s.get_rect(center=(W // 2, H // 2 + 16)))

            dots = "." * (1 + (tick // 18) % 4)
            wait_s = sm.render(
                f"waiting for host to start the game{dots}", True, _DIM)
            scr.blit(wait_s, wait_s.get_rect(center=(W // 2, H // 2 + 52)))

            esc_s = sm.render("ESC  cancel", True, _DIM2)
            scr.blit(esc_s, esc_s.get_rect(center=(W // 2, H // 2 + 88)))

            scr.blit(self.scanlines, (0, 0))
            pygame.display.flip()

    def _resolve_level_stem(self, stem):
        """
        Given a level stem (e.g. 'c1-l1_trusttest' or 'chapter1'),
        find the matching path under ~/mplevels/.
        """
        base = _mplevels_dir()
        # Search all .ler and .lep files/folders recursively under mplevels
        for root, dirs, files in os.walk(base):
            for name in files + dirs:
                no_ext = os.path.splitext(name)[0]
                if no_ext == stem or name == stem:
                    return os.path.join(root, name)
        # Fallback: return duostory path if stem looks like chapter
        if "chapter" in stem.lower():
            return DUO_STORY_PATH
        return ""

    def _run_server_list(self, scanner):
        """Show live server list. Returns server dict or None (back)."""
        self._sel = 0
        while True:
            self._tick += 1
            self.clock.tick(FPS)
            servers = scanner.servers()
            mx, my  = pygame.mouse.get_pos()

            # Hover
            for i, key in enumerate(self._nav):
                r = self._rects.get(key)
                if r and r.collidepoint(mx, my):
                    self._sel = i

            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:   pygame.quit(); sys.exit()
                if ev.type == pygame.KEYDOWN:
                    if ev.key == pygame.K_ESCAPE: return None
                    if ev.key in (pygame.K_UP, pygame.K_w):
                        self._sel = (self._sel - 1) % max(1, len(self._nav))
                    if ev.key in (pygame.K_DOWN, pygame.K_s):
                        self._sel = (self._sel + 1) % max(1, len(self._nav))
                    if ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        r = self._activate_server(servers)
                        if r == "back": return None
                        if isinstance(r, dict): return r
                if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                    for i, key in enumerate(self._nav):
                        rect = self._rects.get(key)
                        if rect and rect.collidepoint(ev.pos):
                            self._sel = i
                            r = self._activate_server(servers)
                            if r == "back": return None
                            if isinstance(r, dict): return r

            self._draw_server_list(servers)
            pygame.display.flip()

    def _activate_server(self, servers):
        if self._sel >= len(self._nav): return None
        key = self._nav[self._sel]
        if key == "back": return "back"
        if isinstance(key, tuple) and key[0] == "server":
            idx = key[1]
            if idx < len(servers):
                return servers[idx]
        return None

    def _draw_server_list(self, servers):
        scr = self.screen
        W, H, t = self.W, self.H, self._tick
        _bg(scr, W, H, t, TILE)
        _title_letters(scr, W, H, t, self.font_xl, self.font_md)

        # Pulse dot to show we're scanning
        pulse_a = int(120 + 80 * math.sin(t * 0.15))
        dot_s   = self.font_sm.render("scanning LAN for hosts...", True,
                                       (pulse_a, min(255, pulse_a + 40), min(255, pulse_a + 60)))
        scr.blit(dot_s, dot_s.get_rect(center=(W // 2, H // 2 - 92)))

        sub = self.font_sm.render(
            "select a host to join — then wait for them to start", True, _DIM)
        scr.blit(sub, sub.get_rect(center=(W // 2, H // 2 - 74)))

        menu_top = H // 2 - 10
        self._nav   = []
        self._rects = {}
        row = 0

        def add(key, label, hint="", teal=False):
            nonlocal row
            iy  = menu_top + row * (_IH + _IP)
            ix  = W // 2 - _MW // 2
            sel = (row == self._sel)
            r   = _row(scr, ix, iy, _MW, label, hint, sel, teal=teal,
                       font_md=self.font_md, font_sm=self.font_sm)
            self._nav.append(key)
            self._rects[key] = r
            row += 1

        if not servers:
            ns = self.font_sm.render("no hosts found  —  ask host to open LAN HOST",
                                      True, _DIM)
            scr.blit(ns, ns.get_rect(center=(W // 2,
                     menu_top + row * (_IH + _IP) + _IH // 2)))
            row += 1
        else:
            for si, srv in enumerate(servers[:8]):
                add(("server", si),
                    srv["name"],
                    f"{srv['ip']}:{srv['port']}",
                    teal=True)

        div_y = menu_top + row * (_IH + _IP) - 2
        pygame.draw.line(scr, _DIM2, (W//2 - _MW//2, div_y), (W//2 + _MW//2, div_y), 1)

        # Back
        back_iy = menu_top + row * (_IH + _IP)
        back_ix = W // 2 - _MW // 2
        back_sel = (row == self._sel)
        back_r = pygame.Rect(back_ix, back_iy, _MW, _IH)
        bg = pygame.Surface((_MW, _IH), pygame.SRCALPHA)
        bg.fill(_BG_SEL if back_sel else _BG_NRM)
        scr.blit(bg, (back_ix, back_iy))
        pygame.draw.rect(scr, _CYAN if back_sel else _DIM, back_r, 2 if back_sel else 1)
        if back_sel:
            pygame.draw.rect(scr, _CYAN, (back_ix, back_iy, 4, _IH))
            _draw_back_arrow(scr, back_ix + 16, back_iy + _IH // 2, 12, _CYAN)
        bl = self.font_md.render("BACK", True, _WHITE if back_sel else _GREY)
        scr.blit(bl, (back_ix + 34, back_iy + _IH // 2 - bl.get_height() // 2))
        self._nav.append("back")
        self._rects["back"] = back_r

        nav_s = self.font_sm.render("select a host to join    ESC  back",
                                     True, _DIM2)
        scr.blit(nav_s, nav_s.get_rect(center=(W // 2, back_iy + _IH + 20)))
        scr.blit(self.scanlines, (0, 0))
