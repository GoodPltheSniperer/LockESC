"""
input_local.py  –  Same-PC Player-2 Controls
=============================================
Player 2 uses the right side of the keyboard so both players share one machine.

  Movement      Arrow keys (UP / DOWN / LEFT / RIGHT)
  Sprint        Right Shift  (hold while moving)
  Hide          Numpad 0     (toggle)
  Use/Door      Numpad Enter (or Numpad 5 as alternative)
  Aim mode      Numpad *     (toggle; aim direction steered by Numpad /  = look-left
                              and all other numpad directional keys as 8-way aim wheel)
  Fire          Numpad +     (fires while in aim mode)
  Cycle gun     Numpad .     (same role as TAB on P1)
  Cycle gear    Numpad -
  Use gear      Numpad 5     (when NOT used as door-alt, i.e. gear is priority if aim off)
  Drop item     Numpad 3
  Drag toggle   Numpad 1
  Other slot 1  Numpad 7
  Other slot 2  Numpad 8
  Other slot 3  Numpad 9
  Other slot 4  Numpad 6

Aim steering (numpad directional wheel while aim mode is ON):
  KP_8 = up        KP_9 = up-right    KP_6 = right   KP_3 = down-right
  KP_2 = down      KP_1 = down-left   KP_4 = left    KP_7 = up-left
  KP_DIVIDE (/) and KP_MULTIPLY (*) are used to steer aim angle continuously
  (/ = aim left, * = aim right) when no directional numpad key is pressed.
  This also works as a soft mouse replacement — you can hold / or * to sweep aim.
"""

import math
import pygame

# ── Key bindings ──────────────────────────────────────────────────────────────

# Movement
K2_UP    = pygame.K_UP
K2_DOWN  = pygame.K_DOWN
K2_LEFT  = pygame.K_LEFT
K2_RIGHT = pygame.K_RIGHT
K2_SPRINT = pygame.K_RSHIFT

# Actions
K2_HIDE       = pygame.K_KP0
K2_USE_DOOR   = pygame.K_KP_ENTER
K2_FIRE       = pygame.K_KP_PLUS
K2_CYCLE_GUN  = pygame.K_KP_PERIOD   # KP .
K2_CYCLE_GEAR = pygame.K_KP_MINUS
K2_USE_GEAR   = pygame.K_KP5
K2_DROP       = pygame.K_KP3
K2_DRAG       = pygame.K_KP1
K2_AIM_TOGGLE = pygame.K_KP_MULTIPLY  # KP *

# Other-slot selects
K2_OTHER = {
    0: pygame.K_KP7,
    1: pygame.K_KP8,
    2: pygame.K_KP9,
    3: pygame.K_KP6,
}

# Aim sweep keys (held for continuous rotation)
K2_AIM_SWEEP_LEFT  = pygame.K_KP_DIVIDE   # /
K2_AIM_SWEEP_RIGHT = pygame.K_KP_MULTIPLY # * (doubles as aim toggle on tap)

# Aim wheel: 8-direction snap via numpad directional cluster
_AIM_ANGLES = {
    pygame.K_KP8: -math.pi / 2,           # up
    pygame.K_KP9: -math.pi / 4,           # up-right
    pygame.K_KP6: 0.0,                    # right
    pygame.K_KP3:  math.pi / 4,           # down-right
    pygame.K_KP2:  math.pi / 2,           # down
    pygame.K_KP1:  3 * math.pi / 4,       # down-left
    pygame.K_KP4:  math.pi,               # left
    pygame.K_KP7: -3 * math.pi / 4,       # up-left
}

AIM_SWEEP_SPEED = math.radians(180)   # degrees per second when holding sweep key

# ── LocalP2Input class ────────────────────────────────────────────────────────

class LocalP2Input:
    """
    Stateless helper.  Call read_frame() once per game tick to get a
    normalised input dict for Player 2.  Pass the dict to MPGame._apply_p2().
    """

    def __init__(self):
        self._aim_angle = 0.0      # current P2 aim angle (radians)
        self._aim_mode  = False    # toggled by KP *

    def read_frame(self, dt: float) -> dict:
        """
        Returns a dict:
          dx, dy        : int  movement deltas (-1/0/1 each axis)
          sprint        : bool
          aim_mode      : bool  current aim state
          aim_angle     : float radians
          fire          : bool  was KP+ pressed (checked from event queue externally)
          hide_toggle   : bool  (checked from event queue externally)
          use_door      : bool  (checked from event queue externally)
          cycle_gun     : bool
          cycle_gear    : bool
          use_gear      : bool
          drop          : bool
          drag          : bool
          other_sel     : int or None
        Most bool fields are True only for the current frame (caller handles
        edge-detection for events; movement and aim_angle are continuous).
        """
        keys = pygame.key.get_pressed()

        # Movement
        dx = int(bool(keys[K2_RIGHT])) - int(bool(keys[K2_LEFT]))
        dy = int(bool(keys[K2_DOWN]))  - int(bool(keys[K2_UP]))
        sprint = bool(keys[K2_SPRINT]) and (dx != 0 or dy != 0)

        # Aim direction from 8-way numpad wheel (highest priority)
        aim_set = False
        for kp_key, angle in _AIM_ANGLES.items():
            if keys[kp_key]:
                self._aim_angle = angle
                aim_set = True
                break

        # Continuous sweep from / and * when aim_mode is on and no wheel key held
        if not aim_set and self._aim_mode:
            if keys[K2_AIM_SWEEP_LEFT]:
                self._aim_angle -= AIM_SWEEP_SPEED * dt
            if keys[K2_AIM_SWEEP_RIGHT]:
                self._aim_angle += AIM_SWEEP_SPEED * dt

        return {
            "dx":         dx,
            "dy":         dy,
            "sprint":     sprint,
            "aim_mode":   self._aim_mode,
            "aim_angle":  self._aim_angle,
        }

    def handle_keydown(self, key: int, inventory, equipment) -> dict:
        """
        Handle KEYDOWN events for P2.  Returns a dict of single-frame actions.
        Must be called from the event loop for every KEYDOWN event.
        """
        actions = {
            "hide_toggle": False,
            "use_door":    False,
            "fire":        False,
            "cycle_gun":   False,
            "cycle_gear":  False,
            "use_gear":    False,
            "drop":        False,
            "drag":        False,
            "other_sel":   None,
        }

        if key == K2_HIDE:
            actions["hide_toggle"] = True

        elif key == K2_USE_DOOR:
            actions["use_door"] = True

        elif key == K2_FIRE:
            actions["fire"] = True

        elif key == K2_CYCLE_GUN:
            actions["cycle_gun"] = True
            if inventory is not None:
                inventory.cycle_gun()

        elif key == K2_CYCLE_GEAR:
            actions["cycle_gear"] = True
            if equipment is not None:
                equipment.cycle_gear()

        elif key == K2_USE_GEAR:
            actions["use_gear"] = True

        elif key == K2_DROP:
            actions["drop"] = True

        elif key == K2_DRAG:
            actions["drag"] = True

        elif key == K2_AIM_TOGGLE:
            self._aim_mode = not self._aim_mode

        else:
            for slot, kp_key in K2_OTHER.items():
                if key == kp_key:
                    actions["other_sel"] = slot
                    if inventory is not None:
                        inventory.other_sel = slot
                        inventory.active_slot = "other"
                    break

        return actions

    def is_p2_key(self, key: int) -> bool:
        """Return True if `key` is exclusively bound to P2 controls.
        Used to short-circuit P1 KEYDOWN handling for P2 keys.
        """
        p2_keys = {
            K2_HIDE, K2_USE_DOOR, K2_FIRE, K2_CYCLE_GUN, K2_CYCLE_GEAR,
            K2_USE_GEAR, K2_DROP, K2_DRAG, K2_AIM_TOGGLE,
            K2_AIM_SWEEP_LEFT,   # KP /
            # arrow keys and RSHIFT (movement) are handled via get_pressed,
            # but block them here too so they don't hit P1 KEYDOWN bindings
            K2_UP, K2_DOWN, K2_LEFT, K2_RIGHT, K2_SPRINT,
        }
        p2_keys.update(K2_OTHER.values())
        p2_keys.update(_AIM_ANGLES.keys())
        return key in p2_keys

    def reset(self):
        self._aim_angle = 0.0
        self._aim_mode  = False
