"""
LockESC Utility functions - Math, geometry, pathfinding, LOS, FOV
"""

from .. import core

# Re-export utility functions
tc = core.tc
ptile = core.ptile
dist = core.dist
adiff = core.adiff
count_walls_between = core.count_walls_between
los_check = core.los_check
astar = core.astar
cast_fov_polygon = core.cast_fov_polygon
draw_text = core.draw_text

__all__ = ['tc', 'ptile', 'dist', 'adiff', 'count_walls_between', 'los_check',
           'astar', 'cast_fov_polygon', 'draw_text']
