"""
goap.py – Goal-Oriented Action Planning for LockESC AI
=======================================================
GOAP is the *sole* decision-making system for Guard and Snitch.
The behaviour loop is:

    1. Perception  →  world-state dict  (suspicion, noise, last_seen, etc.)
    2. GOAPAgent.tick()  →  action name  (what to do this frame)
    3. Locomotion  →  move/face/act based on action name

World-state keys are flat booleans / small integers so the A* planner
stays cheap. The planner replans only when world state actually changes.

Design rules
------------
- Actions declare preconditions (must hold) and effects (applied on completion).
- The planner finds the cheapest action sequence reaching the highest-priority
  unsatisfied goal.
- GOAPAgent.tick() returns the *current* action name every frame.
  It replans automatically when world state changes invalidate the plan.
- complete_action() applies effects and advances the plan; call it when the
  locomotion primitive signals "done".
"""

from __future__ import annotations
import heapq
from typing import Any

WorldState = dict[str, Any]


# ── Core types ─────────────────────────────────────────────────────────────

class Action:
    """
    name          : unique identifier returned by tick()
    preconditions : world-state keys that must equal these values
    effects       : world-state keys set when the action completes
    cost          : planner weight (lower = preferred)
    interruptible : if True, sensing can preempt this mid-execution
    """
    __slots__ = ("name", "preconditions", "effects", "cost", "interruptible")

    def __init__(self, name: str, preconditions: WorldState,
                 effects: WorldState, cost: float = 1.0,
                 interruptible: bool = True) -> None:
        self.name          = name
        self.preconditions = preconditions
        self.effects       = effects
        self.cost          = cost
        self.interruptible = interruptible

    def is_applicable(self, state: WorldState) -> bool:
        return all(state.get(k) == v for k, v in self.preconditions.items())

    def apply(self, state: WorldState) -> WorldState:
        new = dict(state)
        new.update(self.effects)
        return new

    def __repr__(self) -> str:
        return f"Action({self.name!r})"


class Goal:
    """Desired subset of world state."""
    __slots__ = ("name", "desired", "priority")

    def __init__(self, name: str, desired: WorldState,
                 priority: float = 1.0) -> None:
        self.name     = name
        self.desired  = desired
        self.priority = priority

    def is_satisfied(self, state: WorldState) -> bool:
        return all(state.get(k) == v for k, v in self.desired.items())

    def __repr__(self) -> str:
        return f"Goal({self.name!r})"


# ── A* Planner ─────────────────────────────────────────────────────────────

class GOAPPlanner:
    @staticmethod
    def plan(world: WorldState, goal: Goal,
             actions: list[Action], max_depth: int = 16) -> list[Action] | None:
        start  = _freeze(world)
        target = goal.desired
        counter = 0
        heap: list[tuple] = []
        heapq.heappush(heap, (0.0, counter, start, []))
        visited: dict[tuple, float] = {start: 0.0}

        while heap:
            g, _, frozen, path = heapq.heappop(heap)
            state = _thaw(frozen)
            if all(state.get(k) == v for k, v in target.items()):
                return path
            if len(path) >= max_depth:
                continue
            for action in actions:
                if not action.is_applicable(state):
                    continue
                new_state  = action.apply(state)
                new_g      = g + action.cost
                frozen_new = _freeze(new_state)
                if frozen_new not in visited or visited[frozen_new] > new_g:
                    visited[frozen_new] = new_g
                    h = sum(1 for k, v in target.items() if new_state.get(k) != v)
                    counter += 1
                    heapq.heappush(heap,
                        (new_g + h, counter, frozen_new, path + [action]))
        return None


def _freeze(state: WorldState) -> tuple:
    return tuple(sorted(state.items()))

def _thaw(frozen: tuple) -> WorldState:
    return dict(frozen)


# ── GOAPAgent ──────────────────────────────────────────────────────────────

class GOAPAgent:
    """
    Maintains world state, goals, and current plan.

    Every frame:
        agent.set(player_visible=True, ...)   # update perception
        name = agent.tick()                   # get current action name
        if locomotion_done:
            agent.complete_action()           # apply effects, advance plan
    """

    def __init__(self, actions: list[Action]) -> None:
        self.actions   = actions
        self.world: WorldState = {}
        self.goals: list[Goal] = []
        self._plan: list[Action] = []
        self._plan_idx: int = 0
        self._last_goal: Goal | None = None
        self._world_frozen: tuple = ()

    # ── world state ────────────────────────────────────────────────────────

    def set(self, **kwargs) -> None:
        """Update world state. Invalidates plan only when something changes."""
        changed = any(self.world.get(k) != v for k, v in kwargs.items())
        self.world.update(kwargs)
        if changed:
            self._plan = []
            self._plan_idx = 0

    def get(self, key: str, default=None):
        return self.world.get(key, default)

    # ── goals ──────────────────────────────────────────────────────────────

    def add_goal(self, goal: Goal) -> None:
        self.goals.append(goal)
        self.goals.sort(key=lambda g: -g.priority)

    def current_goal(self) -> Goal | None:
        for g in self.goals:
            if not g.is_satisfied(self.world):
                return g
        return None

    # ── planning ───────────────────────────────────────────────────────────

    def replan(self) -> bool:
        goal = self.current_goal()
        if goal is None:
            self._plan = []; self._plan_idx = 0
            return True
        plan = GOAPPlanner.plan(self.world, goal, self.actions)
        if plan is not None:
            self._plan = plan; self._plan_idx = 0
            self._last_goal = goal
            return True
        self._plan = []; self._plan_idx = 0
        return False

    def current_action(self) -> Action | None:
        if self._plan_idx < len(self._plan):
            return self._plan[self._plan_idx]
        return None

    def tick(self) -> str | None:
        """
        Return action name for this frame.
        Tries goals in priority order; falls through to the next goal when the
        highest-priority goal has no achievable plan (e.g. player not visible).
        Replans only when world state has changed or the plan is exhausted.
        """
        for goal in self.goals:
            if goal.is_satisfied(self.world):
                continue  # skip already-satisfied goals

            # Replan if the active goal changed or plan is exhausted
            if goal is not self._last_goal or self._plan_idx >= len(self._plan):
                self._last_goal = goal
                plan = GOAPPlanner.plan(self.world, goal, self.actions)
                if plan is None:
                    continue  # this goal unreachable — try next
                self._plan     = plan
                self._plan_idx = 0

            action = self.current_action()
            if action is None:
                continue

            # Preconditions no longer met → replan once for this goal
            if not action.is_applicable(self.world):
                plan = GOAPPlanner.plan(self.world, goal, self.actions)
                if plan is None:
                    continue
                self._plan     = plan
                self._plan_idx = 0
                action = self.current_action()

            if action:
                return action.name

        return "patrol_walk"  # fallback: patrol when no goal needs attention

    def complete_action(self) -> None:
        """Apply current action's effects to world state and advance the plan."""
        action = self.current_action()
        if action and action.is_applicable(self.world):
            self.world = action.apply(self.world)
        if self._plan_idx < len(self._plan):
            self._plan_idx += 1


# ══════════════════════════════════════════════════════════════════════════
# Guard World-State Reference
# ══════════════════════════════════════════════════════════════════════════
#
#  suspicion_low           bool  0 < suspicion < full  (partially spotted)
#  suspicion_full          bool  suspicion >= 1.0 (confirmed)
#  player_visible          bool  player in FOV+LOS this frame
#  player_near             bool  within arrest/melee range
#  has_last_known          bool  last_player position stored
#  noise_heard             bool  actionable noise this frame
#  noise_dest_set          bool  noise destination stored in agent
#  at_dest                 bool  arrived at current movement target
#  patrol_at_wp            bool  standing at a waypoint
#  search_done             bool  all search points visited
#  body_found              bool  dead body spotted
#  briefing_target         bool  picked a colleague to brief
#  briefed                 bool  briefing delivered this cycle
#  in_combat               bool  gunshot heard / combat triggered
#  player_caught           bool  terminal – player arrested/shot
#  colleague_chasing       bool  a known colleague is already in CHASE state
#  colleague_available     bool  a known colleague is in PATROL/ALERT (can join)
#  teammate_assigned       bool  this guard has been assigned a flanking role this chase
#  going_solo              bool  no known colleagues – decided to chase alone

def GuardActionSet() -> list[Action]:
    return [
        # ── Calm patrol ───────────────────────────────────────────────────
        Action("patrol_walk",
               preconditions={"suspicion_low": False, "suspicion_full": False,
                               "noise_dest_set": False, "body_found": False,
                               "in_combat": False,
                               "briefing_target": False},
               effects={},
               cost=1.0),


        # ── Raised suspicion ──────────────────────────────────────────────
        Action("investigate_sight",
               preconditions={"suspicion_low": True, "suspicion_full": False,
                               "in_combat": False, "has_last_known": True},
               effects={"at_dest": True, "suspicion_low": False},
               cost=0.8),

        # ── Noise investigation ───────────────────────────────────────────
        Action("investigate_noise",
               preconditions={"noise_dest_set": True, "suspicion_full": False,
                               "in_combat": False},
               effects={"at_dest": True, "noise_dest_set": False},
               cost=0.9),

        Action("inspect_spot",
               preconditions={"at_dest": True, "suspicion_full": False,
                               "in_combat": False},
               effects={"at_dest": False, "has_last_known": False,
                        "noise_dest_set": False},
               cost=0.6),

        # ── Full chase ────────────────────────────────────────────────────
        # Solo chase: no known colleagues available or guard deliberately going alone
        Action("chase",
               preconditions={"suspicion_full": True, "player_near": False,
                               "in_combat": False, "teammate_assigned": False,
                               "colleague_available": False},
               effects={"player_near": True, "going_solo": True},
               cost=0.3),

        # Team-up chase: a known colleague is free — call them in to flank
        # This guard takes a flanking intercept angle; the colleague chases direct.
        Action("team_up_chase",
               preconditions={"suspicion_full": True, "player_near": False,
                               "in_combat": False, "colleague_available": True,
                               "teammate_assigned": False},
               effects={"player_near": True, "teammate_assigned": True,
                        "going_solo": False},
               cost=0.2),   # cheaper than solo — coordinated is preferred

        # Join an ongoing chase: a known colleague is already chasing.
        # This guard converges on the last-known position from a different angle.
        Action("join_chase",
               preconditions={"suspicion_full": True, "player_near": False,
                               "in_combat": False, "colleague_chasing": True,
                               "teammate_assigned": False},
               effects={"player_near": True, "teammate_assigned": True,
                        "going_solo": False},
               cost=0.25),

        Action("arrest",
               preconditions={"suspicion_full": True, "player_near": True,
                               "in_combat": False},
               effects={"player_caught": True},
               cost=0.1, interruptible=False),

        # ── Search after losing player ────────────────────────────────────
        Action("search_walk",
               preconditions={"suspicion_full": False, "has_last_known": True,
                               "search_done": False, "at_dest": False,
                               "in_combat": False},
               effects={"at_dest": True},
               cost=1.2),

        Action("search_inspect",
               preconditions={"at_dest": True, "search_done": False,
                               "suspicion_full": False, "in_combat": False},
               effects={"at_dest": False, "search_done": True},
               cost=0.8),

        Action("end_search",
               preconditions={"search_done": True, "suspicion_full": False},
               effects={"search_done": False, "has_last_known": False,
                        "at_dest": False, "patrol_at_wp": False},
               cost=0.5),

        # ── Body found ────────────────────────────────────────────────────
        Action("panicked_sweep",
               preconditions={"body_found": True, "in_combat": False},
               effects={"body_found": False},
               cost=1.5),

        # ── Combat ────────────────────────────────────────────────────────
        Action("combat_cover",
               preconditions={"in_combat": True, "at_dest": False},
               effects={"at_dest": True},
               cost=0.4),

        Action("combat_fire",
               preconditions={"in_combat": True, "at_dest": True,
                               "player_visible": True},
               effects={"player_caught": True},
               cost=0.2, interruptible=False),

        Action("combat_wait",
               preconditions={"in_combat": True, "at_dest": True,
                               "player_visible": False},
               effects={"in_combat": False, "at_dest": False},
               cost=3.0),

        # ── Brief colleague ───────────────────────────────────────────────
        Action("brief_walk",
               preconditions={"briefing_target": True, "briefed": False,
                               "at_dest": False},
               effects={"at_dest": True},
               cost=1.0),

        Action("brief_deliver",
               preconditions={"briefing_target": True, "at_dest": True,
                               "briefed": False},
               effects={"briefed": True, "briefing_target": False,
                        "at_dest": False},
               cost=0.5, interruptible=False),

        Action("brief_done",
               preconditions={"briefed": True},
               effects={"briefed": False, "has_last_known": False},
               cost=0.1),
    ]


# ══════════════════════════════════════════════════════════════════════════
# Snitch World-State Reference
# ══════════════════════════════════════════════════════════════════════════
#
#  suspicion_low   bool
#  suspicion_full  bool
#  player_visible  bool
#  has_last_known  bool
#  noise_dest_set  bool
#  at_dest         bool
#  patrol_at_wp    bool
#  search_done     bool
#  body_found      bool
#  guard_in_range  bool  live guard close enough to deliver report
#  reported        bool  report delivered this run

def SnitchActionSet() -> list[Action]:
    return [
        # ── Calm patrol ───────────────────────────────────────────────────
        Action("patrol_walk",
               preconditions={"suspicion_low": False, "suspicion_full": False,
                               "noise_dest_set": False, "body_found": False,
                               "reported": False},
               effects={},
               cost=1.0),


        # ── Noise ─────────────────────────────────────────────────────────
        Action("investigate_noise",
               preconditions={"noise_dest_set": True, "suspicion_full": False},
               effects={"at_dest": True, "noise_dest_set": False},
               cost=0.9),

        Action("inspect_spot",
               preconditions={"at_dest": True, "suspicion_full": False},
               effects={"at_dest": False, "has_last_known": False,
                        "noise_dest_set": False},
               cost=0.6),

        # ── Confirmed player – run to guard ───────────────────────────────
        Action("run_to_guard",
               preconditions={"suspicion_full": True, "guard_in_range": False,
                               "reported": False},
               effects={"guard_in_range": True},
               cost=0.3),

        Action("deliver_report",
               preconditions={"suspicion_full": True, "guard_in_range": True,
                               "reported": False},
               effects={"reported": True},
               cost=0.2, interruptible=False),

        Action("cooldown_return",
               preconditions={"reported": True},
               effects={"reported": False, "suspicion_full": False,
                        "suspicion_low": False, "has_last_known": False,
                        "guard_in_range": False, "patrol_at_wp": False},
               cost=0.5),

        # ── Search ────────────────────────────────────────────────────────
        Action("search_walk",
               preconditions={"suspicion_full": False, "has_last_known": True,
                               "search_done": False, "at_dest": False},
               effects={"at_dest": True},
               cost=1.2),

        Action("search_inspect",
               preconditions={"at_dest": True, "search_done": False,
                               "suspicion_full": False},
               effects={"at_dest": False, "search_done": True},
               cost=0.8),

        Action("end_search",
               preconditions={"search_done": True, "suspicion_full": False},
               effects={"search_done": False, "has_last_known": False,
                        "at_dest": False, "patrol_at_wp": False},
               cost=0.5),

        # ── Body found ────────────────────────────────────────────────────
        Action("panicked_sweep",
               preconditions={"body_found": True, "suspicion_full": False},
               effects={"body_found": False},
               cost=1.5),
    ]
