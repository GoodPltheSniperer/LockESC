"""
LockESC Game Engine - Modular Package
All classes and functions are organized in categorized submodules.
The full implementation is currently in core.py during this transition phase.

Main module exports backward compatibility with original lockesc.py imports:
    from integrity.functions.lockesc import Game, Player, Guard, Door, ...

Transitional Architecture Plan:
  Phase 1: Keep all code in core.py (CURRENT)
  Phase 2: Split core.py into categorized submodules
  Phase 3: Update category __init__.py files to re-export
  Phase 4: Update main lockesc.py to import from this package
"""

# During transition phase: Import all exports from core module
try:
    from .core import *
    # Explicitly import underscore-prefixed functions (not imported by *)
    from .core import (
        _load_tile_png, _load_lev_defs, _load_state_vis_defs,
        _ensure_lev_file, _check_level_integrity, _svc,
        _draw_lev_tile_pygame, _draw_lev_hinge_pygame, _lev_color, _lev_font,
        _lev_hinge_corner, _draw_bevel_door, _draw_oiled_door,
        _draw_wall_door, _draw_crash_door, _col,
        _vis_color, _vc,
        _gen_sfx, _play,
        _collect_required_tiles, _missing_tile_assets,
        _generate_build_script, _autolink, _load_svg_surface,
    )
except ImportError as e:
    raise ImportError(
        "LockESC core module not found. "
        "Expected to find core.py at: integrity/functions/lockesc/core.py\n"
        f"Original error: {e}"
    )

# Define all public exports
__all__ = [
    # ════ Game Engine ════════════════════════════════════════
    'Game', 'Camera', 'TitleScreen',
    
    # ════ Characters ═════════════════════════════════════════
    'Player', 'Guard', 'Snitch', 'Sentry',
    
    # ════ Doors ══════════════════════════════════════════════
    'Door', 'CrashDoor', 'OiledDoor', 'WallDoor', 'ThinDoor',
    
    # ════ Entities ═══════════════════════════════════════════
    'NoiseEvent', 'ItemPile', 'BuyItem', 'ShopMenu', 'Inventory', 'CameraEntity',
    'IOInput', 'IOOutput', 'Noisemaker', 'Pit', 'CreakFloor', 'TimerNode',
    
    # ════ Registry & Assets ══════════════════════════════════
    'ObjectRegistry', 'SpriteCache',
    
    # ════ Utility Functions ══════════════════════════════════
    'tc', 'ptile', 'dist', 'adiff', 'count_walls_between', 'los_check',
    'astar', 'cast_fov_polygon', 'draw_text',
    'load_level', 'make_default_level_json',
    
    # ════ File & Asset Loading ═══════════════════════════════
    '_load_tile_png', '_load_lev_defs', '_load_state_vis_defs',
    '_ensure_lev_file', '_check_level_integrity', '_svc',
    
    # ════ Visual Rendering ═══════════════════════════════════
    '_draw_lev_tile_pygame', '_draw_lev_hinge_pygame', '_lev_color', '_lev_font',
    '_lev_hinge_corner', '_draw_bevel_door', '_draw_oiled_door',
    '_draw_wall_door', '_draw_crash_door', '_col',
    '_vis_color', '_vc',
    
    # ════ Sound/Audio ════════════════════════════════════════
    '_gen_sfx', '_play',
    
    # ════ Helper/Support ════════════════════════════════════
    '_collect_required_tiles', '_missing_tile_assets',
    '_generate_build_script', '_autolink', '_load_svg_surface',
]
