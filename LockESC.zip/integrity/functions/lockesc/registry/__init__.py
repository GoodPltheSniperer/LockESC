"""
LockESC Registry and data systems - ObjectRegistry, SpriteCache, tile definitions
"""

from .. import core

# Re-export registry classes
ObjectRegistry = core.ObjectRegistry
SpriteCache = core.SpriteCache

__all__ = ['ObjectRegistry', 'SpriteCache']
