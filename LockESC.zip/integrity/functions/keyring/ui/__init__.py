"""
KeyRing Editor - UI Components
Main editor window, canvas, toolbars, panels
"""

from .. import core

# Re-export UI classes
EditorWindow = core.EditorWindow
Canvas = core.Canvas
TileToolBar = core.TileToolBar
WaypointToolBar = core.WaypointToolBar
ProjectTreePanel = core.ProjectTreePanel
SidePanel = core.SidePanel

__all__ = ['EditorWindow', 'Canvas', 'TileToolBar', 'WaypointToolBar',
           'ProjectTreePanel', 'SidePanel']
