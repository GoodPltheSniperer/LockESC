"""
forgemason.py  –  Forgemason Tile + Tag Editor
════════════════════════════════════════════════
Create and edit  .let  tile definition files  AND  .lei  tag / Indent
definition files for LockESC.

  •  Welcome screen — pick "New Tile +", "Load Tile File…",
                            "New Tag +",  "Load Tag File…"
     (styled identical to KeyRingWelcome)
  •  Tile mode: flip flags, configure fields, live JSON preview.
  •  Tag  mode: define Indent properties AND edit exact Python
     function code (on_apply, on_remove, on_tick, on_interact, …)
  •  Save a .lei → triggers builttags.py --compile, then writes
     integrity/tags/cache.pkl that pygame/lockesc.py loads on startup.

CLI args (used when launched from keyring.py):
  --action  new_tile | load_tile | new_tag | load_tag
  --path    <filepath>   (required for load_* actions)

Part of the KeyRing · LockESC toolchain.
Run standalone:  python .editortools/forgemason.py
Or launch from the KeyRing welcome screen.
"""

# ── resolve project root ──────────────────────────────────────────────────────
import sys, os, json, copy, pickle, textwrap, re, subprocess

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

_TAGS_DIR = os.path.join(_ROOT, "integrity", "tags")
if _TAGS_DIR not in sys.path:
    sys.path.insert(0, _TAGS_DIR)
try:
    from builttags import TAGS, tags_by_group, CATEGORY_ORDER
    _HAS_TAGS = True
except ImportError:
    TAGS = {}
    def tags_by_group(): return {}
    CATEGORY_ORDER = []
    _HAS_TAGS = False

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QFileDialog, QMessageBox,
    QScrollArea, QFrame, QLineEdit, QCheckBox, QComboBox,
    QSpinBox, QGroupBox, QFormLayout, QTextEdit,
    QStatusBar, QTabWidget,
    QDialog, QDialogButtonBox, QStackedWidget,
)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtGui import (
    QColor, QFont,
    QSyntaxHighlighter, QTextCharFormat, QAction,
)

# ═════════════════════════════════════════════════════════════════════════════
#  Paths
# ═════════════════════════════════════════════════════════════════════════════

CUSTOM_TILE_DIR = os.path.join(_ROOT, "integrity", "tiles", "CUSTOM")
DEFAULT_TILE_DIR = os.path.join(_ROOT, "integrity", "tiles")
CUSTOM_TAG_DIR  = os.path.join(_ROOT, "integrity", "tags", "CUSTOM")
DEFAULT_TAG_DIR = os.path.join(_ROOT, "integrity", "tags")
BUILTTAGS_PATH  = os.path.join(_ROOT, "integrity", "tags", "builttags.py")
TAG_CACHE_PATH  = os.path.join(_ROOT, "integrity", "tags", "cache.pkl")

# ═════════════════════════════════════════════════════════════════════════════
#  Palette & stylesheet
# ═════════════════════════════════════════════════════════════════════════════

PAL = {
    "bg":        "#0a0c14", "panel":     "#10141e", "panel2":    "#0d1018",
    "border":    "#1a2236", "border2":   "#253040", "accent":    "#4a7ab8",
    "forge":     "#b85020", "forge_hi":  "#e06030", "text":      "#c0ccd8",
    "text_dim":  "#556070", "text_hi":   "#ddeeff", "green":     "#2a7a30",
    "green_hi":  "#3aaa44", "code_bg":   "#080b10", "code_text": "#c8d4e0",
    "code_kw":   "#6688cc", "code_str":  "#88bb66", "code_num":  "#ddaa44",
}

SS = f"""
QMainWindow,QDialog{{background:{PAL['bg']};color:{PAL['text']};}}
QWidget{{background:{PAL['bg']};color:{PAL['text']};font:11px Consolas,monospace;}}
QLabel{{color:{PAL['text']};background:transparent;}}
QPushButton{{background:{PAL['panel']};color:{PAL['text_dim']};border:1px solid {PAL['border']};
  border-radius:5px;padding:7px 14px;font:bold 11px Consolas;text-align:left;}}
QPushButton:hover{{background:{PAL['panel2']};border-color:{PAL['border2']};color:{PAL['text_hi']};}}
QPushButton:pressed{{background:#06080e;}}
QPushButton:disabled{{color:#2a3040;border-color:#141820;}}
QCheckBox{{color:{PAL['text']};spacing:8px;}}
QCheckBox::indicator{{width:14px;height:14px;border:1px solid {PAL['border2']};border-radius:3px;background:{PAL['panel']};}}
QCheckBox::indicator:checked{{background:{PAL['accent']};border-color:{PAL['accent']};}}
QLineEdit,QSpinBox,QDoubleSpinBox,QComboBox{{background:{PAL['panel']};color:{PAL['text']};
  border:1px solid {PAL['border']};border-radius:4px;padding:4px 8px;
  selection-background-color:{PAL['accent']};}}
QLineEdit:focus,QSpinBox:focus,QDoubleSpinBox:focus,QComboBox:focus{{border-color:{PAL['border2']};}}
QGroupBox{{border:1px solid {PAL['border']};border-radius:6px;margin-top:12px;padding-top:8px;
  color:{PAL['text_dim']};font:bold 9px Consolas;letter-spacing:2px;}}
QGroupBox::title{{subcontrol-origin:margin;subcontrol-position:top left;padding:0 6px;color:{PAL['text_dim']};}}
QScrollArea,QScrollBar{{background:{PAL['bg']};border:none;}}
QScrollBar:vertical{{width:8px;}}
QScrollBar::handle:vertical{{background:{PAL['border2']};border-radius:4px;}}
QScrollBar::add-line,QScrollBar::sub-line{{height:0;}}
QTextEdit{{background:{PAL['code_bg']};color:{PAL['code_text']};border:1px solid {PAL['border']};
  border-radius:4px;font:11px Consolas,monospace;selection-background-color:{PAL['accent']};}}
QSplitter::handle{{background:{PAL['border']};width:2px;height:2px;}}
QTabWidget::pane{{border:1px solid {PAL['border']};}}
QTabBar::tab{{background:{PAL['panel']};color:{PAL['text_dim']};border:1px solid {PAL['border']};
  padding:6px 14px;font:bold 10px Consolas;}}
QTabBar::tab:selected{{background:{PAL['bg']};color:{PAL['text_hi']};border-bottom:2px solid {PAL['forge']};}}
QStatusBar{{background:{PAL['panel']};color:{PAL['text_dim']};font:9px Consolas;}}
"""

# ═════════════════════════════════════════════════════════════════════════════
#  Tile .let constants
# ═════════════════════════════════════════════════════════════════════════════

FLAG_NAMES = [
    "openable","bashable","crashable","silent","blocks_movement","blocks_los",
    "uses_channel","linked_by_adjacency","guard_opens","guard_closes",
    "has_open_state","hides_when_closed","thin","is_fence","is_pit",
    "collectible","emits_noise","has_fov","is_entity",
]
FLAG_GROUPS = {
    "Physics / Collision": ["blocks_movement","blocks_los","is_fence","is_pit","thin"],
    "Interaction":         ["openable","bashable","crashable","linked_by_adjacency",
                            "has_open_state","hides_when_closed"],
    "Audio":               ["silent","emits_noise"],
    "Guard AI":            ["guard_opens","guard_closes","has_fov"],
    "Gameplay":            ["collectible","is_entity","uses_channel"],
}
CATEGORIES = ["structure","entity","interactive","io","floor","hazard","other"]

NOISE_PRESETS = {
    "Quiet door":   {"open_once_score":8,"open_twice_score":20,"bash_score":50,"radius_tiles":2,"repeat_window_sec":3.0,"lifetime_sec":0.8},
    "Normal door":  {"open_once_score":18,"open_twice_score":45,"bash_score":70,"radius_tiles":3,"repeat_window_sec":3.0,"lifetime_sec":0.9},
    "Loud crasher": {"open_once_score":0,"crash_score":95,"radius_tiles":6,"repeat_window_sec":1.0,"lifetime_sec":1.5},
    "Noisemaker":   {"pulse_score":40,"pulse_interval_sec":4.0,"radius_tiles":4,"lifetime_sec":1.2},
    "Creak floor":  {"step_score":20,"sprint_score":45,"radius_tiles":2,"lifetime_sec":0.7},
}
VISUAL_PRESETS = {
    "Plain wall":   {"style":"wall"},
    "Plain floor":  {"style":"floor"},
    "Bevel door":   {"style":"bevel_door","closed_color":[75,50,18],"open_color":[140,100,40]},
    "Entity circle":{"style":"entity_circle","fill_color":[200,80,80]},
    "Thin wall":    {"style":"thin_wall"},
    "Pit":          {"style":"pit"},
    "Fence":        {"style":"fence"},
    "Custom":       {"style":"custom"},
}
SOUND_PRESETS = {
    "Door sounds":  {"toggle":"door","bash":"crash"},
    "Crash sounds": {"toggle":None,"bash":"crash","crash":"crash"},
    "Silent":       {"toggle":None,"bash":None},
}

def _blank_let(name="my_tile"):
    return {
        "_comment": f"LockESC Tile Definition (.let) \u2013 {name}",
        "_version": 1, "type": name,
        "label": name.replace("_"," ").title(), "category": "structure",
        "flags": {k: False for k in FLAG_NAMES},
        "defaults":{}, "noise":{}, "sound":{}, "visuals":{"style":"wall"},
    }

# ═════════════════════════════════════════════════════════════════════════════
#  Tag .lei constants + serialisation
# ═════════════════════════════════════════════════════════════════════════════

TAG_CATEGORIES = ["physics","vision","interaction","audio","gameplay",
                  "io","ai","hazard","visuals","structure","other"]
TAG_GROUPS = TAG_CATEGORIES[:]

TAG_FUNC_STUBS = {
    "on_apply": 'def on_apply(tile, level, **kwargs):\n    """Called when this tag is applied to a tile instance at runtime."""\n    pass\n',
    "on_remove": 'def on_remove(tile, level, **kwargs):\n    """Called when this tag is removed from a tile instance."""\n    pass\n',
    "on_tick": 'def on_tick(tile, level, dt, **kwargs):\n    """Called every game tick for tiles carrying this tag."""\n    pass\n',
    "on_interact": 'def on_interact(tile, level, actor, **kwargs):\n    """Called when a player or guard interacts with the tile."""\n    pass\n',
    "on_enter": 'def on_enter(tile, level, actor, **kwargs):\n    """Called when an actor enters the tile\'s cell."""\n    pass\n',
    "on_noise": 'def on_noise(tile, level, noise_event, **kwargs):\n    """Called when a noise event occurs near this tile."""\n    pass\n',
}

def _blank_lei(name="my_tag"):
    return {
        "name": name, "label": name.replace("_"," ").title(),
        "category": "gameplay", "description": f"Custom Indent: {name}",
        "type": "bool", "default": False, "group": "gameplay",
        "icon": "\u00b7", "color": [100,140,200],
        "_funcs": dict(TAG_FUNC_STUBS),
    }

def _lei_to_text(tag):
    name  = tag.get("name","unknown")
    lines = [f"# LockESC Indent  \u2013  {name}"]
    ORDER = ["name","label","category","description","type","default","group","icon","color"]
    for key in ORDER:
        if key not in tag: continue
        val = tag[key]
        if isinstance(val, bool): val = "true" if val else "false"
        elif isinstance(val, list): val = "[" + ", ".join(str(x) for x in val) + "]"
        lines.append(f"{key}: {val}")
    for key, val in tag.items():
        if key in ("_funcs",) or key in ORDER: continue
        if isinstance(val, bool): val = "true" if val else "false"
        elif isinstance(val, list): val = "[" + ", ".join(str(x) for x in val) + "]"
        lines.append(f"{key}: {val}")
    funcs = tag.get("_funcs", {})
    if any(v and v.strip() for v in funcs.values()):
        lines += ["", "# \u2500\u2500 Function implementations \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500"]
        for fn, code in funcs.items():
            if not code or not code.strip(): continue
            lines.append(f"# __func:{fn}__")
            for cl in code.rstrip().splitlines():
                lines.append(f"#   {cl}")
            lines.append("# __endfunc__")
    return "\n".join(lines) + "\n"

def _lei_from_text(text):
    data = {}; funcs = {}; in_func = None; func_lines = []
    for raw in text.splitlines():
        line = raw.strip()
        if line.startswith("# __func:") and line.endswith("__"):
            in_func = line[9:-2]; func_lines = []; continue
        if line == "# __endfunc__":
            if in_func: funcs[in_func] = "\n".join(func_lines) + "\n"
            in_func = None; func_lines = []; continue
        if in_func is not None:
            func_lines.append(raw[4:] if raw.startswith("#   ") else
                               raw[2:] if raw.startswith("# ")  else raw)
            continue
        if not line or line.startswith("#"): continue
        if ":" in line:
            key, _, val = line.partition(":")
            key = key.strip(); val = val.strip()
            if val.lower() == "true": val = True
            elif val.lower() == "false": val = False
            elif val.startswith("[") and val.endswith("]"):
                try: val = [int(x.strip()) for x in val[1:-1].split(",")]
                except ValueError: pass
            data[key] = val
    merged = dict(TAG_FUNC_STUBS); merged.update(funcs)
    data["_funcs"] = merged
    return data

# ═════════════════════════════════════════════════════════════════════════════
#  builttags compile + pygame cache
# ═════════════════════════════════════════════════════════════════════════════

def _compile_builttags_and_cache(status_fn=None):
    say = status_fn or (lambda m: None)
    try:
        r = subprocess.run(
            [sys.executable, BUILTTAGS_PATH, "--compile"],
            capture_output=True, text=True, timeout=15, cwd=_ROOT,
        )
        out = (r.stdout + r.stderr).strip()
        say(f"  \u21bb  builttags: {out.splitlines()[-1] if out else 'compiled'}")
    except Exception as e:
        say(f"  \u2717  builttags compile failed: {e}")
        # fallback: write cache directly from live import
        try:
            import importlib, builttags as _bt
            importlib.reload(_bt)
            _write_cache_direct(_bt.TAGS, status_fn)
        except Exception as e2:
            say(f"  \u2717  cache fallback failed: {e2}")

def _write_cache_direct(tags, status_fn=None):
    say = status_fn or (lambda m: None)
    try:
        os.makedirs(os.path.dirname(TAG_CACHE_PATH), exist_ok=True)
        with open(TAG_CACHE_PATH, "wb") as f:
            pickle.dump({"tags": dict(tags), "version": 1, "source": "builttags_auto"}, f, protocol=4)
        say(f"  \u2713  cache.pkl written  ({len(tags)} tags)")
    except Exception as e:
        say(f"  \u2717  cache.pkl write failed: {e}")

# ═════════════════════════════════════════════════════════════════════════════
#  Syntax Highlighters
# ═════════════════════════════════════════════════════════════════════════════

class _JsonHL(QSyntaxHighlighter):
    def __init__(self, doc):
        super().__init__(doc)
        kw = QTextCharFormat(); kw.setForeground(QColor(PAL["code_kw"]))
        st = QTextCharFormat(); st.setForeground(QColor(PAL["code_str"]))
        nm = QTextCharFormat(); nm.setForeground(QColor(PAL["code_num"]))
        self._rules = [(r'"[^"\\]*(?:\\.[^"\\]*)*"',st),(r'\b(true|false|null)\b',kw),(r'-?\b\d+(?:\.\d+)?\b',nm)]
    def highlightBlock(self, text):
        for p, f in self._rules:
            for m in re.finditer(p, text): self.setFormat(m.start(), m.end()-m.start(), f)

class _PythonHL(QSyntaxHighlighter):
    _KW = {"def","return","pass","import","from","as","if","elif","else","for","while","in",
           "not","and","or","None","True","False","class","try","except","raise","yield","with","lambda"}
    def __init__(self, doc):
        super().__init__(doc)
        self._kw = QTextCharFormat(); self._kw.setForeground(QColor(PAL["code_kw"])); self._kw.setFontWeight(700)
        self._st = QTextCharFormat(); self._st.setForeground(QColor(PAL["code_str"]))
        self._nm = QTextCharFormat(); self._nm.setForeground(QColor(PAL["code_num"]))
        self._cm = QTextCharFormat(); self._cm.setForeground(QColor(PAL["text_dim"]))
        self._fn = QTextCharFormat(); self._fn.setForeground(QColor("#88ccdd"))
    def highlightBlock(self, text):
        idx = text.find("#")
        if idx >= 0: self.setFormat(idx, len(text)-idx, self._cm)
        for m in re.finditer(r'"[^"\\]*(?:\\.[^"\\]*)*"|\'[^\'\\]*(?:\\.[^\'\\]*)*\'', text):
            self.setFormat(m.start(), m.end()-m.start(), self._st)
        for m in re.finditer(r'\b\d+(?:\.\d+)?\b', text):
            self.setFormat(m.start(), m.end()-m.start(), self._nm)
        for m in re.finditer(r'\b\w+\b', text):
            if m.group() in self._KW: self.setFormat(m.start(), len(m.group()), self._kw)
        for m in re.finditer(r'\bdef\s+(\w+)', text):
            self.setFormat(m.start(1), len(m.group(1)), self._fn)

# ═════════════════════════════════════════════════════════════════════════════
#  Tag Chip (tile editor right panel)
# ═════════════════════════════════════════════════════════════════════════════

class _TagChip(QPushButton):
    toggled_tag = pyqtSignal(str, bool)
    def __init__(self, tag, active=False, parent=None):
        super().__init__(parent)
        self._tag = tag
        self._color = QColor(*tag.get("color",[100,140,200]))
        self.setText(f"{tag.get('icon','·')} {tag.get('label',tag['name'])}")
        self.setToolTip(tag.get("description",""))
        self.setCheckable(True); self.setChecked(active)
        self._refresh_style()
        self.toggled.connect(self._on_toggle)
    def _refresh_style(self):
        c = self._color
        if self.isChecked():
            bg=f"rgb({c.red()},{c.green()},{c.blue()})"; txt="#fff"; brd=bg
        else:
            bg=PAL["panel"]; txt=f"rgba({c.red()},{c.green()},{c.blue()},160)"; brd=f"rgba({c.red()},{c.green()},{c.blue()},80)"
        self.setStyleSheet(f"QPushButton{{background:{bg};color:{txt};border:1px solid {brd};border-radius:4px;padding:3px 8px;font:10px Consolas;text-align:left;}}")
    def _on_toggle(self, s): self._refresh_style(); self.toggled_tag.emit(self._tag["name"], s)

# ═════════════════════════════════════════════════════════════════════════════
#  Forgemason Welcome Screen  (mirrors KeyRingWelcome style exactly)
# ═════════════════════════════════════════════════════════════════════════════

class ForgemasonWelcome(QDialog):
    A_NEW_TILE  = "new_tile"
    A_LOAD_TILE = "load_tile"
    A_NEW_TAG   = "new_tag"
    A_LOAD_TAG  = "load_tag"

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Forgemason  \u2013  LockESC")
        self.setModal(True); self.resize(460, 490)
        self.action = self.A_NEW_TILE; self.chosen_path = None
        self.setStyleSheet("""
            QDialog{background:#0a0c12;color:#b0c0d0;}
            QLabel{color:#b0c0d0;background:transparent;}
            QPushButton{background:#12182a;color:#6080a0;border:1px solid #1e2e48;
              border-radius:6px;padding:11px 20px;font:bold 12px Consolas;text-align:left;}
            QPushButton:hover{background:#18223a;border-color:#3a5888;color:#a0c8e8;}
            QPushButton:pressed{background:#0e1420;}
            QFrame{background:#141c28;border:none;}
        """)
        self._build()

    def _build(self):
        v = QVBoxLayout(self); v.setContentsMargins(36,32,36,28); v.setSpacing(0)

        logo = QLabel("\u26d2  Forgemason")
        logo.setStyleSheet("font:bold 34px Consolas;color:#b85020;letter-spacing:2px;background:transparent;")
        tag  = QLabel("LockESC  Tile  +  Tag  Editor")
        tag.setStyleSheet("font:10px Consolas;color:#6a3010;margin-bottom:20px;background:transparent;")
        v.addWidget(logo); v.addWidget(tag)

        d1 = QFrame(); d1.setFrameShape(QFrame.Shape.HLine); d1.setFixedHeight(1); d1.setStyleSheet("background:#1e2e48;")
        v.addWidget(d1); v.addSpacing(16)

        # TILE EDITOR section
        s1 = QLabel("TILE EDITOR")
        s1.setStyleSheet("font:bold 8px Consolas;color:#b85020;letter-spacing:4px;background:transparent;")
        v.addWidget(s1); v.addSpacing(6)

        b_nt = QPushButton("\u2295  New Tile +")
        b_nt.setStyleSheet("QPushButton{background:#1a0e08;color:#c87050;border-color:#3a1808;}QPushButton:hover{background:#281408;color:#e09060;border-color:#6a2810;}")
        b_nt.clicked.connect(lambda: self._pick(self.A_NEW_TILE))
        v.addWidget(b_nt); v.addSpacing(5)

        b_lt = QPushButton("\U0001f4c2  Load Tile File\u2026")
        b_lt.setStyleSheet("QPushButton{background:#120e0a;color:#806040;border-color:#2a1c10;}QPushButton:hover{background:#1e1410;color:#b08060;border-color:#4a2c18;}")
        b_lt.clicked.connect(lambda: self._pick(self.A_LOAD_TILE))
        v.addWidget(b_lt)

        td = QLabel("  Create or edit .let tile definitions.  Flags, presets,\n  noise, sound, visuals.  Saves to tiles/CUSTOM/")
        td.setStyleSheet("font:9px Consolas;color:#4a2810;margin-top:4px;background:transparent;")
        v.addWidget(td); v.addSpacing(14)

        d2 = QFrame(); d2.setFrameShape(QFrame.Shape.HLine); d2.setFixedHeight(1); d2.setStyleSheet("background:#1e2e48;")
        v.addWidget(d2); v.addSpacing(12)

        # TAG EDITOR section
        s2 = QLabel("TAG EDITOR  (INDENTS)")
        s2.setStyleSheet("font:bold 8px Consolas;color:#4878a0;letter-spacing:4px;background:transparent;")
        v.addWidget(s2); v.addSpacing(6)

        b_ntag = QPushButton("\u29eb  New Tag +")
        b_ntag.setStyleSheet("QPushButton{background:#0a1220;color:#4878b8;border-color:#162038;}QPushButton:hover{background:#10203a;color:#70a8e8;border-color:#2a4878;}")
        b_ntag.clicked.connect(lambda: self._pick(self.A_NEW_TAG))
        v.addWidget(b_ntag); v.addSpacing(5)

        b_ltag = QPushButton("\U0001f4c2  Load Tag File\u2026")
        b_ltag.setStyleSheet("QPushButton{background:#0a1018;color:#384868;border-color:#141c2a;}QPushButton:hover{background:#101828;color:#6888a8;border-color:#243858;}")
        b_ltag.clicked.connect(lambda: self._pick(self.A_LOAD_TAG))
        v.addWidget(b_ltag)

        gd = QLabel("  Create or edit .lei Indent definitions.  Set properties\n  AND write exact Python hook function code.\n  Saves \u2192 builttags compile + cache.pkl for pygame.")
        gd.setStyleSheet("font:9px Consolas;color:#2a3848;margin-top:4px;background:transparent;")
        v.addWidget(gd)
        v.addStretch()

        ft = QLabel("tiles: .let    tags: .lei    cache: integrity/tags/cache.pkl")
        ft.setStyleSheet("color:#304858;font:8px Consolas;background:transparent;")
        v.addWidget(ft)

    def _pick(self, action):
        if action == self.A_LOAD_TILE:
            p, _ = QFileDialog.getOpenFileName(self, "Open Tile Definition", DEFAULT_TILE_DIR, "LockESC Tile (*.let);;All Files (*)")
            if not p: return
            self.chosen_path = p
        elif action == self.A_LOAD_TAG:
            p, _ = QFileDialog.getOpenFileName(self, "Open Tag Definition", DEFAULT_TAG_DIR, "LockESC Tag (*.lei);;All Files (*)")
            if not p: return
            self.chosen_path = p
        self.action = action; self.accept()

# ═════════════════════════════════════════════════════════════════════════════
#  Tag Editor Widget
# ═════════════════════════════════════════════════════════════════════════════

class TagEditorWidget(QWidget):
    """Left: .lei property form.  Right: tabbed Python function code editor."""
    changed = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._data: dict = {}; self._inhibit = False
        self._build()

    def _build(self):
        root = QHBoxLayout(self); root.setContentsMargins(0,0,0,0); root.setSpacing(0)

        # Left scroll: property fields
        ls = QScrollArea(); ls.setWidgetResizable(True); ls.setMinimumWidth(295); ls.setMaximumWidth(360)
        lw = QWidget(); ls.setWidget(lw)
        lv = QVBoxLayout(lw); lv.setContentsMargins(14,12,10,12); lv.setSpacing(6)

        hdr = QLabel("\u29eb  Tag Definition")
        hdr.setStyleSheet(f"font:bold 14px Consolas;color:{PAL['accent']};margin-bottom:4px;")
        lv.addWidget(hdr)

        ig = QGroupBox("IDENTITY"); ifl = QFormLayout(ig)
        ifl.setLabelAlignment(Qt.AlignmentFlag.AlignRight); ifl.setSpacing(6)
        self._tf_name  = QLineEdit(); self._tf_name.setPlaceholderText("my_tag")
        self._tf_label = QLineEdit(); self._tf_label.setPlaceholderText("My Tag")
        self._tf_cat   = QComboBox(); [self._tf_cat.addItem(c) for c in TAG_CATEGORIES]
        self._tf_grp   = QComboBox(); [self._tf_grp.addItem(g) for g in TAG_GROUPS]
        self._tf_icon  = QLineEdit(); self._tf_icon.setPlaceholderText("\u00b7"); self._tf_icon.setMaximumWidth(60)
        self._tf_desc  = QTextEdit(); self._tf_desc.setFixedHeight(56); self._tf_desc.setPlaceholderText("What this tag does\u2026")
        ifl.addRow("name:",self._tf_name); ifl.addRow("label:",self._tf_label)
        ifl.addRow("category:",self._tf_cat); ifl.addRow("group:",self._tf_grp)
        ifl.addRow("icon:",self._tf_icon); ifl.addRow("desc:",self._tf_desc)
        lv.addWidget(ig)

        cg = QGroupBox("COLOR  [R, G, B]"); ch = QHBoxLayout(cg)
        self._tf_r = QSpinBox(); self._tf_r.setRange(0,255); self._tf_r.setPrefix("R ")
        self._tf_g = QSpinBox(); self._tf_g.setRange(0,255); self._tf_g.setPrefix("G ")
        self._tf_b = QSpinBox(); self._tf_b.setRange(0,255); self._tf_b.setPrefix("B ")
        self._tf_r.setValue(100); self._tf_g.setValue(140); self._tf_b.setValue(200)
        self._cprev = QLabel("   "); self._cprev.setFixedSize(28,22)
        self._cprev.setStyleSheet("border-radius:4px;border:1px solid #2a3040;")
        ch.addWidget(self._tf_r); ch.addWidget(self._tf_g); ch.addWidget(self._tf_b); ch.addWidget(self._cprev)
        lv.addWidget(cg)

        mg = QGroupBox("MISC"); mfl = QFormLayout(mg)
        self._tf_default = QComboBox(); self._tf_default.addItems(["false","true"])
        self._tf_type    = QComboBox(); self._tf_type.addItems(["bool","int","float","str"])
        mfl.addRow("default:",self._tf_default); mfl.addRow("type:",self._tf_type)
        lv.addWidget(mg); lv.addStretch()

        for w in (self._tf_name, self._tf_label, self._tf_icon):
            w.textChanged.connect(self._on_field)
        for w in (self._tf_cat, self._tf_grp, self._tf_default, self._tf_type):
            w.currentTextChanged.connect(self._on_field)
        for w in (self._tf_r, self._tf_g, self._tf_b):
            w.valueChanged.connect(self._on_field)
        self._tf_desc.textChanged.connect(self._on_field)
        root.addWidget(ls)

        # Right: function code editor tabs
        rw = QWidget(); rv = QVBoxLayout(rw); rv.setContentsMargins(0,0,0,0); rv.setSpacing(0)
        fn_hdr = QLabel("  \u0192  FUNCTION CODE")
        fn_hdr.setStyleSheet(f"background:{PAL['panel']};color:{PAL['text_dim']};font:bold 8px Consolas;letter-spacing:3px;padding:6px 12px;border-bottom:1px solid {PAL['border']};")
        rv.addWidget(fn_hdr)

        self._fn_tabs = QTabWidget()
        self._fn_editors: dict[str, QTextEdit] = {}
        for fn_name, stub in TAG_FUNC_STUBS.items():
            ed = QTextEdit(); ed.setFont(QFont("Consolas",10)); ed.setPlainText(stub)
            _PythonHL(ed.document()); ed.textChanged.connect(self._on_func)
            self._fn_editors[fn_name] = ed
            tab = QWidget(); tl = QVBoxLayout(tab); tl.setContentsMargins(0,0,0,0)
            tip = QLabel(f"  # {fn_name}")
            tip.setStyleSheet(f"color:{PAL['text_dim']};font:8px Consolas;padding:4px 8px;background:{PAL['panel2']};border-bottom:1px solid {PAL['border']};")
            tl.addWidget(tip); tl.addWidget(ed)
            self._fn_tabs.addTab(tab, fn_name)
        rv.addWidget(self._fn_tabs, 1)

        # Snippet bar
        sb_w = QWidget(); sb_h = QHBoxLayout(sb_w)
        sb_h.setContentsMargins(6,4,6,4); sb_h.setSpacing(4)
        sb_h.addWidget(QLabel("  Insert:"))
        for lbl, code in [
            ("emit_noise",   "level.emit_noise(tile.x, tile.y, score=30, radius=3)\n"),
            ("tile.open()",  "tile.set_state('open')\n"),
            ("tile.close()", "tile.set_state('closed')\n"),
            ("stun actor",   "actor.apply_effect('stun', duration=1.5)\n"),
        ]:
            b = QPushButton(lbl); b.setFixedHeight(22)
            b.setStyleSheet(f"QPushButton{{background:{PAL['panel']};color:{PAL['accent']};border:1px solid {PAL['border']};border-radius:3px;padding:1px 6px;font:9px Consolas;text-align:center;}}")
            b.clicked.connect(lambda _,c=code: self._insert(c))
            sb_h.addWidget(b)
        sb_h.addStretch()
        sb_w.setStyleSheet(f"background:{PAL['panel2']};border-top:1px solid {PAL['border']};")
        rv.addWidget(sb_w)
        root.addWidget(rw, 1)

    def load(self, data):
        self._inhibit = True; self._data = data
        self._tf_name.setText(data.get("name",""))
        self._tf_label.setText(data.get("label",""))
        self._tf_desc.setPlainText(data.get("description",""))
        self._tf_icon.setText(str(data.get("icon","\u00b7")))
        def sc(cb, v):
            i = cb.findText(str(v)); cb.setCurrentIndex(max(i,0))
        sc(self._tf_cat,     data.get("category","gameplay"))
        sc(self._tf_grp,     data.get("group","gameplay"))
        sc(self._tf_default, "true" if data.get("default") else "false")
        sc(self._tf_type,    data.get("type","bool"))
        c = data.get("color",[100,140,200])
        self._tf_r.setValue(c[0] if len(c)>0 else 100)
        self._tf_g.setValue(c[1] if len(c)>1 else 140)
        self._tf_b.setValue(c[2] if len(c)>2 else 200)
        self._upd_color()
        funcs = data.get("_funcs",{})
        for fn, ed in self._fn_editors.items():
            ed.blockSignals(True); ed.setPlainText(funcs.get(fn, TAG_FUNC_STUBS.get(fn,""))); ed.blockSignals(False)
        self._inhibit = False

    def collect(self):
        if self._inhibit: return self._data
        d = self._data
        d["name"]        = self._tf_name.text().strip() or "my_tag"
        d["label"]       = self._tf_label.text().strip() or d["name"].replace("_"," ").title()
        d["description"] = self._tf_desc.toPlainText().strip()
        d["icon"]        = self._tf_icon.text().strip() or "\u00b7"
        d["category"]    = self._tf_cat.currentText()
        d["group"]       = self._tf_grp.currentText()
        d["default"]     = self._tf_default.currentText() == "true"
        d["type"]        = self._tf_type.currentText()
        d["color"]       = [self._tf_r.value(), self._tf_g.value(), self._tf_b.value()]
        d["_funcs"]      = {fn: ed.toPlainText() for fn, ed in self._fn_editors.items()}
        return d

    def _on_field(self, *_):
        if not self._inhibit: self._upd_color(); self.collect(); self.changed.emit()
    def _on_func(self):
        if not self._inhibit: self.collect(); self.changed.emit()
    def _upd_color(self):
        r,g,b = self._tf_r.value(), self._tf_g.value(), self._tf_b.value()
        self._cprev.setStyleSheet(f"background:rgb({r},{g},{b});border-radius:4px;border:1px solid #2a3040;")
    def _insert(self, code):
        idx = self._fn_tabs.currentIndex()
        ed  = list(self._fn_editors.values())[idx]
        cur = ed.textCursor(); cur.insertText(code); ed.setTextCursor(cur)

# ═════════════════════════════════════════════════════════════════════════════
#  Main Forgemason Window
# ═════════════════════════════════════════════════════════════════════════════

class ForgeMason(QMainWindow):
    MODE_TILE = "tile"; MODE_TAG = "tag"

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Forgemason  \u2013  LockESC")
        self.resize(1200, 780)
        self._mode = self.MODE_TILE; self._data: dict = {}
        self._filepath: str|None = None; self._unsaved = False; self._inhibit = False
        self._tag_chips: dict[str,_TagChip] = {}
        self._noise_btns: list = []; self._visual_btns: list = []; self._sound_btns: list = []
        self._rebuild_timer = QTimer(self); self._rebuild_timer.setSingleShot(True)
        self._rebuild_timer.timeout.connect(self._sync_json_from_fields)
        self._build_ui(); self.setStyleSheet(SS)

    def _build_ui(self):
        bar = self.menuBar(); fm = bar.addMenu("Forgemason")
        fm.addAction(QAction("Welcome\u2026",self,shortcut="Ctrl+W",triggered=self._cmd_welcome))
        fm.addSeparator()
        fm.addAction(QAction("New Tile",self,shortcut="Ctrl+N",triggered=self._cmd_new_tile))
        fm.addAction(QAction("Load Tile\u2026",self,shortcut="Ctrl+O",triggered=self._cmd_load_tile))
        fm.addSeparator()
        fm.addAction(QAction("New Tag",self,shortcut="Ctrl+Shift+N",triggered=self._cmd_new_tag))
        fm.addAction(QAction("Load Tag\u2026",self,shortcut="Ctrl+Shift+O",triggered=self._cmd_load_tag))
        fm.addSeparator()
        fm.addAction(QAction("Save",self,shortcut="Ctrl+S",triggered=self._cmd_save))
        fm.addAction(QAction("Save As\u2026",self,shortcut="Ctrl+Shift+S",triggered=self._cmd_save_as))
        fm.addSeparator()
        fm.addAction(QAction("Compile Tags + Rebuild Cache",self,shortcut="Ctrl+B",triggered=self._cmd_compile))
        fm.addSeparator()
        fm.addAction(QAction("Close",self,triggered=self.close))
        self._status = QStatusBar(); self.setStatusBar(self._status)
        self._status.showMessage("  \u26d2  Forgemason ready")
        root = QWidget(); self.setCentralWidget(root)
        hl = QHBoxLayout(root); hl.setContentsMargins(0,0,0,0); hl.setSpacing(0)
        self._stack = QStackedWidget()
        self._build_tile_page(); self._build_tag_page()
        hl.addWidget(self._stack)

    # ── Tile page ─────────────────────────────────────────────────────────────

    def _build_tile_page(self):
        page = QWidget(); hl = QHBoxLayout(page); hl.setContentsMargins(0,0,0,0); hl.setSpacing(0)
        ls = QScrollArea(); ls.setWidgetResizable(True); ls.setMinimumWidth(360); ls.setMaximumWidth(440)
        lw = QWidget(); ls.setWidget(lw)
        self._left_vbox = QVBoxLayout(lw); self._left_vbox.setContentsMargins(18,16,14,16); self._left_vbox.setSpacing(8)
        self._build_tile_left(); hl.addWidget(ls)
        cw = QWidget(); cv = QVBoxLayout(cw); cv.setContentsMargins(0,0,0,0); cv.setSpacing(0)
        cv.addWidget(self._sec_lbl("  JSON  \u00b7  LIVE PREVIEW"))
        self._code = QTextEdit(); self._code.setFont(QFont("Consolas",10))
        self._code.setPlaceholderText("// \u26d2  Welcome to Forgemason\n// \u27a4  New Tile  or  Load Tile  to begin\n")
        _JsonHL(self._code.document()); self._code.textChanged.connect(self._on_code_changed)
        cv.addWidget(self._code, 1); hl.addWidget(cw, 1)
        rs = QScrollArea(); rs.setWidgetResizable(True); rs.setMinimumWidth(230); rs.setMaximumWidth(280)
        rw = QWidget(); rs.setWidget(rw)
        self._right_vbox = QVBoxLayout(rw); self._right_vbox.setContentsMargins(10,14,14,14); self._right_vbox.setSpacing(6)
        self._build_tag_panel(); hl.addWidget(rs)
        self._stack.addWidget(page)

    def _build_tile_left(self):
        v = self._left_vbox
        t = QLabel("\u26d2  Forgemason"); t.setStyleSheet(f"font:bold 22px Consolas;color:{PAL['forge']};letter-spacing:1px;")
        s = QLabel("LockESC  Tile  Editor  (.let)"); s.setStyleSheet(f"font:9px Consolas;color:{PAL['text_dim']};margin-bottom:8px;")
        v.addWidget(t); v.addWidget(s)
        h1 = QHBoxLayout(); h1.setSpacing(6)
        self._btn_new = QPushButton("\u2295  New Tile +")
        self._btn_new.setStyleSheet(f"QPushButton{{background:{PAL['green']};color:#aaffaa;border-color:#1a4a20;}}QPushButton:hover{{background:{PAL['green_hi']};}}")
        self._btn_new.clicked.connect(self._cmd_new_tile); h1.addWidget(self._btn_new)
        self._btn_load = QPushButton("\U0001f4c2  Load Tile\u2026"); self._btn_load.clicked.connect(self._cmd_load_tile); h1.addWidget(self._btn_load)
        v.addLayout(h1)
        h2 = QHBoxLayout(); h2.setSpacing(6)
        self._btn_save = QPushButton("\U0001f4be  Save")
        self._btn_save.setStyleSheet(f"QPushButton{{background:{PAL['forge']};color:#ffddcc;border-color:#602010;}}QPushButton:hover{{background:{PAL['forge_hi']};}}")
        self._btn_save.clicked.connect(self._cmd_save); h2.addWidget(self._btn_save)
        self._btn_save_as = QPushButton("Save As\u2026"); self._btn_save_as.clicked.connect(self._cmd_save_as); h2.addWidget(self._btn_save_as)
        v.addLayout(h2)
        wb = QPushButton("\u2190 Welcome"); wb.clicked.connect(self._cmd_welcome); v.addWidget(wb)
        self._add_sep(v)
        ig = QGroupBox("IDENTITY"); ifl = QFormLayout(ig); ifl.setLabelAlignment(Qt.AlignmentFlag.AlignRight); ifl.setSpacing(6)
        self._f_type = QLineEdit(); self._f_type.setPlaceholderText("my_tile")
        self._f_label = QLineEdit(); self._f_label.setPlaceholderText("My Tile")
        self._f_cat = QComboBox(); [self._f_cat.addItem(c) for c in CATEGORIES]
        for w in (self._f_type, self._f_label, self._f_cat): w.setEnabled(False)
        ifl.addRow("type:",self._f_type); ifl.addRow("label:",self._f_label); ifl.addRow("category:",self._f_cat)
        v.addWidget(ig)
        self._flag_checks: dict[str,QCheckBox] = {}
        for gname, flags in FLAG_GROUPS.items():
            grp = QGroupBox(gname.upper()); gv = QVBoxLayout(grp); gv.setSpacing(3)
            for flag in flags:
                ti = TAGS.get(flag, {}); icon = ti.get("icon","")
                cb = QCheckBox(f"{icon}  {flag}"); cb.setToolTip(ti.get("description",flag)); cb.setEnabled(False)
                cb.stateChanged.connect(lambda _,f=flag: self._on_flag_changed(f))
                self._flag_checks[flag] = cb; gv.addWidget(cb)
            v.addWidget(grp)
        pg = QGroupBox("PRESETS"); pv = QVBoxLayout(pg); pv.setSpacing(4)
        for lbl, presets, attr, handler in [
            ("Noise:",NOISE_PRESETS,"_noise_btns",self._apply_noise_preset),
            ("Visuals:",VISUAL_PRESETS,"_visual_btns",self._apply_visual_preset),
            ("Sound:",SOUND_PRESETS,"_sound_btns",self._apply_sound_preset),
        ]:
            pv.addWidget(QLabel(lbl)); ph = QHBoxLayout(); ph.setSpacing(4); btns=[]
            for nm in presets:
                b=QPushButton(nm); b.setEnabled(False); b.setFixedHeight(26)
                b.clicked.connect(lambda _,n=nm,h=handler: h(n)); ph.addWidget(b); btns.append(b)
            setattr(self,attr,btns); pv.addLayout(ph)
        v.addWidget(pg)
        dg = QGroupBox("DEFAULTS (JSON inline)"); dv = QVBoxLayout(dg)
        self._f_defaults = QTextEdit(); self._f_defaults.setFixedHeight(60)
        self._f_defaults.setPlaceholderText('{"open": false}'); self._f_defaults.setEnabled(False)
        self._f_defaults.textChanged.connect(lambda: self._schedule_rebuild())
        dv.addWidget(self._f_defaults); v.addWidget(dg)
        v.addStretch()
        ft = QLabel("  Save: integrity/tiles/CUSTOM/ (new)\n  or original file path (existing)")
        ft.setStyleSheet(f"color:{PAL['text_dim']};font:8px Consolas;"); v.addWidget(ft)

    def _build_tag_panel(self):
        v = self._right_vbox
        v.addWidget(self._make_lbl("\u29eb  INDENTS  (TAGS)", f"font:bold 9px Consolas;color:{PAL['forge']};letter-spacing:2px;margin-bottom:6px;"))
        v.addWidget(self._make_lbl("Click a chip to toggle that\nIndent on/off for this tile.", f"font:9px Consolas;color:{PAL['text_dim']};margin-bottom:10px;"))
        if not _HAS_TAGS or not TAGS:
            v.addWidget(QLabel("(no tags loaded)")); v.addStretch(); return
        for group in sorted(tags_by_group().keys()):
            v.addWidget(self._make_lbl(group.upper(), f"font:bold 8px Consolas;color:{PAL['text_dim']};letter-spacing:3px;margin-top:8px;"))
            for tag in tags_by_group()[group]:
                chip = _TagChip(tag); chip.setEnabled(False)
                chip.toggled_tag.connect(self._on_tag_chip_toggled)
                self._tag_chips[tag["name"]] = chip; v.addWidget(chip)
        v.addStretch()
        rel = QPushButton("\u21ba  Reload Tags"); rel.setToolTip("Re-read .lei files and refresh chips."); rel.clicked.connect(self._reload_tags); v.addWidget(rel)

    # ── Tag page ──────────────────────────────────────────────────────────────

    def _build_tag_page(self):
        page = QWidget(); rv = QVBoxLayout(page); rv.setContentsMargins(0,0,0,0); rv.setSpacing(0)
        tb = QWidget(); tb.setStyleSheet(f"background:{PAL['panel']};border-bottom:1px solid {PAL['border']};")
        tbh = QHBoxLayout(tb); tbh.setContentsMargins(12,6,12,6); tbh.setSpacing(8)
        tbh.addWidget(self._make_lbl("\u29eb  Forgemason  \u2014  Tag Editor  (.lei)", f"font:bold 12px Consolas;color:{PAL['accent']};background:transparent;"))
        tbh.addStretch()
        for lbl, slot, xss in [
            ("\u2295  New Tag +", self._cmd_new_tag, f"background:#0a1220;color:{PAL['accent']};border-color:#162038;"),
            ("\U0001f4c2  Load Tag\u2026", self._cmd_load_tag, ""),
            ("\U0001f4be  Save", self._cmd_save, f"background:{PAL['forge']};color:#ffddcc;border-color:#602010;"),
            ("Save As\u2026", self._cmd_save_as, ""),
            ("\u2699  Compile + Cache", self._cmd_compile, "background:#10200a;color:#5aaa40;border-color:#1e4018;"),
            ("\u2190 Welcome", self._cmd_welcome, ""),
        ]:
            b = QPushButton(lbl)
            if xss: b.setStyleSheet(f"QPushButton{{{xss}}}")
            b.clicked.connect(slot); tbh.addWidget(b)
        rv.addWidget(tb)
        self._tag_editor = TagEditorWidget(); self._tag_editor.changed.connect(self._mark_unsaved)
        rv.addWidget(self._tag_editor, 1)
        hint = QLabel("  \u27f5 fields    |    function code \u27f6    |    Save \u2192 builttags compile + cache.pkl for pygame")
        hint.setStyleSheet(f"background:{PAL['panel2']};color:{PAL['text_dim']};font:8px Consolas;padding:4px 12px;border-top:1px solid {PAL['border']};")
        rv.addWidget(hint); self._stack.addWidget(page)

    # ── Mode switch ───────────────────────────────────────────────────────────

    def _switch_mode(self, mode):
        self._mode = mode
        if mode == self.MODE_TILE:
            self._stack.setCurrentIndex(0); self.setWindowTitle("Forgemason  \u2013  Tile Editor  \u00b7  LockESC")
        else:
            self._stack.setCurrentIndex(1); self.setWindowTitle("Forgemason  \u2013  Tag Editor  \u00b7  LockESC")

    # ── Welcome ───────────────────────────────────────────────────────────────

    def _cmd_welcome(self):
        if self._unsaved and self._data:
            r = QMessageBox.question(self, "Unsaved Changes", "Save before returning to welcome?",
                QMessageBox.StandardButton.Save|QMessageBox.StandardButton.Discard|QMessageBox.StandardButton.Cancel)
            if r == QMessageBox.StandardButton.Save: self._cmd_save()
            elif r == QMessageBox.StandardButton.Cancel: return
        dlg = ForgemasonWelcome(self)
        if dlg.exec() != QDialog.DialogCode.Accepted: return
        a = dlg.action; p = dlg.chosen_path
        if   a == ForgemasonWelcome.A_NEW_TILE:           self._cmd_new_tile()
        elif a == ForgemasonWelcome.A_LOAD_TILE and p:     self._load_tile_from_path(p)
        elif a == ForgemasonWelcome.A_NEW_TAG:             self._cmd_new_tag()
        elif a == ForgemasonWelcome.A_LOAD_TAG  and p:     self._load_tag_from_path(p)

    # ── Tile commands ─────────────────────────────────────────────────────────

    def _cmd_new_tile(self):
        name, ok = self._ask_name("Tile type name (snake_case):", "my_tile")
        if not ok or not name: return
        name = name.strip().lower().replace(" ","_")
        self._data = _blank_let(name); self._filepath = None; self._unsaved = False
        self._switch_mode(self.MODE_TILE); self._set_tile_enabled(True)
        self._load_into_form(); self._refresh_code()
        self.setWindowTitle(f"Forgemason  \u2013  {name}  [new]")
        self._status.showMessage(f"  \u2295  New tile: {name}   (unsaved)")

    def _cmd_load_tile(self):
        p, _ = QFileDialog.getOpenFileName(self, "Open Tile Definition", DEFAULT_TILE_DIR, "LockESC Tile (*.let);;All Files (*)")
        if p: self._load_tile_from_path(p)

    def _load_tile_from_path(self, path):
        try:
            with open(path, encoding="utf-8") as f: data = json.load(f)
        except Exception as e: QMessageBox.critical(self,"Load Error",str(e)); return
        self._data = data; self._filepath = path; self._unsaved = False
        self._switch_mode(self.MODE_TILE); self._set_tile_enabled(True)
        self._load_into_form(); self._refresh_code()
        self.setWindowTitle(f"Forgemason  \u2013  {os.path.basename(path)}")
        self._status.showMessage(f"  \u2713  Loaded: {path}")

    # ── Tag commands ──────────────────────────────────────────────────────────

    def _cmd_new_tag(self):
        name, ok = self._ask_name("Tag name (snake_case):", "my_tag")
        if not ok or not name: return
        name = name.strip().lower().replace(" ","_")
        self._data = _blank_lei(name); self._filepath = None; self._unsaved = False
        self._switch_mode(self.MODE_TAG); self._tag_editor.load(self._data)
        self.setWindowTitle(f"Forgemason  \u2013  \u29eb {name}  [new]")
        self._status.showMessage(f"  \u29eb  New tag: {name}   (unsaved)")

    def _cmd_load_tag(self):
        p, _ = QFileDialog.getOpenFileName(self, "Open Tag Definition", DEFAULT_TAG_DIR, "LockESC Tag (*.lei);;All Files (*)")
        if p: self._load_tag_from_path(p)

    def _load_tag_from_path(self, path):
        try:
            with open(path, encoding="utf-8") as f: data = _lei_from_text(f.read())
        except Exception as e: QMessageBox.critical(self,"Load Error",str(e)); return
        self._data = data; self._filepath = path; self._unsaved = False
        self._switch_mode(self.MODE_TAG); self._tag_editor.load(self._data)
        self.setWindowTitle(f"Forgemason  \u2013  \u29eb {os.path.basename(path)}")
        self._status.showMessage(f"  \u2713  Loaded tag: {path}")

    # ── Compile ───────────────────────────────────────────────────────────────

    def _cmd_compile(self):
        self._status.showMessage("  \u21bb  Compiling builttags + writing cache\u2026")
        QApplication.processEvents()
        _compile_builttags_and_cache(status_fn=lambda m: self._status.showMessage(m))

    # ── Save ──────────────────────────────────────────────────────────────────

    def _cmd_save(self):
        if not self._data: return
        if not self._filepath: self._cmd_save_as(); return
        self._write(self._filepath)

    def _cmd_save_as(self):
        if not self._data: return
        if self._mode == self.MODE_TILE:
            os.makedirs(CUSTOM_TILE_DIR, exist_ok=True)
            default = os.path.join(CUSTOM_TILE_DIR, f"{self._data.get('type','my_tile')}.let")
            p,_ = QFileDialog.getSaveFileName(self,"Save Tile As",default,"LockESC Tile (*.let);;All Files (*)")
        else:
            os.makedirs(CUSTOM_TAG_DIR, exist_ok=True)
            default = os.path.join(CUSTOM_TAG_DIR, f"{self._data.get('name','my_tag')}.lei")
            p,_ = QFileDialog.getSaveFileName(self,"Save Tag As",default,"LockESC Tag (*.lei);;All Files (*)")
        if not p: return
        self._filepath = p; self._write(p)

    def _write(self, path):
        try:
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
            if self._mode == self.MODE_TILE:
                self._sync_json_from_fields()
                with open(path,"w",encoding="utf-8") as f:
                    json.dump(self._data,f,indent=2,ensure_ascii=False); f.write("\n")
            else:
                self._data = self._tag_editor.collect()
                with open(path,"w",encoding="utf-8") as f:
                    f.write(_lei_to_text(self._data))
                _compile_builttags_and_cache(status_fn=lambda m: self._status.showMessage(m))
        except Exception as e: QMessageBox.critical(self,"Save Error",str(e)); return
        self._unsaved = False
        self.setWindowTitle(f"Forgemason  \u2013  {os.path.basename(path)}")
        self._status.showMessage(f"  \u2713  Saved: {path}")

    # ── Tile form ─────────────────────────────────────────────────────────────

    def _set_tile_enabled(self, on):
        for w in (self._f_type,self._f_label,self._f_cat,self._f_defaults,self._btn_save,self._btn_save_as):
            w.setEnabled(on)
        for cb in self._flag_checks.values(): cb.setEnabled(on)
        for chip in self._tag_chips.values(): chip.setEnabled(on)
        for lst in (self._noise_btns,self._visual_btns,self._sound_btns):
            for b in lst: b.setEnabled(on)

    def _load_into_form(self):
        self._inhibit = True; d = self._data
        self._f_type.setText(d.get("type","")); self._f_label.setText(d.get("label",""))
        i = self._f_cat.findText(d.get("category","structure")); self._f_cat.setCurrentIndex(max(i,0))
        flags = d.get("flags",{})
        for name, cb in self._flag_checks.items(): cb.setChecked(bool(flags.get(name,False)))
        for tn, chip in self._tag_chips.items():
            chip.blockSignals(True); chip.setChecked(bool(flags.get(tn,False))); chip.blockSignals(False); chip._refresh_style()
        defs = d.get("defaults",{})
        self._f_defaults.setPlainText(json.dumps(defs,indent=2) if defs else "")
        self._inhibit = False

    def _sync_json_from_fields(self):
        if self._inhibit or not self._data or self._mode != self.MODE_TILE: return
        d = self._data
        d["type"]     = self._f_type.text().strip() or "my_tile"
        d["label"]    = self._f_label.text().strip() or d["type"].replace("_"," ").title()
        d["category"] = self._f_cat.currentText()
        d["_comment"] = f"LockESC Tile Definition (.let) \u2013 {d['type']}"
        flags = d.setdefault("flags",{})
        for name, cb in self._flag_checks.items(): flags[name] = cb.isChecked()
        try:
            txt = self._f_defaults.toPlainText().strip()
            d["defaults"] = json.loads(txt) if txt else {}
        except json.JSONDecodeError: pass
        self._refresh_code()

    def _refresh_code(self):
        self._inhibit = True; cp = self._code.textCursor().position()
        try: text = json.dumps(self._data, indent=2, ensure_ascii=False)
        except Exception as e: text = f"// JSON error: {e}"
        self._code.setPlainText(text)
        c = self._code.textCursor(); c.setPosition(min(cp,len(text))); self._code.setTextCursor(c)
        self._inhibit = False; self._mark_unsaved()

    def _on_code_changed(self):
        if self._inhibit or self._mode != self.MODE_TILE: return
        text = self._code.toPlainText().strip()
        if not text: return
        try: parsed = json.loads(text)
        except json.JSONDecodeError:
            self._status.showMessage("  \u2717  JSON parse error"); return
        self._inhibit = True; self._data = parsed; self._load_into_form(); self._inhibit = False
        self._status.showMessage("  \u2713  JSON parsed OK"); self._mark_unsaved()

    def _on_flag_changed(self, flag_name):
        if self._inhibit: return
        chip = self._tag_chips.get(flag_name)
        if chip:
            chip.blockSignals(True); chip.setChecked(self._flag_checks[flag_name].isChecked()); chip.blockSignals(False); chip._refresh_style()
        self._schedule_rebuild()

    def _on_tag_chip_toggled(self, tag_name, state):
        if self._inhibit: return
        cb = self._flag_checks.get(tag_name)
        if cb: cb.blockSignals(True); cb.setChecked(state); cb.blockSignals(False)
        if self._data: self._data.setdefault("flags",{})[tag_name] = state; self._refresh_code()

    def _apply_noise_preset(self, n):
        if not self._data: return
        self._data["noise"] = copy.deepcopy(NOISE_PRESETS[n]); self._refresh_code(); self._status.showMessage(f"  Noise: {n}")

    def _apply_visual_preset(self, n):
        if not self._data: return
        self._data["visuals"] = copy.deepcopy(VISUAL_PRESETS[n]); self._refresh_code(); self._status.showMessage(f"  Visual: {n}")

    def _apply_sound_preset(self, n):
        if not self._data: return
        self._data["sound"] = copy.deepcopy(SOUND_PRESETS[n]); self._refresh_code(); self._status.showMessage(f"  Sound: {n}")

    def _schedule_rebuild(self): self._rebuild_timer.start(80)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _sec_lbl(self, text):
        lbl = QLabel(text)
        lbl.setStyleSheet(f"background:{PAL['panel']};color:{PAL['text_dim']};font:bold 8px Consolas;letter-spacing:3px;padding:6px 12px;border-bottom:1px solid {PAL['border']};")
        return lbl

    def _make_lbl(self, text, style=""):
        lbl = QLabel(text); lbl.setStyleSheet(style); return lbl

    def _add_sep(self, layout):
        line = QFrame(); line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet(f"background:{PAL['border']};"); line.setFixedHeight(1)
        layout.addWidget(line); layout.addSpacing(4)

    def _ask_name(self, prompt, default):
        dlg = QDialog(self); dlg.setWindowTitle("Forgemason"); dlg.setStyleSheet(SS); dlg.resize(340,120)
        v = QVBoxLayout(dlg); v.addWidget(QLabel(prompt))
        edit = QLineEdit(default); edit.selectAll(); v.addWidget(edit)
        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(dlg.accept); btns.rejected.connect(dlg.reject); v.addWidget(btns)
        return edit.text(), dlg.exec() == QDialog.DialogCode.Accepted

    def _mark_unsaved(self):
        self._unsaved = True
        if self._filepath: self.setWindowTitle(f"Forgemason  \u2013  {os.path.basename(self._filepath)}  \u2022")

    def _reload_tags(self):
        import importlib
        try:
            import builttags; importlib.reload(builttags)
            global TAGS; TAGS = builttags.TAGS
            while self._right_vbox.count():
                item = self._right_vbox.takeAt(0)
                if item.widget(): item.widget().deleteLater()
            self._tag_chips.clear(); self._build_tag_panel()
            self._status.showMessage("  \u21ba  Tags reloaded")
        except Exception as e: QMessageBox.warning(self,"Reload Tags",str(e))

    def closeEvent(self, event):
        if self._unsaved and self._data:
            r = QMessageBox.question(self,"Unsaved Changes","Save before closing?",
                QMessageBox.StandardButton.Save|QMessageBox.StandardButton.Discard|QMessageBox.StandardButton.Cancel)
            if r == QMessageBox.StandardButton.Save: self._cmd_save(); event.accept()
            elif r == QMessageBox.StandardButton.Discard: event.accept()
            else: event.ignore()
        else: event.accept()

    def show_and_welcome(self):
        self.show(); self._cmd_welcome()

# ═════════════════════════════════════════════════════════════════════════════
#  CLI arg parser + entry points
# ═════════════════════════════════════════════════════════════════════════════

def _parse_cli_args():
    """Parse --action and --path CLI arguments (used when launched from keyring.py)."""
    action = ""; path = ""; args = sys.argv[1:]; i = 0
    while i < len(args):
        if args[i] == "--action" and i+1 < len(args): action = args[i+1]; i += 2
        elif args[i] == "--path" and i+1 < len(args): path = args[i+1]; i += 2
        else: i += 1
    return action, path


def launch():
    """Launch Forgemason (called from keyring.py launcher)."""
    app = QApplication.instance() or QApplication(sys.argv)
    win = ForgeMason(); win.show_and_welcome()
    if not QApplication.instance(): sys.exit(app.exec())
    else: app.exec()


if __name__ == "__main__":
    app = QApplication(sys.argv); app.setStyle("Fusion")
    _ico = os.path.join(os.path.dirname(os.path.abspath(__file__)), "forgemason.ico")
    if os.path.isfile(_ico):
        from PyQt6.QtGui import QIcon
        app.setWindowIcon(QIcon(_ico))
    win = ForgeMason()
    action, path = _parse_cli_args()
    # If launched with --action from keyring.py, skip welcome and open directly.
    if   action == "new_tile":             win.show(); win._cmd_new_tile()
    elif action == "load_tile" and path:   win.show(); win._load_tile_from_path(path)
    elif action == "new_tag":              win.show(); win._cmd_new_tag()
    elif action == "load_tag"  and path:   win.show(); win._load_tag_from_path(path)
    else:                                  win.show_and_welcome()
    sys.exit(app.exec())
