"""
monicle.py  –  Monicle Editor
══════════════════════════════
A .lev visual-definition viewer and real-time live editor.

 •  Open any .lev file OR just start typing JSON in the code panel.
 •  Preview updates instantly as you type (50 ms debounce).
 •  State strip: ALL visual states of a tile, side-by-side, with correct
    per-state colours drawn from the companion .let file.
 •  Drag the divider between code and preview freely.
 •  Zoom / tile-size slider.  Save back to the .lev file.

Part of the KeyRing · LockESC toolchain.
Run standalone:  python .editortools/monicle.py
"""

import sys, os, json, math, copy

_HERE = os.path.dirname(os.path.abspath(__file__))

def _find_project_root(start):
    # Walk up until we find integrity/tiles/ + integrity/functions/ — works
    # whether monicle.py is in .editortools/ or deeper inside the project tree.
    d = start
    for _ in range(12):
        if (os.path.isdir(os.path.join(d, "integrity", "tiles")) and
                os.path.isdir(os.path.join(d, "integrity", "functions"))):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return os.path.dirname(start)   # last-resort fallback

_ROOT = _find_project_root(_HERE)
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QSplitter, QLabel, QPushButton, QFileDialog, QMessageBox,
    QSlider, QStatusBar, QComboBox, QPlainTextEdit,
    QTabWidget, QListWidget, QListWidgetItem, QCheckBox,
    QScrollArea, QGroupBox, QLineEdit, QGridLayout, QFrame,
    QTreeWidget, QTreeWidgetItem, QDialog, QDialogButtonBox,
    QAbstractItemView, QSizePolicy,
)
from PyQt6.QtCore import Qt, QTimer, QRect, QPoint
from PyQt6.QtGui  import (
    QPainter, QColor, QPen, QBrush, QFont, QPolygon,
    QSyntaxHighlighter, QTextCharFormat, QTextDocument,
    QRadialGradient, QKeySequence, QAction, QPixmap, QIcon,
)

try:
    from keyring import _thin_wall_segs
    _HAS_KR = True
except ImportError:
    _HAS_KR = False
    def _thin_wall_segs(rx, ry, tp, shape, rot):
        cy = ry + tp // 2
        return [(rx + 2, cy, rx + tp - 2, cy)]


# ═════════════════════════════════════════════════════════════════════════════
#  .let helpers
# ═════════════════════════════════════════════════════════════════════════════

def _load_let(tile_type: str) -> dict:
    tile_dir = os.path.join(_ROOT, "integrity", "tiles")
    for d in (os.path.join(tile_dir, "CUSTOM"), tile_dir):
        p = os.path.join(d, f"{tile_type}.let")
        if os.path.isfile(p):
            try:
                with open(p, encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
    return {}


# ═════════════════════════════════════════════════════════════════════════════
#  State derivation
# ═════════════════════════════════════════════════════════════════════════════

_THIN_SHAPES = [
    ("straight",  0), ("straight", 90),
    ("corner",    0), ("corner",   90),
    ("T",         0), ("plus",     0),
]


def _derive_states(flags: dict, tile_type: str) -> list:
    """Return [(label, obj_dict), ...] for every distinct visual state."""
    is_thin     = flags.get("thin", False)
    openable    = flags.get("has_open_state", False) or flags.get("openable", False)
    bashable    = flags.get("bashable", False) or flags.get("crashable", False)
    collectible = flags.get("collectible", False)

    if is_thin and tile_type in ("thin_wall", "thin_door"):
        states = [(shape + (f" {rot}°" if rot else ""),
                   {"shape": shape, "rotation": rot, "open": False})
                  for shape, rot in _THIN_SHAPES]
        if tile_type == "thin_door":
            states += [("open " + shape + (f" {rot}°" if rot else ""),
                        {"shape": shape, "rotation": rot, "open": True})
                       for shape, rot in _THIN_SHAPES]
        return states

    if openable:
        states = [("closed", {"open": False}), ("open", {"open": True})]
        if bashable:
            states.append(("bashed", {"open": True, "bashed": True}))
        return states

    if collectible:
        return [("present", {}), ("collected", {"collected": True})]

    return [("default", {})]


# ═════════════════════════════════════════════════════════════════════════════
#  Layer renderer
# ═════════════════════════════════════════════════════════════════════════════

def _c(raw, fallback=None) -> QColor:
    if isinstance(raw, (list, tuple)) and len(raw) >= 3:
        return QColor(int(raw[0]), int(raw[1]), int(raw[2]),
                      int(raw[3]) if len(raw) > 3 else 255)
    return fallback or QColor(180, 180, 180)


def _render_layers(p: QPainter, layers: list, rx: int, ry: int, tp: int,
                   obj: dict = None):
    """Draw the layer list exactly as given (no state substitution)."""
    obj = obj or {}
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing)

    def px(f): return rx + int(f * tp)
    def py(f): return ry + int(f * tp)
    def pw(f): return max(1, int(f * tp))

    for layer in layers:
        if not isinstance(layer, dict):
            continue
        t   = layer.get("type", "")
        col = _c(layer.get("color"), QColor(200, 200, 200))
        lw  = pw(layer.get("pen_width", 0.04))
        x0  = px(layer.get("x", 0.0));  y0 = py(layer.get("y", 0.0))
        w0  = pw(layer.get("w", 1.0));  h0 = pw(layer.get("h", 1.0))
        pst = Qt.PenStyle.DashLine if layer.get("dashed") else Qt.PenStyle.SolidLine
        rnd = layer.get("rounded", False)

        if t == "rect":
            p.setPen(Qt.PenStyle.NoPen); p.setBrush(QBrush(col))
            p.drawRoundedRect(x0,y0,w0,h0,4,4) if rnd else p.drawRect(x0,y0,w0,h0)
        elif t == "rect_outline":
            p.setPen(QPen(col,lw,pst)); p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(x0,y0,w0,h0,4,4) if rnd else p.drawRect(x0,y0,w0,h0)
        elif t == "ellipse":
            p.setPen(Qt.PenStyle.NoPen); p.setBrush(QBrush(col))
            p.drawEllipse(x0,y0,w0,h0)
        elif t == "ellipse_outline":
            p.setPen(QPen(col,lw,pst)); p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(x0,y0,w0,h0)
        elif t == "line":
            cap = Qt.PenCapStyle.RoundCap if layer.get("cap")=="round" else Qt.PenCapStyle.FlatCap
            p.setPen(QPen(col,lw,pst,cap))
            p.drawLine(px(layer.get("x1",0.0)), py(layer.get("y1",0.0)),
                       px(layer.get("x2",1.0)), py(layer.get("y2",1.0)))
        elif t == "cross":
            p.setPen(QPen(col,lw,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap))
            p.drawLine(px(layer.get("x1",.08)),py(layer.get("y1",.08)),
                       px(layer.get("x2",.92)),py(layer.get("y2",.92)))
            p.drawLine(px(layer.get("x2",.92)),py(layer.get("y1",.08)),
                       px(layer.get("x1",.08)),py(layer.get("y2",.92)))
        elif t == "arc":
            p.setPen(QPen(col,lw)); p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawArc(x0,y0,w0,h0,int(layer.get("start_angle",0)*16),
                      int(layer.get("span_angle",90)*16))
        elif t == "pie":
            p.setPen(Qt.PenStyle.NoPen); p.setBrush(QBrush(col))
            p.drawPie(x0,y0,w0,h0,int(layer.get("start_angle",45)*16),
                      int(layer.get("span_angle",90)*16))
        elif t == "triangle":
            pts = layer.get("pts",[[.5,0],[0,1],[1,1]])
            p.setPen(Qt.PenStyle.NoPen); p.setBrush(QBrush(col))
            p.drawPolygon(QPolygon([QPoint(px(q[0]),py(q[1])) for q in pts]))
        elif t == "radial_gradient_ellipse":
            col2 = _c(layer.get("color2"),QColor(0,0,0,0))
            grad = QRadialGradient(x0+w0//2,y0+h0//2,w0//2)
            grad.setColorAt(0,col); grad.setColorAt(1,col2)
            p.setPen(Qt.PenStyle.NoPen); p.setBrush(QBrush(grad))
            p.drawEllipse(x0,y0,w0,h0)
        elif t == "text":
            if tp >= 16:
                p.setPen(QPen(col))
                p.setFont(QFont("Consolas",max(6,int(layer.get("font_scale",.25)*tp)),
                                QFont.Weight.Bold))
                p.drawText(rx,ry,tp,tp,Qt.AlignmentFlag.AlignCenter,layer.get("text","?"))
        elif t in ("hinge_dot","hinge_line"):
            _draw_hinge(p, layer, rx, ry, tp, obj)
        elif layer.get("_slats"):
            sc = _c(layer.get("slat_color"),col)
            p.setPen(QPen(sc,pw(layer.get("pen_width",.03))))
            cnt = layer.get("slat_count",5)
            for i in range(1,cnt):
                xi = rx+int(i*tp/cnt); p.drawLine(xi,ry+2,xi,ry+tp-2)
        elif layer.get("_hatch"):
            hc = _c(layer.get("hatch_color"),col)
            p.setPen(QPen(hc,pw(layer.get("pen_width",.02))))
            gap = int(layer.get("spacing",.17)*tp)
            for xi in range(0,tp*2,max(4,gap)):
                p.drawLine(rx+xi-tp,ry,rx+xi,ry+tp)
        elif layer.get("_wave"):
            wc = _c(layer.get("wave_color"),col)
            amp = layer.get("amplitude",.07)*tp; cy2 = ry+tp//2
            p.setPen(QPen(wc,pw(layer.get("pen_width",.02))))
            pts = [QPoint(xi,int(cy2+math.sin((xi-rx)*.5)*amp))
                   for xi in range(rx+4,rx+tp-3,2)]
            for i in range(len(pts)-1): p.drawLine(pts[i],pts[i+1])
        elif layer.get("_thin_wall_segments"):
            tc = _c(layer.get("color"),QColor(170,195,255))
            pen = QPen(tc,pw(layer.get("pen_width",.11)),Qt.PenStyle.SolidLine,
                       Qt.PenCapStyle.RoundCap,Qt.PenJoinStyle.RoundJoin)
            p.setPen(pen)
            for x1,y1,x2,y2 in _thin_wall_segs(rx,ry,tp,
                                                 obj.get("shape","straight"),
                                                 obj.get("rotation",0)):
                p.drawLine(x1,y1,x2,y2)
    p.restore()


def _draw_hinge(p, layer, rx, ry, tp, obj):
    obj = obj or {}
    is_open = obj.get("open", False)
    base_rot = obj.get("rotation", 0)
    H = {"top-left":(rx,ry),"top-right":(rx+tp,ry),
         "bottom-left":(rx,ry+tp),"bottom-right":(rx+tp,ry+tp),
         "left":(rx,ry+tp//2),"right":(rx+tp,ry+tp//2),
         "top":(rx+tp//2,ry),"bottom":(rx+tp//2,ry+tp)}
    hx, hy = H.get(layer.get("hinge","top-left").lower(), (rx,ry))
    ang = math.radians((layer.get("closed_angle",0) + base_rot +
                        (layer.get("open_angle",90) if is_open else 0)) % 360)
    L = tp * 0.88
    ex, ey = hx + L*math.cos(ang), hy + L*math.sin(ang)
    col = _c(layer.get("color"), QColor(200,150,50))
    if is_open: col = QColor(120,200,100)
    t = layer.get("type","")
    if t == "hinge_line":
        lw = max(2, int(layer.get("pen_width",.09)*tp))
        p.setPen(QPen(col,lw,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap))
        p.drawLine(hx,hy,int(ex),int(ey))
    elif t == "hinge_dot":
        r = int(layer.get("radius",.07)*tp)
        p.setPen(Qt.PenStyle.NoPen); p.setBrush(QBrush(col))
        p.drawEllipse(hx-r,hy-r,r*2,r*2)


# ═════════════════════════════════════════════════════════════════════════════
#  State-aware paint
#
#  The .lev files are each authored at ONE reference state (usually open/default).
#  _apply_state_colors() produces a modified deep-copy of the layers with the
#  correct colours for the requested state, taken from the .let visuals dict.
#  The substitution is layer-index-based (matching the known layer order that
#  each tile style uses) so it's exact, not heuristic.
# ═════════════════════════════════════════════════════════════════════════════

def _apply_state_colors(layers: list, vis: dict, state: str) -> list:
    """
    Return a new list of layers with colours swapped for the given state.
    state is one of: 'closed', 'open', 'bashed', 'present', 'collected', 'default'
    """
    if not vis or not layers:
        return layers

    style = vis.get("style", "")
    layers = copy.deepcopy(layers)   # never mutate the original

    def set_col(idx, key, fallback=None):
        """Set layers[idx]['color'] from vis[key], if both exist."""
        if idx < len(layers) and key in vis:
            layers[idx]["color"] = list(vis[key])
        elif idx < len(layers) and fallback:
            layers[idx]["color"] = list(fallback)

    def set_text(idx, key):
        if idx < len(layers) and key in vis:
            layers[idx]["text"] = vis[key]

    # ── bevel_door  (door, wall_door acts-as bevel when open) ─────────────────
    # layer[0]=fill rect  [1-2]=bevel_light lines  [3-4]=bevel_dark lines
    # layer[5]=knob ellipse  [6]=text label
    if style == "bevel_door":
        if state == "closed":
            set_col(0, "closed_color")
            set_text(6, "label_closed")
        elif state == "open":
            set_col(0, "open_color")
            set_text(6, "label_open")
        elif state == "bashed":
            set_col(0, "bashed_color")
            if "bash_x_color" in vis:
                # recolour the cross/bevel to show damage
                for i in (1,2,3,4):
                    if i < len(layers):
                        layers[i]["color"] = list(vis["bash_x_color"])
            set_text(6, "label_bashed")
        return layers

    # ── oiled_door ────────────────────────────────────────────────────────────
    # same layer order as bevel_door; layer[5]=indicator dot
    if style == "oiled_door":
        if state == "closed":
            set_col(0, "closed_color")
            set_text(6, "label_closed")
        elif state == "open":
            set_col(0, "open_color")
            set_text(6, "label_open")
        return layers

    # ── wall_door ─────────────────────────────────────────────────────────────
    # .lev authored as CLOSED (wall appearance).
    # layer[0]=rect  [1-2]=wall lighter lines  [3-4]=wall darker lines
    # layer[5]=rect_outline (hidden when closed, visible when open)
    # layer[6]=ellipse handle (hidden when closed, visible when open)
    if style == "wall_door":
        if state == "open":
            set_col(0, "open_color")
            # edge lines become open_border
            for i in (1, 2):
                if "open_border" in vis and i < len(layers):
                    layers[i]["color"] = list(vis["open_border"])
            for i in (3, 4):
                if "open_border" in vis and i < len(layers):
                    col = list(vis["open_border"])
                    col[3] = 80 if len(col) < 4 else col[3]  # slightly dim
                    layers[i]["color"] = col
        # closed stays as authored (wall look)
        return layers

    # ── crash_door ────────────────────────────────────────────────────────────
    # layer[0]=fill rect  [1]=rect_outline  [2]=cross  [3]=knob  [4]=text
    if style == "crash_door":
        if state == "closed":
            set_col(0, "closed_color")
            set_col(1, "border_color")
            set_col(2, "x_color")
            set_text(4, "label_closed")
        elif state == "open":
            set_col(0, "open_color")
            if "open_alpha" in vis:
                alpha = int(vis["open_alpha"] * 255)
                c = list(vis.get("open_color", [180,60,20]))
                if len(c) >= 3: c = c[:3] + [alpha]
                layers[0]["color"] = c
            set_text(4, "label_open")
        return layers

    # ── thin_door ─────────────────────────────────────────────────────────────
    # handled entirely by hinge geometry (obj["open"]) — no color sub needed
    # but we can tint the hinge layers
    if style == "thin_door":
        for layer in layers:
            t = layer.get("type","")
            if t in ("hinge_dot","hinge_line"):
                if state == "open" and "open_color" in vis:
                    layer["color"] = list(vis["open_color"])
                elif state == "closed" and "closed_color" in vis:
                    layer["color"] = list(vis["closed_color"])
        return layers

    # ── exit ──────────────────────────────────────────────────────────────────
    if style == "exit":
        if state in ("open", "unlocked") and "open_color" in vis:
            set_col(0, "open_color")
        elif state in ("closed", "locked") and "locked_color" in vis:
            set_col(0, "locked_color")
        return layers

    # ── anything else: no substitution (single-state tiles) ──────────────────
    return layers


def paint_tile_state(p: QPainter, layers: list, vis: dict,
                     tile_type: str, state: str, obj: dict,
                     rx: int, ry: int, tp: int):
    """Public entry: render tile layers with correct state colours."""
    modified = _apply_state_colors(layers, vis, state)
    _render_layers(p, modified, rx, ry, tp, obj)


# keep old name for any callers
def render_layers(painter, layers, rx, ry, tp, obj=None):
    _render_layers(painter, layers, rx, ry, tp, obj)


# ═════════════════════════════════════════════════════════════════════════════
#  JSON syntax highlighter
# ═════════════════════════════════════════════════════════════════════════════

class _JsonHighlighter(QSyntaxHighlighter):
    def __init__(self, doc):
        super().__init__(doc)
        import re
        def fmt(r, g, b, bold=False):
            f = QTextCharFormat(); f.setForeground(QColor(r, g, b))
            if bold: f.setFontWeight(700)
            return f
        self._rules = [
            (re.compile(r'"(?:[^"\\]|\\.)*"'),       fmt(180,220,140)),
            (re.compile(r'\b-?\d+(?:\.\d+)?\b'),     fmt(220,175,90)),
            (re.compile(r'\b(?:true|false|null)\b'),  fmt(130,190,240,True)),
            (re.compile(r'"[^"]*"(?=\s*:)'),          fmt(120,190,255,True)),
            (re.compile(r'[{}\[\]]'),                 fmt(100,140,200,True)),
        ]
    def highlightBlock(self, text):
        for pat, fmt in self._rules:
            for m in pat.finditer(text):
                self.setFormat(m.start(), m.end()-m.start(), fmt)


class _CodeEditor(QPlainTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        font = QFont("Consolas", 11); font.setFixedPitch(True)
        self.setFont(font)
        self.setStyleSheet("QPlainTextEdit{background:#090b10;color:#c8d8e8;"
                           "border:none;selection-background-color:#1e3a5a;}")
        self.setTabStopDistance(28)
        self.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        _JsonHighlighter(self.document())


# ═════════════════════════════════════════════════════════════════════════════
#  State preview canvas
# ═════════════════════════════════════════════════════════════════════════════

_BGA = QColor(24,28,40); _BGB = QColor(20,24,36); _GRID = QColor(35,42,60)
_SBG = QColor(10,12,18); _SEP = QColor(22,30,46)
_LDM = QColor(55,85,120); _LACT = QColor(120,175,225); _BACT = QColor(70,130,195)


class _StatePreview(QWidget):
    STRIP_H = 88

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(200,160)
        self._layers  = []
        self._vis     = {}
        self._ttype   = "tile"
        self._tname   = ""
        self._states  = [("default", {})]
        self._active  = 0
        self._hover   = -1
        self._ts      = 64
        self.setStyleSheet("background:#090b10;")
        self.setMouseTracking(True)

    def set_content(self, layers, vis, tile_type, tile_name, states):
        self._layers = layers
        self._vis    = vis or {}
        self._ttype  = tile_type or "tile"
        self._tname  = tile_name or tile_type or "tile"
        self._states = states or [("default", {})]
        self._active = min(self._active, max(0, len(self._states)-1))
        self.update()

    def set_tile_size(self, px):
        self._ts = max(16, min(256, px)); self.update()

    def _albl(self): return self._states[self._active][0] if self._states else "default"
    def _aobj(self): return self._states[self._active][1] if self._states else {}

    def _st(self):   return self.height() - self.STRIP_H
    def _gh(self):   return self.height() - self.STRIP_H
    def _cw(self):   return max(72, self.width() // max(1,len(self._states)))
    def _cr(self, i):return QRect(i*self._cw(), self._st()+2, self._cw()-2, self.STRIP_H-4)
    def _idx(self, pos):
        if pos.y() < self._st(): return -1
        i = pos.x() // max(1,self._cw())
        return i if 0 <= i < len(self._states) else -1

    def mousePressEvent(self, ev):
        if ev.button()==Qt.MouseButton.LeftButton:
            i = self._idx(ev.position().toPoint())
            if i >= 0: self._active = i; self.update()
    def mouseMoveEvent(self, ev):
        i = self._idx(ev.position().toPoint())
        if i != self._hover: self._hover = i; self.update()
    def leaveEvent(self, ev):
        if self._hover != -1: self._hover = -1; self.update()

    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        W, H = self.width(), self.height(); gh = self._gh()
        sz = 12
        for r in range(gh//sz+1):
            for c in range(W//sz+1):
                p.fillRect(c*sz,r*sz,sz,sz,_BGA if (r+c)%2==0 else _BGB)
        if not self._layers:
            p.setPen(QColor(60,80,100)); p.setFont(QFont("Consolas",11))
            p.drawText(QRect(0,0,W,gh),Qt.AlignmentFlag.AlignCenter,"No layers to preview")
        else:
            self._draw_grid(p,W,gh)
        self._draw_strip(p,W)

    def _draw_grid(self, p, W, gh):
        tp = self._ts
        lbl, obj = self._albl(), self._aobj()
        cols = max(1, W//tp); rows = max(1, gh//tp)
        ox = (W-cols*tp)//2; oy = (gh-rows*tp)//2
        for r in range(rows):
            for c in range(cols):
                rx, ry = ox+c*tp, oy+r*tp
                p.setPen(QPen(_GRID,1)); p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawRect(rx,ry,tp,tp)
                paint_tile_state(p,self._layers,self._vis,self._ttype,lbl,obj,rx,ry,tp)
        p.setPen(_LDM); p.setFont(QFont("Consolas",9))
        p.drawText(QRect(4,gh-20,W-8,18),
                   Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignVCenter,
                   f"{self._tname}  [{lbl}]")

    def _draw_strip(self, p, W):
        st = self._st()
        p.fillRect(0,st,W,self.STRIP_H,_SBG)
        p.setPen(QPen(_SEP,1)); p.drawLine(0,st,W,st)
        cw = self._cw(); font = QFont("Consolas",8); font.setBold(True)
        for i,(lbl,obj) in enumerate(self._states):
            cr = self._cr(i); ia = i==self._active; ih = i==self._hover
            bg = QColor(18,28,44) if ia else QColor(14,20,34) if ih else QColor(10,13,20)
            p.fillRect(cr,bg)
            p.setPen(QPen(_BACT if ia else _SEP,1)); p.drawRect(cr)
            # mini tile preview
            lh = 16; avh = cr.height()-lh-6; avw = cr.width()-6
            tc = min(avw,avh,54)
            if tc >= 14 and self._layers:
                tx = cr.left()+(cr.width()-tc)//2; ty = cr.top()+(avh-tc)//2+3
                for rr in range(tc//6+1):
                    for cc in range(tc//6+1):
                        p.fillRect(tx+cc*6,ty+rr*6,6,6,_BGA if (rr+cc)%2==0 else _BGB)
                p.setPen(QPen(_GRID,1)); p.drawRect(tx,ty,tc,tc)
                paint_tile_state(p,self._layers,self._vis,self._ttype,lbl,obj,tx,ty,tc)
            p.setPen(_LACT if ia else _LDM); p.setFont(font)
            p.drawText(cr.left(),cr.bottom()-lh,cr.width(),lh,
                       Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignVCenter,lbl)
        p.setPen(QColor(26,40,62)); p.setFont(QFont("Consolas",8))
        p.drawText(QRect(0,st+2,W-4,self.STRIP_H-4),
                   Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignVCenter,
                   "click state to preview  ")


# ═════════════════════════════════════════════════════════════════════════════
#  PNG Mode
#
#  Folder layout (mirrors core.py):
#    integrity/tiles/<tile>.png                             default (built-in, dev.py required)
#    integrity/tiles/<tile>_<state>.png                    default, state-specific
#    integrity/tiles/CUSTOM/<tile>.png                     custom tile default (no dev.py gate)
#    integrity/tiles/CUSTOM/<tile>_<state>.png             custom tile, state-specific
#    integrity/tiles/level_pngs/<level_stem>/<tile>.png          level-specific
#    integrity/tiles/level_pngs/<level_stem>/<tile>_<state>.png  level+state specific
#    integrity/tiles/level_pngs/CUSTOM/<tile>/<level_stem>/...   custom, level-specific
# ═════════════════════════════════════════════════════════════════════════════

_TILES_DIR      = os.path.join(_ROOT, "integrity", "tiles")
_CUSTOM_DIR     = os.path.join(_TILES_DIR, "CUSTOM")
_LEVEL_PNGS_DIR = os.path.join(_TILES_DIR, "level_pngs")
_EDITOR_DIR     = os.path.join(_TILES_DIR, "editor")          # editor-only PNGs
_EDITOR_LVL_DIR = os.path.join(_LEVEL_PNGS_DIR, "editor")    # editor level-specific
_DEV_PY         = os.path.join(_ROOT, "integrity", "functions", "misc", "dev.py")
_MISC_DIR       = os.path.join(_ROOT, "integrity", "functions", "misc")


def _png_cfg_path() -> str:
    return os.path.join(_TILES_DIR, "png_visuals.json")

# State names derived from .let flags — same set core.py emits
_ALL_STATES = ["default", "closed", "open", "bashed", "present", "collected"]


def _dev_present() -> bool:
    return os.path.isfile(_DEV_PY)


def _is_custom(tile: str) -> bool:
    return os.path.isfile(os.path.join(_CUSTOM_DIR, f"{tile}.let"))


def _tile_dir(tile: str) -> str:
    return _CUSTOM_DIR if _is_custom(tile) else _TILES_DIR


def _default_png_path(tile: str, state: str) -> str:
    """Absolute path where the shared (game+editor) default PNG should live."""
    d = _tile_dir(tile)
    if state and state != "default":
        return os.path.join(d, f"{tile}_{state}.png")
    return os.path.join(d, f"{tile}.png")


def _editor_png_path(tile: str, state: str) -> str:
    """Absolute path where the editor-only default PNG should live.

    Lives in  integrity/tiles/editor/<tile>[_<state>].png
    The game engine never checks this folder, so it's always safe to put
    a diagram/placeholder here without affecting in-game visuals.
    """
    if state and state != "default":
        return os.path.join(_EDITOR_DIR, f"{tile}_{state}.png")
    return os.path.join(_EDITOR_DIR, f"{tile}.png")


def _level_png_path(tile: str, state: str, level_stem: str) -> str:
    """Absolute path where the shared level-specific PNG should live."""
    if _is_custom(tile):
        base = os.path.join(_LEVEL_PNGS_DIR, "CUSTOM", tile, level_stem)
    else:
        base = os.path.join(_LEVEL_PNGS_DIR, level_stem)
    if state and state != "default":
        return os.path.join(base, f"{tile}_{state}.png")
    return os.path.join(base, f"{tile}.png")


def _editor_level_png_path(tile: str, state: str, level_stem: str) -> str:
    """Absolute path where the editor-only level-specific PNG should live.

    Lives in  integrity/tiles/level_pngs/editor/<level_stem>/<tile>[_<state>].png
    """
    base = os.path.join(_EDITOR_LVL_DIR, level_stem)
    if state and state != "default":
        return os.path.join(base, f"{tile}_{state}.png")
    return os.path.join(base, f"{tile}.png")


def _discover_lets() -> list:
    names = set()
    for d in (_TILES_DIR, _CUSTOM_DIR):
        if os.path.isdir(d):
            for fn in os.listdir(d):
                if fn.endswith(".let"):
                    names.add(fn[:-4])
    return sorted(names)


def _states_for_tile(tile: str) -> list:
    """Return relevant state names from the tile's .let flags."""
    let_path = os.path.join(_tile_dir(tile), f"{tile}.let")
    try:
        with open(let_path, encoding="utf-8") as f:
            flags = json.load(f).get("flags", {})
    except Exception:
        flags = {}
    states = ["default"]
    if flags.get("has_open_state") or flags.get("openable"):
        states += ["closed", "open"]
        if flags.get("bashable") or flags.get("crashable"):
            states.append("bashed")
    if flags.get("collectible"):
        states += ["present", "collected"]
    return states


def _discover_levels() -> list:
    stems = []
    for root_name in ("levels", "mplevels"):
        base = os.path.join(_ROOT, root_name)
        if not os.path.isdir(base):
            continue
        for dirpath, dirnames, filenames in os.walk(base):
            for fn in filenames + dirnames:
                if fn.endswith((".ler", ".lep")):
                    stem = os.path.splitext(fn)[0]
                    if stem not in stems:
                        stems.append(stem)
    return sorted(stems)


# ─────────────────────────────────────────────────────────────────────────────
#  Tiny PNG preview widget
# ─────────────────────────────────────────────────────────────────────────────

class _PngThumb(QLabel):
    """Fixed-size checkered-background PNG preview."""
    def __init__(self, size=64, parent=None):
        super().__init__(parent)
        self._sz = size
        self.setFixedSize(size, size)
        self._path = ""
        self._refresh()

    def set_path(self, path: str):
        self._path = path or ""
        self._refresh()

    def _refresh(self):
        canvas = QPixmap(self._sz, self._sz)
        canvas.fill(QColor(0, 0, 0, 0))
        p = QPainter(canvas)
        sz = 8
        for r in range(self._sz // sz + 1):
            for c in range(self._sz // sz + 1):
                p.fillRect(c*sz, r*sz, sz, sz,
                           QColor(28, 32, 46) if (r+c)%2==0 else QColor(22, 26, 38))
        if self._path and os.path.isfile(self._path):
            pm = QPixmap(self._path)
            if not pm.isNull():
                pm = pm.scaled(self._sz-2, self._sz-2,
                               Qt.AspectRatioMode.KeepAspectRatio,
                               Qt.TransformationMode.SmoothTransformation)
                ox = (self._sz - pm.width())  // 2
                oy = (self._sz - pm.height()) // 2
                p.drawPixmap(ox, oy, pm)
        else:
            p.setPen(QColor(50, 70, 100))
            p.setFont(QFont("Consolas", 7))
            p.drawText(0, 0, self._sz, self._sz, Qt.AlignmentFlag.AlignCenter, "–")
        p.end()
        self.setPixmap(canvas)
        self.setStyleSheet("border:1px solid #1a2236;")


# ─────────────────────────────────────────────────────────────────────────────
#  State row — one row per state showing default + level overrides
# ─────────────────────────────────────────────────────────────────────────────

class _StateRow(QWidget):
    """One row per tile state, showing two PNG slots side by side:

      GAME   – the PNG the game engine loads (integrity/tiles/<tile>.png)
      EDITOR – a KeyRing-only PNG that overrides what you see while editing
               (integrity/tiles/editor/<tile>.png — never loaded by lockesc)

    Both slots support Browse / Clear and per-level overrides.
    """
    def __init__(self, tile: str, state: str, level_stems: list, parent=None):
        super().__init__(parent)
        self._tile      = tile
        self._state     = state
        self._levels    = level_stems
        self._is_custom = _is_custom(tile)
        self._build()
        self._refresh()

    # ── build ─────────────────────────────────────────────────────────────────

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── state label bar ───────────────────────────────────────────────────
        lbar = QWidget()
        lbar.setStyleSheet("background:#0a0e18;border-bottom:1px solid #101828;")
        lh = QHBoxLayout(lbar); lh.setContentsMargins(8, 3, 8, 3); lh.setSpacing(0)
        state_lbl = QLabel(self._state.upper())
        state_lbl.setStyleSheet("color:#4a8090;font:bold 9px Consolas;")
        lh.addWidget(state_lbl)
        root.addWidget(lbar)

        # ── two-column slot area ───────────────────────────────────────────────
        cols = QWidget()
        cols.setStyleSheet("background:#0d111a;")
        ch = QHBoxLayout(cols); ch.setContentsMargins(0, 0, 0, 0); ch.setSpacing(0)

        # GAME slot
        game_col = self._make_slot(
            label       = "🎮  GAME",
            label_style = "color:#507850;font:bold 8px Consolas;letter-spacing:2px;",
            col_style   = "background:#0b0f14;border-right:1px solid #101828;",
            path_fn     = lambda: _default_png_path(self._tile, self._state),
            thumb_attr  = "_game_thumb",
            lbl_attr    = "_game_lbl",
            badge_attr  = "_dev_badge",
            browse_slot = self._browse_game,
            clear_slot  = self._clear_game,
            lvl_slot    = self._add_game_level_override,
            ovr_attr    = "_game_ovr_layout",
        )
        ch.addWidget(game_col, 1)

        # EDITOR slot
        ed_col = self._make_slot(
            label       = "✏  EDITOR",
            label_style = "color:#506888;font:bold 8px Consolas;letter-spacing:2px;",
            col_style   = "background:#0c0e16;",
            path_fn     = lambda: _editor_png_path(self._tile, self._state),
            thumb_attr  = "_ed_thumb",
            lbl_attr    = "_ed_lbl",
            badge_attr  = None,          # editor slot always writable — no gate
            browse_slot = self._browse_editor,
            clear_slot  = self._clear_editor,
            lvl_slot    = self._add_ed_level_override,
            ovr_attr    = "_ed_ovr_layout",
        )
        ch.addWidget(ed_col, 1)

        root.addWidget(cols)

    def _make_slot(self, label, label_style, col_style,
                   path_fn, thumb_attr, lbl_attr, badge_attr,
                   browse_slot, clear_slot, lvl_slot, ovr_attr):
        """Build one PNG slot column and wire up the widget attributes."""
        col = QWidget(); col.setStyleSheet(col_style)
        cv = QVBoxLayout(col); cv.setContentsMargins(6, 4, 6, 4); cv.setSpacing(4)

        # slot label
        slbl = QLabel(label); slbl.setStyleSheet(label_style)
        cv.addWidget(slbl)

        # thumb + path row
        tr = QWidget()
        th = QHBoxLayout(tr); th.setContentsMargins(0, 0, 0, 0); th.setSpacing(6)
        thumb = _PngThumb(48)
        setattr(self, thumb_attr, thumb)
        th.addWidget(thumb)

        path_lbl = QLabel("(none)")
        path_lbl.setStyleSheet("color:#1e3040;font:9px Consolas;")
        path_lbl.setWordWrap(True)
        setattr(self, lbl_attr, path_lbl)
        th.addWidget(path_lbl, 1)
        cv.addWidget(tr)

        # dev.py gate badge (game slot only)
        if badge_attr:
            badge = QLabel("⚙ dev.py required")
            badge.setStyleSheet("color:#604020;font:8px Consolas;"
                                "background:#180e08;border:1px solid #302010;"
                                "border-radius:2px;padding:1px 4px;")
            badge.setVisible(False)
            setattr(self, badge_attr, badge)
            cv.addWidget(badge)

        # buttons row
        br = QWidget()
        bh = QHBoxLayout(br); bh.setContentsMargins(0, 0, 0, 0); bh.setSpacing(4)
        browse_btn = QPushButton("Browse…"); browse_btn.setFixedHeight(20)
        browse_btn.clicked.connect(browse_slot); bh.addWidget(browse_btn)
        clear_btn = QPushButton("✕"); clear_btn.setFixedSize(20, 20)
        clear_btn.setStyleSheet("QPushButton{background:#120808;color:#603030;"
                                "border:1px solid #2a1010;border-radius:3px;padding:0;}"
                                "QPushButton:hover{color:#c05050;}")
        clear_btn.clicked.connect(clear_slot); bh.addWidget(clear_btn)
        lvl_btn = QPushButton("+ Level"); lvl_btn.setFixedHeight(20)
        lvl_btn.setStyleSheet("QPushButton{background:#080e18;color:#2a5878;"
                              "border:1px solid #1a2e40;border-radius:3px;padding:2px 6px;}"
                              "QPushButton:hover{color:#5090b0;border-color:#2a5070;}")
        lvl_btn.clicked.connect(lvl_slot); bh.addWidget(lvl_btn)
        bh.addStretch()
        cv.addWidget(br)

        # level overrides sub-list
        ovr_w = QWidget(); ovr_w.setStyleSheet("background:transparent;")
        ovr_l = QVBoxLayout(ovr_w)
        ovr_l.setContentsMargins(4, 0, 0, 0); ovr_l.setSpacing(2)
        setattr(self, ovr_attr, ovr_l)
        cv.addWidget(ovr_w)

        return col

    # ── refresh ───────────────────────────────────────────────────────────────

    def _refresh(self):
        # game slot
        gp = _default_png_path(self._tile, self._state)
        gex = os.path.isfile(gp)
        self._game_thumb.set_path(gp if gex else "")
        rel = os.path.relpath(gp, _ROOT)
        self._game_lbl.setText(rel if gex else "(none)  →  " + rel)
        self._game_lbl.setStyleSheet(
            "color:#4a8870;font:9px Consolas;" if gex else "color:#1e3040;font:9px Consolas;")
        show_badge = not self._is_custom and not _dev_present()
        self._dev_badge.setVisible(show_badge)

        # editor slot
        ep = _editor_png_path(self._tile, self._state)
        eex = os.path.isfile(ep)
        self._ed_thumb.set_path(ep if eex else "")
        erel = os.path.relpath(ep, _ROOT)
        self._ed_lbl.setText(erel if eex else "(none)  →  " + erel)
        self._ed_lbl.setStyleSheet(
            "color:#4a6888;font:9px Consolas;" if eex else "color:#1e3040;font:9px Consolas;")

    # ── game slot actions ─────────────────────────────────────────────────────

    def _browse_game(self):
        self._browse_slot(_default_png_path(self._tile, self._state),
                          self._game_thumb, self._game_lbl, "game")

    def _clear_game(self):
        self._clear_slot(_default_png_path(self._tile, self._state),
                         self._game_thumb, self._game_lbl)

    def _add_game_level_override(self):
        self._add_level_override_for(
            path_fn=lambda stem: _level_png_path(self._tile, self._state, stem),
            ovr_layout=self._game_ovr_layout,
            tag="game")

    # ── editor slot actions ───────────────────────────────────────────────────

    def _browse_editor(self):
        self._browse_slot(_editor_png_path(self._tile, self._state),
                          self._ed_thumb, self._ed_lbl, "editor")

    def _clear_editor(self):
        self._clear_slot(_editor_png_path(self._tile, self._state),
                         self._ed_thumb, self._ed_lbl)

    def _add_ed_level_override(self):
        self._add_level_override_for(
            path_fn=lambda stem: _editor_level_png_path(self._tile, self._state, stem),
            ovr_layout=self._ed_ovr_layout,
            tag="editor")

    # ── shared slot helpers ───────────────────────────────────────────────────

    def _browse_slot(self, dst_path, thumb, lbl, tag):
        import shutil
        folder = os.path.dirname(dst_path)
        os.makedirs(folder, exist_ok=True)
        src, _ = QFileDialog.getOpenFileName(
            self, f"{tag.upper()} PNG for {self._tile} [{self._state}]",
            folder, "PNG Images (*.png);;All (*)")
        if not src:
            return
        if os.path.abspath(src) != os.path.abspath(dst_path):
            try:
                shutil.copy2(src, dst_path)
            except Exception as e:
                QMessageBox.critical(self, "Copy error", str(e)); return
        thumb.set_path(dst_path)
        lbl.setText(os.path.relpath(dst_path, _ROOT))
        lbl.setStyleSheet("color:#4a8870;font:9px Consolas;" if tag == "game"
                          else "color:#4a6888;font:9px Consolas;")

    def _clear_slot(self, path, thumb, lbl):
        if os.path.isfile(path):
            reply = QMessageBox.question(self, "Delete PNG?",
                f"Delete  {os.path.relpath(path, _ROOT)}?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if reply == QMessageBox.StandardButton.Yes:
                try: os.remove(path)
                except Exception as e: QMessageBox.critical(self, "Error", str(e)); return
        thumb.set_path("")
        lbl.setStyleSheet("color:#1e3040;font:9px Consolas;")
        self._refresh()

    def _add_level_override_for(self, path_fn, ovr_layout, tag):
        dlg = _LvlPickDlg(self._levels, [], self)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        picked = dlg.picked()
        if not picked:
            return
        import shutil
        first_path = path_fn(picked[0])
        folder = os.path.dirname(first_path)
        os.makedirs(folder, exist_ok=True)
        src, _ = QFileDialog.getOpenFileName(
            self, f"{tag.upper()} PNG — {self._tile} [{self._state}] — {len(picked)} level(s)",
            folder, "PNG Images (*.png);;All (*)")
        if not src:
            return
        for stem in picked:
            dst = path_fn(stem)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            if os.path.abspath(src) != os.path.abspath(dst):
                try:
                    shutil.copy2(src, dst)
                except Exception as e:
                    QMessageBox.warning(self, "Copy warning", f"{stem}: {e}")
            self._add_ovr_row(stem, path_fn, ovr_layout, tag)

    def _add_ovr_row(self, level_stem, path_fn, ovr_layout, tag):
        for i in range(ovr_layout.count()):
            w = ovr_layout.itemAt(i).widget()
            if w and w.property("level_stem") == level_stem:
                return
        row = self._make_ovr_row(level_stem, path_fn, tag)
        ovr_layout.addWidget(row)

    def _make_ovr_row(self, level_stem, path_fn, tag) -> QWidget:
        path = path_fn(level_stem)
        row = QWidget()
        row.setProperty("level_stem", level_stem)
        row.setStyleSheet("background:#090b12;border-bottom:1px solid #0e1420;")
        rh = QHBoxLayout(row); rh.setContentsMargins(4, 2, 4, 2); rh.setSpacing(6)

        thumb = _PngThumb(32)
        thumb.set_path(path if os.path.isfile(path) else "")
        rh.addWidget(thumb)

        info = QVBoxLayout(); info.setSpacing(1)
        stem_lbl = QLabel(level_stem)
        stem_lbl.setStyleSheet("color:#3a6888;font:bold 8px Consolas;")
        path_lbl = QLabel(os.path.relpath(path, _ROOT) if os.path.isfile(path) else "(missing)")
        path_lbl.setStyleSheet("color:#1e3848;font:8px Consolas;")
        info.addWidget(stem_lbl); info.addWidget(path_lbl)
        rh.addLayout(info, 1)

        chg = QPushButton("Change"); chg.setFixedHeight(18)
        chg.clicked.connect(lambda _, s=level_stem, t=thumb, pl=path_lbl, fn=path_fn, tg=tag:
                             self._change_ovr(s, t, pl, fn, tg))
        rh.addWidget(chg)

        rm = QPushButton("✕"); rm.setFixedSize(18, 18)
        rm.setStyleSheet("QPushButton{background:#120808;color:#603030;"
                         "border:1px solid #2a1010;border-radius:3px;padding:0;}"
                         "QPushButton:hover{color:#c05050;}")
        rm.clicked.connect(lambda _, r=row, s=level_stem, fn=path_fn: self._remove_ovr(r, s, fn))
        rh.addWidget(rm)
        return row

    def _change_ovr(self, level_stem, thumb, path_lbl, path_fn, tag):
        import shutil
        path = path_fn(level_stem)
        folder = os.path.dirname(path)
        os.makedirs(folder, exist_ok=True)
        src, _ = QFileDialog.getOpenFileName(
            self, f"New {tag.upper()} PNG — {level_stem}", folder, "PNG Images (*.png);;All (*)")
        if not src:
            return
        if os.path.abspath(src) != os.path.abspath(path):
            try: shutil.copy2(src, path)
            except Exception as e: QMessageBox.critical(self, "Error", str(e)); return
        thumb.set_path(path)
        path_lbl.setText(os.path.relpath(path, _ROOT))

    def _remove_ovr(self, row_widget, level_stem, path_fn):
        path = path_fn(level_stem)
        if os.path.isfile(path):
            reply = QMessageBox.question(self, "Delete?",
                f"Delete  {os.path.relpath(path, _ROOT)}?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if reply == QMessageBox.StandardButton.Yes:
                try: os.remove(path)
                except Exception as e: QMessageBox.critical(self, "Error", str(e)); return
        row_widget.deleteLater()

    def reload_overrides(self):
        """Rebuild level override rows for both slots from disk."""
        # game overrides
        for layout in (self._game_ovr_layout, self._ed_ovr_layout):
            while layout.count():
                item = layout.takeAt(0)
                if item.widget(): item.widget().deleteLater()

        # game: scan level_pngs/<level_stem>/
        game_base = (os.path.join(_LEVEL_PNGS_DIR, "CUSTOM", self._tile)
                     if _is_custom(self._tile) else _LEVEL_PNGS_DIR)
        if os.path.isdir(game_base):
            for stem in sorted(os.listdir(game_base)):
                path = _level_png_path(self._tile, self._state, stem)
                if os.path.isfile(path):
                    self._add_ovr_row(stem, lambda s: _level_png_path(self._tile, self._state, s),
                                      self._game_ovr_layout, "game")

        # editor: scan level_pngs/editor/<level_stem>/
        if os.path.isdir(_EDITOR_LVL_DIR):
            for stem in sorted(os.listdir(_EDITOR_LVL_DIR)):
                path = _editor_level_png_path(self._tile, self._state, stem)
                if os.path.isfile(path):
                    self._add_ovr_row(stem, lambda s: _editor_level_png_path(self._tile, self._state, s),
                                      self._ed_ovr_layout, "editor")


# ─────────────────────────────────────────────────────────────────────────────
#  Level picker dialog
# ─────────────────────────────────────────────────────────────────────────────

class _LvlPickDlg(QDialog):
    def __init__(self, all_stems: list, selected: list, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Pick levels")
        self.setMinimumSize(460, 360)
        self.setStyleSheet(parent.styleSheet() if parent else "")
        v = QVBoxLayout(self)

        note = QLabel("Select one or more levels — the same PNG will be copied into each.")
        note.setStyleSheet("color:#2a5060;font:9px Consolas;padding:4px;")
        note.setWordWrap(True); v.addWidget(note)

        sf = QLineEdit(); sf.setPlaceholderText("filter…")
        sf.setStyleSheet("background:#0d1018;color:#90b0c8;border:1px solid #1e2e48;"
                         "border-radius:3px;padding:4px;font:10px Consolas;")
        v.addWidget(sf)

        self._lw = QListWidget()
        self._lw.setStyleSheet("QListWidget{background:#090b12;color:#90b0c8;"
                               "border:1px solid #1a2236;font:10px Consolas;}"
                               "QListWidget::item:selected{background:#1a2a40;}"
                               "QListWidget::item:hover{background:#0e1828;}")
        self._lw.setSelectionMode(QAbstractItemView.SelectionMode.MultiSelection)
        self._items = []
        for stem in all_stems:
            it = QListWidgetItem(stem)
            it.setData(Qt.ItemDataRole.UserRole, stem)
            if stem in selected: it.setSelected(True)
            self._lw.addItem(it); self._items.append(it)
        v.addWidget(self._lw, 1)

        browse_btn = QPushButton("Browse for level not in list…")
        browse_btn.clicked.connect(self._browse); v.addWidget(browse_btn)

        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                              QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        v.addWidget(bb)
        sf.textChanged.connect(lambda t: [
            it.setHidden(t.lower() not in it.text().lower()) for it in self._items])

    def _browse(self):
        p, _ = QFileDialog.getOpenFileName(self, "Level file", _ROOT,
                                           "LockESC Level (*.ler *.lep);;All (*)")
        if p:
            stem = os.path.splitext(os.path.basename(p.rstrip("/\\")))[0]
            for it in self._items:
                if it.data(Qt.ItemDataRole.UserRole) == stem:
                    it.setSelected(True); return
            it = QListWidgetItem(stem)
            it.setData(Qt.ItemDataRole.UserRole, stem)
            it.setSelected(True)
            self._lw.addItem(it); self._items.append(it)

    def picked(self) -> list:
        return [it.data(Qt.ItemDataRole.UserRole) for it in self._items if it.isSelected()]


# ─────────────────────────────────────────────────────────────────────────────
#  PNG Mode main panel
# ─────────────────────────────────────────────────────────────────────────────

class _PngModePanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._tile = None
        self._level_stems = _discover_levels()
        self._build()
        self._refresh_list()

    def _build(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0); root.setSpacing(0)

        # ── left: tile list ───────────────────────────────────────────────────
        left = QWidget(); left.setFixedWidth(190)
        left.setStyleSheet("background:#080a10;border-right:1px solid #141c28;")
        lv = QVBoxLayout(left); lv.setContentsMargins(0,0,0,0); lv.setSpacing(0)

        hdr = QLabel("  TILES")
        hdr.setStyleSheet("background:#060810;color:#2a5070;font:bold 9px Consolas;"
                          "letter-spacing:3px;padding:5px 10px;"
                          "border-bottom:1px solid #0e1420;")
        lv.addWidget(hdr)

        sf = QLineEdit(); sf.setPlaceholderText("filter…")
        sf.setStyleSheet("background:#0a0c12;color:#5080a0;border:none;"
                         "border-bottom:1px solid #141c28;padding:4px 10px;font:10px Consolas;")
        sf.textChanged.connect(self._filter)
        lv.addWidget(sf)

        self._lw = QListWidget()
        self._lw.setStyleSheet(
            "QListWidget{background:#080a10;color:#6090b0;border:none;font:10px Consolas;}"
            "QListWidget::item{padding:3px 10px;}"
            "QListWidget::item:selected{background:#10182a;color:#90c0e0;}"
            "QListWidget::item:hover{background:#0c1018;}")
        self._lw.currentItemChanged.connect(self._on_sel)
        lv.addWidget(self._lw, 1)

        reload_btn = QPushButton("↺  Reload")
        reload_btn.setFixedHeight(26)
        reload_btn.setStyleSheet("QPushButton{background:#060810;color:#2a5060;"
                                 "border:none;border-top:1px solid #141c28;font:9px Consolas;}"
                                 "QPushButton:hover{color:#5090a0;}")
        reload_btn.clicked.connect(self._reload)
        lv.addWidget(reload_btn)
        root.addWidget(left)

        # ── right: state rows ─────────────────────────────────────────────────
        right = QWidget(); right.setStyleSheet("background:#090b12;")
        rv = QVBoxLayout(right); rv.setContentsMargins(0,0,0,0); rv.setSpacing(0)

        self._rhdr = QLabel("  select a tile →")
        self._rhdr.setStyleSheet("background:#060810;color:#2a5070;font:bold 10px Consolas;"
                                 "padding:6px 12px;border-bottom:1px solid #0e1420;")
        rv.addWidget(self._rhdr)

        # dev.py info banner
        self._dev_banner = QLabel()
        self._dev_banner.setStyleSheet("background:#100e08;color:#706030;"
                                       "font:9px Consolas;padding:4px 12px;"
                                       "border-bottom:1px solid #201e08;")
        self._dev_banner.setWordWrap(True)
        rv.addWidget(self._dev_banner)

        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea{border:none;background:#090b12;}")
        self._states_widget = QWidget()
        self._states_widget.setStyleSheet("background:#090b12;")
        self._states_layout = QVBoxLayout(self._states_widget)
        self._states_layout.setContentsMargins(0,0,0,0); self._states_layout.setSpacing(1)
        self._states_layout.addStretch()
        scroll.setWidget(self._states_widget)
        rv.addWidget(scroll, 1)

        root.addWidget(right, 1)
        self._right = right

    # ── tile list ─────────────────────────────────────────────────────────────

    def _refresh_list(self):
        self._all_tiles = _discover_lets()
        self._lw.clear()
        for t in self._all_tiles:
            it = QListWidgetItem(("★  " if _is_custom(t) else "   ") + t)
            it.setData(Qt.ItemDataRole.UserRole, t)
            # green tint if any PNG exists on disk
            has_png = os.path.isfile(_default_png_path(t, "default")) or \
                      os.path.isfile(_default_png_path(t, ""))
            if has_png:
                it.setForeground(QColor(60, 160, 80))
            self._lw.addItem(it)

    def _filter(self, txt):
        for i in range(self._lw.count()):
            it = self._lw.item(i)
            it.setHidden(txt.lower() not in it.text().lower())

    def _on_sel(self, cur, _):
        if not cur:
            self._tile = None; return
        self._tile = cur.data(Qt.ItemDataRole.UserRole)
        self._rhdr.setText(f"  {self._tile}"
                           + ("  [CUSTOM]" if _is_custom(self._tile) else ""))
        self._update_dev_banner()
        self._rebuild_states()

    def _update_dev_banner(self):
        if not self._tile:
            self._dev_banner.hide(); return
        if _is_custom(self._tile):
            self._dev_banner.setText("Custom tile — default PNGs always available, no dev.py needed.")
            self._dev_banner.setStyleSheet("background:#081008;color:#308040;"
                                           "font:9px Consolas;padding:4px 12px;"
                                           "border-bottom:1px solid #102010;")
        elif _dev_present():
            self._dev_banner.setText("dev.py detected — default PNGs enabled for built-in tiles.")
            self._dev_banner.setStyleSheet("background:#080a10;color:#2a5060;"
                                           "font:9px Consolas;padding:4px 12px;"
                                           "border-bottom:1px solid #0e1420;")
        else:
            self._dev_banner.setText(
                "dev.py not found in integrity/functions/misc/ — "
                "default PNGs for built-in tiles are disabled at runtime.  "
                "You can still author them here; they won't load in-game until dev.py is present.  "
                "Level-specific overrides work regardless.")
            self._dev_banner.setStyleSheet("background:#100e08;color:#706030;"
                                           "font:9px Consolas;padding:4px 12px;"
                                           "border-bottom:1px solid #201e08;")
        self._dev_banner.show()

    def _rebuild_states(self):
        lay = self._states_layout
        while lay.count() > 1:
            item = lay.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        if not self._tile:
            return
        states = _states_for_tile(self._tile)
        for st in states:
            row = _StateRow(self._tile, st, self._level_stems, self)
            row.reload_overrides()
            lay.insertWidget(lay.count()-1, row)

    def _reload(self):
        self._level_stems = _discover_levels()
        self._refresh_list()
        if self._tile:
            self._rebuild_states()


# ═════════════════════════════════════════════════════════════════════════════
#  Stylesheet + constants
# ═════════════════════════════════════════════════════════════════════════════

_DARK = """
QMainWindow,QWidget{background:#0a0c12;color:#b0c8d8;font:11px Consolas;}
QSplitter::handle{background:#141c28;}
QLabel{color:#607888;}
QPushButton{background:#12182a;color:#6088a8;border:1px solid #1e2e48;
  border-radius:3px;padding:4px 12px;}
QPushButton:hover{background:#1a2840;color:#90c0e0;border-color:#3060a0;}
QPushButton:pressed{background:#0e1420;}
QComboBox{background:#12182a;color:#7090b0;border:1px solid #1e2e48;
  border-radius:3px;padding:3px 6px;}
QComboBox::drop-down{border:none;}
QComboBox QAbstractItemView{background:#0e1420;color:#90b8d0;
  selection-background-color:#1e3050;}
QSlider::groove:horizontal{background:#141c28;height:4px;border-radius:2px;}
QSlider::handle:horizontal{background:#3060a0;width:14px;height:14px;
  margin:-5px 0;border-radius:7px;}
QScrollBar:vertical{background:#0a0c12;width:7px;}
QScrollBar::handle:vertical{background:#1e2a3a;border-radius:3px;}
QStatusBar{background:#080a10;color:#2a4050;border-top:1px solid #141c28;}
"""

_KR = "keyring"; _LE = "lockesc"
_SFX = {_KR:"_keyring.lev", _LE:"_lockesc.lev"}
_VLB = {_KR:"KeyRing  (editor)", _LE:"Game  (lockesc)"}
_VAST = {
    _KR:"QPushButton{background:#0e1e30;color:#5090d0;border:1px solid #2a5080;border-radius:3px;padding:4px 14px;}",
    _LE:"QPushButton{background:#1a0e28;color:#9060d0;border:1px solid #5030a0;border-radius:3px;padding:4px 14px;}",
}
_VIDLE = ("QPushButton{background:#0e1018;color:#2a3848;border:1px solid #141c28;"
          "border-radius:3px;padding:4px 14px;}"
          "QPushButton:hover{background:#141820;color:#4a6878;}")


# ═════════════════════════════════════════════════════════════════════════════
#  Main window
# ═════════════════════════════════════════════════════════════════════════════

class MonicleEditor(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Monicle  –  Visual Editor  |  LockESC")
        self.resize(1280, 800); self.setStyleSheet(_DARK)
        self._filepath = None; self._tile = None
        self._variant  = _KR
        self._flags    = {}; self._vis = {}
        self._deb = QTimer(); self._deb.setSingleShot(True); self._deb.setInterval(50)
        self._deb.timeout.connect(self._upd)
        self._build(); self._blank()

    def _build(self):
        mb = self.menuBar()
        mb.setStyleSheet("QMenuBar{background:#080a10;color:#4a7090;}"
                         "QMenuBar::item:selected{background:#141c28;color:#90c0e0;}"
                         "QMenu{background:#0a0e18;color:#90b8d0;border:1px solid #1e2e48;}"
                         "QMenu::item:selected{background:#1a2a40;}")
        fm = mb.addMenu("File")
        for lbl,key,slot in [("New","Ctrl+N",self._new),("Open .lev…","Ctrl+O",self._open),
                              ("Save","Ctrl+S",self._save),("Save As…","Ctrl+Shift+S",self._save_as)]:
            a=QAction(lbl,self); a.setShortcut(QKeySequence(key)); a.triggered.connect(slot); fm.addAction(a)

        # ── tab container ─────────────────────────────────────────────────────
        cen = QWidget(); self.setCentralWidget(cen)
        root = QVBoxLayout(cen); root.setContentsMargins(0, 0, 0, 0); root.setSpacing(0)

        self._tabs = QTabWidget()
        self._tabs.setStyleSheet(
            "QTabWidget::pane{border:none;background:#090b12;}"
            "QTabBar::tab{background:#080a10;color:#2a5070;font:bold 9px Consolas;"
            "  letter-spacing:2px;padding:6px 18px;border:1px solid #141c28;"
            "  border-bottom:none;border-top-left-radius:3px;border-top-right-radius:3px;}"
            "QTabBar::tab:selected{background:#090b12;color:#60a0d0;"
            "  border-color:#1e3050;}"
            "QTabBar::tab:hover{background:#0c0e18;color:#4a8090;}")
        root.addWidget(self._tabs)

        # ── Tab 1: JSON .lev editor (existing UI) ─────────────────────────────
        lev_tab = QWidget(); lev_tab.setStyleSheet("background:#090b12;")
        lv = QVBoxLayout(lev_tab); lv.setContentsMargins(0, 0, 0, 0); lv.setSpacing(0)

        bar=QWidget(); bar.setStyleSheet("background:#080a10;border-bottom:1px solid #141c28;")
        bar.setFixedHeight(44)
        bh=QHBoxLayout(bar); bh.setContentsMargins(10,6,10,6); bh.setSpacing(6)
        logo=QLabel("🔍  Monicle")
        logo.setStyleSheet("font:bold 15px Consolas;color:#2870b8;letter-spacing:1px;padding-right:10px;")
        bh.addWidget(logo)
        for lbl,slot in [("New",self._new),("Open…",self._open),("Save",self._save)]:
            b=QPushButton(lbl); b.setFixedHeight(28); b.clicked.connect(slot); bh.addWidget(b)
        bh.addWidget(QLabel("  Tile:"))
        self._tc=QComboBox(); self._tc.setFixedHeight(28); self._tc.setMinimumWidth(160)
        self._tc.setToolTip("Select tile — states derived from companion .let file")
        self._pop_combo(); self._tc.currentIndexChanged.connect(self._combo_ch)
        bh.addWidget(self._tc)
        bh.addSpacing(8)
        self._vb={}
        for v in (_KR,_LE):
            b=QPushButton(_VLB[v]); b.setFixedHeight(28)
            b.clicked.connect(lambda _,vv=v:self._set_var(vv))
            self._vb[v]=b; bh.addWidget(b)
        self._rfv()
        bh.addStretch()
        self._slbl=QLabel(""); self._slbl.setStyleSheet("color:#2a5070;font:9px Consolas;min-width:150px;")
        bh.addWidget(self._slbl)
        bh.addWidget(QLabel("Tile px:"))
        self._ss=QSlider(Qt.Orientation.Horizontal); self._ss.setRange(16,200)
        self._ss.setValue(64); self._ss.setFixedWidth(110); self._ss.valueChanged.connect(self._sz)
        self._szl=QLabel("64"); self._szl.setStyleSheet("color:#3a6080;min-width:24px;")
        bh.addWidget(self._ss); bh.addWidget(self._szl)
        lv.addWidget(bar)

        self._pl=QLabel("  No file open  –  type JSON below or pick a tile above")
        self._pl.setStyleSheet("background:#060810;color:#1e3040;font:9px Consolas;"
                               "padding:2px 14px;border-bottom:1px solid #0e1420;")
        lv.addWidget(self._pl)

        sp=QSplitter(Qt.Orientation.Horizontal); sp.setHandleWidth(6)
        cc=QWidget(); cc.setStyleSheet("background:#090b10;")
        cv=QVBoxLayout(cc); cv.setContentsMargins(0,0,0,0); cv.setSpacing(0)
        self._ch=QLabel("  JSON  LAYERS  –  KeyRing (editor)")
        self._ch.setStyleSheet("background:#070910;color:#2a5070;font:bold 9px Consolas;"
                               "letter-spacing:3px;padding:4px 14px;border-bottom:1px solid #0e1420;")
        cv.addWidget(self._ch)
        self._ed=_CodeEditor(); self._ed.textChanged.connect(self._tc_ch); cv.addWidget(self._ed,1)
        self._eb=QLabel(""); self._eb.setStyleSheet("background:#180808;color:#d06060;font:9px Consolas;"
                                                    "padding:3px 14px;border-top:1px solid #2a0808;")
        self._eb.setVisible(False); cv.addWidget(self._eb)
        sp.addWidget(cc)
        pc=QWidget(); pv=QVBoxLayout(pc); pv.setContentsMargins(0,0,0,0); pv.setSpacing(0)
        self._ph=QLabel("  PREVIEW  –  KeyRing")
        self._ph.setStyleSheet("background:#070910;color:#2a5070;font:bold 9px Consolas;"
                               "letter-spacing:3px;padding:4px 14px;border-bottom:1px solid #0e1420;")
        pv.addWidget(self._ph)
        self._pv=_StatePreview(); pv.addWidget(self._pv,1)
        sp.addWidget(pc); sp.setSizes([520,720])
        lv.addWidget(sp,1)
        sb=QStatusBar(); sb.setFixedHeight(22); self.setStatusBar(sb); self._sb=sb
        self._sp=sp

        self._tabs.addTab(lev_tab, "🎨  LEV Editor")

        # ── Tab 2: PNG mode ───────────────────────────────────────────────────
        self._png_panel = _PngModePanel(self)
        self._png_panel.cfg_saved = lambda: self._sb.showMessage(
            f"png_visuals.json saved  →  {_png_cfg_path()}", 5000)
        self._tabs.addTab(self._png_panel, "🖼  PNG Mode")

    # ── variant ───────────────────────────────────────────────────────────────

    def _rfv(self):
        for v,b in self._vb.items(): b.setStyleSheet(_VAST[v] if v==self._variant else _VIDLE)

    def _rfh(self):
        col="#2a5070" if self._variant==_KR else "#4a2878"; vn=_VLB[self._variant]
        tp=f"  {self._tile}  " if self._tile else "  "
        self._ch.setText(f"  JSON  LAYERS{tp}—  {vn}")
        self._ch.setStyleSheet(f"background:#070910;color:{col};font:bold 9px Consolas;"
                               f"letter-spacing:3px;padding:4px 14px;border-bottom:1px solid #0e1420;")
        self._ph.setText(f"  PREVIEW  –  {vn}")
        self._ph.setStyleSheet(f"background:#070910;color:{col};font:bold 9px Consolas;"
                               f"letter-spacing:3px;padding:4px 14px;border-bottom:1px solid #0e1420;")

    def _set_var(self, v):
        if v==self._variant: return
        self._variant=v; self._rfv(); self._rfh()
        if self._tile:
            td=os.path.join(_ROOT,"integrity","tiles")
            sfx=_SFX[v]
            for d in (os.path.join(td,"CUSTOM"),td):
                p=os.path.join(d,f"{self._tile}{sfx}")
                if os.path.isfile(p): self._lf(p,False,False); return
            self._blank(True); self._sb.showMessage(f"No {sfx} for '{self._tile}' — blank",5000); return
        self._upd()

    # ── combo ─────────────────────────────────────────────────────────────────

    def _pop_combo(self):
        self._tc.blockSignals(True); self._tc.clear(); self._tc.addItem("(free edit)",None)
        td=os.path.join(_ROOT,"integrity","tiles"); cd=os.path.join(td,"CUSTOM")
        names={}
        for d,tag in ((td,"builtin"),(cd,"custom")):
            if os.path.isdir(d):
                for fn in os.listdir(d):
                    for sfx in (_SFX[_KR],_SFX[_LE]):
                        if fn.endswith(sfx): names[fn[:-len(sfx)]]=tag
        for n in sorted(names): self._tc.addItem(f"  ★ {n}" if names[n]=="custom" else f"  {n}",n)
        self._tc.blockSignals(False)

    def _combo_ch(self, idx):
        n=self._tc.itemData(idx)
        if not n: self._tile=None;self._flags={};self._vis={};self._blank(False);return
        td=os.path.join(_ROOT,"integrity","tiles"); cd=os.path.join(td,"CUSTOM"); sfx=_SFX[self._variant]
        for d in (cd,td):
            p=os.path.join(d,f"{n}{sfx}")
            if os.path.isfile(p): self._lf(p,False,True); return
        self._tile=n; let=_load_let(n); self._flags=let.get("flags",{}); self._vis=let.get("visuals",{})
        self._blank(True); self._sb.showMessage(f"No {sfx} for '{n}' — blank",6000)

    # ── file ops ──────────────────────────────────────────────────────────────

    def _blank(self, keep=False):
        tmpl=json.dumps([{"type":"rect","color":[55,70,115]},
            {"type":"line","x1":0.0,"y1":0.0,"x2":1.0,"y2":0.0,"color":[70,95,155],"pen_width":0.04},
            {"type":"line","x1":0.0,"y1":0.0,"x2":0.0,"y2":1.0,"color":[70,95,155],"pen_width":0.04},
            {"type":"ellipse","x":0.28,"y":0.28,"w":0.44,"h":0.44,"color":[90,120,200]},
            {"type":"text","text":"?","color":[255,255,255],"font_scale":0.28}],indent=2)
        if not keep: self._tile=None;self._flags={};self._vis={}
        self._ed.blockSignals(True); self._ed.setPlainText(tmpl); self._ed.blockSignals(False)
        self._sp2(None); self._rfh(); self._upd()

    def _lf(self, path, upd_combo=True, upd_tile=True):
        try:
            with open(path,encoding="utf-8") as f: raw=json.load(f)
        except Exception as e: QMessageBox.critical(self,"Open Error",str(e)); return
        tk=None; ld=raw
        if isinstance(raw,dict):
            for k,v in raw.items():
                if not k.startswith("_") and isinstance(v,list): tk=k;ld=v;break
        if upd_tile:
            bn=os.path.basename(path)
            for sfx in (_SFX[_KR],_SFX[_LE],".lev"):
                if bn.endswith(sfx): self._tile=bn[:-len(sfx)]; break
            else: self._tile=tk
            if self._tile:
                let=_load_let(self._tile); self._flags=let.get("flags",{}); self._vis=let.get("visuals",{})
            for v,sfx in _SFX.items():
                if path.endswith(sfx): self._variant=v; self._rfv(); break
        self._ed.blockSignals(True); self._ed.setPlainText(json.dumps(ld,indent=2)); self._ed.blockSignals(False)
        self._sp2(path); self._rfh(); self._upd(tk or self._tile or "tile")
        self._sb.showMessage(f"Opened  {os.path.basename(path)}",4000)
        if upd_combo and self._tile:
            self._tc.blockSignals(True)
            for i in range(self._tc.count()):
                if self._tc.itemData(i)==self._tile: self._tc.setCurrentIndex(i); break
            self._tc.blockSignals(False)

    def _sp2(self, path):
        self._filepath=path
        if path:
            vt=("  [KeyRing editor]" if path.endswith(_SFX[_KR]) else
                "  [Game / lockesc]" if path.endswith(_SFX[_LE]) else "")
            col="#2a6070" if self._variant==_KR else "#4a2878"
            self._pl.setText(f"  {path}{vt}")
            self._pl.setStyleSheet(f"background:#060810;color:{col};font:9px Consolas;"
                                   f"padding:2px 14px;border-bottom:1px solid #0e1420;")
        else:
            self._pl.setText("  Unsaved  –  Ctrl+S to save  |  pick a tile above to load one")
            self._pl.setStyleSheet("background:#060810;color:#1e3040;font:9px Consolas;"
                                   "padding:2px 14px;border-bottom:1px solid #0e1420;")

    def _tc_ch(self): self._deb.start()

    def _upd(self, lbl=""):
        txt=self._ed.toPlainText().strip()
        if not txt:
            self._serr(""); self._pv.set_content([],{},"","",[]); self._slbl.setText(""); return
        try: data=json.loads(txt)
        except json.JSONDecodeError as e:
            self._serr(f"JSON error  line {e.lineno}  col {e.colno}  –  {e.msg}"); return
        if not isinstance(data,list):
            self._serr("Expected a JSON array of shape layers at the top level"); return
        self._serr("")
        tn=self._tile or lbl or "tile"
        states=_derive_states(self._flags,tn)
        n=len(states); src="from .let" if self._flags else "default"
        self._slbl.setText(f"{n} state{'s' if n!=1 else ''}  ·  {src}")
        self._pv.set_content(data, self._vis, tn, tn, states)

    def _serr(self, msg):
        if msg: self._eb.setText(f"  ⚠  {msg}"); self._eb.setVisible(True)
        else:   self._eb.setVisible(False)

    def _sz(self, v): self._szl.setText(str(v)); self._pv.set_tile_size(v)

    def _new(self):
        self._tile=None; self._flags={}; self._vis={}; self._blank()
        self._tc.blockSignals(True); self._tc.setCurrentIndex(0); self._tc.blockSignals(False)

    def _open(self):
        start=os.path.join(_ROOT,"integrity","tiles")
        p,_=QFileDialog.getOpenFileName(self,"Open .lev File",start,"LockESC Visual Def (*.lev);;All Files (*)")
        if p: self._lf(p)

    def _save(self):
        if self._filepath: self._write(self._filepath)
        elif self._tile:
            td=os.path.join(_ROOT,"integrity","tiles")
            self._write(os.path.join(td,f"{self._tile}{_SFX[self._variant]}"))
        else: self._save_as()

    def _save_as(self):
        start=os.path.join(_ROOT,"integrity","tiles")
        p,_=QFileDialog.getSaveFileName(self,"Save .lev File",start,"LockESC Visual Def (*.lev);;All Files (*)")
        if p:
            if not p.endswith(".lev"): p+=".lev"
            self._write(p)

    def _write(self, path):
        txt=self._ed.toPlainText().strip()
        try: layers=json.loads(txt)
        except json.JSONDecodeError as e:
            QMessageBox.critical(self,"Save Error",f"Cannot save: JSON has errors.\n\n{e}"); return
        bn=os.path.basename(path); tk=bn
        for sfx in (_SFX[_KR],_SFX[_LE],".lev"):
            if bn.endswith(sfx): tk=bn[:-len(sfx)]; break
        ex={}
        if os.path.isfile(path):
            try:
                with open(path,encoding="utf-8") as f: ex=json.load(f)
            except: pass
        wr={k:v for k,v in ex.items() if k.startswith("_")}
        vn="KeyRing" if path.endswith(_SFX[_KR]) else "LockESC (game)"
        wr.setdefault("_comment",f"LockESC Visual Definition — {vn} — {tk}")
        wr.setdefault("_version",1)
        wr["_note"]=(f"Per-tile visual definition for '{tk}'. "
                     f"Used by {'keyring.py' if path.endswith(_SFX[_KR]) else 'lockesc.py'}.")
        wr[tk]=layers
        try:
            with open(path,"w",encoding="utf-8") as f: json.dump(wr,f,indent=2)
        except Exception as e:
            QMessageBox.critical(self,"Save Error",str(e)); return
        for v,sfx in _SFX.items():
            if path.endswith(sfx): self._variant=v; self._rfv(); break
        self._tile=tk; let=_load_let(tk); self._flags=let.get("flags",{}); self._vis=let.get("visuals",{})
        self._sp2(path); self._rfh(); self._pop_combo()
        self._tc.blockSignals(True)
        for i in range(self._tc.count()):
            if self._tc.itemData(i)==tk: self._tc.setCurrentIndex(i); break
        self._tc.blockSignals(False)
        self._upd(); self._sb.showMessage(f"Saved  {os.path.basename(path)}",4000)


# ═════════════════════════════════════════════════════════════════════════════

def main():
    app=QApplication(sys.argv); app.setStyle("Fusion")
    _ico = os.path.join(os.path.dirname(os.path.abspath(__file__)), "monicle.ico")
    if os.path.isfile(_ico):
        from PyQt6.QtGui import QIcon
        app.setWindowIcon(QIcon(_ico))
    win=MonicleEditor(); win.show(); sys.exit(app.exec())

if __name__=="__main__":
    main()
