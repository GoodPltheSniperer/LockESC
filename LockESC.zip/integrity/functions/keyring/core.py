"""
LockESC – KeyRing Level Editor  v6
===================================
pip install PyQt6
python keyring.py

Tools
-----
  • WALL / FLOOR / PLAYER / etc.  – paint tiles  (Left-drag)
  • ERASE  – remove tiles  (Right-click always erases)
  • SELECT – drag to marquee-select tiles
             Double-click OR Alt+Enter a selected tile → Property editor

Waypoints
---------
  • Place a GUARD, select it in the Guard panel, click "Add Waypoint"
  • Click on canvas to drop waypoints
  • Pause waypoints shown as rings (guard lingers there)

Controls
--------
  🖱 Left-drag   – paint / select
  🖱 Right-click – erase
  🖱 Middle-drag – pan
  Scroll          – zoom
  G               – toggle grid
  F               – fit level
  Delete          – erase selected tile
  Alt+Enter       – edit selected tile properties
  Ctrl+Z          – undo
  Ctrl+Y          – redo
  F5              – run level

Visuals
-------
  Edit integrity/visuals/defaultvis_kr.lev to customise every tile's drawn appearance.
  The .lev file is human-readable JSON — change colours, shapes, layer order.
"""

import sys, json, os, subprocess, math, copy, traceback, datetime
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QSplitter, QLabel, QPushButton, QButtonGroup, QScrollArea,
    QFileDialog, QMessageBox, QSpinBox, QLineEdit, QGroupBox,
    QFormLayout, QFrame, QListWidget, QListWidgetItem, QToolBar,
    QStatusBar, QSizePolicy, QSlider, QAbstractItemView,
    QDialog, QDialogButtonBox, QCheckBox, QComboBox, QDoubleSpinBox,
    QTextEdit, QTabWidget, QToolButton, QMenu, QStackedWidget,
)
from PyQt6.QtCore import Qt, QPoint, QRect, QSize, QTimer, pyqtSignal, QRectF
from PyQt6.QtGui import (
    QPainter, QColor, QPen, QBrush, QFont, QKeySequence,
    QAction, QPixmap, QIcon, QPolygon, QPainterPath, QFontDatabase,
    QRadialGradient, QLinearGradient,
    QUndoStack, QUndoCommand,
)

# ── palette ──────────────────────────────────────────────────────────────────
PAL = {
    "bg":         QColor( 32,  34,  40),
    "panel":      QColor( 42,  44,  52),
    "panel_dark": QColor( 28,  30,  36),
    "border":     QColor( 58,  62,  74),
    "accent":     QColor( 88, 140, 220),
    "accent2":    QColor(220, 140,  55),
    "text":       QColor(210, 215, 225),
    "text_dim":   QColor(120, 125, 140),
    "grid":       QColor( 50,  55,  68),
    "grid_major": QColor( 65,  72,  90),
    # tile colours
    "wall":       QColor( 55,  70, 115),
    "floor":      QColor( 28,  52,  88),
    "player":     QColor(220,  55,  75),
    "player2":    QColor( 40, 180, 240),
    "exit":       QColor(  0, 200, 110),
    "loot":       QColor(255, 200,   0),
    "hide":       QColor( 80, 120, 190),
    "guard":      QColor(240, 165,  30),
    "door":       QColor(140, 100,  40),
    "crashdoor":  QColor(180,  60,  20),
    "window":     QColor( 80, 160, 200),
    "noisemaker": QColor(200, 100, 220),
    "main_loot":  QColor(255,  80,  20),
    # subtiles
    "oiled_door":     QColor( 80, 160,  60),
    "wall_door":      QColor( 70,  55, 110),
    "thin_door":      QColor(200, 150,  50),
    "fence":          QColor( 90, 120,  70),
    "pit":            QColor( 12,  16,  36),
    "creak_floor":    QColor(160, 120,  50),
    "item_pile":      QColor(200, 170,  80),
    "buy_item":       QColor( 80, 160, 255),
    "shop_leave":     QColor( 80, 220,  80),
    "detail_img":     QColor(180, 100, 220),
    "detail_txt":     QColor(220, 180, 100),
    "snitch":         QColor(200, 130,  40),
    "camera":         QColor(140, 200,  70),
    "invisible_wall": QColor( 90, 110, 180),
    "thin_wall":      QColor(170, 195, 255),
    "mini_loot":      QColor(200, 165,   0),
    # IO nodes
    "transmit_node":  QColor( 60, 200, 210),
    "receive_node":   QColor(210, 170,  60),
    "erase":      QColor(180,  50,  50),
    "select":     QColor(100, 180, 255),
    "waypoint":   QColor( 80, 160, 220),
    "wp_pause":   QColor(200, 160,  60),
    # edge / region
    "edge_wall":  QColor(170, 200, 255),
    "edge_door":  QColor(200, 150,  60),
    "region":                    QColor( 80, 200, 120),
    "region_inbetween":          QColor(180, 220, 255),
    "region_inbetween_doorway":  QColor(255, 200,  80),
    # AI hint tiles
    "ai_coverhint":  QColor(255, 120,  60),
    "ai_chokehint":  QColor(180,  60, 220),
    "ai_avoidhint":  QColor( 60, 180, 255),
}

TILE_TYPES = [
    "wall", "floor", "player", "player2", "exit",
    "loot", "mini_loot", "main_loot", "hide",
    "guard", "door", "crashdoor", "window", "noisemaker",
    # subtile / advanced types
    "oiled_door", "wall_door", "fence", "pit", "creak_floor",
    "snitch", "camera", "invisible_wall", "thin_wall",
    # edge types (placed on grid lines, not tile centers)
    "edge_wall", "edge_door",
    # region family
    "region", "region_inbetween", "region_inbetween_doorway",
    # AI hint tiles (painted zones – inform guard AI, invisible in-game)
    "ai_coverhint", "ai_chokehint", "ai_avoidhint",
    # IO (non-tile) – placed via IO panel, appear in canvas with special icon
    "transmit_node", "receive_node",
    # shop tiles (visible only when room Is shop? is checked)
    "item_pile", "buy_item", "shop_leave",
    # detail decorations
    "detail_img", "detail_txt",
]

TILE_ICONS = {
    "wall":           "▪",
    "floor":          "·",
    "player":         "P",
    "player2":        "P2",
    "exit":           "E",
    "loot":           "$",
    "mini_loot":      "¢",
    "hide":           "H",
    "guard":          "G",
    "main_loot":      "★",
    "door":           "▬",
    "crashdoor":      "!▬",
    "window":         "≡",
    "noisemaker":     "♪",
    "oiled_door":     "○▬",
    "wall_door":      "?▬",
    "fence":          "╫",
    "pit":            "○",
    "creak_floor":    "~",
    "item_pile":      "✦",
    "buy_item":       "$",
    "shop_leave":     "→",
    "detail_img":     "🖼",
    "detail_txt":     "T",
    "snitch":         "◈",
    "camera":         "⊙",
    "invisible_wall": "░",
    "thin_wall":      "┼",
    "transmit_node":  "→",
    "receive_node":   "←",
    "edge_wall":      "┃",
    "edge_door":      "⌶",
    "region":                   "⬡",
    "region_inbetween":         "⬡~",
    "region_inbetween_doorway": "⬡|",
    # AI hint tiles
    "ai_coverhint":  "⛉",
    "ai_chokehint":  "⛒",
    "ai_avoidhint":  "⊗",
}

TILE_TIPS = {
    "wall":           "Wall – solid obstacle",
    "floor":          "Floor – open walkable space",
    "player":         "Player start (one per level)",
    "player2":        "Player 2 start – multiplayer spawn point",
    "exit":           "Exit door (one per level)",
    "loot":           "Collectible ($100 pts each)",
    "mini_loot":      "Mini Loot – small collectible ($25 pts); doesn't count toward exit",
    "hide":           "Hide spot – player presses H here",
    "guard":          "Guard – click then add waypoints in panel",
    "main_loot":      "Main Loot – collecting it opens exit",
    "door":           "Door – player presses E to toggle",
    "crashdoor":      "Crash-door – player must sprint-ram to open; loud!",
    "window":         "Window – guards see through; players can't pass",
    "noisemaker":     "Noisemaker – emits periodic noise pulses",
    "oiled_door":     "Oiled Door – silent toggle, green tint",
    "wall_door":      "Wall Door – hidden when closed, looks like a wall",
    "fence":          "Fence – blocks player movement; guards see through",
    "pit":            "Pit – player falls in when sprinting; instant death",
    "creak_floor":    "Creak Floor – emits noise when walked/sprinted on",
    "snitch":         "Snitch – spots player, runs to nearest guard to report (does NOT fight)",
    "camera":         "Camera – security camera with scanning FOV",
    "invisible_wall": "Invisible Wall – solid but invisible in-game",
    "thin_wall":      "Thin Wall – line-shaped wall (straight/corner/T/plus)",
    "transmit_node":  "Transmit Node – fires IO channel when triggered by player/timer",
    "receive_node":   "Receive Node – receives IO channel and triggers connected object",
    "edge_wall":      "Edge Wall – thin wall on a tile edge; click a grid line to place",
    "edge_door":      "Edge Door – thin door on a tile edge; rotates open when used, bashed by sprint",
    "region":                   "Region – paint tiles into a visibility zone; adjacent=lit, far=dark",
    "region_inbetween":         "Region Inbetween – connector corridor; both bordering regions lit when player is near",
    "region_inbetween_doorway": "Region Doorway – connector that checks LOS-blocker state; open door = both regions lit, closed = only near side lit",
    # AI hint tiles
    "ai_coverhint":  "Cover Hint – NPCs seek this tile as cover when under fire",
    "ai_chokehint":  "Choke Hint – NPCs coordinate to deny player access to this area",
    "ai_avoidhint":  "Avoid Hint – NPCs route around this zone during patrol",
}

# ── Waypoint node types ───────────────────────────────────────────────────────
WP_TYPES = ["wp_select", "waypoint", "waitpoint", "ignore", "watch", "check"]

WP_ICONS = {
    "wp_select":  "↖",
    "waypoint":   "●",
    "waitpoint":  "⏸",
    "ignore":     "✕",
    "watch":      "👁",
    "check":      "?",
}

# Colours per waypoint node type
WP_COLORS = {
    "wp_select":  QColor(100, 180, 255),
    "waypoint":   QColor( 80, 160, 220),
    "waitpoint":  QColor(200, 160,  60),
    "ignore":     QColor(120, 120, 120),
    "watch":      QColor( 80, 210, 130),
    "check":      QColor(220, 120,  60),
}

WP_TOOLTIP_LONG = {
    "wp_select":
        "<b>WAYPOINT SELECT</b><br>"
        "Click a waypoint node to select it.<br>"
        "Drag to move it. Arrow keys nudge it.<br>"
        "Delete removes it. Dbl-click edits properties.",

    "waypoint":
        "<b>WAYPOINT ●</b><br>"
        "Standard pass-through node. Guard walks<br>"
        "to this position and continues to the next.<br>"
        "Right-click a placed node to erase it.",

    "waitpoint":
        "<b>WAITPOINT ⏸</b><br>"
        "Guard reaches this node and pauses for a<br>"
        "configurable amount of time, slowly rotating<br>"
        "to look around before moving on.",

    "ignore":
        "<b>IGNORE ✕</b><br>"
        "Guard passes through this node with reduced<br>"
        "awareness — suspicion rise rate is lowered<br>"
        "while in the configurable radius around it.<br>"
        "Useful near known noisy areas (vents, etc.).",

    "watch":
        "<b>WATCH 👁</b><br>"
        "Guard will stare intently at this position<br>"
        "while passing nearby — FOV is briefly<br>"
        "redirected toward it. Configurable look time.",

    "check":
        "<b>CHECK ?</b><br>"
        "If placed on a hide spot, guard physically<br>"
        "checks it while patrolling. If placed on a<br>"
        "door, guard may randomly inspect it.<br>"
        "Configurable check chance (0–100%).",
}

DEFAULT_COLS = 22
DEFAULT_ROWS = 16
DEFAULT_TILE = 48

# ══════════════════════════════════════════════════════════════════════════════
# Bundle file format  (.ler / .lep as folders)
# ══════════════════════════════════════════════════════════════════════════════
# A .ler bundle  = folder  roomname.ler/   containing  room.ler   (JSON)
# A .lep bundle  = folder  project.lep/   containing  project.lep (JSON)
# Flat files (legacy single-file format) continue to work transparently.
# All read/write goes through _ler_json_path / _lep_json_path / _bundle_save.

def _ler_json_path(path: str) -> str:
    """Return the actual JSON file inside a .ler bundle (or the path itself).
    Handles Windows permission quirks where isdir() may return False on restricted dirs.
    """
    if path.lower().endswith(".ler"):
        # Try bundle folder first (works even if isdir is unreliable on Windows)
        inner = os.path.join(path, "room.ler")
        if os.path.isfile(inner):
            return inner
        # Try any .ler inside if it's a directory
        try:
            if os.path.isdir(path):
                for f in os.listdir(path):
                    if f.lower().endswith(".ler"):
                        return os.path.join(path, f)
        except OSError:
            pass
    return path  # flat file or unrecognised

def _lep_json_path(path: str) -> str:
    """Return the actual JSON file inside a .lep bundle (or the path itself).

    Priority inside a bundle:
      1. File whose stem matches the bundle folder name (e.g. chapter1.lep
         inside chapter1.lep/)  -- this is the authoritative project file.
      2. Any other non-project.lep file.
      3. project.lep as last resort (some bundles use it as an empty stub).
    """
    if os.path.isdir(path) and path.lower().endswith(".lep"):
        bundle_stem = os.path.splitext(os.path.basename(path))[0].lower()
        try:
            candidates = [f for f in os.listdir(path) if f.lower().endswith(".lep")]
        except OSError:
            return path
        # 1. Stem match
        for f in candidates:
            if os.path.splitext(f)[0].lower() == bundle_stem:
                return os.path.join(path, f)
        # 2. Any non-stub
        for f in candidates:
            if f.lower() != "project.lep":
                return os.path.join(path, f)
        # 3. Stub fallback
        fallback = os.path.join(path, "project.lep")
        if os.path.isfile(fallback):
            return fallback
    return path

def _lep_base(path: str) -> str:
    """Return the directory that sibling .ler room bundles live in, relative to a .lep.

    A .lep bundle is a folder whose name ends .lep.  Room .ler bundles are SIBLINGS
    of that folder, not children.  The correct base for resolving room paths is the
    PARENT of the bundle dir.

    Accepts the bundle dir, the inner JSON, or a flat .lep file.
    """
    p = os.path.abspath(path)
    if p.lower().endswith(".lep"):
        if os.path.isdir(p):
            return os.path.dirname(p)
        elif os.path.isfile(p):
            parent = os.path.dirname(p)
            if parent.lower().endswith(".lep") and os.path.isdir(parent):
                return os.path.dirname(parent)
            return parent
    return os.path.dirname(p)


def _find_room_bundle(raw_path: str, lep_base_dir: str) -> str:
    """Resolve a room path to an existing .ler bundle, searching multiple locations.

    Search order:
      1. Absolute path — used directly.
      2. Relative to lep_base_dir (sibling of the .lep bundle) — normal case.
      3. Inside _PROJECT_ROOT/levels/ and its immediate subdirectories.
      4. Recursive walk of _PROJECT_ROOT/levels/ by name match.
    Returns the first existing path found, or the sibling path as fallback.
    """
    if os.path.isabs(raw_path):
        return raw_path
    sibling = os.path.normpath(os.path.join(lep_base_dir, raw_path))
    if os.path.exists(sibling):
        return sibling
    target_name = os.path.basename(raw_path)
    levels_root = os.path.join(_PROJECT_ROOT, "levels")
    search_dirs = [levels_root]
    try:
        for entry in os.scandir(levels_root):
            if entry.is_dir():
                search_dirs.append(entry.path)
    except OSError:
        pass
    for d in search_dirs:
        candidate = os.path.normpath(os.path.join(d, target_name))
        if os.path.exists(candidate):
            return candidate
    try:
        for dirpath, dirnames, _ in os.walk(levels_root):
            for dn in dirnames:
                if dn.lower() == target_name.lower():
                    candidate = os.path.join(dirpath, dn)
                    if os.path.exists(candidate):
                        return candidate
    except OSError:
        pass
    return sibling


def _save_ler_bundle(data: dict, bundle_path: str) -> None:
    """Write level JSON into a .ler bundle folder, creating it if needed."""
    os.makedirs(bundle_path, exist_ok=True)
    json_path = os.path.join(bundle_path, "room.ler")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def _save_lep_bundle(data: dict, bundle_path: str) -> None:
    """Write project JSON into a .lep bundle folder, creating it if needed."""
    os.makedirs(bundle_path, exist_ok=True)
    json_path = os.path.join(bundle_path, "project.lep")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def _bundle_open_ler(data: dict, path: str) -> dict:
    """Read a .ler (bundle or flat). Returns parsed JSON dict."""
    real = _ler_json_path(path)
    with open(real, encoding="utf-8") as f:
        return json.load(f)

def _bundle_open_lep(data_unused, path: str) -> dict:
    """Read a .lep (bundle or flat). Returns parsed JSON dict."""
    real = _lep_json_path(path)
    with open(real, encoding="utf-8") as f:
        return json.load(f)


class LevelBrowserDialog(QDialog):
    """
    Custom Qt file browser rooted at the project levels/ folder.

    Rules:
    - Normal folders are shown as navigable directories (▶ prefix).
    - Folders/files whose name ends in .ler or .lep are shown as leaf items
      (bundle icons); double-click or Open button selects them.
    - Used for both open AND save-as (save mode allows typing a new name).
    """

    def __init__(self, parent=None, caption="Open Level", mode="open",
                 root_dir=None, ext=".ler"):
        super().__init__(parent)
        self.setWindowTitle(caption)
        self.setMinimumSize(620, 480)
        self._mode = mode          # "open" or "save"
        self._ext  = ext.lower()
        self._result_path = ""

        _pr = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(
                os.path.abspath(__file__)))))
        self._root = os.path.abspath(root_dir or os.path.join(_pr, "levels"))
        os.makedirs(self._root, exist_ok=True)
        self._cwd = self._root

        self._setup_ui()
        self._load_dir()

    # ── UI setup ──────────────────────────────────────────────────────────
    def _setup_ui(self):
        from PyQt6.QtWidgets import (QVBoxLayout, QHBoxLayout, QListWidget,
                                     QListWidgetItem, QLineEdit, QLabel,
                                     QPushButton, QSizePolicy)
        self.setStyleSheet("""
            QDialog        { background:#1a1c26; color:#c8d4e8; font:12px Consolas; }
            QListWidget    { background:#0e1018; border:1px solid #2e3650;
                             color:#b8c8e0; font:12px Consolas; outline:none; }
            QListWidget::item          { padding:5px 10px; }
            QListWidget::item:selected { background:#26508a; color:#e8f0ff; }
            QListWidget::item:hover    { background:#1c2e4a; }
            QLineEdit      { background:#0e1018; border:1px solid #3e4a6a;
                             color:#c8d4e8; padding:4px 8px; font:12px Consolas; }
            QPushButton    { background:#283858; color:#b0c0d8;
                             border:1px solid #3a4a6a; border-radius:3px;
                             padding:4px 12px; font:11px Consolas; }
            QPushButton:hover   { background:#344870; }
            QPushButton:pressed { background:#1e2c50; }
            QLabel         { color:#6878a8; font:11px Consolas; }
        """)
        vbox = QVBoxLayout(self)
        vbox.setSpacing(6); vbox.setContentsMargins(10, 10, 10, 10)

        # Breadcrumb + up button
        nav = QHBoxLayout()
        self._up_btn = QPushButton("←  Up")
        self._up_btn.setFixedWidth(80)
        self._up_btn.clicked.connect(self._go_up)
        self._crumb = QLabel("")
        nav.addWidget(self._up_btn)
        nav.addWidget(self._crumb, 1)
        vbox.addLayout(nav)

        # File list
        self._list = QListWidget()
        self._list.itemDoubleClicked.connect(self._on_double_click)
        self._list.itemClicked.connect(self._on_click)
        vbox.addWidget(self._list, 1)

        # Name field (save mode) or read-only display (open mode)
        name_row = QHBoxLayout()
        name_lbl = QLabel("Name:" if self._mode == "save" else "Selected:")
        self._name_edit = QLineEdit()
        if self._mode == "open":
            self._name_edit.setReadOnly(True)
            self._name_edit.setStyleSheet(
                "background:#090c14; color:#607090; border:1px solid #2a3458;")
        name_row.addWidget(name_lbl)
        name_row.addWidget(self._name_edit, 1)
        vbox.addLayout(name_row)

        # Buttons
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        self._ok_btn = QPushButton("Open" if self._mode == "open" else "Save")
        self._ok_btn.setDefault(True)
        self._ok_btn.clicked.connect(self._accept_selection)
        btn_row.addWidget(cancel)
        btn_row.addWidget(self._ok_btn)
        vbox.addLayout(btn_row)

    # ── directory loading ─────────────────────────────────────────────────
    def _load_dir(self):
        self._list.clear()
        try:
            entries = sorted(os.scandir(self._cwd), key=lambda e: (
                not e.is_dir(), e.name.lower()))
        except PermissionError:
            return

        for e in entries:
            name = e.name
            low  = name.lower()
            if name.startswith(".") or name.startswith("__"):
                continue
            is_bundle = low.endswith(".ler") or low.endswith(".lep")
            is_dir    = e.is_dir() and not is_bundle

            if is_bundle:
                icon = "📦 " if low.endswith(".lep") else "🗂 "
                tag  = "  [project]" if low.endswith(".lep") else "  [room]"
                item = QListWidgetItem(icon + name + tag)
                from PyQt6.QtGui import QColor
                item.setForeground(QColor(140, 220, 130) if low.endswith(".lep")
                                   else QColor(140, 180, 240))
            elif is_dir:
                item = QListWidgetItem("▶  " + name + "/")
            else:
                item = QListWidgetItem("    " + name)
                from PyQt6.QtGui import QColor
                item.setForeground(QColor(80, 95, 120))

            item.setData(256, e.path)      # abs path
            item.setData(257, is_bundle)
            item.setData(258, is_dir)
            self._list.addItem(item)

        # Breadcrumb — show actual root folder name, not hardcoded "levels/"
        root_label = os.path.basename(self._root).rstrip("/\\") + "/"
        rel = os.path.relpath(self._cwd, self._root)
        crumb = root_label + ("" if rel == "." else rel.replace("\\", "/"))
        self._crumb.setText(crumb)
        self._up_btn.setEnabled(self._cwd != self._root)

    def _go_up(self):
        if self._cwd != self._root:
            self._cwd = os.path.dirname(self._cwd)
            self._load_dir()

    def _on_click(self, item):
        abs_p     = item.data(256)
        is_bundle = item.data(257)
        if is_bundle:
            self._name_edit.setText(os.path.basename(abs_p))
            self._result_path = abs_p

    def _on_double_click(self, item):
        abs_p     = item.data(256)
        is_bundle = item.data(257)
        is_dir    = item.data(258)
        if is_bundle:
            self._result_path = abs_p
            self.accept()
        elif is_dir:
            self._cwd = abs_p
            self._load_dir()

    def _accept_selection(self):
        if self._mode == "save":
            name = self._name_edit.text().strip()
            if not name:
                return
            if not name.lower().endswith(self._ext):
                name += self._ext
            self._result_path = os.path.join(self._cwd, name)
            self.accept()
        else:
            if self._result_path:
                self.accept()

    def selected_path(self):
        return self._result_path

    # ── static helpers ────────────────────────────────────────────────────
    @staticmethod
    def get_open(parent, caption, ext=".ler", start_dir=None):
        dlg = LevelBrowserDialog(parent, caption=caption, mode="open", ext=ext,
                                 root_dir=start_dir)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            p = dlg.selected_path()
            if p: return p, True
        return "", False

    @staticmethod
    def get_save(parent, caption, ext=".ler", start_dir=None):
        dlg = LevelBrowserDialog(parent, caption=caption, mode="save", ext=ext,
                                 root_dir=start_dir)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            p = dlg.selected_path()
            if p: return p, True
        return "", False


# ══════════════════════════════════════════════════════════════════════════════
# .lev  Visual Definition System
# ══════════════════════════════════════════════════════════════════════════════
# Path to the shared visual definition file (created on first launch if absent)
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(
                    os.path.abspath(__file__)))))
_LEV_PATH = os.path.join(_PROJECT_ROOT, "integrity", "visuals", "defaultvis_kr.lev")
# Per-tile _keyring.lev files live in integrity/tiles/ alongside .let files.
# Naming: <tile_type>_keyring.lev  (e.g. wall_keyring.lev)
_LET_DIR  = os.path.join(_PROJECT_ROOT, "integrity", "tiles")


# ── PNG cache for editor -----------------------------------------------------
# Keys: absolute path string → QPixmap | None
_PNG_CACHE_QT: dict[str, "QPixmap | None"] = {}

_CUSTOM_DIR_KR      = os.path.join(_LET_DIR, "CUSTOM")
_LEVEL_PNGS_DIR_KR  = os.path.join(_LET_DIR, "level_pngs")
_DEV_PY_KR          = os.path.join(_PROJECT_ROOT, "integrity", "functions", "misc", "dev.py")


def _dev_present_kr() -> bool:
    return os.path.isfile(_DEV_PY_KR)


def _is_custom_kr(tile_type: str) -> bool:
    return os.path.isfile(os.path.join(_CUSTOM_DIR_KR, f"{tile_type}.let"))


def _load_tile_png_qt(tile_type: str, state: str = "", level_stem: str = ""):
    """Return the best-match QPixmap for tile_type+state+level, or None.

    Priority (most-specific first):
      Editor-only overrides (never loaded by the game engine):
        1. level_pngs/editor/<level_stem>/<tile>_<state>.png
        2. level_pngs/editor/<level_stem>/<tile>.png
        3. editor/<tile>_<state>.png
        4. editor/<tile>.png
      Shared game+editor assets (same files the game loads):
        5. level_pngs/<level_stem>/<tile>_<state>.png
        6. level_pngs/<level_stem>/<tile>.png
        7. CUSTOM/<tile>_<state>.png
        8. CUSTOM/<tile>.png
        9. <tile>_<state>.png                (dev.py or custom)
       10. <tile>.png                        (dev.py or custom)

    Results are cached by absolute path.
    """
    candidates = []

    # ── editor-only overrides (highest priority, game never sees these) ────
    _editor_dir    = os.path.join(_LET_DIR, "editor")
    _lvl_editor_dir = os.path.join(_LEVEL_PNGS_DIR_KR, "editor")
    if level_stem:
        lvl_ed = os.path.join(_lvl_editor_dir, level_stem)
        if state:
            candidates.append(os.path.join(lvl_ed, f"{tile_type}_{state}.png"))
        candidates.append(os.path.join(lvl_ed, f"{tile_type}.png"))
    if state:
        candidates.append(os.path.join(_editor_dir, f"{tile_type}_{state}.png"))
    candidates.append(os.path.join(_editor_dir, f"{tile_type}.png"))

    # ── shared game+editor assets ─────────────────────────────────────────
    if level_stem:
        lvl_dir = os.path.join(_LEVEL_PNGS_DIR_KR, level_stem)
        if state:
            candidates.append(os.path.join(lvl_dir, f"{tile_type}_{state}.png"))
        candidates.append(os.path.join(lvl_dir, f"{tile_type}.png"))
        # CUSTOM mirror
        custom_lvl = os.path.join(_LEVEL_PNGS_DIR_KR, "CUSTOM", tile_type, level_stem)
        if state:
            candidates.append(os.path.join(custom_lvl, f"{tile_type}_{state}.png"))
        candidates.append(os.path.join(custom_lvl, f"{tile_type}.png"))

    # global — CUSTOM tiles always allowed; built-ins need dev.py
    allow_global = _is_custom_kr(tile_type) or _dev_present_kr()
    if allow_global:
        if _is_custom_kr(tile_type):
            if state:
                candidates.append(os.path.join(_CUSTOM_DIR_KR, f"{tile_type}_{state}.png"))
            candidates.append(os.path.join(_CUSTOM_DIR_KR, f"{tile_type}.png"))
        if state:
            candidates.append(os.path.join(_LET_DIR, f"{tile_type}_{state}.png"))
        candidates.append(os.path.join(_LET_DIR, f"{tile_type}.png"))

    for path in candidates:
        if path in _PNG_CACHE_QT:
            if _PNG_CACHE_QT[path] is not None:
                return _PNG_CACHE_QT[path]
            continue
        if not os.path.isfile(path):
            _PNG_CACHE_QT[path] = None
            continue
        pix = QPixmap(path)
        _PNG_CACHE_QT[path] = None if pix.isNull() else pix
        if _PNG_CACHE_QT[path] is not None:
            return _PNG_CACHE_QT[path]
    return None


_LEV_DEFS: dict = {}   # tile_type  →  list of layer dicts  (loaded once)

# ── Canonical default .lev (mirrors lockesc.py's _DEFAULT_LEV_JSON) ──────────
_DEFAULT_LEV_JSON = {
    "_comment": "LockESC Visual Definition File (.lev) – auto-generated defaults",
    "_version": 1,
    "_doc": [
        "Each top-level key is a tile type. Entry = list of LAYER objects.",
        "Coordinates are 0..1 fractions of tile size.",
        "color / color2: [R,G,B] or [R,G,B,A]  (0-255 integers).",
        "pen_width: stroke as fraction of tile.",
        "dashed/rounded: bool.",
        "text / font_scale: text label.",
        "pts: [[fx,fy],...] for triangles.",
        "start_angle/span_angle: degrees for arc/pie.",
        "hinge: top-left|top-right|bottom-left|bottom-right|left|right|top|bottom",
        "closed_angle / open_angle: degrees for hinge_line / hinge_dot."
    ],
    "wall": [
        {"type": "rect",    "color": [55, 70, 115]},
        {"type": "line",    "x1": 0.0, "y1": 0.0, "x2": 1.0, "y2": 0.0,  "color": [70, 95, 155],  "pen_width": 0.04},
        {"type": "line",    "x1": 0.0, "y1": 0.0, "x2": 0.0, "y2": 1.0,  "color": [70, 95, 155],  "pen_width": 0.04},
        {"type": "line",    "x1": 1.0, "y1": 0.0, "x2": 1.0, "y2": 1.0,  "color": [20, 28,  52],  "pen_width": 0.02},
        {"type": "line",    "x1": 0.0, "y1": 1.0, "x2": 1.0, "y2": 1.0,  "color": [20, 28,  52],  "pen_width": 0.02}
    ],
    "floor": [{"type": "rect", "color": [28, 52, 88]}],
    "player": [
        {"type": "ellipse",         "x": 0.1,  "y": 0.1,  "w": 0.8, "h": 0.8, "color": [220, 55, 75]},
        {"type": "ellipse_outline", "x": 0.1,  "y": 0.1,  "w": 0.8, "h": 0.8, "color": [255,255,255,60], "pen_width": 0.04},
        {"type": "text",   "text": "P", "color": [255,255,255], "font_scale": 0.28}
    ],
    "exit": [
        {"type": "ellipse",         "x": 0.1,  "y": 0.1,  "w": 0.8, "h": 0.8, "color": [0, 200, 110]},
        {"type": "ellipse_outline", "x": 0.1,  "y": 0.1,  "w": 0.8, "h": 0.8, "color": [255,255,255,60], "pen_width": 0.04},
        {"type": "text",   "text": "E", "color": [255,255,255], "font_scale": 0.28}
    ],
    "loot": [
        {"type": "ellipse",         "x": 0.1,  "y": 0.1,  "w": 0.8, "h": 0.8, "color": [255, 200, 0]},
        {"type": "ellipse_outline", "x": 0.1,  "y": 0.1,  "w": 0.8, "h": 0.8, "color": [255,255,255,60], "pen_width": 0.04},
        {"type": "text",   "text": "$", "color": [255,255,255], "font_scale": 0.28}
    ],
    "mini_loot": [
        {"type": "ellipse",         "x": 0.2,  "y": 0.2,  "w": 0.6, "h": 0.6, "color": [200, 165, 0]},
        {"type": "ellipse_outline", "x": 0.2,  "y": 0.2,  "w": 0.6, "h": 0.6, "color": [255, 220, 80],    "pen_width": 0.05},
        {"type": "ellipse_outline", "x": 0.3,  "y": 0.3,  "w": 0.4, "h": 0.4, "color": [255,245,140,100], "pen_width": 0.03},
        {"type": "text",   "text": "¢", "color": [255,255,200], "font_scale": 0.22}
    ],
    "main_loot": [
        {"type": "radial_gradient_ellipse", "x": 0.05, "y": 0.05, "w": 0.9, "h": 0.9, "color": [255,160,60,200], "color2": [255,80,20,0]},
        {"type": "ellipse",         "x": 0.18, "y": 0.18, "w": 0.64, "h": 0.64, "color": [255, 80, 20]},
        {"type": "ellipse_outline", "x": 0.18, "y": 0.18, "w": 0.64, "h": 0.64, "color": [255,200,80], "pen_width": 0.04},
        {"type": "text",   "text": "★", "color": [255,255,200], "font_scale": 0.30}
    ],
    "hide": [
        {"type": "rect",         "x": 0.04, "y": 0.04, "w": 0.92, "h": 0.92, "color": [80,120,190,80],  "rounded": True},
        {"type": "rect_outline", "x": 0.04, "y": 0.04, "w": 0.92, "h": 0.92, "color": [80,120,190],     "pen_width": 0.04, "rounded": True},
        {"type": "text",   "text": "H", "color": [255,255,255], "font_scale": 0.28}
    ],
    "guard": [
        {"type": "ellipse",         "x": 0.12, "y": 0.12, "w": 0.76, "h": 0.76, "color": [240,165,30]},
        {"type": "ellipse_outline", "x": 0.12, "y": 0.12, "w": 0.76, "h": 0.76, "color": [180,120,10], "pen_width": 0.04},
        {"type": "text",   "text": "G", "color": [255,255,255], "font_scale": 0.28}
    ],
    "door": [
        {"type": "rect",         "color": [140,100,40]},
        {"type": "line", "x1":0.02,"y1":0.02,"x2":1.0,"y2":0.02, "color":[180,140,70],"pen_width":0.04},
        {"type": "line", "x1":0.02,"y1":0.02,"x2":0.02,"y2":1.0, "color":[180,140,70],"pen_width":0.04},
        {"type": "line", "x1":0.02,"y1":0.98,"x2":1.0,"y2":0.98, "color":[50,35,10],  "pen_width":0.04},
        {"type": "line", "x1":0.98,"y1":0.02,"x2":0.98,"y2":0.98,"color":[50,35,10],  "pen_width":0.04},
        {"type": "ellipse", "x":0.78,"y":0.42,"w":0.10,"h":0.10,  "color":[255,200,80]},
        {"type": "text",   "text": "▬", "color": [255,255,255], "font_scale": 0.22}
    ],
    "crashdoor": [
        {"type": "rect",         "color": [180,60,20]},
        {"type": "rect_outline", "x":0.02,"y":0.02,"w":0.96,"h":0.96,"color":[220,80,40],"pen_width":0.06},
        {"type": "cross",        "x1":0.08,"y1":0.08,"x2":0.92,"y2":0.92,"color":[220,80,40],"pen_width":0.07},
        {"type": "text",   "text": "!", "color": [255,180,160], "font_scale": 0.30}
    ],
    "window": [
        {"type": "rect",         "color": [80,160,200,80]},
        {"type": "rect_outline", "x":0.04,"y":0.04,"w":0.92,"h":0.92,"color":[80,160,200],"pen_width":0.04},
        {"type": "line", "x1":0.5,"y1":0.04,"x2":0.5,"y2":0.96,"color":[80,160,200],"pen_width":0.04},
        {"type": "line", "x1":0.04,"y1":0.5,"x2":0.96,"y2":0.5,"color":[80,160,200],"pen_width":0.04},
        {"type": "text",   "text": "≡", "color": [200,240,255], "font_scale": 0.22}
    ],
    "noisemaker": [
        {"type": "radial_gradient_ellipse","x":0.05,"y":0.05,"w":0.9,"h":0.9,"color":[220,120,255,200],"color2":[180,60,220,0]},
        {"type": "ellipse",         "x":0.18,"y":0.18,"w":0.64,"h":0.64,"color":[200,100,220]},
        {"type": "ellipse_outline", "x":0.18,"y":0.18,"w":0.64,"h":0.64,"color":[220,80,255],"pen_width":0.04},
        {"type": "text",   "text": "♪", "color": [255,220,255], "font_scale": 0.26}
    ],
    "oiled_door": [
        {"type": "rect",         "color": [140,100,40]},
        {"type": "line", "x1":0.02,"y1":0.02,"x2":1.0,"y2":0.02, "color":[180,140,70],"pen_width":0.04},
        {"type": "line", "x1":0.02,"y1":0.02,"x2":0.02,"y2":1.0, "color":[180,140,70],"pen_width":0.04},
        {"type": "line", "x1":0.02,"y1":0.98,"x2":1.0,"y2":0.98, "color":[50,35,10],  "pen_width":0.04},
        {"type": "line", "x1":0.98,"y1":0.02,"x2":0.98,"y2":0.98,"color":[50,35,10],  "pen_width":0.04},
        {"type": "ellipse", "x":0.72,"y":0.04,"w":0.14,"h":0.14,  "color":[80,220,100]},
        {"type": "text",   "text": "○▬", "color": [200,255,200], "font_scale": 0.18}
    ],
    "wall_door": [
        {"type": "rect",         "color": [55,70,115]},
        {"type": "line", "x1":0.0,"y1":0.0,"x2":1.0,"y2":0.0, "color":[70,95,155],"pen_width":0.04},
        {"type": "line", "x1":0.0,"y1":0.0,"x2":0.0,"y2":1.0, "color":[70,95,155],"pen_width":0.04},
        {"type": "line", "x1":1.0,"y1":0.0,"x2":1.0,"y2":1.0, "color":[20,28,52], "pen_width":0.02},
        {"type": "line", "x1":0.0,"y1":1.0,"x2":1.0,"y2":1.0, "color":[20,28,52], "pen_width":0.02},
        {"type": "rect_outline","x":0.1,"y":0.1,"w":0.8,"h":0.8,"color":[120,100,170,120],"pen_width":0.02,"dashed":True},
        {"type": "ellipse","x":0.78,"y":0.04,"w":0.1,"h":0.1,   "color":[160,120,220,180]}
    ],
    "thin_door": [
        {"type": "hinge_dot",  "hinge":"top-left","color":[200,150,50], "radius":0.07},
        {"type": "hinge_line", "hinge":"top-left","color":[200,150,50], "pen_width":0.09,
         "closed_angle":0, "open_angle":90}
    ],
    "fence": [
        {"type": "rect",         "color": [28,52,88]},
        {"type": "rect_outline", "x":0.02,"y":0.02,"w":0.96,"h":0.96,"color":[90,120,70],"pen_width":0.04},
        {"_slats": True, "slat_color":[90,120,70],"slat_count":5,"pen_width":0.03},
        {"type": "line", "x1":0.04,"y1":0.5,"x2":0.96,"y2":0.5,"color":[90,120,70],"pen_width":0.02},
        {"type": "text",   "text": "╫", "color": [160,200,120], "font_scale": 0.26}
    ],
    "pit": [
        {"type": "rect",         "color": [12,16,36]},
        {"_hatch": True, "hatch_color":[20,25,50,140],"pen_width":0.02,"spacing":0.17},
        {"type": "ellipse",      "x":0.25,"y":0.25,"w":0.5,"h":0.5,"color":[8,10,22]},
        {"type": "ellipse_outline","x":0.25,"y":0.25,"w":0.5,"h":0.5,"color":[30,40,90],"pen_width":0.02},
        {"type": "text",   "text": "○", "color": [40,55,100], "font_scale": 0.22}
    ],
    "creak_floor": [
        {"_wave": True, "wave_color":[160,120,50,90], "pen_width":0.02, "amplitude":0.07}
    ],
    "snitch": [
        {"type": "triangle", "pts":[[0.5,0.0],[0.0,0.42],[1.0,0.42]], "color":[255,200,70,55]},
        {"type": "ellipse",         "x":0.12,"y":0.12,"w":0.76,"h":0.76,"color":[200,130,40]},
        {"type": "ellipse_outline", "x":0.12,"y":0.12,"w":0.76,"h":0.76,"color":[160,100,10],"pen_width":0.04},
        {"type": "ellipse_outline", "x":0.12,"y":0.12,"w":0.76,"h":0.76,"color":[255,255,255],"pen_width":0.02},
        {"type": "text",   "text": "◈", "color": [255,255,255], "font_scale": 0.26}
    ],
    "camera": [
        {"type": "pie",  "x":0.0,"y":-0.5,"w":2.0,"h":2.0,"color":[140,200,70,50],"start_angle":45,"span_angle":90},
        {"type": "rect", "x":0.25,"y":0.33,"w":0.5,"h":0.34,"color":[140,200,70]},
        {"type": "rect_outline","x":0.25,"y":0.33,"w":0.5,"h":0.34,"color":[80,160,40],"pen_width":0.04},
        {"type": "ellipse","x":0.64,"y":0.42,"w":0.18,"h":0.18,"color":[10,20,8]},
        {"type": "ellipse_outline","x":0.64,"y":0.42,"w":0.18,"h":0.18,"color":[140,200,70],"pen_width":0.02},
        {"type": "text",   "text": "⊙", "color": [220,255,180], "font_scale": 0.22}
    ],
    "invisible_wall": [
        {"type": "rect",         "color": [90,110,180,35]},
        {"type": "rect_outline", "x":0.04,"y":0.04,"w":0.92,"h":0.92,"color":[90,110,180,160],"pen_width":0.04,"dashed":True}
    ],
    "thin_wall": [
        {"_thin_wall_segments": True, "color":[170,195,255],"pen_width":0.11}
    ],
    "transmit_node": [
        {"type": "rect",         "x":0.06,"y":0.06,"w":0.88,"h":0.88,"color":[60,200,210,60]},
        {"type": "rect_outline", "x":0.06,"y":0.06,"w":0.88,"h":0.88,"color":[60,200,210],"pen_width":0.04},
        {"type": "text",   "text": "→", "color": [80,255,255], "font_scale": 0.30}
    ],
    "receive_node": [
        {"type": "rect",         "x":0.06,"y":0.06,"w":0.88,"h":0.88,"color":[210,170,60,60]},
        {"type": "rect_outline", "x":0.06,"y":0.06,"w":0.88,"h":0.88,"color":[210,170,60],"pen_width":0.04},
        {"type": "text",   "text": "←", "color": [255,220,100], "font_scale": 0.30}
    ]
}


def _ensure_lev_file():
    """Write per-tile *_keyring.lev files into integrity/tiles/ if absent.
    Also writes the legacy monolithic defaultvis_kr.lev for compatibility.
    """
    os.makedirs(_LET_DIR, exist_ok=True)
    lev_dir = os.path.dirname(_LEV_PATH)
    os.makedirs(lev_dir, exist_ok=True)
    defaults = {k: v for k, v in _DEFAULT_LEV_JSON.items() if not k.startswith("_")}
    for tile_type, layers in defaults.items():
        per_tile_path = os.path.join(_LET_DIR, f"{tile_type}_keyring.lev")
        if not os.path.exists(per_tile_path):
            try:
                data = {
                    "_comment": f"LockESC Visual Definition - EDITOR (KeyRing) - {tile_type}",
                    "_version": 1,
                    "_note": f"Per-tile visual definition for '{tile_type}'. Used by keyring.py.",
                    tile_type: layers,
                }
                with open(per_tile_path, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
            except Exception as e:
                print(f"[lev] Could not write {per_tile_path}: {e}")
    if not os.path.exists(_LEV_PATH):
        try:
            with open(_LEV_PATH, "w", encoding="utf-8") as f:
                json.dump(_DEFAULT_LEV_JSON, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"[lev] Could not write {_LEV_PATH}: {e}")


def _load_lev_defs() -> dict:
    """Load tile visual definitions STRICTLY from per-tile *_keyring.lev files.

    Priority (highest to lowest):
      1. Per-tile  integrity/tiles/CUSTOM/*_keyring.lev  (custom tile overrides)
      2. Per-tile  integrity/tiles/*_keyring.lev          (built-in tile visuals)
      3. Monolithic integrity/visuals/defaultvis_kr.lev   (legacy monolithic fallback)

    The hardcoded _DEFAULT_LEV_JSON is NO LONGER used as a runtime fallback.
    Use _check_level_integrity() / the per-level build script to ensure required
    files exist.  Missing tiles fall back to a placeholder '?' draw in the editor.
    """
    global _LEV_DEFS
    if _LEV_DEFS:
        return _LEV_DEFS

    merged: dict = {}
    import glob as _glob

    # Step 1a: built-in per-tile *_keyring.lev files
    if os.path.isdir(_LET_DIR):
        for fpath in sorted(_glob.glob(os.path.join(_LET_DIR, "*_keyring.lev"))):
            try:
                with open(fpath, encoding="utf-8") as f:
                    raw = json.load(f)
                for k, v in raw.items():
                    if not k.startswith("_"):
                        merged[k] = v
            except Exception as e:
                print(f"[lev] Skipping {fpath}: {e}")

    # Step 1b: CUSTOM tile overrides (take priority)
    custom_dir = os.path.join(_LET_DIR, "CUSTOM")
    if os.path.isdir(custom_dir):
        for fpath in sorted(_glob.glob(os.path.join(custom_dir, "*_keyring.lev"))):
            try:
                with open(fpath, encoding="utf-8") as f:
                    raw = json.load(f)
                for k, v in raw.items():
                    if not k.startswith("_"):
                        merged[k] = v
            except Exception as e:
                print(f"[lev] Skipping custom {fpath}: {e}")

    # Step 2: monolithic fallback for anything still missing
    try:
        with open(_LEV_PATH, encoding="utf-8") as f:
            mono = json.load(f)
        for k, v in mono.items():
            if not k.startswith("_") and k not in merged:
                merged[k] = v
    except Exception:
        pass

    if merged:
        print(f"[lev] Editor loaded visuals for {len(merged)} tile type(s) from .lev files")
    else:
        print("[lev] WARNING: No _keyring.lev files found — editor tiles will show placeholder '?'")

    _LEV_DEFS = merged
    return _LEV_DEFS


# ── State-visual definitions  (integrity/tiles/state_keyring.lev) ─────────────
# These hold colour/style values for state-dependent drawing in the editor,
# e.g. guard/player/exit colours.  Flat dict wrapped in { "state": { … } }.

_STATE_VIS_DEFS_KR: dict = {}


def _load_state_vis_defs() -> dict:
    """Load state colour definitions from state_keyring.lev (editor variant).
    Falls back to state_lockesc.lev, then to empty dict.
    """
    global _STATE_VIS_DEFS_KR
    if _STATE_VIS_DEFS_KR:
        return _STATE_VIS_DEFS_KR

    candidates = [
        os.path.join(_LET_DIR, "CUSTOM", "state_keyring.lev"),
        os.path.join(_LET_DIR, "state_keyring.lev"),
        os.path.join(_LET_DIR, "CUSTOM", "state_lockesc.lev"),
        os.path.join(_LET_DIR, "state_lockesc.lev"),
    ]
    for path in candidates:
        if os.path.isfile(path):
            try:
                with open(path, encoding="utf-8") as f:
                    raw = json.load(f)
                colours = raw.get("state", raw)
                merged: dict = {}
                for k, v in colours.items():
                    if k.startswith("_"):
                        continue
                    if isinstance(v, (list, tuple)) and len(v) >= 3:
                        merged[k] = tuple(int(x) for x in v[:4])
                _STATE_VIS_DEFS_KR = merged
                return _STATE_VIS_DEFS_KR
            except Exception as e:
                print(f"[lev] Could not load state vis from {path}: {e}")

    _STATE_VIS_DEFS_KR = {}
    return _STATE_VIS_DEFS_KR


# ── Level integrity helpers (editor mirror of lockesc version) ─────────────────

_ESSENTIAL_TILE_TYPES_KR = {
    "wall", "floor", "player", "player2", "exit", "loot", "mini_loot", "main_loot",
    "hide", "guard", "door", "oiled_door", "wall_door", "crashdoor",
    "window", "fence", "pit", "creak_floor", "item_pile", "snitch", "camera",
    "invisible_wall", "thin_wall", "thin_door",
    "transmit_node", "receive_node", "noisemaker",
}


def _collect_required_tiles_kr(level_data: dict) -> set:
    """Return set of tile types referenced in a level's objects list."""
    return {obj.get("type", "") for obj in level_data.get("objects", []) if obj.get("type")}


def _missing_tile_assets_kr(required_types: set) -> list:
    """Return list of (tile_type, missing_kind) for absent files.
    missing_kind: 'let' | 'keyring_lev'
    """
    import glob as _glob
    existing_let = set()
    existing_lev = set()
    for d in (_LET_DIR, os.path.join(_LET_DIR, "CUSTOM")):
        if not os.path.isdir(d):
            continue
        for fp in _glob.glob(os.path.join(d, "*.let")):
            existing_let.add(os.path.basename(fp)[:-4])
        for fp in _glob.glob(os.path.join(d, "*_keyring.lev")):
            name = os.path.basename(fp)
            if name.endswith("_keyring.lev"):
                existing_lev.add(name[:-len("_keyring.lev")])

    missing = []
    for tt in sorted(required_types):
        if tt in ("region", "region_inbetween", "region_inbetween_doorway",
                  "ai_coverhint", "ai_chokehint", "ai_avoidhint",
                  "timer_node", "input_node", "output_node", "bob", "floor"):
            continue
        is_builtin = tt in _ESSENTIAL_TILE_TYPES_KR
        if not is_builtin and tt not in existing_let:
            missing.append((tt, "let"))
        if tt not in existing_lev:
            missing.append((tt, "keyring_lev"))
    return missing


# ── .let tile definition loader ───────────────────────────────────────────────
_LET_DEFS: dict = {}  # tile_type → full .let dict (loaded once)


def _load_let_defs() -> dict:
    """Load per-tile .let definition files from integrity/tiles/.

    Returns a dict of tile_type → let definition dict.
    Falls back gracefully – missing files simply won't override hardcoded values.
    """
    global _LET_DEFS
    if _LET_DEFS:
        return _LET_DEFS
    import glob as _glob
    if not os.path.isdir(_LET_DIR):
        return {}
    for fpath in sorted(_glob.glob(os.path.join(_LET_DIR, "*.let"))):
        try:
            with open(fpath, encoding="utf-8") as f:
                data = json.load(f)
            tile_type = data.get("type")
            if tile_type:
                _LET_DEFS[tile_type] = data
        except Exception as e:
            print(f"[let] Skipping {fpath}: {e}")
    # Also load from CUSTOM subdirectory (custom tiles override built-ins)
    custom_dir = os.path.join(_LET_DIR, "CUSTOM")
    if os.path.isdir(custom_dir):
        for fpath in sorted(_glob.glob(os.path.join(custom_dir, "*.let"))):
            try:
                with open(fpath, encoding="utf-8") as f:
                    data = json.load(f)
                tile_type = data.get("type")
                if tile_type:
                    _LET_DEFS[tile_type] = data
            except Exception as e:
                print(f"[let] Skipping custom {fpath}: {e}")
    if _LET_DEFS:
        print(f"[let] Loaded tile definitions: {sorted(_LET_DEFS.keys())}")
    return _LET_DEFS


def _apply_let_defs():
    """Merge .let definitions into TILE_TYPES, TILE_ICONS, TILE_TOOLTIP_LONG.

    Called once at startup after both lists are fully constructed.
    New tile types found only in .let files (not in hardcoded TILE_TYPES) are
    appended so the editor can use them without code changes.
    """
    defs = _load_let_defs()
    for tile_type, let in defs.items():
        # Add to TILE_TYPES if not already present
        if tile_type not in TILE_TYPES:
            TILE_TYPES.append(tile_type)
            print(f"[let] Registered new tile type from .let: {tile_type}")
        # Update tooltip from label + category if not already customised
        if tile_type not in TILE_TOOLTIP_LONG:
            label    = let.get("label", tile_type)
            category = let.get("category", "")
            TILE_TOOLTIP_LONG[tile_type] = f"<b>{label.upper()}</b><br>Category: {category}"

    # ── Story Dev: register story-only tile types if dev.py is present ────
    try:
        from integrity.functions.misc.dev import register_story_tiles as _reg_story
        _reg_story(TILE_TYPES, TILE_ICONS, TILE_TOOLTIP_LONG)
        print("[dev] Story tile types registered from integrity/functions/misc/dev.py")
    except ImportError:
        pass  # dev.py not present — story tiles unavailable, no error


def _let_flag(tile_type: str, flag: str, default=False):
    """Return a flag value from the .let definition for a tile type."""
    defs = _load_let_defs()
    let  = defs.get(tile_type, {})
    return let.get("flags", {}).get(flag, default)


def _qcol(lst, fallback=None):
    """[R,G,B] or [R,G,B,A] → QColor, with optional fallback."""
    if lst and len(lst) >= 3:
        if len(lst) == 4:
            return QColor(lst[0], lst[1], lst[2], lst[3])
        return QColor(lst[0], lst[1], lst[2])
    return fallback or QColor(128, 128, 128)


def _draw_lev_tile(painter: QPainter, tile_type: str,
                   rx: int, ry: int, tp: int,
                   obj: dict = None,
                   state: str = "",
                   level_stem: str = ""):
    """
    Draw one tile using its .lev layer stack (or PNG override).

    rx, ry     = pixel top-left of the tile
    tp         = tile size in pixels
    obj        = tile object dict (shape/rotation/open state for thin_door etc.)
    state      = visual state: "open","closed","bashed","collected","present",""
    level_stem = bare level name for level-specific PNG lookup

    Returns True if drawn; False if no .lev entry exists (caller draws fallback).
    """
    # PNG override: level-specific first, then global hierarchy
    pix = _load_tile_png_qt(tile_type, state=state, level_stem=level_stem)
    if pix:
        if pix.width() != tp or pix.height() != tp:
            pix = pix.scaled(tp, tp,
                             Qt.AspectRatioMode.IgnoreAspectRatio,
                             Qt.TransformationMode.SmoothTransformation)
        painter.drawPixmap(rx, ry, pix)
        return True

    defs = _load_lev_defs()
    layers = defs.get(tile_type)
    if not layers:
        return False

    p = painter
    p.save()

    def px(f):  return rx + int(f * tp)
    def py(f):  return ry + int(f * tp)
    def pw(f):  return max(1, int(f * tp))

    for layer in layers:
        t = layer.get("type", "")
        col  = _qcol(layer.get("color"),  QColor(200, 200, 200))
        col2 = _qcol(layer.get("color2"), QColor(0, 0, 0, 0))
        lw   = pw(layer.get("pen_width", 0.04))
        x0, y0 = px(layer.get("x", 0.0)), py(layer.get("y", 0.0))
        w0, h0 = pw(layer.get("w", 1.0)), pw(layer.get("h", 1.0))
        is_dashed  = layer.get("dashed", False)
        is_rounded = layer.get("rounded", False)

        pen_style = Qt.PenStyle.DashLine if is_dashed else Qt.PenStyle.SolidLine

        if t == "rect":
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(col))
            if is_rounded:
                p.drawRoundedRect(x0, y0, w0, h0, 4, 4)
            else:
                p.drawRect(x0, y0, w0, h0)

        elif t == "rect_outline":
            p.setPen(QPen(col, lw, pen_style))
            p.setBrush(Qt.BrushStyle.NoBrush)
            if is_rounded:
                p.drawRoundedRect(x0, y0, w0, h0, 4, 4)
            else:
                p.drawRect(x0, y0, w0, h0)

        elif t == "ellipse":
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(col))
            p.drawEllipse(x0, y0, w0, h0)

        elif t == "ellipse_outline":
            p.setPen(QPen(col, lw, pen_style))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(x0, y0, w0, h0)

        elif t == "line":
            cap = (Qt.PenCapStyle.RoundCap if layer.get("cap") == "round"
                   else Qt.PenCapStyle.FlatCap)
            pen = QPen(col, lw, pen_style, cap)
            p.setPen(pen)
            p.drawLine(px(layer.get("x1", 0.0)), py(layer.get("y1", 0.0)),
                       px(layer.get("x2", 1.0)), py(layer.get("y2", 1.0)))

        elif t == "cross":
            cap = Qt.PenCapStyle.RoundCap
            pen = QPen(col, lw, Qt.PenStyle.SolidLine, cap)
            p.setPen(pen)
            x1, y1 = px(layer.get("x1", 0.08)), py(layer.get("y1", 0.08))
            x2, y2 = px(layer.get("x2", 0.92)), py(layer.get("y2", 0.92))
            p.drawLine(x1, y1, x2, y2)
            p.drawLine(x2, y1, x1, y2)

        elif t == "plus":
            pen = QPen(col, lw, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
            p.setPen(pen)
            cx2 = rx + tp // 2;  cy2 = ry + tp // 2
            p.drawLine(px(layer.get("margin", 0.08)), cy2, px(1.0 - layer.get("margin", 0.08)), cy2)
            p.drawLine(cx2, py(layer.get("margin", 0.08)), cx2, py(1.0 - layer.get("margin", 0.08)))

        elif t == "arc":
            pen = QPen(col, lw)
            p.setPen(pen); p.setBrush(Qt.BrushStyle.NoBrush)
            sa = int(layer.get("start_angle", 0) * 16)
            sp = int(layer.get("span_angle", 90) * 16)
            p.drawArc(x0, y0, w0, h0, sa, sp)

        elif t == "pie":
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(col))
            sa = int(layer.get("start_angle", 45) * 16)
            sp = int(layer.get("span_angle", 90) * 16)
            p.drawPie(x0, y0, w0, h0, sa, sp)

        elif t == "triangle":
            pts_f = layer.get("pts", [[0.5,0],[0,1],[1,1]])
            poly  = QPolygon([QPoint(px(pt[0]), py(pt[1])) for pt in pts_f])
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(col))
            p.drawPolygon(poly)

        elif t == "radial_gradient_ellipse":
            cx2 = x0 + w0 // 2;  cy2 = y0 + h0 // 2
            grad = QRadialGradient(cx2, cy2, w0 // 2)
            grad.setColorAt(0, col)
            grad.setColorAt(1, col2)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(grad))
            p.drawEllipse(x0, y0, w0, h0)

        elif t == "text":
            if tp >= 16:
                fsize = max(6, int(layer.get("font_scale", 0.25) * tp))
                p.setPen(QPen(col))
                p.setFont(QFont("Consolas", fsize, QFont.Weight.Bold))
                p.drawText(rx, ry, tp, tp, Qt.AlignmentFlag.AlignCenter,
                           layer.get("text", "?"))

        # ── Thin-door hinge layers ────────────────────────────────────────
        elif t in ("hinge_dot", "hinge_line"):
            _draw_hinge_layer(p, layer, rx, ry, tp, obj)

        # ── Special procedural layers ─────────────────────────────────────
        elif layer.get("_slats"):
            # Fence vertical slats
            sc = _qcol(layer.get("slat_color"), col)
            slw = pw(layer.get("pen_width", 0.03))
            p.setPen(QPen(sc, slw))
            count = layer.get("slat_count", 5)
            for i in range(1, count):
                xi = rx + int(i * tp / count)
                p.drawLine(xi, ry + 2, xi, ry + tp - 2)

        elif layer.get("_hatch"):
            hc = _qcol(layer.get("hatch_color"), col)
            hlw = pw(layer.get("pen_width", 0.02))
            p.setPen(QPen(hc, hlw))
            gap = int(layer.get("spacing", 0.17) * tp)
            for xi in range(0, tp * 2, max(4, gap)):
                p.drawLine(rx + xi - tp, ry, rx + xi, ry + tp)

        elif layer.get("_wave"):
            wc = _qcol(layer.get("wave_color"), col)
            wlw = pw(layer.get("pen_width", 0.02))
            amp = layer.get("amplitude", 0.07) * tp
            cy2 = ry + tp // 2
            p.setPen(QPen(wc, wlw))
            pts_w = []
            for xi in range(rx + 4, rx + tp - 3, 2):
                yi = int(cy2 + math.sin((xi - rx) * 0.5) * amp)
                pts_w.append(QPoint(xi, yi))
            for i in range(len(pts_w) - 1):
                p.drawLine(pts_w[i], pts_w[i + 1])

        elif layer.get("_thin_wall_segments"):
            # Reuses _thin_wall_segs helper — passes obj shape/rotation
            tc = _qcol(layer.get("color"), QColor(170, 195, 255))
            tlw = pw(layer.get("pen_width", 0.11))
            pen_tw = QPen(tc, tlw, Qt.PenStyle.SolidLine,
                          Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
            p.setPen(pen_tw)
            shape = (obj or {}).get("shape", "straight")
            rot   = (obj or {}).get("rotation", 0)
            for x1, y1, x2, y2 in _thin_wall_segs(rx, ry, tp, shape, rot):
                p.drawLine(x1, y1, x2, y2)

    p.restore()
    return True


def _hinge_corner(hinge_str: str, rx: int, ry: int, tp: int):
    """Return (hx, hy) pixel position of the hinge from a string descriptor."""
    h = hinge_str.lower()
    if h == "top-left":     return rx,      ry
    if h == "top-right":    return rx + tp, ry
    if h == "bottom-left":  return rx,      ry + tp
    if h == "bottom-right": return rx + tp, ry + tp
    if h == "left":         return rx,      ry + tp // 2
    if h == "right":        return rx + tp, ry + tp // 2
    if h == "top":          return rx + tp // 2, ry
    if h == "bottom":       return rx + tp // 2, ry + tp
    return rx, ry  # fallback


def _draw_hinge_layer(p: QPainter, layer: dict,
                      rx: int, ry: int, tp: int, obj: dict):
    """Draw a hinge_line or hinge_dot layer for thin_door tiles."""
    obj = obj or {}
    is_open     = obj.get("open", False)
    base_rot    = obj.get("rotation", 0)  # editor rotation (0/90/180/270)
    hinge_str   = layer.get("hinge", "top-left")
    hx, hy      = _hinge_corner(hinge_str, rx, ry, tp)

    # Door angle: closed = closed_angle + base_rot
    #             open   = closed_angle + base_rot + open_offset
    closed_angle = layer.get("closed_angle", 0)
    open_offset  = layer.get("open_angle", 90)
    angle_deg    = (closed_angle + base_rot + (open_offset if is_open else 0)) % 360
    angle_rad    = math.radians(angle_deg)

    door_len = tp * 0.88   # door length ≈ 88% of tile
    ex = hx + door_len * math.cos(angle_rad)
    ey = hy + door_len * math.sin(angle_rad)

    col = _qcol(layer.get("color"), QColor(200, 150, 50))
    if is_open:
        col = QColor(120, 200, 100)

    t = layer.get("type", "")
    if t == "hinge_line":
        lw = max(2, int(layer.get("pen_width", 0.09) * tp))
        pen = QPen(col, lw, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
        p.setPen(pen)
        p.drawLine(hx, hy, int(ex), int(ey))

    elif t == "hinge_dot":
        r = int(layer.get("radius", 0.07) * tp)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(col))
        p.drawEllipse(hx - r, hy - r, r * 2, r * 2)


# ── IO Signal/Slot definitions per tile type ──────────────────────────────
# TILE_SLOTS:   { tile_type: [slot_name, ...] }   (inputs – things that can be triggered)
# TILE_SIGNALS: { tile_type: [signal_name, ...] } (outputs – events this tile emits)
TILE_SLOTS = {
    "door":           ["open_door", "close_door", "toggle_door"],
    "oiled_door":     ["open_door", "close_door", "toggle_door"],
    "wall_door":      ["open_wall_door", "close_wall_door", "toggle_wall_door"],
    "thin_door":      ["open_door", "close_door", "toggle_door"],
    "crashdoor":      ["lock", "unlock"],
    "noisemaker":     ["toggle_noisemaker"],
    "snitch":         ["activate", "deactivate", "alert"],
    "camera":         ["activate", "deactivate"],
    "loot":           ["enable", "disable"],
    "mini_loot":      ["enable", "disable"],
    "main_loot":      ["enable", "disable"],
    "exit":           ["unlock", "lock"],
    "hide":           ["enable", "disable"],
    "creak_floor":    ["enable", "disable"],
    "pit":            ["enable", "disable"],
    "fence":          ["enable", "disable"],
    "receive_node":   ["trigger"],
}
TILE_SIGNALS = {
    "door":           ["on_opened", "on_closed", "on_interacted", "on_bashed"],
    "oiled_door":     ["on_opened", "on_closed", "on_interacted"],
    "wall_door":      ["on_opened", "on_closed", "on_interacted"],
    "thin_door":      ["on_opened", "on_closed", "on_interacted"],
    "crashdoor":      ["on_rammed"],
    "noisemaker":     ["on_pulse"],
    "snitch":         ["on_spotted", "on_lost"],
    "camera":         ["on_spotted", "on_lost"],
    "loot":           ["on_pickup"],
    "mini_loot":      ["on_pickup"],
    "main_loot":      ["on_pickup", "on_main_loot_pickup"],
    "item_pile":      ["on_pickup"],
    "exit":           ["on_used"],
    "creak_floor":    ["on_walked", "on_sprinted"],
    "guard":          ["on_alert", "on_chase", "on_patrol"],
    "transmit_node":  ["on_triggered"],
}


# ════════════════════════════════════════════════════════════════════════════
# Top tile-tool bar  (icon strip, left-weighted, with tooltips)
# ════════════════════════════════════════════════════════════════════════════

# Longer tooltip descriptions shown on hover
TILE_TOOLTIP_LONG = {
    "wall":      "<b>WALL</b><br>Solid obstacle – blocks movement and LOS.<br>"
                 "Guards and players cannot pass through.<br>"
                 "Dampens noise by ~45% per wall layer.",
    "floor":     "<b>FLOOR</b><br>Open walkable space (implicit – everything<br>"
                 "that isn't a wall is floor). Place explicitly to<br>override other tiles.",
    "player":    "<b>PLAYER START</b><br>Where the player spawns.<br>"
                 "Only one allowed per level.",
    "player2":   "<b>PLAYER 2 START</b><br>Where the second player spawns<br>"
                 "in multiplayer mode. Only used when the level is loaded<br>"
                 "via the MULTIPLAYER config. One per level.",
    "exit":      "<b>EXIT</b><br>Escape point. Locked until win condition met<br>"
                 "(all loot collected, or main loot grabbed).<br>One per level.",
    "loot":      "<b>LOOT</b><br>Collectible item — +100 pts each.<br>"
                 "Collect all loot (or grab Main Loot) to open the Exit.",
    "main_loot": "<b>MAIN LOOT ★</b><br>Primary objective. Grabbing it<br>"
                 "immediately opens the exit — but guards will<br>"
                 "notice the empty pedestal and trigger a SEARCH sweep.",
    "hide":      "<b>HIDE SPOT</b><br>Player presses <b>H</b> here to go invisible.<br>"
                 "Guards in SEARCH mode will still check hide spots.<br>"
                 "Witnessing the player hide triggers immediate chase.",
    "guard":     "<b>GUARD</b><br>AI security guard. Place then add waypoints<br>"
                 "in the Guard panel. Dot waypoints = normal pass-through.<br>"
                 "Ring waypoints = guard pauses and looks around.<br>"
                 "Properties: <b>knows_layout</b> (smarter intercept) and<br>"
                 "<b>ambusher</b> (cuts off player in pursuit).",
    "door":      "<b>DOOR</b><br>Player presses <b>E</b> to toggle open/closed.<br>"
                 "Guards notice open doors and will close them.<br>"
                 "Opening once = soft noise. Opening twice quickly = suspicious.",
    "crashdoor": "<b>CRASH-DOOR !</b><br>Requires the player to <b>sprint-ram</b> it to open.<br>"
                 "Makes a huge noise (score 95, radius 8 tiles).<br>"
                 "Guards across the level will investigate.",
    "window":    "<b>WINDOW ≡</b><br>Guards can see through windows (transparent LOS).<br>"
                 "Players cannot pass through them.<br>"
                 "Noise is NOT dampened through windows.",
    "noisemaker":"<b>NOISEMAKER ♪</b><br>Emits periodic noise pulses on a timer.<br>"
                 "Configure interval, score, radius and ambiguity<br>"
                 "in the property editor (dbl-click after placing).",
    "oiled_door":"<b>OILED DOOR ○▬</b><br>Silent door – makes no noise when toggled.<br>"
                 "Subtle green tint distinguishes it from regular doors.<br>"
                 "Guards still close open oiled doors on patrol.",
    "wall_door": "<b>WALL DOOR ?▬</b><br>Secret door hidden in the wall.<br>"
                 "Completely indistinguishable from a wall when closed.<br>"
                 "Player presses E to open. Guards don't notice it.",
    "fence":     "<b>FENCE ╫</b><br>Blocks player movement but guards see through it.<br>"
                 "Fences do not block guard LOS or dampen noise.",
    "pit":       "<b>PIT ○</b><br>Instant death if the player sprints into it.<br>"
                 "Walking players stop at the edge safely.<br>"
                 "Falls show \"FALLEN!\" not \"CAUGHT!\".",
    "creak_floor":"<b>CREAK FLOOR ~</b><br>Emits noise when the player walks/sprints on it.<br>"
                  "Walk score 35 · Sprint score 60 · Cooldown 0.5 s.",
    "item_pile":  "<b>ITEM PILE ✦</b><br>A collectible pile of items on the floor.<br>"
                  "Player walks over it to pick up contents.<br>"
                  "Supports weapons, keycards, wearables (equip_wear) and gear (equip_gear).",
    "buy_item":   "<b>BUY ITEM $</b><br>Shop purchase tile (shop rooms only).<br>"
                  "Player steps on it to open an in-game keyboard purchase menu.<br>"
                  "Configure items, prices and stock in properties.<br>"
                  "Supports weapons, keycards, wearables (equip_wear) and gear (equip_gear).",
    "shop_leave": "<b>SHOP LEAVE →</b><br>Shop exit tile (shop rooms only).<br>"
                  "Player steps on it to leave the shop and advance to the next level.",
    "detail_img": "<b>DETAIL IMAGE 🖼</b><br>"
                  "Decorative image drawn at a chosen render layer.<br>"
                  "Image is stored inside the level bundle under <b>images/</b> —<br>"
                  "use the ✎ browse button in Properties to pick &amp; copy it in.<br>"
                  "Size can span multiple tiles (e.g. 3×2 for a floor mural).<br>"
                  "<b>Layer 0</b> = behind items &amp; player (floor art)<br>"
                  "<b>Layer 1</b> = above items, below player (ground decals)<br>"
                  "<b>Layer 2</b> = above everything (overlays, fog, signs)<br>"
                  "Alpha 0–255 controls transparency.",
    "detail_txt": "<b>DETAIL TEXT T</b><br>Decorative text label drawn at a chosen layer.<br>"
                  "Useful for tutorial prompts, floor signs, and in-world UI.<br>"
                  "Supports \\\\n for newlines. Size sets the word-wrap bounds.",
    "snitch":    "<b>SNITCH ◈</b><br>Stationary guard with rotating FOV cone.<br>"
                 "Configure rotation speed and FOV angle in properties.",
    "camera":    "<b>CAMERA ⊙</b><br>Security camera with scanning arc FOV.<br>"
                 "Configure sweep range, speed and sight in properties.<br>"
                 "Alerts all guards when it spots the player.",
    "invisible_wall": "<b>INVISIBLE WALL ░</b><br>Solid wall – blocks movement and LOS.<br>"
                 "Completely invisible during gameplay.<br>"
                 "Editor shows it as a faint dashed ghost outline.",
    "thin_wall": "<b>THIN WALL ┼</b><br>A thin line wall drawn within the tile.<br>"
                 "Shapes: Straight · Corner · T-junction · Plus.<br>"
                 "Double-click to set shape and rotation (0/90/180/270°).<br>"
                 "Blocks movement and LOS like a full wall.",
    "mini_loot": "<b>MINI LOOT ¢</b><br>A small collectible — +25 pts each.<br>"
                 "Does NOT count toward the loot total needed to open the exit.<br>"
                 "Good for optional score pickups or secrets.",
    "thin_door": "<b>THIN DOOR ⌶</b><br>A line-shaped door that swings open 90°.<br>"
                 "Player presses <b>E</b> to toggle open/closed.<br>"
                 "Makes door noise; guards notice open thin doors.<br>"
                 "Set shape and rotation in properties (like thin wall).",
    "transmit_node": "<b>TRANSMIT NODE →</b><br>Fires an IO channel when triggered.<br>"
                 "Trigger modes: player step, proximity, interval.<br>"
                 "Wire to Receive Nodes via the Connection panel (W key).",
    "receive_node":  "<b>RECEIVE NODE ←</b><br>Receives an IO channel and triggers an action.<br>"
                 "Connects to doors, cameras, noisemakers, etc.<br>"
                 "Wire from Transmit Nodes via the Connection panel (W key).",
    "erase":     "<b>ERASE</b><br>Remove tiles. Right-click always erases<br>"
                 "regardless of active tool.",
    "select":    "<b>SELECT ▣</b><br>Drag to marquee-select a region.<br>"
                 "Double-click a tile to open its property editor.<br>"
                 "Alt+Enter on hovered tile also opens properties.<br>"
                 "Delete key erases all selected tiles.",
    "edge_wall": "<b>EDGE WALL ┃</b><br>A thin wall placed ON a grid line between tiles.<br>"
                 "Click any grid edge to place. Blocks movement and LOS.<br>"
                 "Perfect for interior walls without filling full tiles.",
    "edge_door": "<b>EDGE DOOR ⌶</b><br>A thin door on a tile edge.<br>"
                 "Opens by rotating 90° away from the hinge; refuses to open<br>"
                 "if something is blocking the swing path.<br>"
                 "Sprint into it to bash it open loudly.",
    "region":    "<b>REGION ⬡</b><br>Paint tiles into a named visibility zone.<br>"
                 "Player's region + adjacent = fully lit. Two regions away = black.<br>"
                 "Guards in dark regions emit faint noise silhouettes.<br>"
                 "Use Edit > Set Region ID to switch between regions 1–9.",
    "region_inbetween":
                 "<b>REGION INBETWEEN ⬡~</b><br>"
                 "Connector corridor between two numbered regions.<br>"
                 "When the player enters this tile (or any region bordering it),<br>"
                 "both adjacent regions are lit simultaneously.<br>"
                 "Use this for hallways, doorframes, and open archways.<br>"
                 "Does NOT need a region_id – it connects automatically by adjacency.",
    "region_inbetween_doorway":
                 "<b>REGION DOORWAY ⬡|</b><br>"
                 "LOS-aware connector between two numbered regions.<br>"
                 "Checks whether any door/crashdoor/wall-door/thin-door<br>"
                 "on or adjacent to this tile is currently <b>closed</b>.<br>"
                 "• All openables OPEN → both regions lit (you can see through).<br>"
                 "• Any openable CLOSED → only the near side is lit (sealed room).<br>"
                 "• No openable present → behaves like a plain inbetween.<br>"
                 "Optional JSON field 'connects':[rid_a,rid_b] pins the two regions;<br>"
                 "if omitted they are auto-detected from adjacency.",
    # ── AI hint tiles ──────────────────────────────────────────────────────
    "ai_coverhint":
                 "<b>COVER ⛉ (ai_coverhint)</b><br>"
                 "Paint tiles NPCs strongly prefer as cover during combat.<br>"
                 "Guards fleeing gunshots will path toward these spots above all.<br>"
                 "Invisible in-game. Works alongside wall-adjacency scoring.<br>"
                 "Useful near walls, pillars, and crates.",
    "ai_chokehint":
                 "<b>BLOCK ⛒ (ai_chokehint)</b><br>"
                 "Paint a zone NPCs will coordinate to deny the player access to.<br>"
                 "During chase, guards try to converge on or encircle this area.<br>"
                 "Invisible in-game. Good for doorways, narrow corridors, and exits.",
    "ai_avoidhint":
                 "<b>AVOID ⊗ (ai_avoidhint)</b><br>"
                 "Paint tiles guards treat as obstructions during patrol routing.<br>"
                 "Guards will path around this zone even if it is physically open.<br>"
                 "Invisible in-game. Use to shape patrol routes without walls.",
}

_TOOL_ORDER = TILE_TYPES + ["erase", "select"]

_TOOL_ICONS_TEXT = dict(TILE_ICONS)
_TOOL_ICONS_TEXT["erase"]  = "✕"
_TOOL_ICONS_TEXT["select"] = "▣"

# Separator groups – put a visual gap before these tools
_SEPARATORS_BEFORE = {"oiled_door", "transmit_node", "erase", "select"}


def _make_wp_pixmap(wp_type, size=32):
    """Render a waypoint-tool icon pixmap."""
    col = WP_COLORS.get(wp_type, QColor(150, 150, 150))
    pix = QPixmap(size, size)
    pix.fill(Qt.GlobalColor.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    cx = cy = size // 2
    r  = size // 2 - 3

    if wp_type == "wp_select":
        p.setPen(QPen(col, 2, Qt.PenStyle.DashLine))
        p.setBrush(QBrush(QColor(col.red(), col.green(), col.blue(), 30)))
        p.drawRect(4, 4, size-8, size-8)

    elif wp_type == "waypoint":
        p.setPen(QPen(col.darker(130), 2))
        p.setBrush(QBrush(col))
        p.drawEllipse(cx-r, cy-r, r*2, r*2)

    elif wp_type == "waitpoint":
        # filled circle with pause bars inside
        p.setPen(QPen(col.darker(130), 2))
        p.setBrush(QBrush(col))
        p.drawEllipse(cx-r, cy-r, r*2, r*2)
        p.setPen(QPen(QColor(255,255,255), max(2, size//10)))
        bw = max(2, size//8)
        p.drawLine(cx-bw, cy-r+4, cx-bw, cy+r-4)
        p.drawLine(cx+bw, cy-r+4, cx+bw, cy+r-4)

    elif wp_type == "ignore":
        # grey circle with X
        p.setPen(QPen(col.darker(120), 2))
        p.setBrush(QBrush(col))
        p.drawEllipse(cx-r, cy-r, r*2, r*2)
        p.setPen(QPen(QColor(255,255,255), max(2, size//9)))
        p.drawLine(cx-r+4, cy-r+4, cx+r-4, cy+r-4)
        p.drawLine(cx+r-4, cy-r+4, cx-r+4, cy+r-4)

    elif wp_type == "watch":
        # eye shape
        path = QPainterPath()
        path.moveTo(cx - r, cy)
        path.quadTo(cx, cy - r, cx + r, cy)
        path.quadTo(cx, cy + r, cx - r, cy)
        p.setPen(QPen(col, 2))
        p.setBrush(QBrush(QColor(col.red(), col.green(), col.blue(), 60)))
        p.drawPath(path)
        p.setPen(QPen(col.darker(120), 2))
        p.setBrush(QBrush(col))
        iris = max(3, r // 2)
        p.drawEllipse(cx - iris, cy - iris, iris*2, iris*2)

    elif wp_type == "check":
        # diamond shape
        poly = QPolygon([
            QPoint(cx, cy - r),
            QPoint(cx + r, cy),
            QPoint(cx, cy + r),
            QPoint(cx - r, cy),
        ])
        p.setPen(QPen(col.darker(120), 2))
        p.setBrush(QBrush(col))
        p.drawPolygon(poly)
        p.setPen(QPen(QColor(255,255,255), max(1, size//12)))
        p.setFont(QFont("Consolas", max(5, size//4), QFont.Weight.Bold))
        p.drawText(0, 0, size, size, Qt.AlignmentFlag.AlignCenter, "?")

    p.end()
    return pix


def _make_tile_pixmap(tool_name, size=32):
    """Render a small coloured tile icon as a QPixmap.

    If a PNG override exists for the given tool/tile, return that scaled to the
    requested size. Otherwise fall back to the original procedurally-generated
    icon for shapes such as erase/select that never have PNG art.
    """
    # PNG override (shares same location as :file:`integrity/tiles/png` used by
    # the runtime engine).  This keeps the editor visuals in sync with the
    # game and makes custom art appear in the toolbar.
    png = _load_tile_png_qt(tool_name)
    if png:
        if png.width() != size or png.height() != size:
            return png.scaled(size, size,
                              Qt.AspectRatioMode.IgnoreAspectRatio,
                              Qt.TransformationMode.SmoothTransformation)
        return png

    col = PAL.get(tool_name, PAL["text"])
    pix = QPixmap(size, size)
    pix.fill(Qt.GlobalColor.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)

    r = size // 2 - 1
    cx = cy = size // 2

    if tool_name == "wall":
        p.fillRect(2, 2, size-4, size-4, col)
        p.setPen(QPen(QColor(70, 95, 155), 2))
        p.drawLine(2, 2, size-2, 2); p.drawLine(2, 2, 2, size-2)
        p.setPen(QPen(QColor(20, 28, 52), 1))
        p.drawLine(size-2, 2, size-2, size-2); p.drawLine(2, size-2, size-2, size-2)

    elif tool_name in ("door", "crashdoor"):
        p.fillRect(3, 3, size-6, size-6, col)
        border_col = QColor(220, 80, 40) if tool_name == "crashdoor" else QColor(35, 52, 95)
        p.setPen(QPen(border_col, 2))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRect(3, 3, size-6, size-6)
        if tool_name == "crashdoor":
            p.drawLine(5, 5, size-5, size-5)
            p.drawLine(size-5, 5, 5, size-5)

    elif tool_name == "window":
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(QColor(col.red(), col.green(), col.blue(), 80)))
        p.drawRect(3, 3, size-6, size-6)
        p.setPen(QPen(col, 2))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRect(3, 3, size-6, size-6)
        # window panes
        p.drawLine(cx, 3, cx, size-3)
        p.drawLine(3, cy, size-3, cy)

    elif tool_name == "hide":
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(QColor(col.red(), col.green(), col.blue(), 90)))
        p.drawRoundedRect(2, 2, size-4, size-4, 4, 4)
        p.setPen(QPen(col, 2)); p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(2, 2, size-4, size-4, 4, 4)

    elif tool_name in ("player", "player2", "exit", "loot", "guard"):
        p.setPen(QPen(QColor(255,255,255,60), 2))
        p.setBrush(QBrush(col))
        p.drawEllipse(cx-r, cy-r, r*2, r*2)

    elif tool_name in ("main_loot", "noisemaker"):
        grad = QRadialGradient(cx, cy, r)
        light = col.lighter(160)
        grad.setColorAt(0, light); grad.setColorAt(1, QColor(col.red(), col.green(), col.blue(), 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(grad))
        p.drawEllipse(cx-r, cy-r, r*2, r*2)
        p.setPen(QPen(col.lighter(130), 2)); p.setBrush(QBrush(col))
        inner = r - 4
        p.drawEllipse(cx-inner, cy-inner, inner*2, inner*2)

    elif tool_name == "oiled_door":
        p.fillRect(3, 3, size-6, size-6, col)
        p.setPen(QPen(QColor(100, 200, 70), 2))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRect(3, 3, size-6, size-6)
        # small circle = oiled indicator
        p.setBrush(QBrush(QColor(160, 240, 120)))
        p.drawEllipse(size-9, 3, 6, 6)

    elif tool_name == "wall_door":
        # Looks like a wall with a subtle door crease
        p.fillRect(2, 2, size-4, size-4, col)
        p.setPen(QPen(QColor(90, 75, 130), 1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRect(2, 2, size-4, size-4)
        p.setPen(QPen(QColor(120, 100, 170, 120), 1, Qt.PenStyle.DashLine))
        p.drawRect(5, 5, size-10, size-10)

    elif tool_name == "fence":
        p.setPen(QPen(col, 2))
        p.drawRect(3, 3, size-6, size-6)
        # vertical slats
        for xi in range(5, size-4, 5):
            p.drawLine(xi, 4, xi, size-4)
        # horizontal rail
        p.drawLine(4, size//2, size-4, size//2)

    elif tool_name == "pit":
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(col))
        p.drawRect(3, 3, size-6, size-6)
        # diagonal hatching
        dark = QColor(5, 8, 20)
        p.setPen(QPen(dark, 1))
        for xi in range(0, size*2, 6):
            p.drawLine(xi-size, 3, xi, size-3)
        # ring
        p.setPen(QPen(QColor(30, 40, 90), 2))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(cx-r+4, cy-r+4, (r-4)*2, (r-4)*2)

    elif tool_name == "creak_floor":
        p.fillRect(3, 3, size-6, size-6, QColor(col.red(), col.green(), col.blue(), 60))
        p.setPen(QPen(col, 2))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRect(3, 3, size-6, size-6)
        # wavy line
        p.setPen(QPen(col.lighter(130), 1))
        pts = []
        for xi in range(5, size-4, 2):
            yi = cy + int(math.sin((xi - 5) * 0.7) * 3)
            pts.append(QPoint(xi, yi))
        if len(pts) >= 2:
            for i in range(len(pts)-1):
                p.drawLine(pts[i], pts[i+1])

    elif tool_name == "snitch":
        p.setPen(QPen(QColor(160, 100, 10), 2))
        p.setBrush(QBrush(col))
        p.drawEllipse(cx-r, cy-r, r*2, r*2)
        # FOV indicator triangle
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(QColor(255, 220, 80, 120)))
        tri = QPolygon([QPoint(cx, cy), QPoint(cx-r, cy-r-4), QPoint(cx+r, cy-r-4)])
        p.drawPolygon(tri)

    elif tool_name == "camera":
        # camera body
        p.setPen(QPen(QColor(80, 160, 40), 2))
        p.setBrush(QBrush(col))
        p.drawRect(4, cy-r+2, size-12, (r-2)*2)
        # lens circle
        p.setBrush(QBrush(QColor(30, 60, 20)))
        p.drawEllipse(size-12, cy-5, 9, 9)
        # sweep arc indicator
        p.setPen(QPen(QColor(180, 255, 100, 100), 1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawArc(cx-r, cy-r, r*2, r*2, 30*16, 120*16)

    elif tool_name == "invisible_wall":
        # Ghost dashed border on nearly-transparent fill
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(QColor(col.red(), col.green(), col.blue(), 35)))
        p.drawRect(2, 2, size-4, size-4)
        p.setPen(QPen(col, 2, Qt.PenStyle.DashLine))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRect(2, 2, size-4, size-4)

    elif tool_name == "thin_wall":
        # Plus/cross to convey "line wall"
        pen_tw = QPen(col, max(2, size//10), Qt.PenStyle.SolidLine,
                      Qt.PenCapStyle.RoundCap)
        p.setPen(pen_tw)
        p.drawLine(4, cy, size-4, cy)   # horizontal
        p.drawLine(cx, 4, cx, size-4)   # vertical

    elif tool_name == "erase":
        p.setPen(QPen(col, 3))
        p.drawLine(5, 5, size-5, size-5)
        p.drawLine(size-5, 5, 5, size-5)

    elif tool_name == "select":
        p.setPen(QPen(col, 2, Qt.PenStyle.DashLine))
        p.setBrush(QBrush(QColor(col.red(), col.green(), col.blue(), 35)))
        p.drawRect(4, 4, size-8, size-8)

    else:
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(col))
        p.drawRect(3, 3, size-6, size-6)

    # small text label overlay
    p.setPen(QPen(Qt.GlobalColor.white))
    sym = _TOOL_ICONS_TEXT.get(tool_name, tool_name[0].upper())
    font = QFont("Consolas", max(6, size // 4), QFont.Weight.Bold)
    p.setFont(font)
    p.drawText(0, 0, size, size, Qt.AlignmentFlag.AlignCenter, sym)
    p.end()
    return pix


class TileToolBar(QWidget):
    """
    Tabbed tile-tool bar.  Each tab shows a fixed set of tool groups.

    Tabs:
        Common    – wall, floor, detail, player, exit, loot, hide, guard, door, noisemaker
        Shop      – buy_item, shop_leave  (shown only when "Is Shop?" is enabled)
        Regions   – region, region_inbetween, region_inbetween_doorway
        NPC Tools – ai_coverhint, ai_chokehint, ai_avoidhint

    Each tool slot = a main checkable button + optional tiny ▾ button that pops a
    QMenu listing all variants in that group.  Selecting a variant updates the main
    button's icon and fires tool_selected.

    erase + select are always pinned at far right regardless of active tab.
    """
    tool_selected = pyqtSignal(str)

    ICON_SIZE  = 34
    BTN_SIZE   = 42
    ARR_W      = 14

    # ── Tab definitions: (tab_key, label, groups) ─────────────────────────
    TAB_COMMON = "common"
    TAB_SHOP   = "shop"
    TAB_REGION = "regions"
    TAB_NPC    = "npc_tools"

    COMMON_GROUPS = [
        ("wall",       ["wall", "fence", "window", "invisible_wall"]),
        ("floor",      ["floor", "creak_floor", "pit", "item_pile"]),
        ("detail",     ["detail_img", "detail_txt"]),
        ("player",     ["player", "player2"]),
        ("exit",       ["exit"]),
        ("loot",       ["loot", "main_loot", "mini_loot"]),
        ("hide",       ["hide"]),
        ("guard",      ["guard", "snitch", "camera"]),
        ("door",       ["door", "oiled_door", "wall_door", "crashdoor"]),
        ("noisemaker", ["noisemaker"]),
    ]
    SHOP_GROUPS = [
        ("buy_item",   ["buy_item"]),
        ("shop_leave", ["shop_leave"]),
    ]
    REGION_GROUPS = [
        ("region",     ["region", "region_inbetween", "region_inbetween_doorway"]),
    ]
    NPC_GROUPS = [
        ("ai_coverhint", ["ai_coverhint"]),
        ("ai_chokehint", ["ai_chokehint"]),
        ("ai_avoidhint", ["ai_avoidhint"]),
    ]

    # Flat GROUPS list kept for backwards-compat (used by set_shop_mode, select, _restore_check)
    @property
    def GROUPS(self):
        g = list(self.COMMON_GROUPS)
        if self._shop_enabled:
            g += self.SHOP_GROUPS
        g += self.REGION_GROUPS
        g += self.NPC_GROUPS
        return g

    _TOOLBAR_STYLE = """
        QWidget#TileToolBar {
            background: #1a1c24;
            border-bottom: 1px solid #3a3e4a;
        }
        QToolButton {
            background: #22242e;
            border: 1px solid #2e3040;
            border-radius: 5px;
            padding: 2px;
        }
        QToolButton:hover {
            background: #2e3248;
            border: 1px solid #5070b0;
        }
        QToolButton:checked {
            background: #1e3060;
            border: 2px solid #5888d8;
        }
        QToolButton:pressed {
            background: #18224a;
        }
        QToolButton#arr {
            background: #1e2030;
            border: 1px solid #2a2e42;
            border-radius: 3px;
            padding: 0px;
            font: bold 9px Consolas;
            color: #7090c0;
        }
        QToolButton#arr:hover {
            background: #283050;
            border: 1px solid #5070b0;
            color: #a0c0ff;
        }
        QToolTip {
            background: #12141e;
            color: #c8d4f0;
            border: 1px solid #3a4a70;
            border-radius: 4px;
            padding: 6px 8px;
            font: 12px Consolas;
        }
        QMenu {
            background: #1a1c28;
            color: #c0c8e0;
            border: 1px solid #3a4060;
        }
        QMenu::item {
            padding: 4px 18px 4px 10px;
            font: 11px Consolas;
        }
        QMenu::item:selected {
            background: #2a4080;
            color: #e0eaff;
        }
        QMenu::icon {
            padding-left: 4px;
        }
        QPushButton#tab_btn {
            background: #1e2030;
            border: 1px solid #2a2e42;
            border-bottom: none;
            border-radius: 4px 4px 0px 0px;
            color: #7090b8;
            font: bold 10px Consolas;
            padding: 2px 8px;
            min-width: 52px;
        }
        QPushButton#tab_btn:hover {
            background: #252840;
            color: #c0d0f0;
        }
        QPushButton#tab_btn[active="true"] {
            background: #2a3260;
            border: 2px solid #5888d8;
            border-bottom: none;
            color: #c8daff;
        }
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("TileToolBar")
        self.setStyleSheet(self._TOOLBAR_STYLE)
        self.setFixedHeight(self.BTN_SIZE + 32)

        self._shop_enabled = False
        self._active_tab   = self.TAB_COMMON
        self._active_tool  = "wall"

        # Per-group state: which variant is currently the active face
        _all_groups = (self.COMMON_GROUPS + self.SHOP_GROUPS +
                       self.REGION_GROUPS + self.NPC_GROUPS)
        self._group_active = {g[0]: g[1][0] for g in _all_groups}

        self._btn_group    = QButtonGroup(self)
        self._btn_group.setExclusive(True)
        self._main_btns    = {}
        self._slot_widgets = {}

        # Main layout: tab row on top, tools row below
        vbox = QVBoxLayout(self)
        vbox.setContentsMargins(4, 2, 4, 0)
        vbox.setSpacing(0)

        # Tab row
        self._tab_row = QHBoxLayout()
        self._tab_row.setContentsMargins(0, 0, 0, 0)
        self._tab_row.setSpacing(2)
        vbox.addLayout(self._tab_row)

        # Tools row
        self._tools_row = QHBoxLayout()
        self._tools_row.setContentsMargins(0, 2, 0, 0)
        self._tools_row.setSpacing(2)
        vbox.addLayout(self._tools_row)

        self._build_tab_buttons()
        self._build_tools()

    # ── Tab button row ────────────────────────────────────────────────────

    _TAB_DEFS = [
        (TAB_COMMON, "Common"),
        (TAB_SHOP,   "Shop"),
        (TAB_REGION, "Regions"),
        (TAB_NPC,    "NPC Tools"),
    ]

    def _build_tab_buttons(self):
        while self._tab_row.count():
            item = self._tab_row.takeAt(0)
            if item.widget(): item.widget().setParent(None)
        self._tab_btns = {}
        for key, label in self._TAB_DEFS:
            if key == self.TAB_SHOP and not self._shop_enabled:
                continue
            btn = QPushButton(label)
            btn.setObjectName("tab_btn")
            btn.setProperty("active", str(key == self._active_tab).lower())
            btn.setStyleSheet(self._TOOLBAR_STYLE)
            btn.setFixedHeight(20)
            btn.clicked.connect(lambda _, k=key: self._switch_tab(k))
            self._tab_row.addWidget(btn)
            self._tab_btns[key] = btn
        self._tab_row.addStretch(1)

    def _switch_tab(self, key):
        if key == self._active_tab:
            return
        self._active_tab = key
        self._build_tab_buttons()
        self._build_tools()

    def _tab_groups(self):
        if self._active_tab == self.TAB_COMMON:
            return self.COMMON_GROUPS
        elif self._active_tab == self.TAB_SHOP:
            return self.SHOP_GROUPS
        elif self._active_tab == self.TAB_REGION:
            return self.REGION_GROUPS
        elif self._active_tab == self.TAB_NPC:
            return self.NPC_GROUPS
        return self.COMMON_GROUPS

    # ── Tool slot row ─────────────────────────────────────────────────────

    def _clear_tools(self):
        while self._tools_row.count():
            item = self._tools_row.takeAt(0)
            if item.widget(): item.widget().setParent(None)

    def _build_tools(self):
        self._clear_tools()
        self._main_btns.clear()
        self._slot_widgets.clear()
        for b in self._btn_group.buttons():
            self._btn_group.removeButton(b)

        for primary, variants in self._tab_groups():
            slot = self._make_slot(primary, variants)
            self._tools_row.addWidget(slot)

        self._tools_row.addStretch(1)

        # Separator
        sep = QFrame(); sep.setFrameShape(QFrame.Shape.VLine)
        sep.setStyleSheet("color: #3a3e4a; margin: 4px 2px;")
        self._tools_row.addWidget(sep)

        # Pinned: erase + select
        for pinned in ("erase", "select"):
            btn = QToolButton()
            btn.setCheckable(True)
            btn.setIconSize(QSize(self.ICON_SIZE, self.ICON_SIZE))
            btn.setFixedSize(self.BTN_SIZE, self.BTN_SIZE)
            btn.setIcon(QIcon(_make_tile_pixmap(pinned, self.ICON_SIZE)))
            col     = PAL.get(pinned, PAL["text"])
            hex_col = f"#{col.red():02x}{col.green():02x}{col.blue():02x}"
            tip     = TILE_TOOLTIP_LONG.get(pinned, pinned)
            btn.setToolTip(f"<span style='color:{hex_col}'>{tip}</span>")
            btn.setToolTipDuration(6000)
            btn.clicked.connect(lambda _, t=pinned: self._on_pinned_click(t))
            self._btn_group.addButton(btn)
            self._main_btns[pinned] = btn
            self._tools_row.addWidget(btn)

        # Active label
        self._active_lbl = QLabel("  WALL")
        self._active_lbl.setStyleSheet(
            "color: #5888d8; font: bold 11px Consolas; padding: 0 8px 0 4px;")
        self._tools_row.addWidget(self._active_lbl)

        self._restore_check()

    # ── Internal helpers ──────────────────────────────────────────────────

    def _make_slot(self, primary, variants):
        slot = QWidget()
        slot.setFixedHeight(self.BTN_SIZE)
        h = QHBoxLayout(slot)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(1)

        has_variants = len(variants) > 1

        btn = QToolButton()
        btn.setCheckable(True)
        btn.setIconSize(QSize(self.ICON_SIZE, self.ICON_SIZE))
        active = self._group_active[primary]
        btn.setIcon(QIcon(_make_tile_pixmap(active, self.ICON_SIZE)))
        btn.setFixedSize(self.BTN_SIZE, self.BTN_SIZE)
        col     = PAL.get(active, PAL["text"])
        hex_col = f"#{col.red():02x}{col.green():02x}{col.blue():02x}"
        tip     = TILE_TOOLTIP_LONG.get(active, active)
        btn.setToolTip(f"<span style='color:{hex_col}'>{tip}</span>")
        btn.setToolTipDuration(6000)
        btn.clicked.connect(lambda _, p=primary: self._on_main_click(p))
        self._btn_group.addButton(btn)
        self._main_btns[primary] = btn
        h.addWidget(btn)

        if has_variants:
            arr = QToolButton()
            arr.setObjectName("arr")
            arr.setText("▾")
            arr.setFixedSize(self.ARR_W, self.BTN_SIZE)
            arr.setToolTip("Choose variant")
            arr.clicked.connect(lambda _, p=primary, vs=variants, b=btn, a=arr:
                                self._show_variant_menu(p, vs, b, a))
            h.addWidget(arr)
            slot.setFixedWidth(self.BTN_SIZE + self.ARR_W + 1)
        else:
            slot.setFixedWidth(self.BTN_SIZE)

        self._slot_widgets[primary] = slot
        return slot

    def _restore_check(self):
        active = self._active_tool
        for primary, variants in self._tab_groups():
            if active in variants and primary in self._main_btns:
                self._main_btns[primary].setChecked(True)
                return
        if active in ("erase", "select") and active in self._main_btns:
            self._main_btns[active].setChecked(True)

    # ── Variant menu ──────────────────────────────────────────────────────

    def _show_variant_menu(self, primary, variants, main_btn, arr_btn):
        menu = QMenu(self)
        for variant in variants:
            col     = PAL.get(variant, PAL["text"])
            hex_col = f"#{col.red():02x}{col.green():02x}{col.blue():02x}"
            label   = TILE_TIPS.get(variant, variant)
            icon    = QIcon(_make_tile_pixmap(variant, 24))
            act     = menu.addAction(icon, f"  {label}")
            act.setData(variant)
        chosen = menu.exec(arr_btn.mapToGlobal(
            QPoint(0, arr_btn.height())))
        if chosen and chosen.data():
            self._select_variant(primary, chosen.data(), main_btn)

    def _select_variant(self, primary, variant, main_btn):
        self._group_active[primary] = variant
        main_btn.setIcon(QIcon(_make_tile_pixmap(variant, self.ICON_SIZE)))
        col     = PAL.get(variant, PAL["text"])
        hex_col = f"#{col.red():02x}{col.green():02x}{col.blue():02x}"
        tip     = TILE_TOOLTIP_LONG.get(variant, variant)
        main_btn.setToolTip(f"<span style='color:{hex_col}'>{tip}</span>")
        main_btn.setChecked(True)
        self._activate(variant)

    # ── Click handlers ────────────────────────────────────────────────────

    def _on_main_click(self, primary):
        self._activate(self._group_active[primary])

    def _on_pinned_click(self, tool):
        self._activate(tool)

    def _activate(self, tool):
        self._active_tool = tool
        col     = PAL.get(tool, PAL["text"])
        hex_col = f"#{col.red():02x}{col.green():02x}{col.blue():02x}"
        self._active_lbl.setText(f"  {tool.upper().replace('_',' ')}")
        self._active_lbl.setStyleSheet(
            f"color:{hex_col}; font:bold 11px Consolas; padding:0 8px 0 4px;")
        self.tool_selected.emit(tool)

    # ── Public API ────────────────────────────────────────────────────────

    def select(self, tool):
        """Programmatically activate a tool, switching tab if needed."""
        for tab_key, tab_label in self._TAB_DEFS:
            if tab_key == self.TAB_SHOP and not self._shop_enabled:
                continue
            if tab_key == self.TAB_COMMON:   groups = self.COMMON_GROUPS
            elif tab_key == self.TAB_SHOP:   groups = self.SHOP_GROUPS
            elif tab_key == self.TAB_REGION: groups = self.REGION_GROUPS
            else:                            groups = self.NPC_GROUPS
            for primary, variants in groups:
                if tool in variants:
                    self._group_active[primary] = tool
                    if self._active_tab != tab_key:
                        self._active_tab = tab_key
                        self._build_tab_buttons()
                        self._build_tools()
                    elif primary in self._main_btns:
                        btn = self._main_btns[primary]
                        btn.setIcon(QIcon(_make_tile_pixmap(tool, self.ICON_SIZE)))
                        btn.setChecked(True)
                    self._activate(tool)
                    return
        if tool in ("erase", "select"):
            if tool in self._main_btns:
                self._main_btns[tool].setChecked(True)
            self._activate(tool)

    # ── Shop mode ─────────────────────────────────────────────────────────

    def set_shop_mode(self, enabled: bool) -> None:
        """Show/hide the Shop tab."""
        if self._shop_enabled == enabled:
            return
        self._shop_enabled = enabled
        # If shop tab was active and is now hidden, fall back to Common
        if not enabled and self._active_tab == self.TAB_SHOP:
            self._active_tab = self.TAB_COMMON
        self._build_tab_buttons()
        self._build_tools()


# ════════════════════════════════════════════════════════════════════════════
# Waypoint tool bar
# ════════════════════════════════════════════════════════════════════════════
class WaypointToolBar(QWidget):
    """
    Waypoint-mode tool strip. Shows when the user is editing a guard's path.
    Tools: SELECT (move nodes), WAYPOINT, WAITPOINT, IGNORE, WATCH, CHECK.
    """
    tool_selected = pyqtSignal(str)   # emits wp tool name

    ICON_SIZE = 34
    BTN_SIZE  = 42

    _STYLE = """
        QWidget#WaypointToolBar {
            background: #1a1e18;
            border-bottom: 1px solid #3a4a2e;
        }
        QToolButton {
            background: #1e2220;
            border: 1px solid #2e4030;
            border-radius: 5px;
            padding: 2px;
        }
        QToolButton:hover {
            background: #283628;
            border: 1px solid #508050;
        }
        QToolButton:checked {
            background: #1e3820;
            border: 2px solid #50c060;
        }
        QToolButton:pressed {
            background: #162818;
        }
        QToolTip {
            background: #121a12;
            color: #c8e0c8;
            border: 1px solid #3a6040;
            border-radius: 4px;
            padding: 6px 8px;
            font: 12px Consolas;
        }
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("WaypointToolBar")
        self.setStyleSheet(self._STYLE)
        self.setFixedHeight(self.BTN_SIZE + 10)

        self._btns  = {}
        self._group = QButtonGroup(self)
        self._group.setExclusive(True)

        hbox = QHBoxLayout(self)
        hbox.setContentsMargins(8, 4, 8, 4)
        hbox.setSpacing(3)

        # Header label
        hdr = QLabel("  WAYPOINT TOOLS")
        hdr.setStyleSheet("color: #60a860; font: bold 11px Consolas; padding-right: 6px;")
        hbox.addWidget(hdr)

        sep0 = QFrame(); sep0.setFrameShape(QFrame.Shape.VLine)
        sep0.setStyleSheet("color: #3a4a2e; margin: 4px 2px;")
        hbox.addWidget(sep0)

        for i, wt in enumerate(WP_TYPES):
            if i > 0 and wt in ("ignore", "watch", "check"):
                if wt == "ignore":
                    sep = QFrame(); sep.setFrameShape(QFrame.Shape.VLine)
                    sep.setStyleSheet("color: #3a4a2e; margin: 4px 2px;")
                    hbox.addWidget(sep)

            btn = QToolButton()
            btn.setCheckable(True)
            btn.setIconSize(QSize(self.ICON_SIZE, self.ICON_SIZE))
            btn.setFixedSize(self.BTN_SIZE, self.BTN_SIZE)
            btn.setIcon(QIcon(_make_wp_pixmap(wt, self.ICON_SIZE)))

            col     = WP_COLORS.get(wt, QColor(150, 150, 150))
            hex_col = f"#{col.red():02x}{col.green():02x}{col.blue():02x}"
            tip     = WP_TOOLTIP_LONG.get(wt, wt)
            btn.setToolTip(f"<span style='color:{hex_col}'>{tip}</span>")
            btn.setToolTipDuration(6000)

            btn.clicked.connect(lambda _, t=wt: self._on_click(t))
            self._group.addButton(btn)
            self._btns[wt] = btn
            hbox.addWidget(btn)

        hbox.addStretch(1)

        self._active_lbl = QLabel("  WAYPOINT SELECT")
        self._active_lbl.setStyleSheet(
            "color: #64b8f8; font: bold 11px Consolas; padding-right: 10px;")
        hbox.addWidget(self._active_lbl)

        # Default: select
        self._btns["wp_select"].setChecked(True)
        self.current_wp_tool = "wp_select"

    def _on_click(self, wt):
        self.current_wp_tool = wt
        col     = WP_COLORS.get(wt, QColor(150, 150, 150))
        hex_col = f"#{col.red():02x}{col.green():02x}{col.blue():02x}"
        self._active_lbl.setText(f"  {wt.upper().replace('_',' ')}")
        self._active_lbl.setStyleSheet(
            f"color:{hex_col}; font:bold 11px Consolas; padding-right:10px;")
        self.tool_selected.emit(wt)

    def select(self, wt):
        if wt in self._btns:
            self._btns[wt].setChecked(True)
            self._on_click(wt)


# ════════════════════════════════════════════════════════════════════════════
# Waypoint node property dialog
# ════════════════════════════════════════════════════════════════════════════
class WaypointPropertyDialog(QDialog):
    """Edit per-node waypoint properties."""

    def __init__(self, wp_data, parent=None):
        super().__init__(parent)
        self.data = dict(wp_data)   # must have 'type', 'col', 'row'
        wt = self.data.get("type", "waypoint")
        self.setWindowTitle(f"Waypoint – {wt.upper()} @ ({self.data['col']},{self.data['row']})")
        self.setMinimumWidth(360)
        self.setStyleSheet("""
            QDialog { background: #121a12; color: #c8e0c8; font: 12px Consolas; }
            QLabel { color: #90b890; }
            QGroupBox { color: #608060; font: bold 11px Consolas;
                        border: 1px solid #2e4a2e; border-radius: 4px;
                        margin-top:8px; padding-top:4px; }
            QGroupBox::title { subcontrol-origin:margin; left:8px; }
            QSpinBox, QDoubleSpinBox, QLineEdit, QCheckBox {
                background: #0c120c; color: #a8c8a8;
                border: 1px solid #2e4030; border-radius:3px;
                padding:3px 6px; font:11px Consolas; }
            QPushButton { background:#2a4a2a; color:#c8e0c8; border:none;
                          border-radius:3px; padding:5px 14px; font:bold 11px Consolas; }
            QPushButton:hover { background:#3a6040; }
        """)
        self._widgets = {}
        self._build(wt)

    def _build(self, wt):
        vbox = QVBoxLayout(self)
        vbox.setSpacing(10)

        grp = QGroupBox(f"Node Type: {wt.upper().replace('_',' ')}")
        form = QFormLayout(grp)
        form.setSpacing(6)

        col = WP_COLORS.get(wt, QColor(150, 150, 150))
        hex_col = f"#{col.red():02x}{col.green():02x}{col.blue():02x}"
        form.addRow("Position:",
                    QLabel(f"({self.data['col']}, {self.data['row']})"))

        if wt == "waitpoint":
            self._addf(form, "wait_min",  "Min wait (s)",  self.data.get("wait_min",  2.5),  0.0, 60.0)
            self._addf(form, "wait_max",  "Max wait (s)",  self.data.get("wait_max",  5.0),   0.0, 60.0)
            self._addf(form, "look_speed","Rotation speed", self.data.get("look_speed", 1.0),  0.0,  5.0)
            self._addi(form, "look_turns","Look turns",     self.data.get("look_turns", 2),     0,   10)

        elif wt == "ignore":
            self._addi(form, "radius_tiles","Ignore radius (tiles)", self.data.get("radius_tiles", 3), 1, 20)
            self._addf(form, "susp_mul",    "Suspicion multiplier",  self.data.get("susp_mul", 0.2),  0.0, 1.0)
            info = QLabel("Guard's suspicion rise is multiplied<br>by the above value while in range.")
            info.setStyleSheet(f"color:{hex_col}; font:10px Consolas;")
            info.setWordWrap(True)
            form.addRow("", info)

        elif wt == "watch":
            self._addf(form, "look_time",  "Look duration (s)",  self.data.get("look_time", 1.5),  0.0, 10.0)
            self._addi(form, "trigger_dist","Trigger distance (tiles)", self.data.get("trigger_dist", 4), 1, 20)
            self._addc(form, "alert_if_see","Go ALERT if something seen?", self.data.get("alert_if_see", True))

        elif wt == "check":
            self._addi(form, "check_chance","Check chance (%)", self.data.get("check_chance", 60), 0, 100)
            self._addf(form, "check_time",  "Inspect duration (s)", self.data.get("check_time", 2.0), 0.0, 10.0)
            self._addc(form, "always_check","Always check (ignore chance)?", self.data.get("always_check", False))
            info = QLabel("Place on a HIDE tile or DOOR tile.<br>"
                          "Guard will stop and inspect it while patrolling.")
            info.setStyleSheet(f"color:{hex_col}; font:10px Consolas;")
            info.setWordWrap(True)
            form.addRow("", info)

        elif wt == "waypoint":
            info = QLabel("Standard pass-through waypoint.<br>No additional configuration needed.")
            info.setStyleSheet(f"color:{hex_col}; font:10px Consolas;")
            info.setWordWrap(True)
            form.addRow("", info)

        vbox.addWidget(grp)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(self._accept)
        btns.rejected.connect(self.reject)
        vbox.addWidget(btns)

    def _addi(self, form, key, label, val, mn, mx):
        sb = QSpinBox(); sb.setRange(mn, mx); sb.setValue(int(val))
        self._widgets[key] = ("int", sb)
        form.addRow(label + ":", sb)

    def _addf(self, form, key, label, val, mn, mx):
        sb = QDoubleSpinBox(); sb.setRange(mn, mx); sb.setSingleStep(0.1)
        sb.setDecimals(2); sb.setValue(float(val))
        self._widgets[key] = ("float", sb)
        form.addRow(label + ":", sb)

    def _addc(self, form, key, label, val):
        cb = QCheckBox(); cb.setChecked(bool(val))
        self._widgets[key] = ("check", cb)
        form.addRow(label + ":", cb)

    def _accept(self):
        for key, (kind, w) in self._widgets.items():
            if kind == "int":   self.data[key] = w.value()
            elif kind == "float": self.data[key] = w.value()
            elif kind == "check": self.data[key] = w.isChecked()
        self.accept()

    def result_data(self):
        return self.data


# ════════════════════════════════════════════════════════════════════════════
# Property editor dialog – per tile type
# ════════════════════════════════════════════════════════════════════════════
class PropertyDialog(QDialog):
    """Shows tile-type-specific properties for editing."""

    def __init__(self, obj, parent=None, bundle_path=None):
        super().__init__(parent)
        self.obj = dict(obj)
        self._bundle_path = bundle_path  # .ler bundle folder (may be None)
        t = obj["type"]
        self.setWindowTitle(f"Properties – {t.upper()} @ ({obj['col']},{obj['row']})")
        self.setMinimumWidth(380)
        self._apply_style()
        self._build(t)

    def _apply_style(self):
        self.setStyleSheet("""
            QDialog { background: #1e2028; color: #d2d7e1; font: 12px Consolas; }
            QLabel { color: #a0a8c0; }
            QGroupBox { color: #7080a0; font: bold 11px Consolas;
                        border: 1px solid #3a3e4a; border-radius: 4px;
                        margin-top:8px; padding-top:4px; }
            QGroupBox::title { subcontrol-origin:margin; left:8px; }
            QSpinBox, QDoubleSpinBox, QLineEdit, QComboBox, QCheckBox, QTextEdit {
                background: #12141c; color: #c8d0e0;
                border: 1px solid #3a4060; border-radius:3px;
                padding:3px 6px; font:11px Consolas; }
            QPushButton { background:#3a5080; color:#fff; border:none;
                          border-radius:3px; padding:5px 14px; font:bold 11px Consolas; }
            QPushButton:hover { background:#4a68a0; }
        """)

    def _build(self, t):
        vbox = QVBoxLayout(self)
        vbox.setSpacing(10)

        form_grp = QGroupBox("Tile Properties")
        form = QFormLayout(form_grp)
        form.setSpacing(6)
        self._widgets = {}

        # Common
        pos_lbl = QLabel(f"({self.obj['col']}, {self.obj['row']})")
        form.addRow("Position:", pos_lbl)

        if t == "door":
            self._add_check(form, "open",
                            "Initially open?", self.obj.get("open", False))
            self._add_int(form, "noise_score",
                          "Custom noise (0=default)", self.obj.get("noise_score", 0), 0, 200)

        elif t == "crashdoor":
            self._add_info(form, "Behavior",
                           "Player must SPRINT into this door to open it.\nMakes a huge noise when rammed.")

        elif t == "window":
            self._add_info(form, "Behavior",
                           "Guards can see through windows.\nPlayers cannot pass through windows.")
            self._add_check(form, "one_way",
                            "One-way view (guards see in, not out)?",
                            self.obj.get("one_way", False))

        elif t == "noisemaker":
            self._add_float(form, "interval",
                            "Pulse interval (seconds)", self.obj.get("interval", 4.0), 0.5, 60.0)
            self._add_int(form, "score",
                          "Noise score (38+ triggers guards)", self.obj.get("score", 60), 1, 200)
            self._add_int(form, "radius",
                          "Hearing radius (px)", self.obj.get("radius", 240), 48, 1000)
            self._add_check(form, "ambiguous",
                            "Ambiguous (guards search general area)?",
                            self.obj.get("ambiguous", True))
            self._add_check(form, "active",
                            "Initially active?", self.obj.get("active", True))

        elif t == "guard":
            self._add_float(form, "speed_mul",
                            "Speed multiplier", self.obj.get("speed_mul", 1.0), 0.1, 5.0)
            self._add_float(form, "sight_mul",
                            "Sight range multiplier", self.obj.get("sight_mul", 1.0), 0.1, 3.0)
            self._add_float(form, "fov_mul",
                            "FOV multiplier", self.obj.get("fov_mul", 1.0), 0.1, 3.0)
            self._add_int(form, "alert_duration",
                          "Alert duration (s, 0=default)", self.obj.get("alert_duration", 0), 0, 60)
            self._add_check(form, "knows_layout",
                            "Knows layout (smarter ambush/cutoff)?",
                            self.obj.get("knows_layout", False))
            self._add_check(form, "ambusher",
                            "Ambusher (tries to cut off player in pursuit)?",
                            self.obj.get("ambusher", False))
            self._add_info(form, "Knows Layout",
                           "Guard learns the level map.\nIn chase: tries to predict and intercept player\n"
                           "rather than just following last known position.")
            self._add_info(form, "Ambusher",
                           "Guard aggressively tries to cut the player off\nduring pursuit, refreshing intercept routes 2.5× more often.\n"
                           "Implies Knows Layout.")
            self._add_check(form, "has_gun",
                            "Armed (has gun)?",
                            self.obj.get("has_gun", False))
            self._add_info(form, "Armed Guard",
                           "Armed guards enter COMBAT state when they hear gunfire nearby.\n"
                           "In COMBAT: seeks cover, shoots player if in LOS.\n"
                           "Unarmed guards still enter COMBAT but flee instead.\n"
                           "Player takes 1 hit per shot (2 hits = death).")
            self._add_info(form, "Waypoints", "Edit waypoints in the Guard panel on the left.")

        elif t == "hide":
            self._add_info(form, "Behavior",
                           "Player presses H on this tile to hide.\nGuards will search here when suspicious.")
            self._add_check(form, "noisy_exit",
                            "Noisy to exit? (rustling)", self.obj.get("noisy_exit", False))

        elif t == "loot":
            self._add_int(form, "value", "Point value", self.obj.get("value", 100), 1, 9999)
            self._add_check(form, "visible_through_wall",
                            "Visible to guards through walls?",
                            self.obj.get("visible_through_wall", False))

        elif t == "main_loot":
            self._add_int(form, "value", "Point value", self.obj.get("value", 500), 1, 9999)
            self._add_check(form, "guards_notice_missing",
                            "Guards notice when taken?",
                            self.obj.get("guards_notice_missing", True))
            self._add_int(form, "notice_delay",
                          "Notice delay (s)", self.obj.get("notice_delay", 0), 0, 30)

        elif t == "exit":
            self._add_check(form, "requires_all_loot",
                            "Requires all loot collected?",
                            self.obj.get("requires_all_loot", True))

        elif t == "wall":
            self._add_check(form, "transparent_to_sound",
                            "Transparent to sound?",
                            self.obj.get("transparent_to_sound", False))

        elif t == "invisible_wall":
            self._add_info(form, "Behavior",
                           "Identical to a solid wall for movement and LOS.\n"
                           "Completely invisible during gameplay.\n"
                           "Shown as a ghost outline in the editor only.")
            self._add_check(form, "transparent_to_sound",
                            "Transparent to sound?",
                            self.obj.get("transparent_to_sound", False))

        elif t == "thin_wall":
            self._add_combo(form, "shape", "Shape",
                            ["straight", "corner", "t", "plus"],
                            ["Straight (─ / │)", "Corner (└ / ┘ / ┐ / ┌)",
                             "T-junction (┴ / ├ / ┬ / ┤)", "Plus / cross (┼)"],
                            self.obj.get("shape", "straight"))
            self._add_combo(form, "rotation", "Rotation",
                            [0, 90, 180, 270],
                            ["0°  (default)", "90°  (CW)", "180°", "270°  (CCW)"],
                            self.obj.get("rotation", 0))
            self._add_info(form, "Shapes",
                           "Straight 0°=horizontal, 90°=vertical.\n"
                           "Corner rotates CW: 0°=top+right, 90°=right+bottom,\n"
                           "  180°=bottom+left, 270°=left+top.\n"
                           "T-junction rotates CW: 0°=opening up,\n"
                           "  90°=opening left, 180°=opening down, 270°=opening right.\n"
                           "Plus: full cross, rotation ignored.")

        elif t in ("player", "player2"):
            if t == "player2":
                self._add_info(form, "Player 2 Spawn",
                               "Multiplayer spawn point for Player 2.\n"
                               "Only used when launched via MULTIPLAYER config.")
            self._add_float(form, "walk_speed_mul",
                            "Walk speed multiplier", self.obj.get("walk_speed_mul", 1.0), 0.1, 5.0)
            self._add_float(form, "sprint_speed_mul",
                            "Sprint speed multiplier", self.obj.get("sprint_speed_mul", 1.0), 0.1, 5.0)

        elif t == "floor":
            self._add_info(form, "Behavior",
                           "Explicit floor tile. Walkable by default.\n"
                           "Place to override other tile types.")

        elif t == "oiled_door":
            self._add_check(form, "open",
                            "Initially open?", self.obj.get("open", False))
            self._add_info(form, "Behavior",
                           "Silent – makes no noise when toggled.\n"
                           "Guards still close oiled doors on patrol.")

        elif t == "wall_door":
            self._add_check(form, "open",
                            "Initially open?", self.obj.get("open", False))
            self._add_info(form, "Behavior",
                           "Hidden door – looks like a wall when closed.\n"
                           "Guards don't notice it and cannot open it.")

        elif t == "fence":
            self._add_check(form, "active",
                            "Initially active?", self.obj.get("active", True))
            self._add_info(form, "Behavior",
                           "Blocks player movement; guards see through.\n"
                           "Does not dampen noise. Can be toggled via IO.")

        elif t == "pit":
            self._add_check(form, "active",
                            "Initially active?", self.obj.get("active", True))
            self._add_info(form, "Death condition",
                           "Player falls in if SPRINTING across it.\n"
                           "Walking players stop safely at the edge.")

        elif t == "creak_floor":
            self._add_int(form, "noise_score",
                          "Walk noise score (38+ alerts guards)", self.obj.get("noise_score", 35), 0, 200)
            self._add_int(form, "sprint_noise_score",
                          "Sprint noise score", self.obj.get("sprint_noise_score", 60), 0, 200)
            self._add_float(form, "cooldown",
                            "Cooldown between pulses (s)", self.obj.get("cooldown", 0.5), 0.1, 10.0)
            self._add_check(form, "active",
                            "Initially active?", self.obj.get("active", True))
            self._add_info(form, "Behavior",
                           "Emits noise when walked or sprinted on.\n"
                           "Guards ≥38 score will investigate.")

        elif t == "item_pile":
            contents = self.obj.get("contents", {})
            self._add_info(form, "Behavior",
                           "Player walks over this tile to pick up all items.\n"
                           "Tick each item to include it in the pile.\n"
                           "Set amount via the spinbox next to each item.")
            ITEMS = [
                ("silenced_pistol",  "Silenced Pistol",        "primary"),
                ("1911",             "1911 Pistol",             "primary"),
                ("shotgun",          "Shotgun",                 "primary"),
                ("m4a1",             "M4A1",                    "primary"),
                ("keycard",          "Keycard",                 "other"),
                # Wearables (equip_wear)
                ("creased_sneakers", "Creased Sneakers",        "equip_wear"),
                ("rubber_soles",     "Rubber Soles",            "equip_wear"),
                ("socks",            "Thick Socks",             "equip_wear"),
                ("lead_boots",       "Lead Boots",              "equip_wear"),
                ("static_wrap",      "Static Wrap",             "equip_wear"),
                ("ghost_threads",    "Ghost Threads",           "equip_wear"),
                # Gear (equip_gear)
                ("invisi_cloak",     "Burning Invisi-Cloak",    "equip_gear"),
                ("raycast_goggles",  "Raycast Goggles",         "equip_gear"),
                ("smoke_pellet",     "Smoke Pellet",            "equip_gear"),
                ("emp_pulse",        "EMP Pulse",               "equip_gear"),
                ("adrenaline_shot",  "Adrenaline Shot",         "equip_gear"),
                ("decoy_beeper",     "Decoy Beeper",            "equip_gear"),
            ]
            self._item_pile_widgets = {}
            for key, label, slot in ITEMS:
                row_widget = QWidget()
                row_layout = QHBoxLayout(row_widget)
                row_layout.setContentsMargins(0, 0, 0, 0)
                row_layout.setSpacing(6)
                cb = QCheckBox()
                cb.setChecked(key in contents)
                sb = QSpinBox()
                sb.setRange(1, 99)
                sb.setValue(int(contents.get(key, 1)))
                sb.setEnabled(key in contents)
                sb.setFixedWidth(54)
                slot_lbl = QLabel(f"[{slot}]")
                slot_lbl.setStyleSheet("color:#506080; font:10px Consolas;")
                cb.toggled.connect(sb.setEnabled)
                row_layout.addWidget(cb)
                row_layout.addWidget(sb)
                row_layout.addWidget(slot_lbl)
                row_layout.addStretch()
                self._item_pile_widgets[key] = (cb, sb)
                form.addRow(label + ":", row_widget)

        elif t == "buy_item":
            contents = self.obj.get("contents", {})
            self._add_info(form, "Behavior",
                           "Player steps on this tile to open the shop purchase menu.\n"
                           "Tick each item to list it for sale.\n"
                           "Set PRICE (gold cost) and STOCK (quantity available) per item.")
            ITEMS = [
                ("silenced_pistol",  "Silenced Pistol",        "primary"),
                ("1911",             "1911 Pistol",             "primary"),
                ("shotgun",          "Shotgun",                 "primary"),
                ("m4a1",             "M4A1",                    "primary"),
                ("keycard",          "Keycard",                 "other"),
                # Wearables (equip_wear)
                ("creased_sneakers", "Creased Sneakers",        "equip_wear"),
                ("rubber_soles",     "Rubber Soles",            "equip_wear"),
                ("socks",            "Thick Socks",             "equip_wear"),
                ("lead_boots",       "Lead Boots",              "equip_wear"),
                ("static_wrap",      "Static Wrap",             "equip_wear"),
                ("ghost_threads",    "Ghost Threads",           "equip_wear"),
                # Gear (equip_gear)
                ("invisi_cloak",     "Burning Invisi-Cloak",    "equip_gear"),
                ("raycast_goggles",  "Raycast Goggles",         "equip_gear"),
                ("smoke_pellet",     "Smoke Pellet",            "equip_gear"),
                ("emp_pulse",        "EMP Pulse",               "equip_gear"),
                ("adrenaline_shot",  "Adrenaline Shot",         "equip_gear"),
                ("decoy_beeper",     "Decoy Beeper",            "equip_gear"),
            ]
            self._buy_item_widgets = {}
            for key, label, slot in ITEMS:
                entry = contents.get(key, {})
                if isinstance(entry, int):
                    entry = {"price": entry, "stock": 99}
                row_widget = QWidget()
                row_layout = QHBoxLayout(row_widget)
                row_layout.setContentsMargins(0, 0, 0, 0)
                row_layout.setSpacing(6)
                cb = QCheckBox()
                cb.setChecked(key in contents)
                price_sb = QSpinBox()
                price_sb.setRange(0, 9999)
                price_sb.setValue(int(entry.get("price", 0)))
                price_sb.setEnabled(key in contents)
                price_sb.setFixedWidth(60)
                price_sb.setToolTip("Price in gold")
                stock_sb = QSpinBox()
                stock_sb.setRange(1, 99)
                stock_sb.setValue(int(entry.get("stock", 1)))
                stock_sb.setEnabled(key in contents)
                stock_sb.setFixedWidth(46)
                stock_sb.setToolTip("Stock quantity")
                price_lbl = QLabel("g")
                price_lbl.setStyleSheet("color:#c8a850; font:10px Consolas;")
                stock_lbl = QLabel("×")
                stock_lbl.setStyleSheet("color:#6878a0; font:10px Consolas;")
                slot_lbl = QLabel(f"[{slot}]")
                slot_lbl.setStyleSheet("color:#506080; font:10px Consolas;")
                cb.toggled.connect(price_sb.setEnabled)
                cb.toggled.connect(stock_sb.setEnabled)
                row_layout.addWidget(cb)
                row_layout.addWidget(price_sb)
                row_layout.addWidget(price_lbl)
                row_layout.addWidget(stock_lbl)
                row_layout.addWidget(stock_sb)
                row_layout.addWidget(slot_lbl)
                row_layout.addStretch()
                self._buy_item_widgets[key] = (cb, price_sb, stock_sb)
                form.addRow(label + ":", row_widget)

        elif t == "shop_leave":
            self._add_info(form, "Behavior",
                           "Player steps on this tile to leave the shop.\n"
                           "Automatically advances to the next level\n"
                           "(as set by the 'next_level' field in the .ler file).\n"
                           "If no next level is set, acts like the exit tile.")

        elif t == "detail_img":
            bundle_label = (os.path.basename(self._bundle_path)
                            if self._bundle_path else "unsaved level")
            self._add_info(form, "About",
                           f"Decorative image drawn at a chosen render layer.\n"
                           f"Images are stored inside the level bundle:\n"
                           f"  {bundle_label}/images/<file>\n"
                           "Pick a file to copy it in automatically.")
            # ── Image picker row ──────────────────────────────────────────
            img_row = QWidget()
            img_hl  = QHBoxLayout(img_row)
            img_hl.setContentsMargins(0, 0, 0, 0); img_hl.setSpacing(6)
            self._img_edit = QLineEdit(self.obj.get("image", ""))
            self._img_edit.setPlaceholderText("filename.png (inside bundle/images/)")
            self._img_preview = QLabel()
            self._img_preview.setFixedSize(96, 96)
            self._img_preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self._img_preview.setStyleSheet(
                "border:1px solid #3a4060; background:#080a12; color:#4a5878;"
                "font:10px Consolas;")
            self._img_preview.setToolTip("Image preview — click Browse (…) to choose a file")
            browse_btn = QPushButton("…")
            browse_btn.setFixedWidth(28)
            browse_btn.setToolTip(
                "Browse for an image file.\n"
                "It will be copied into the level bundle's images/ folder\n"
                "and the filename stored here.")
            img_hl.addWidget(self._img_edit, 1)
            img_hl.addWidget(browse_btn)
            img_hl.addWidget(self._img_preview)
            form.addRow("Image file:", img_row)
            # update preview on text change
            self._img_edit.textChanged.connect(self._refresh_img_preview)
            browse_btn.clicked.connect(self._browse_detail_img)
            self._refresh_img_preview(self._img_edit.text())
            # remaining numeric fields
            self._add_float(form, "size_w",   "Width (tiles)",
                            self.obj.get("size_w", 1.0), 0.25, 16.0)
            self._add_float(form, "size_h",   "Height (tiles)",
                            self.obj.get("size_h", 1.0), 0.25, 16.0)
            self._add_int(form,   "layer",    "Render layer  (0=below items · 1=below player · 2=above all)",
                          self.obj.get("layer", 0), 0, 2)
            self._add_int(form,   "alpha",    "Alpha (0–255)",
                          self.obj.get("alpha", 255), 0, 255)
            self._add_int(form,   "offset_x", "Pixel offset X",
                          self.obj.get("offset_x", 0), -512, 512)
            self._add_int(form,   "offset_y", "Pixel offset Y",
                          self.obj.get("offset_y", 0), -512, 512)

        elif t == "detail_txt":
            self._add_info(form, "About",
                           "Decorative text label drawn at a chosen render layer.\n"
                           "Use \\n in the text field for newlines.\n"
                           "Size sets the bounding box for alignment.")
            self._add_str(form,   "text",       "Text (\\n for newline)",
                          self.obj.get("text", ""))
            self._add_float(form, "size_w",     "Width (tiles)",
                            self.obj.get("size_w", 1.0), 0.25, 16.0)
            self._add_float(form, "size_h",     "Height (tiles)",
                            self.obj.get("size_h", 1.0), 0.25, 16.0)
            self._add_int(form,   "layer",      "Render layer  (0=below items · 1=below player · 2=above all)",
                          self.obj.get("layer", 0), 0, 2)
            self._add_float(form, "font_scale", "Font scale (fraction of tile px)",
                            self.obj.get("font_scale", 0.3), 0.05, 2.0)
            # Color row
            col_raw = self.obj.get("color", [220, 220, 180])
            col_str = ", ".join(str(v) for v in col_raw)
            self._add_str(form,   "color",      "Color (R, G, B)",
                          col_str)
            self._add_int(form,   "alpha",      "Alpha (0–255)",
                          self.obj.get("alpha", 255), 0, 255)
            # Align combo
            align_w = QComboBox()
            for opt in ("left", "center", "right"):
                align_w.addItem(opt, opt)
            align_w.setCurrentIndex(["left", "center", "right"].index(
                self.obj.get("align", "center")))
            form.addRow("Align:", align_w)
            self._extra_widgets = getattr(self, "_extra_widgets", {})
            self._extra_widgets["align"] = ("combo", align_w)
            self._add_int(form,   "offset_x",   "Pixel offset X",
                          self.obj.get("offset_x", 0), -512, 512)
            self._add_int(form,   "offset_y",   "Pixel offset Y",
                          self.obj.get("offset_y", 0), -512, 512)

        elif t == "snitch":
            self._add_float(form, "sight_mul",
                            "Sight range multiplier (×200px)", self.obj.get("sight_mul", 1.0), 0.1, 5.0)
            self._add_float(form, "fov_mul",
                            "FOV half-angle multiplier (×60°)", self.obj.get("fov_mul", 1.0), 0.1, 3.0)
            self._add_float(form, "rotation_speed",
                            "Rotation speed (°/s, 0=stationary)", self.obj.get("rotation_speed", 0.0), 0.0, 360.0)
            self._add_float(form, "facing",
                            "Initial facing angle (°, 0=right)", self.obj.get("facing", 0.0), 0.0, 360.0)
            self._add_check(form, "active",
                            "Initially active?", self.obj.get("active", True))
            self._add_info(form, "Behavior",
                           "Snitch: spots player then RUNS to nearest guard to report.\n"
                           "Does NOT raise alarm directly, does NOT fight.\n"
                           "Alert cooldown: 8 s. Can be killed by player.")

        elif t == "camera":
            self._add_float(form, "fov_degrees",
                            "FOV cone width (°)", self.obj.get("fov_degrees", 60.0), 5.0, 180.0)
            self._add_float(form, "sweep_degrees",
                            "Sweep arc (±° from facing)", self.obj.get("sweep_degrees", 90.0), 0.0, 180.0)
            self._add_float(form, "sweep_speed",
                            "Sweep speed (°/s)", self.obj.get("sweep_speed", 30.0), 1.0, 360.0)
            self._add_float(form, "sight_range",
                            "Sight range (tiles)", self.obj.get("sight_range", 8.0), 1.0, 40.0)
            self._add_float(form, "facing",
                            "Base facing angle (°, 0=right)", self.obj.get("facing", 0.0), 0.0, 360.0)
            self._add_check(form, "active",
                            "Initially active?", self.obj.get("active", True))
            self._add_info(form, "Behavior",
                           "Sweeps FOV arc back and forth.\n"
                           "Raises global alert when player spotted.\n"
                           "Alert cooldown: 10 s.")

        elif t == "mini_loot":
            self._add_int(form, "value", "Point value", self.obj.get("value", 50), 1, 9999)
            self._add_info(form, "Behavior",
                           "Does NOT count toward exit unlock condition.\n"
                           "Good for optional score or secrets.")

        elif t == "thin_door":
            self._add_combo(form, "shape", "Shape",
                            ["straight", "corner"],
                            ["Straight (─ / │)", "Corner (└ / ┐ / etc.)"],
                            self.obj.get("shape", "straight"))
            self._add_combo(form, "rotation", "Closed rotation",
                            [0, 90, 180, 270],
                            ["0° (horizontal)", "90° (vertical)", "180°", "270°"],
                            self.obj.get("rotation", 0))
            self._add_check(form, "open",
                            "Initially open?", self.obj.get("open", False))
            self._add_int(form, "noise_score",
                          "Noise score (0=default)", self.obj.get("noise_score", 0), 0, 200)
            self._add_int(form, "channel",
                          "IO channel (0=none)", self.obj.get("channel", 0), 0, 255)
            self._add_info(form, "Behavior",
                           "Swings open 90° when toggled.\n"
                           "Guards notice open thin doors.\n"
                           "Player presses E to use.")

        elif t in ("transmit_node", "input_node"):
            self._add_int(form, "channel",
                          "IO channel to fire", self.obj.get("channel", 1), 0, 255)
            self._add_combo(form, "trigger_mode", "Trigger mode",
                            ["player_step", "proximity", "interval"],
                            ["Player steps on tile", "Player enters radius", "Timed interval"],
                            self.obj.get("trigger_mode", "player_step"))
            self._add_float(form, "interval",
                            "Interval (s, if timed)", self.obj.get("interval", 5.0), 0.1, 300.0)
            self._add_float(form, "radius",
                            "Proximity radius (tiles)", self.obj.get("radius", 2.0), 0.5, 20.0)
            self._add_check(form, "one_shot",
                            "One-shot (fire once only)?", self.obj.get("one_shot", False))
            self._add_info(form, "Behavior",
                           "Wire to Receive Nodes via the Connection panel.\n"
                           "Channel 0 = not connected.")

        elif t in ("receive_node", "output_node"):
            self._add_int(form, "channel",
                          "IO channel to listen on", self.obj.get("channel", 1), 0, 255)
            self._add_combo(form, "action", "Action on trigger",
                            ["toggle", "open", "close", "activate", "deactivate", "pulse"],
                            ["Toggle state", "Open/enable", "Close/disable",
                             "Activate", "Deactivate", "One-shot pulse"],
                            self.obj.get("action", "toggle"))
            self._add_info(form, "Target",
                           "The receive node triggers the object at its position.\n"
                           "Place it ON the object tile (door, camera, etc.).")

        vbox.addWidget(form_grp)

        # Buttons
        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(self._accept)
        btns.rejected.connect(self.reject)
        vbox.addWidget(btns)

    def _add_check(self, form, key, label, value):
        cb = QCheckBox()
        cb.setChecked(bool(value))
        self._widgets[key] = ("check", cb)
        form.addRow(label + ":", cb)

    def _add_str(self, form, key, label, value):
        le = QLineEdit()
        le.setText(str(value))
        self._widgets[key] = ("str", le)
        form.addRow(label + ":", le)

    def _browse_detail_img(self):
        """Open a file picker for detail_img; copies chosen image into bundle/images/."""
        start = ""
        if self._bundle_path and os.path.isdir(self._bundle_path):
            start = os.path.join(self._bundle_path, "images")
            os.makedirs(start, exist_ok=True)
        path, _ = QFileDialog.getOpenFileName(
            self, "Pick Image for Detail", start or ".",
            "Images (*.png *.jpg *.jpeg *.bmp *.gif *.webp);;All Files (*)")
        if not path:
            return
        # If bundle exists, copy the image in and store just the filename
        if self._bundle_path and os.path.isdir(self._bundle_path):
            import shutil
            images_dir = os.path.join(self._bundle_path, "images")
            os.makedirs(images_dir, exist_ok=True)
            dest_name = os.path.basename(path)
            dest_path = os.path.join(images_dir, dest_name)
            if not os.path.isfile(dest_path) or not os.path.samefile(path, dest_path):
                shutil.copy2(path, dest_path)
            self._img_edit.setText(dest_name)
        else:
            # No bundle yet — store absolute path; will be bundled on save
            self._img_edit.setText(path)

    def _refresh_img_preview(self, text):
        """Show a 96×96 thumbnail of the current image value with dimension tooltip."""
        if not hasattr(self, "_img_preview"):
            return
        text = text.strip()
        pix = None
        resolved = ""
        if text:
            candidates = [text]
            if self._bundle_path and os.path.isdir(self._bundle_path):
                candidates.insert(0, os.path.join(self._bundle_path, "images", text))
                candidates.insert(1, os.path.join(self._bundle_path, "_assets", text))
            for p in candidates:
                if os.path.isfile(p):
                    pix = QPixmap(p)
                    resolved = p
                    break
        if pix and not pix.isNull():
            w, h = pix.width(), pix.height()
            self._img_preview.setPixmap(
                pix.scaled(96, 96, Qt.AspectRatioMode.KeepAspectRatio,
                           Qt.TransformationMode.SmoothTransformation))
            rel = os.path.relpath(resolved, self._bundle_path) if self._bundle_path else resolved
            self._img_preview.setToolTip(
                f"<b>{os.path.basename(resolved)}</b><br>"
                f"{w} × {h} px<br>"
                f"<span style='color:#607090'>{rel}</span>")
        else:
            self._img_preview.setPixmap(QPixmap())
            if text:
                self._img_preview.setText("not\nfound")
                self._img_preview.setToolTip(
                    f"Image not found:\n{text}\n\n"
                    "Browse (…) to locate and copy it into the bundle.")
            else:
                self._img_preview.setText("no\nimage")
                self._img_preview.setToolTip("No image set. Click … to browse.")

    def _add_int(self, form, key, label, value, min_=0, max_=9999):
        sb = QSpinBox()
        sb.setRange(min_, max_)
        sb.setValue(int(value))
        self._widgets[key] = ("int", sb)
        form.addRow(label + ":", sb)

    def _add_float(self, form, key, label, value, min_=0.0, max_=100.0):
        sb = QDoubleSpinBox()
        sb.setRange(min_, max_)
        sb.setSingleStep(0.1)
        sb.setDecimals(2)
        sb.setValue(float(value))
        self._widgets[key] = ("float", sb)
        form.addRow(label + ":", sb)

    def _add_info(self, form, label, text):
        lbl = QLabel(text)
        lbl.setStyleSheet("color:#6878a0; font:10px Consolas;")
        lbl.setWordWrap(True)
        form.addRow(f"<b>{label}:</b>", lbl)

    def _add_combo(self, form, key, label, values, display_labels, current):
        cb = QComboBox()
        for val, disp in zip(values, display_labels):
            cb.addItem(disp, val)
        for i in range(cb.count()):
            if cb.itemData(i) == current:
                cb.setCurrentIndex(i)
                break
        self._widgets[key] = ("combo", cb)
        form.addRow(label + ":", cb)

    # ── Compact shorthand aliases (match property_dialog.py API) ─────────
    def _addc(self, form, key, label, val):
        self._add_check(form, key, label, val)

    def _addi(self, form, key, label, val, mn=0, mx=9999):
        self._add_int(form, key, label, val, min_=mn, max_=mx)

    def _addf(self, form, key, label, val, mn=0.0, mx=100.0):
        self._add_float(form, key, label, val, min_=mn, max_=mx)

    def result_data(self):
        """Return the edited data dict (alias for self.obj after _accept)."""
        return self.obj

    def _accept(self):
        for key, (kind, widget) in self._widgets.items():
            if kind == "check":
                self.obj[key] = widget.isChecked()
            elif kind == "int":
                self.obj[key] = widget.value()
            elif kind == "float":
                self.obj[key] = widget.value()
            elif kind == "combo":
                self.obj[key] = widget.currentData()
            elif kind == "str":
                self.obj[key] = widget.text()
        # detail_img: save image from custom picker widget
        if self.obj.get("type") == "detail_img" and hasattr(self, "_img_edit"):
            raw_img = self._img_edit.text().strip()
            if raw_img and self._bundle_path and os.path.isdir(self._bundle_path):
                # If it's an absolute path, copy into bundle/images/ and store filename
                if os.path.isabs(raw_img) and os.path.isfile(raw_img):
                    import shutil
                    images_dir = os.path.join(self._bundle_path, "images")
                    os.makedirs(images_dir, exist_ok=True)
                    dest_name = os.path.basename(raw_img)
                    dest_path = os.path.join(images_dir, dest_name)
                    if not os.path.isfile(dest_path):
                        shutil.copy2(raw_img, dest_path)
                    raw_img = dest_name
            self.obj["image"] = raw_img
        # detail_txt: parse color string "R, G, B" → [R, G, B]
        if self.obj.get("type") == "detail_txt" and "color" in self.obj:
            try:
                parts = [int(v.strip()) for v in str(self.obj["color"]).split(",")]
                self.obj["color"] = parts[:3] if len(parts) >= 3 else [220, 220, 180]
            except Exception:
                self.obj["color"] = [220, 220, 180]
        # detail_txt: align combo stored in _extra_widgets
        if hasattr(self, "_extra_widgets"):
            for key, (kind, widget) in self._extra_widgets.items():
                if kind == "combo":
                    self.obj[key] = widget.currentData()
        # item_pile contents
        if hasattr(self, "_item_pile_widgets"):
            contents = {}
            for key, (cb, sb) in self._item_pile_widgets.items():
                if cb.isChecked():
                    contents[key] = sb.value()
            self.obj["contents"] = contents
        # buy_item contents (price + stock per item)
        if hasattr(self, "_buy_item_widgets"):
            contents = {}
            for key, (cb, price_sb, stock_sb) in self._buy_item_widgets.items():
                if cb.isChecked():
                    contents[key] = {"price": price_sb.value(), "stock": stock_sb.value()}
            self.obj["contents"] = contents
        self.accept()

    def result_obj(self):
        return self.obj



# ════════════════════════════════════════════════════════════════════════════
# Project model  (.lep file – LockESC Project)
# ════════════════════════════════════════════════════════════════════════════
class ProjectModel:
    """
    A project groups an ordered list of rooms (.ler files) into a campaign.
    The file on disk is a .lep (LockESC Project) JSON.
    """
    VERSION = 1

    def __init__(self, name="Untitled Project"):
        self.name          = name
        self.rooms         = []   # list of dicts: {"name": str, "path": str (abs)}
        self.default_visuals = {}  # project-wide visual defaults

    # ── persistence ───────────────────────────────────────────────────────────
    def to_dict(self, project_path):
        """Serialise; paths stored relative to the sibling root of the .lep bundle."""
        base = _lep_base(project_path)
        rooms_rel = []
        for r in self.rooms:
            try:
                rel = os.path.relpath(r["path"], base)
            except ValueError:
                rel = r["path"]   # different drive on Windows → keep absolute
            rooms_rel.append({"name": r["name"], "path": rel})
        d = {"_version": self.VERSION, "name": self.name, "rooms": rooms_rel}
        if self.default_visuals:
            d["default_visuals"] = self.default_visuals
        return d

    @staticmethod
    def from_dict(data, project_path):
        # Base is the PARENT of the .lep bundle dir, so room .ler bundles resolve
        # as siblings of the .lep bundle (not children inside it).
        base = _lep_base(project_path)
        pm = ProjectModel(data.get("name", "Project"))
        pm.default_visuals = data.get("default_visuals", {})
        for r in data.get("rooms", []):
            raw = r.get("path", "")
            abs_path = _find_room_bundle(raw, base)
            pm.rooms.append({"name": r.get("name", os.path.basename(abs_path)),
                             "path": abs_path})
        return pm

    # ── helpers ───────────────────────────────────────────────────────────────
    def add_room(self, path, name=None):
        abs_path = os.path.abspath(path)
        # avoid duplicates
        if any(r["path"] == abs_path for r in self.rooms):
            return
        self.rooms.append({"name": name or os.path.splitext(os.path.basename(abs_path))[0],
                           "path": abs_path})

    def remove_room(self, idx):
        if 0 <= idx < len(self.rooms):
            self.rooms.pop(idx)

    def move_room(self, idx, delta):
        new = idx + delta
        if 0 <= new < len(self.rooms):
            self.rooms[idx], self.rooms[new] = self.rooms[new], self.rooms[idx]
            return new
        return idx

    def rename_room(self, idx, name):
        if 0 <= idx < len(self.rooms):
            self.rooms[idx]["name"] = name


# ════════════════════════════════════════════════════════════════════════════
# Project tree side panel widget
# ════════════════════════════════════════════════════════════════════════════
def _proj_ss():
    return """
        QWidget        { background: #22242e; color: #c0c8d8; font: 11px Consolas; }
        QListWidget    { background: #191b23; border: 1px solid #35394a;
                         color: #b8c4d8; outline: none; }
        QListWidget::item          { padding: 3px 6px; }
        QListWidget::item:selected { background: #2e4a70; color: #e0eaff; }
        QListWidget::item:hover    { background: #26334a; }
        QPushButton    { background: #2e3240; color: #b0bcd0;
                         border: 1px solid #3e4458; border-radius: 3px;
                         padding: 3px 8px; font: 10px Consolas; }
        QPushButton:hover   { background: #3a4458; }
        QPushButton:pressed { background: #283050; }
        QLabel         { color: #7a8898; font: 10px Consolas; }
    """

class ProjectTreePanel(QWidget):
    """
    Left sidebar section showing the active project and its room roster.
    Emits signals that EditorWindow connects to.
    """
    room_open_requested   = pyqtSignal(str)   # abs path of room .ler
    project_changed       = pyqtSignal()      # project structure mutated

    def __init__(self):
        super().__init__()
        self.project      = None   # ProjectModel or None
        self.project_path = None   # path to .lep file
        self.mp_mode      = False  # set by EditorWindow when in [MP] mode
        self._build()

    def _mp_dir(self):
        """Return the correct root dir for file dialogs based on mp_mode."""
        if self.mp_mode:
            d = os.path.join(os.path.expanduser("~"), "mplevels")
            os.makedirs(d, exist_ok=True)
            return d
        return None   # LevelBrowserDialog defaults to levels/

    def _build(self):
        self.setStyleSheet(_proj_ss())
        vbox = QVBoxLayout(self)
        vbox.setContentsMargins(6, 6, 6, 4)
        vbox.setSpacing(4)

        # ── header row ────────────────────────────────────────────────────
        hdr = QHBoxLayout()
        self._proj_lbl = QLabel("  No Project")
        self._proj_lbl.setStyleSheet(
            "font: bold 11px Consolas; color: #8ab0e0; padding: 2px 0;")
        hdr.addWidget(self._proj_lbl, 1)

        self._btn_new_proj  = QPushButton("New")
        self._btn_open_proj = QPushButton("Open")
        self._btn_save_proj = QPushButton("Save")
        for b in (self._btn_new_proj, self._btn_open_proj, self._btn_save_proj):
            b.setFixedHeight(22)
            hdr.addWidget(b)
        vbox.addLayout(hdr)

        # ── room list ─────────────────────────────────────────────────────
        self._room_list = QListWidget()
        self._room_list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self._room_list.setDefaultDropAction(Qt.DropAction.MoveAction)
        self._room_list.setToolTip("Double-click to open room in editor")
        self._room_list.itemDoubleClicked.connect(self._on_room_dblclick)
        self._room_list.model().rowsMoved.connect(self._on_rows_moved)
        vbox.addWidget(self._room_list)

        # ── room action buttons ───────────────────────────────────────────
        row1 = QHBoxLayout()
        self._btn_add_room    = QPushButton("＋ Add Room")
        self._btn_new_room    = QPushButton("＋ New Room")
        row1.addWidget(self._btn_add_room)
        row1.addWidget(self._btn_new_room)
        vbox.addLayout(row1)

        row2 = QHBoxLayout()
        self._btn_rm_room     = QPushButton("✕ Remove")
        self._btn_up_room     = QPushButton("▲")
        self._btn_dn_room     = QPushButton("▼")
        self._btn_up_room.setFixedWidth(32)
        self._btn_dn_room.setFixedWidth(32)
        row2.addWidget(self._btn_rm_room, 1)
        row2.addWidget(self._btn_up_room)
        row2.addWidget(self._btn_dn_room)
        vbox.addLayout(row2)

        self._info_lbl = QLabel("No project open.\nNew or Open a project above.")
        self._info_lbl.setWordWrap(True)
        vbox.addWidget(self._info_lbl)

        # ── wire ──────────────────────────────────────────────────────────
        self._btn_new_proj.clicked.connect(self._new_project)
        self._btn_open_proj.clicked.connect(self._open_project)
        self._btn_save_proj.clicked.connect(self._save_project)
        self._btn_add_room.clicked.connect(self._add_room)
        self._btn_new_room.clicked.connect(self._new_room)
        self._btn_rm_room.clicked.connect(self._remove_room)
        self._btn_up_room.clicked.connect(lambda: self._move_room(-1))
        self._btn_dn_room.clicked.connect(lambda: self._move_room(1))

        self._set_controls_enabled(False)

    # ── internal helpers ──────────────────────────────────────────────────
    def _set_controls_enabled(self, on):
        for w in (self._btn_save_proj, self._btn_add_room, self._btn_new_room,
                  self._btn_rm_room, self._btn_up_room, self._btn_dn_room):
            w.setEnabled(on)

    def _refresh_list(self):
        self._room_list.clear()
        if not self.project:
            self._info_lbl.setText("No project open.\nNew or Open a project above.")
            self._proj_lbl.setText("  No Project")
            self._set_controls_enabled(False)
            return
        self._proj_lbl.setText(f"  {self.project.name}")
        n = len(self.project.rooms)
        self._info_lbl.setText(
            f"{n} room{'s' if n!=1 else ''}  |  drag to reorder")
        self._set_controls_enabled(True)
        for i, r in enumerate(self.project.rooms):
            exists = os.path.exists(r["path"])
            icon   = "🔴" if not exists else f"{i+1:02d}"
            tip    = r["path"] if exists else f"⚠ File not found:\n{r['path']}"
            item   = QListWidgetItem(f"  {icon}  {r['name']}")
            item.setToolTip(tip)
            if not exists:
                item.setForeground(QColor(180, 80, 80))
            self._room_list.addItem(item)

    def _current_idx(self):
        return self._room_list.currentRow()

    # ── project ops ───────────────────────────────────────────────────────
    def _new_project(self):
        name, ok = self._ask_name("New Project", "Project name:", "Untitled Project")
        if not ok: return
        path, ok2 = LevelBrowserDialog.get_save(self, "Save New Project (.lep)", ".lep", start_dir=self._mp_dir())
        if not ok2 or not path: return
        self.project      = ProjectModel(name)
        self.project_path = path
        self._save_project()
        self._refresh_list()
        self.project_changed.emit()

    def _open_project(self):
        path, ok = LevelBrowserDialog.get_open(self, "Open Project (.lep)", ".lep", start_dir=self._mp_dir())
        if not ok or not path: return
        try:
            real = _lep_json_path(path)
            with open(real) as f: data = json.load(f)
            self.project      = ProjectModel.from_dict(data, real)
            self.project_path = path
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to open project:\n{e}")
            return
        self._refresh_list()
        self.project_changed.emit()

    def _save_project(self):
        if not self.project: return
        if not self.project_path:
            path, ok = LevelBrowserDialog.get_save(self, "Save Project", ".lep", start_dir=self._mp_dir())
            if not ok or not path: return
            self.project_path = path
        try:
            real = _lep_json_path(self.project_path)
            _save_lep_bundle(
                self.project.to_dict(real),
                self.project_path)
        except Exception as e:
            QMessageBox.critical(self, "Save Error", str(e))

    # ── room ops ──────────────────────────────────────────────────────────
    def _add_room(self):
        if not self.project: return
        path, ok = LevelBrowserDialog.get_open(self, "Add Room (.ler)", ".ler", start_dir=self._mp_dir())
        if not ok or not path: return
        self.project.add_room(path)
        self._refresh_list()
        self._save_project()
        self.project_changed.emit()

    def _new_room(self):
        """Ask editor to create a new room and add it to the project."""
        if not self.project: return
        # signal editor to trigger save-as for a new room; it will call
        # add_room_to_project() on us after saving.
        self.room_open_requested.emit("")   # empty = "create new"

    def _remove_room(self):
        idx = self._current_idx()
        if idx < 0 or not self.project: return
        r = self.project.rooms[idx]
        ans = QMessageBox.question(
            self, "Remove Room",
            f"Remove «{r['name']}» from this project?\n(File is not deleted.)",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if ans != QMessageBox.StandardButton.Yes: return
        self.project.remove_room(idx)
        self._refresh_list()
        self._save_project()
        self.project_changed.emit()

    def _move_room(self, delta):
        idx = self._current_idx()
        if idx < 0 or not self.project: return
        new_idx = self.project.move_room(idx, delta)
        self._refresh_list()
        self._room_list.setCurrentRow(new_idx)
        self._save_project()
        self.project_changed.emit()

    def _on_room_dblclick(self, item):
        idx = self._room_list.row(item)
        if self.project and 0 <= idx < len(self.project.rooms):
            p = self.project.rooms[idx]["path"]
            if not os.path.exists(p):
                QMessageBox.warning(self, "Missing File",
                    f"Room file not found:\n{p}")
                return
            self.room_open_requested.emit(p)

    def _on_rows_moved(self, *_):
        """Sync drag-reorder back to ProjectModel."""
        if not self.project: return
        new_order = []
        for i in range(self._room_list.count()):
            # re-derive from display order; rooms list was already reordered
            # by the QListWidget's internal move — we just rebuild from indices
            pass
        # Simplest reliable approach: rebuild order from current list labels
        # by matching display text to room names/paths
        name_to_room = {r["name"]: r for r in self.project.rooms}
        reordered = []
        for i in range(self._room_list.count()):
            text = self._room_list.item(i).text().strip()
            # strip leading index "01  name"
            parts = text.split("  ", 1)
            label = parts[-1].strip() if len(parts) > 1 else text
            if label in name_to_room:
                reordered.append(name_to_room[label])
        if len(reordered) == len(self.project.rooms):
            self.project.rooms = reordered
        self._refresh_list()
        self._save_project()
        self.project_changed.emit()

    # ── public API ────────────────────────────────────────────────────────
    def add_room_to_project(self, path, name=None):
        """Called by EditorWindow after saving a new room."""
        if self.project:
            self.project.add_room(path, name)
            self._refresh_list()
            self._save_project()
            self.project_changed.emit()

    @staticmethod
    def _ask_name(title, label, default=""):
        from PyQt6.QtWidgets import QInputDialog
        text, ok = QInputDialog.getText(None, title, label,
                                        text=default)
        return text.strip(), ok and bool(text.strip())


# ════════════════════════════════════════════════════════════════════════════
# Level data model
# ════════════════════════════════════════════════════════════════════════════
class LevelModel:
    def __init__(self, cols=DEFAULT_COLS, rows=DEFAULT_ROWS,
                 tile_size=DEFAULT_TILE, name="Untitled"):
        self.name      = name
        self.cols      = cols
        self.rows      = rows
        self.tile_size = tile_size
        self.objects   = []
        self.visuals   = {}   # visual config – written/read by IntegrityEditor
        self.connections = []  # IO wiring: [{from_col,from_row,from_signal,to_col,to_row,to_slot}]
        self.timers    = []   # off-tile timer nodes: [{channel,interval,delay,one_shot,active,label}]
        # ── Room / level properties ───────────────────────────────────────────
        self.is_shop   = False   # True → shop toolbar tab is shown; buy_item/shop_leave tiles allowed
        self.room_props: dict = {}   # extensible bag for future per-room flags

    def clear(self):
        self.objects = []
        self.connections = []
        self.timers = []

    def to_json(self):
        d = {
            "name":      self.name,
            "tile_size": self.tile_size,
            "cols":      self.cols,
            "rows":      self.rows,
            "objects":   self.objects,
        }
        if self.visuals:
            d["visuals"] = self.visuals
        if self.connections:
            d["connections"] = self.connections
        if self.timers:
            d["timers"] = self.timers
        if self.is_shop:
            d["is_shop"] = True
        if self.room_props:
            d["room_props"] = self.room_props
        return d

    @staticmethod
    def from_json(data):
        m = LevelModel(data["cols"], data["rows"],
                       data.get("tile_size", DEFAULT_TILE),
                       data.get("name", "Level"))
        m.objects = data.get("objects", [])
        m.visuals = data.get("visuals", {})
        m.connections = data.get("connections", [])
        m.timers = data.get("timers", [])
        m.is_shop   = bool(data.get("is_shop", False))
        m.room_props = data.get("room_props", {})
        return m

    def objects_at(self, col, row):
        return [o for o in self.objects if o["col"] == col and o["row"] == row]

    def remove_at(self, col, row):
        self.objects = [o for o in self.objects
                        if not (o["col"] == col and o["row"] == row)]
        # Remove any connections touching this tile
        self.connections = [c for c in self.connections
                            if not ((c["from_col"] == col and c["from_row"] == row) or
                                    (c["to_col"] == col and c["to_row"] == row))]

    def place(self, col, row, tile_type, extra=None):
        if col < 0 or row < 0 or col >= self.cols or row >= self.rows:
            return None
        if tile_type in ("player", "player2", "exit"):
            self.objects = [o for o in self.objects if o["type"] != tile_type]
        elif tile_type == "guard":
            # Remove any existing guard at this exact tile to prevent duplicates,
            # but leave guards at other positions intact.
            self.objects = [o for o in self.objects
                            if not (o["type"] == "guard" and o["col"] == col and o["row"] == row)]
        else:
            self.remove_at(col, row)

        obj = {"type": tile_type, "col": col, "row": row}
        if extra:
            obj.update(extra)
        self.objects.append(obj)
        return obj

    def guards(self):
        return [o for o in self.objects if o["type"] == "guard"]

    def _ensure_wp_nodes(self, guard_obj):
        """Migrate old [col,row] waypoints to rich node dicts if needed."""
        wps  = guard_obj.get("waypoints", [[guard_obj["col"], guard_obj["row"]]])
        pfs  = guard_obj.get("pause_flags", [False]*len(wps))
        nodes = guard_obj.get("wp_nodes", None)
        if nodes is None:
            # Migrate
            nodes = []
            for i, wp in enumerate(wps):
                is_pause = pfs[i] if i < len(pfs) else False
                nodes.append({
                    "col": wp[0], "row": wp[1],
                    "type": "waitpoint" if is_pause else "waypoint",
                })
            guard_obj["wp_nodes"] = nodes
        return nodes

    def add_waypoint_to_guard(self, guard_obj, col, row, wp_type="waypoint", extra=None):
        nodes = self._ensure_wp_nodes(guard_obj)
        # Don't add duplicate positions (except wp_select doesn't add)
        for n in nodes:
            if n["col"] == col and n["row"] == row:
                return
        node = {"col": col, "row": row, "type": wp_type}
        if extra:
            node.update(extra)
        nodes.append(node)
        # Sync legacy fields
        self._sync_legacy(guard_obj)

    def _sync_legacy(self, guard_obj):
        """Keep old waypoints/pause_flags in sync for game engine compatibility."""
        nodes = guard_obj.get("wp_nodes", [])
        guard_obj["waypoints"]   = [[n["col"], n["row"]] for n in nodes]
        guard_obj["pause_flags"] = [n.get("type") == "waitpoint" for n in nodes]

    def move_waypoint(self, guard_obj, node_idx, new_col, new_row):
        nodes = self._ensure_wp_nodes(guard_obj)
        if 0 <= node_idx < len(nodes):
            # First node is spawn – can be moved but only if not idx 0, or allow it
            nodes[node_idx]["col"] = new_col
            nodes[node_idx]["row"] = new_row
            if node_idx == 0:
                guard_obj["col"] = new_col
                guard_obj["row"] = new_row
            self._sync_legacy(guard_obj)

    def remove_waypoint(self, guard_obj, idx):
        nodes = self._ensure_wp_nodes(guard_obj)
        if 0 < idx < len(nodes):   # never remove spawn (idx 0)
            nodes.pop(idx)
            self._sync_legacy(guard_obj)

    def toggle_pause_flag(self, guard_obj, idx):
        """Legacy toggle – flips between waypoint/waitpoint."""
        nodes = self._ensure_wp_nodes(guard_obj)
        if 0 <= idx < len(nodes):
            t = nodes[idx].get("type", "waypoint")
            nodes[idx]["type"] = "waitpoint" if t != "waitpoint" else "waypoint"
            self._sync_legacy(guard_obj)

    def set_node_type(self, guard_obj, idx, wp_type):
        nodes = self._ensure_wp_nodes(guard_obj)
        if 0 <= idx < len(nodes):
            nodes[idx]["type"] = wp_type
            self._sync_legacy(guard_obj)


def _thin_wall_segs(rx, ry, tp, shape, rot):
    """
    Return a list of (x1,y1,x2,y2) line segments for a thin-wall tile.
    rx,ry = top-left pixel of tile, tp = tile size in pixels.
    """
    cx, cy = rx + tp // 2, ry + tp // 2
    mg = max(2, tp // 8)          # inset margin from tile edge
    # named endpoints
    top    = (cx,        ry + mg)
    bottom = (cx,        ry + tp - mg)
    left   = (rx + mg,   cy)
    right  = (rx + tp - mg, cy)
    ctr    = (cx, cy)

    rot = rot % 360

    if shape == "straight":
        if rot in (0, 180):
            return [(*left,  *right)]
        else:
            return [(*top,   *bottom)]

    elif shape == "corner":
        # 0°=top+right  90°=right+bottom  180°=bottom+left  270°=left+top
        segs = [
            [(*top, *ctr), (*ctr, *right)],
            [(*right, *ctr), (*ctr, *bottom)],
            [(*bottom, *ctr), (*ctr, *left)],
            [(*left, *ctr), (*ctr, *top)],
        ]
        return segs[(rot // 90) % 4]

    elif shape == "t":
        # 0°=opening up (hor + top arm)
        # 90°=opening left (vert + right arm)
        # 180°=opening down (hor + bottom arm)
        # 270°=opening right (vert + left arm)
        segs = [
            [(*left, *right), (*top, *ctr)],
            [(*top, *bottom), (*ctr, *right)],
            [(*left, *right), (*ctr, *bottom)],
            [(*top, *bottom), (*left, *ctr)],
        ]
        return segs[(rot // 90) % 4]

    else:  # plus
        return [(*left, *right), (*top, *bottom)]


# ════════════════════════════════════════════════════════════════════════════
# Canvas widget
# ════════════════════════════════════════════════════════════════════════════
class Canvas(QWidget):
    tile_clicked      = pyqtSignal(int, int, int)   # col, row, button
    tile_dbl_click    = pyqtSignal(int, int)
    status_update     = pyqtSignal(str)
    selection_changed = pyqtSignal(list)            # list of (col, row)
    wp_node_clicked   = pyqtSignal(int)             # waypoint node index clicked
    wp_node_dbl_click = pyqtSignal(int)             # for property edit
    selection_nudged  = pyqtSignal(int, int)        # dx, dy for selected tiles nudge
    conn_tile_clicked = pyqtSignal(int, int)        # col, row in connection mode
    stroke_ended      = pyqtSignal()                # mouse released after paint stroke
    context_menu_requested = pyqtSignal(int, int, object)  # col, row, QPoint(global)                # mouse released after paint stroke

    def __init__(self, model: LevelModel):
        super().__init__()
        self.model      = model
        self.zoom       = 1.0
        self.offset     = QPoint(20, 20)
        self._pan_last  = None
        self._panning   = False
        self.show_grid  = True
        self.selected_guard = None
        self.wp_mode    = False
        self.current_tool    = "wall"
        self.current_wp_tool = "wp_select"

        # SELECT tool state
        self._sel_start       = None
        self._sel_rect        = None
        self._selected        = set()   # set of (col, row)
        self._dragging_select = False

        # Waypoint SELECT state
        self.selected_wp_idx  = -1      # which waypoint node is selected
        self._wp_dragging     = False   # dragging a wp node

        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setMinimumSize(400, 300)
        self._hover = (-1, -1)
        self.conn_mode  = False   # IO connection wiring mode
        self.level_stem = ""      # set by EditorWindow when a level is opened; drives PNG lookup
        self._conn_src  = None    # (col, row) of source tile being wired
        self._shift_erasing = False  # Shift+LMB drag erase mode

    def set_model(self, model):
        self.model = model
        self.selected_guard = None
        self.wp_mode = False
        self.conn_mode = False
        self._conn_src = None
        self._selected.clear()
        self._sel_rect = None
        self.fit()
        self.update()

    def fit(self):
        w, h = self.width(), self.height()
        zx = (w - 40) / (self.model.cols * DEFAULT_TILE)
        zy = (h - 40) / (self.model.rows * DEFAULT_TILE)
        self.zoom = max(0.2, min(3.0, min(zx, zy)))
        tw = self.model.cols * self.tile_px()
        th = self.model.rows * self.tile_px()
        self.offset = QPoint((w - tw) // 2, (h - th) // 2)
        self.update()

    def tile_px(self):
        return int(DEFAULT_TILE * self.zoom)

    def canvas_to_tile(self, cx, cy):
        tp = self.tile_px()
        col = int((cx - self.offset.x()) // tp)
        row = int((cy - self.offset.y()) // tp)
        return col, row

    def tile_center(self, col, row):
        tp = self.tile_px()
        x = self.offset.x() + col * tp + tp // 2
        y = self.offset.y() + row * tp + tp // 2
        return QPoint(x, y)

    def tile_rect(self, col, row):
        tp = self.tile_px()
        x  = self.offset.x() + col * tp
        y  = self.offset.y() + row * tp
        return QRect(x, y, tp, tp)

    # ── paint ────────────────────────────────────────────────────────────────
    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        m   = self.model
        tp  = self.tile_px()
        ox  = self.offset.x()
        oy  = self.offset.y()
        W   = m.cols * tp
        H   = m.rows * tp

        p.fillRect(self.rect(), PAL["bg"])
        p.fillRect(ox, oy, W, H, PAL["floor"])

        # checkerboard floor
        for r in range(m.rows):
            for c in range(m.cols):
                if (c + r) % 2 == 0:
                    p.fillRect(ox + c*tp, oy + r*tp, tp, tp, QColor(24, 56, 96))

        # objects – walls first
        walls = {(o["col"], o["row"]) for o in m.objects if o["type"] == "wall"}

        # Pre-compute linked door pairs (exactly 2 adjacent same-type doors)
        # Mirrors ObjectRegistry._autolink logic so the editor shows the same dot
        def _linked_positions(dtype):
            pos_set = {(o["col"], o["row"]) for o in m.objects if o["type"] == dtype}
            linked = set(); visited = set()
            for start in pos_set:
                if start in visited: continue
                comp = []; q = [start]
                while q:
                    cur = q.pop()
                    if cur in visited: continue
                    visited.add(cur); comp.append(cur)
                    cc, cr = cur
                    for dc2, dr2 in ((1,0),(-1,0),(0,1),(0,-1)):
                        nb = (cc+dc2, cr+dr2)
                        if nb in pos_set and nb not in visited: q.append(nb)
                if len(comp) == 2: linked.update(comp)
            return linked
        _DOOR_TYPES = ("door","oiled_door","wall_door","crashdoor","thin_door")
        _linked = {t: _linked_positions(t) for t in _DOOR_TYPES}
        for (c, r) in walls:
            rx = ox + c * tp
            ry = oy + r * tp
            p.fillRect(rx, ry, tp, tp, PAL["wall"])
            pen = QPen(QColor(70, 95, 155), 2)
            p.setPen(pen)
            p.drawLine(rx, ry, rx + tp, ry)
            p.drawLine(rx, ry, rx, ry + tp)
            p.setPen(QPen(QColor(20, 28, 52), 1))
            p.drawLine(rx + tp, ry, rx + tp, ry + tp)
            p.drawLine(rx, ry + tp, rx + tp, ry + tp)

        # windows (translucent)
        for obj in m.objects:
            if obj["type"] == "window":
                c, r = obj["col"], obj["row"]
                rx, ry = ox + c*tp, oy + r*tp
                col = PAL["window"]
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(QColor(col.red(), col.green(), col.blue(), 80)))
                p.drawRect(rx, ry, tp, tp)
                p.setPen(QPen(col, 2))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawRect(rx+1, ry+1, tp-2, tp-2)

        # invisible walls – editor ghost (floor tint + dashed outline)
        invis_col = PAL["invisible_wall"]
        for obj in m.objects:
            if obj["type"] == "invisible_wall":
                c2, r2 = obj["col"], obj["row"]
                rx2, ry2 = ox + c2*tp, oy + r2*tp
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(QColor(invis_col.red(), invis_col.green(),
                                        invis_col.blue(), 28)))
                p.drawRect(rx2, ry2, tp, tp)
                p.setPen(QPen(QColor(invis_col.red(), invis_col.green(),
                                     invis_col.blue(), 160), 2, Qt.PenStyle.DashLine))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawRect(rx2+2, ry2+2, tp-4, tp-4)

        # thin walls – line shapes
        thin_col = PAL["thin_wall"]
        lw = max(2, tp // 9)
        thin_pen = QPen(thin_col, lw, Qt.PenStyle.SolidLine,
                        Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
        for obj in m.objects:
            if obj["type"] == "thin_wall":
                c2, r2 = obj["col"], obj["row"]
                rx2, ry2 = ox + c2*tp, oy + r2*tp
                shape = obj.get("shape", "straight")
                rot   = obj.get("rotation", 0)
                p.setPen(thin_pen)
                for x1, y1, x2, y2 in _thin_wall_segs(rx2, ry2, tp, shape, rot):
                    p.drawLine(x1, y1, x2, y2)
                # small shape label in corner when tile is large enough
                if tp >= 24:
                    shape_sym = {"straight": "─" if rot % 180 == 0 else "│",
                                 "corner": "└", "t": "┴", "plus": "┼"}.get(shape, "┼")
                    p.setPen(QPen(thin_col.lighter(140)))
                    p.setFont(QFont("Consolas", max(6, tp // 6)))
                    p.drawText(rx2 + 2, ry2 + 2, tp - 4, tp // 3,
                               Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop,
                               shape_sym)

        # thin doors – hinge-based rotation via .lev renderer
        for obj in m.objects:
            if obj["type"] == "thin_door":
                c2, r2 = obj["col"], obj["row"]
                rx2, ry2 = ox + c2*tp, oy + r2*tp
                # Use .lev renderer (hinge_dot + hinge_line layers)
                if not _draw_lev_tile(p, "thin_door", rx2, ry2, tp, obj,
                                      state="open" if obj.get("open") else "closed",
                                      level_stem=self.level_stem):
                    # fallback: old center-based drawing
                    is_open = obj.get("open", False)
                    rot     = obj.get("rotation", 0)
                    tdoor_col     = PAL["thin_door"]
                    tdoor_open_col = QColor(120, 200, 100)
                    draw_col = tdoor_open_col if is_open else tdoor_col
                    vrot = (rot + 90) % 360 if is_open else rot
                    cx2, cy2 = rx2 + tp//2, ry2 + tp//2
                    mg = max(2, tp // 8)
                    if vrot in (0, 180):
                        x1, y1, x2, y2 = rx2+mg, cy2, rx2+tp-mg, cy2
                    else:
                        x1, y1, x2, y2 = cx2, ry2+mg, cx2, ry2+tp-mg
                    lw_td = max(3, tp // 7)
                    pen_td = QPen(draw_col, lw_td, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
                    p.setPen(pen_td); p.drawLine(x1, y1, x2, y2)
                    hr = max(2, tp // 12)
                    hx2 = rx2 + mg if (vrot in (0, 180)) else cx2

        # ── Region tiles ─────────────────────────────────────────────────
        # Shown when any region-family tool is active
        _show_regions = self.current_tool in ("region",
                                              "region_inbetween",
                                              "region_inbetween_doorway")
        if _show_regions:
            REGION_COLORS = [
                QColor( 80, 200, 120, 55),  # 1 green
                QColor( 80, 140, 220, 55),  # 2 blue
                QColor(200, 140,  60, 55),  # 3 orange
                QColor(200,  80, 160, 55),  # 4 pink
                QColor(100, 200, 200, 55),  # 5 teal
            ]
            REGION_BORDER = [
                QColor( 80, 200, 120, 160),
                QColor( 80, 140, 220, 160),
                QColor(200, 140,  60, 160),
                QColor(200,  80, 160, 160),
                QColor(100, 200, 200, 160),
            ]
            # Inbetween: sky-blue fill, dashed border, "~" label
            IBW_FILL   = QColor(180, 220, 255, 55)
            IBW_BORDER = QColor(120, 180, 255, 180)
            # Doorway: amber fill, dashed border, "|" label
            DWY_FILL   = QColor(255, 200,  80, 65)
            DWY_BORDER = QColor(230, 160,  30, 200)

            for obj in m.objects:
                rtype = obj.get("type", "")
                if rtype not in ("region", "region_inbetween",
                                 "region_inbetween_doorway"):
                    continue

                if rtype == "region":
                    rid      = obj.get("region_id", 1)
                    col_idx  = (rid - 1) % len(REGION_COLORS)
                    fill_col = REGION_COLORS[col_idx]
                    brd_col  = REGION_BORDER[col_idx]
                    label    = str(rid)
                    pen_style = Qt.PenStyle.DotLine
                elif rtype == "region_inbetween":
                    fill_col = IBW_FILL
                    brd_col  = IBW_BORDER
                    label    = "~"
                    pen_style = Qt.PenStyle.DashLine
                else:  # region_inbetween_doorway
                    fill_col = DWY_FILL
                    brd_col  = DWY_BORDER
                    label    = "|"
                    pen_style = Qt.PenStyle.DashDotLine

                for t in obj.get("tiles", []):
                    tc_, tr = t[0], t[1]
                    rx3 = ox + tc_*tp; ry3 = oy + tr*tp
                    p.setPen(Qt.PenStyle.NoPen)
                    p.setBrush(QBrush(fill_col))
                    p.drawRect(rx3, ry3, tp, tp)
                    p.setPen(QPen(brd_col, 1, pen_style))
                    p.setBrush(Qt.BrushStyle.NoBrush)
                    p.drawRect(rx3+1, ry3+1, tp-2, tp-2)
                    if tp >= 20:
                        p.setPen(QPen(brd_col.lighter(140)))
                        p.setFont(QFont("Consolas", max(6, tp // 5), QFont.Weight.Bold))
                        p.drawText(rx3+2, ry3+2, tp-4, tp-4,
                                   Qt.AlignmentFlag.AlignCenter, label)

        # ── AI hint tiles ─────────────────────────────────────────────────
        # Shown when any ai hint tool is active (or always, faintly)
        _show_ai_hints = self.current_tool in ("ai_coverhint",
                                               "ai_chokehint",
                                               "ai_avoidhint")
        AI_HINT_STYLES = {
            "ai_coverhint":  (QColor(255, 120,  60, 60),  QColor(255, 120,  60, 180),
                              Qt.PenStyle.DotLine, "C"),
            "ai_chokehint":  (QColor(180,  60, 220, 60),  QColor(180,  60, 220, 180),
                              Qt.PenStyle.DashLine, "B"),
            "ai_avoidhint":  (QColor( 60, 180, 255, 60),  QColor( 60, 180, 255, 180),
                              Qt.PenStyle.DashDotLine, "A"),
        }
        for obj in m.objects:
            htype = obj.get("type", "")
            if htype not in AI_HINT_STYLES:
                continue
            # Always show faintly; brighter when the matching tool is active
            fill_col, brd_col, pen_style, label = AI_HINT_STYLES[htype]
            if not _show_ai_hints:
                fill_col = QColor(fill_col.red(), fill_col.green(),
                                  fill_col.blue(), 20)
                brd_col  = QColor(brd_col.red(), brd_col.green(),
                                  brd_col.blue(), 60)
            for t in obj.get("tiles", []):
                tc_, tr = t[0], t[1]
                rx3 = ox + tc_*tp; ry3 = oy + tr*tp
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(fill_col))
                p.drawRect(rx3, ry3, tp, tp)
                p.setPen(QPen(brd_col, 1, pen_style))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawRect(rx3+1, ry3+1, tp-2, tp-2)
                if tp >= 20 and _show_ai_hints:
                    p.setPen(QPen(brd_col.lighter(130)))
                    p.setFont(QFont("Consolas", max(6, tp // 5), QFont.Weight.Bold))
                    p.drawText(rx3+2, ry3+2, tp-4, tp-4,
                               Qt.AlignmentFlag.AlignCenter, label)

        # ── Edge walls ───────────────────────────────────────────────────
        edge_wall_col = PAL["edge_wall"]
        edge_wall_pen = QPen(edge_wall_col, max(3, tp // 10),
                             Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
        for obj in m.objects:
            if obj.get("type") == "edge_wall":
                ec, er, es = obj["col"], obj["row"], obj.get("side", "N")
                if es == "N":
                    x1_, y1_ = ox + ec*tp, oy + er*tp
                    x2_, y2_ = x1_ + tp, y1_
                elif es == "S":
                    x1_, y1_ = ox + ec*tp, oy + (er+1)*tp
                    x2_, y2_ = x1_ + tp, y1_
                elif es == "W":
                    x1_, y1_ = ox + ec*tp, oy + er*tp
                    x2_, y2_ = x1_, y1_ + tp
                else:  # E
                    x1_, y1_ = ox + (ec+1)*tp, oy + er*tp
                    x2_, y2_ = x1_, y1_ + tp
                p.setPen(edge_wall_pen)
                p.drawLine(x1_, y1_, x2_, y2_)
                # Tick marks at ends
                p.setPen(QPen(edge_wall_col.darker(130), max(2, tp // 14)))
                if es in ("N", "S"):
                    p.drawLine(x1_, y1_-3, x1_, y1_+3)
                    p.drawLine(x2_, y2_-3, x2_, y2_+3)
                else:
                    p.drawLine(x1_-3, y1_, x1_+3, y1_)
                    p.drawLine(x2_-3, y2_, x2_+3, y2_)

        # ── Edge doors ───────────────────────────────────────────────────
        for obj in m.objects:
            if obj.get("type") == "edge_door":
                ec, er, es = obj["col"], obj["row"], obj.get("side", "N")
                is_open = obj.get("open", False)
                door_col = PAL["edge_door"] if not is_open else QColor(120, 200, 100)
                lw = max(3, tp // 9)
                pen_ed = QPen(door_col, lw, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
                p.setPen(pen_ed)

                door_len = tp * 0.9
                if es in ("N", "S"):
                    row_y = oy + er*tp if es == "N" else oy + (er+1)*tp
                    hx_, hy_ = ox + ec*tp, row_y
                    if is_open:
                        # Rotated 90° (perpendicular)
                        tx_, ty_ = hx_, hy_ - int(door_len)
                    else:
                        tx_, ty_ = hx_ + int(door_len), hy_
                else:  # W or E
                    col_x = ox + ec*tp if es == "W" else ox + (ec+1)*tp
                    hx_, hy_ = col_x, oy + er*tp
                    if is_open:
                        tx_, ty_ = hx_ - int(door_len), hy_
                    else:
                        tx_, ty_ = hx_, hy_ + int(door_len)

                p.drawLine(hx_, hy_, tx_, ty_)
                # Hinge dot
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(QColor(220, 190, 100)))
                p.drawEllipse(hx_ - 4, hy_ - 4, 8, 8)

        # guard waypoint paths
        for g in m.guards():
            nodes = g.get("wp_nodes") or []
            if not nodes:
                # fallback to legacy
                wps  = g.get("waypoints", [[g["col"], g["row"]]])
                pfs  = g.get("pause_flags", [False]*len(wps))
                nodes = [{"col": w[0], "row": w[1],
                          "type": "waitpoint" if (i < len(pfs) and pfs[i]) else "waypoint"}
                         for i, w in enumerate(wps)]

            is_sel_guard = (g is self.selected_guard)

            # Build patrol-stop list (watch/check/ignore are modifiers, not stops)
            _MOD_TYPES = {"watch", "check", "ignore"}
            stop_nodes = [n for n in nodes if n.get("type", "waypoint") not in _MOD_TYPES]
            if len(stop_nodes) > 1:
                # Draw loop lines between patrol stops only
                line_col = PAL["waypoint"] if not is_sel_guard else PAL["select"]
                pp = QPen(line_col, max(1, tp // 22), Qt.PenStyle.DashLine)
                p.setPen(pp)
                for i in range(len(stop_nodes)):
                    a = stop_nodes[i]; b = stop_nodes[(i+1) % len(stop_nodes)]
                    ax = ox + a["col"]*tp + tp//2; ay = oy + a["row"]*tp + tp//2
                    bx = ox + b["col"]*tp + tp//2; by = oy + b["row"]*tp + tp//2
                    p.drawLine(ax, ay, bx, by)

            for i, node in enumerate(nodes):
                cx2 = ox + node["col"]*tp + tp//2
                cy2 = oy + node["row"]*tp + tp//2
                nt  = node.get("type", "waypoint")
                r2  = max(4, tp // 7)
                nc  = WP_COLORS.get(nt, PAL["waypoint"])

                is_selected_node = (is_sel_guard and i == self.selected_wp_idx)

                if is_selected_node:
                    # selection halo
                    p.setPen(QPen(PAL["select"], 2))
                    p.setBrush(QBrush(QColor(100, 180, 255, 40)))
                    p.drawEllipse(cx2 - r2 - 4, cy2 - r2 - 4, (r2+4)*2, (r2+4)*2)

                if nt == "waypoint":
                    p.setPen(QPen(nc.darker(130), 2))
                    p.setBrush(QBrush(nc))
                    p.drawEllipse(cx2 - r2, cy2 - r2, r2*2, r2*2)

                elif nt == "waitpoint":
                    # ring with inner fill
                    p.setPen(QPen(WP_COLORS["waitpoint"], 2))
                    p.setBrush(QBrush(QColor(WP_COLORS["waitpoint"].red(),
                                            WP_COLORS["waitpoint"].green(),
                                            WP_COLORS["waitpoint"].blue(), 80)))
                    p.drawEllipse(cx2 - r2, cy2 - r2, r2*2, r2*2)
                    # pause bars
                    bw = max(1, r2//3)
                    p.setPen(QPen(WP_COLORS["waitpoint"], max(1, r2//3)))
                    p.drawLine(cx2-bw, cy2-r2+3, cx2-bw, cy2+r2-3)
                    p.drawLine(cx2+bw, cy2-r2+3, cx2+bw, cy2+r2-3)

                elif nt == "ignore":
                    # Match game: faded X (grey)
                    r_i = r2
                    p.setPen(QPen(QColor(120, 120, 120), max(1, r_i//2)))
                    p.drawLine(cx2-r_i+2, cy2-r_i+2, cx2+r_i-2, cy2+r_i-2)
                    p.drawLine(cx2+r_i-2, cy2-r_i+2, cx2-r_i+2, cy2+r_i-2)

                elif nt == "watch":
                    # Match game: cyan circle outline with inner dot
                    p.setPen(QPen(nc, 2))
                    p.setBrush(Qt.BrushStyle.NoBrush)
                    p.drawEllipse(cx2 - r2, cy2 - r2, r2*2, r2*2)
                    p.setPen(Qt.PenStyle.NoPen)
                    p.setBrush(QBrush(nc))
                    iris = max(2, r2//2)
                    p.drawEllipse(cx2-iris, cy2-iris, iris*2, iris*2)

                elif nt == "check":
                    # Match game: orange diamond outline
                    poly = QPolygon([
                        QPoint(cx2, cy2-r2), QPoint(cx2+r2, cy2),
                        QPoint(cx2, cy2+r2), QPoint(cx2-r2, cy2),
                    ])
                    p.setPen(QPen(nc, 2))
                    p.setBrush(Qt.BrushStyle.NoBrush)
                    p.drawPolygon(poly)

                # Index label
                if tp > 24:
                    p.setPen(QPen(QColor(255,255,255), 1))
                    p.setFont(QFont("Consolas", max(5, tp // 8)))
                    p.drawText(cx2 - r2, cy2 - r2, r2*2, r2*2,
                               Qt.AlignmentFlag.AlignCenter, str(i))

                # Type icon for non-standard nodes
                if nt not in ("waypoint",) and tp > 32:
                    icon = WP_ICONS.get(nt, "")
                    if icon:
                        p.setPen(QPen(QColor(255,255,255,180), 1))
                        p.setFont(QFont("Consolas", max(5, tp // 9)))
                        p.drawText(cx2 + r2, cy2 - r2, r2, r2,
                                   Qt.AlignmentFlag.AlignCenter, icon)

        # other objects
        font = QFont("Consolas", max(7, tp // 5), QFont.Weight.Bold)
        p.setFont(font)
        for obj in m.objects:
            t   = obj["type"]
            if t in ("wall", "window", "invisible_wall", "thin_wall"): continue
            c, r = obj["col"], obj["row"]
            rx   = ox + c * tp
            ry   = oy + r * tp
            col  = PAL.get(t, PAL["text"])

            if t == "door":
                # Match game visual: filled rect with bevel + handle dot + label
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(col))
                p.drawRect(rx, ry, tp, tp)
                # Bevel highlight (top/left lighter, bottom/right darker)
                p.setPen(QPen(QColor(180, 140, 70), 2))
                p.drawLine(rx+1, ry+1, rx+tp-1, ry+1)
                p.drawLine(rx+1, ry+1, rx+1, ry+tp-1)
                p.setPen(QPen(QColor(50, 35, 10), 2))
                p.drawLine(rx+1, ry+tp-1, rx+tp-1, ry+tp-1)
                p.drawLine(rx+tp-1, ry+1, rx+tp-1, ry+tp-1)
                # Small knob
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(QColor(255, 200, 80)))
                p.drawEllipse(rx+tp-7, ry+tp//2-2, 4, 4)

            elif t == "crashdoor":
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(col))
                p.drawRect(rx, ry, tp, tp)
                p.setPen(QPen(QColor(220, 80, 40), 3))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawRect(rx+1, ry+1, tp-2, tp-2)
                # X mark on top
                p.drawLine(rx+4, ry+4, rx+tp-4, ry+tp-4)
                p.drawLine(rx+tp-4, ry+4, rx+4, ry+tp-4)

            elif t == "noisemaker":
                cx2 = rx + tp//2; cy2 = ry + tp//2; cr = max(4, tp//3)
                glow = QRadialGradient(cx2, cy2, cr)
                glow.setColorAt(0, QColor(220, 120, 255, 200))
                glow.setColorAt(1, QColor(180, 60, 220, 0))
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(glow))
                p.drawEllipse(cx2-cr, cy2-cr, cr*2, cr*2)
                p.setPen(QPen(QColor(220, 80, 255), 2))
                p.setBrush(QBrush(col))
                p.drawEllipse(cx2-cr+3, cy2-cr+3, (cr-3)*2, (cr-3)*2)

            elif t == "main_loot":
                cx2 = rx + tp//2; cy2 = ry + tp//2; cr = max(5, tp//3)
                glow = QRadialGradient(cx2, cy2, cr)
                glow.setColorAt(0, QColor(255, 160, 60, 200))
                glow.setColorAt(1, QColor(255, 80,  20,   0))
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(glow))
                p.drawEllipse(cx2-cr, cy2-cr, cr*2, cr*2)
                p.setPen(QPen(QColor(255, 200, 80), 2))
                p.setBrush(QBrush(col))
                p.drawEllipse(cx2-cr+3, cy2-cr+3, (cr-3)*2, (cr-3)*2)

            elif t == "hide":
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(QColor(col.red(), col.green(), col.blue(), 80)))
                p.drawRect(rx, ry, tp, tp)
                p.setPen(QPen(col, 2))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawRect(rx + 1, ry + 1, tp - 2, tp - 2)

            elif t == "guard":
                cx2 = rx + tp//2; cy2 = ry + tp//2; cr = max(4, tp // 3)
                p.setPen(QPen(QColor(180, 120, 10), 2))
                p.setBrush(QBrush(col))
                p.drawEllipse(cx2 - cr, cy2 - cr, cr*2, cr*2)
                if obj is self.selected_guard:
                    p.setPen(QPen(PAL["select"], 3))
                    p.setBrush(Qt.BrushStyle.NoBrush)
                    p.drawEllipse(cx2 - cr - 3, cy2 - cr - 3, (cr+3)*2, (cr+3)*2)

            elif t in ("player", "player2", "exit", "loot"):
                cx2 = rx + tp//2; cy2 = ry + tp//2; cr = max(4, tp // 3)
                p.setPen(QPen(QColor(255,255,255,80), 2))
                p.setBrush(QBrush(col))
                p.drawEllipse(cx2 - cr, cy2 - cr, cr*2, cr*2)

            elif t == "mini_loot":
                # Distinct small coin — use .lev renderer if available
                if not _draw_lev_tile(p, "mini_loot", rx, ry, tp, obj,
                                      level_stem=self.level_stem):
                    # Fallback: smaller golden coin
                    cx2 = rx + tp//2; cy2 = ry + tp//2
                    cr  = max(3, tp // 4)
                    p.setPen(QPen(QColor(255, 220, 80), max(1, tp//16)))
                    p.setBrush(QBrush(col))
                    p.drawEllipse(cx2 - cr, cy2 - cr, cr*2, cr*2)
                    inner = max(1, cr - max(1, tp//16))
                    p.setPen(QPen(QColor(255, 245, 140, 100), 1))
                    p.setBrush(Qt.BrushStyle.NoBrush)
                    p.drawEllipse(cx2 - inner, cy2 - inner, inner*2, inner*2)
                    if tp >= 20:
                        p.setPen(QPen(QColor(255, 255, 200)))
                        p.setFont(QFont("Consolas", max(5, tp // 6), QFont.Weight.Bold))
                        p.drawText(rx, ry, tp, tp, Qt.AlignmentFlag.AlignCenter, "¢")

            elif t == "oiled_door":
                # Match game: looks like regular door with green dot (silent indicator)
                door_col = PAL["door"]
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(door_col))
                p.drawRect(rx, ry, tp, tp)
                # Bevel
                p.setPen(QPen(QColor(180, 140, 70), 2))
                p.drawLine(rx+1, ry+1, rx+tp-1, ry+1)
                p.drawLine(rx+1, ry+1, rx+1, ry+tp-1)
                p.setPen(QPen(QColor(50, 35, 10), 2))
                p.drawLine(rx+1, ry+tp-1, rx+tp-1, ry+tp-1)
                p.drawLine(rx+tp-1, ry+1, rx+tp-1, ry+tp-1)
                # Green oiled dot
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(QColor(80, 220, 100)))
                p.drawEllipse(rx+tp-8, ry+3, 5, 5)

            elif t == "wall_door":
                # Full wall visual when closed (that's the point – hidden door)
                # Use the same bevel/line style as the wall block
                wall_col = PAL["wall"]
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(wall_col))
                p.drawRect(rx, ry, tp, tp)
                p.setPen(QPen(QColor(70, 95, 155), 2))
                p.drawLine(rx, ry, rx+tp, ry)
                p.drawLine(rx, ry, rx, ry+tp)
                p.setPen(QPen(QColor(20, 28, 52), 1))
                p.drawLine(rx+tp, ry, rx+tp, ry+tp)
                p.drawLine(rx, ry+tp, rx+tp, ry+tp)
                # Tiny purple dot in corner – editor-only hint (invisible in game)
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(QColor(160, 120, 220, 180)))
                p.drawEllipse(rx+tp-6, ry+2, 4, 4)

            elif t == "fence":
                # Match game exactly: floor bg + border + vertical slats + mid rail
                p.fillRect(rx, ry, tp, tp, PAL["floor"])
                slat_w = max(1, tp//14)
                p.setPen(QPen(col, slat_w))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawRect(rx+1, ry+1, tp-2, tp-2)
                slat_gap = max(4, tp // 5)
                for xi in range(rx + slat_gap//2, rx+tp, slat_gap):
                    p.drawLine(xi, ry+2, xi, ry+tp-2)
                # Middle horizontal rail
                p.setPen(QPen(col, max(1, tp//16)))
                p.drawLine(rx+2, ry+tp//2, rx+tp-2, ry+tp//2)

            elif t == "pit":
                # Match game: very dark void + diagonal hash
                p.fillRect(rx, ry, tp, tp, col)
                p.setPen(QPen(QColor(20, 25, 50, 140), 1))
                for xi in range(0, tp*2, 8):
                    p.drawLine(rx+xi-tp, ry, rx+xi, ry+tp)
                # "void" circle in center
                p.setPen(QPen(QColor(30, 35, 65), 1))
                p.setBrush(QBrush(QColor(8, 10, 22)))
                cr2 = max(3, tp//5)
                p.drawEllipse(rx+tp//2-cr2, ry+tp//2-cr2, cr2*2, cr2*2)

            elif t == "creak_floor":
                # Very faint ghost so designer can place it, communicates "invisible in-game"
                ghost = QColor(col.red(), col.green(), col.blue(), 25)
                p.fillRect(rx, ry, tp, tp, ghost)
                p.setPen(QPen(QColor(col.red(), col.green(), col.blue(), 70), 1, Qt.PenStyle.DashLine))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawRect(rx+2, ry+2, tp-4, tp-4)
                # Faint wavy line (designer hint)
                p.setPen(QPen(QColor(col.red(), col.green(), col.blue(), 90), max(1, tp//20)))
                cx2 = rx + tp//2; cy2 = ry + tp//2
                pts_w = []
                for xi in range(rx+4, rx+tp-3, 2):
                    yi = cy2 + int(math.sin((xi - rx) * 0.5) * max(2, tp//12))
                    pts_w.append(QPoint(xi, yi))
                for i in range(len(pts_w)-1):
                    p.drawLine(pts_w[i], pts_w[i+1])

            elif t == "snitch":
                # Match game: amber circle with FOV cone and "S" label
                cx2 = rx + tp//2; cy2 = ry + tp//2; cr = max(4, tp // 3)
                # FOV cone (pointing up = default facing)
                fov_half = max(cr, cr + 2)
                tri = QPolygon([QPoint(cx2, cy2),
                                QPoint(cx2 - fov_half, ry + 2),
                                QPoint(cx2 + fov_half, ry + 2)])
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(QColor(255, 200, 70, 55)))
                p.drawPolygon(tri)
                # Body circle
                p.setPen(QPen(QColor(160, 100, 10), 2))
                p.setBrush(QBrush(col))
                p.drawEllipse(cx2 - cr, cy2 - cr, cr*2, cr*2)
                p.setPen(QPen(QColor(255, 255, 255), 1))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawEllipse(cx2 - cr, cy2 - cr, cr*2, cr*2)

            elif t == "camera":
                # Match game: teal body + lens + sweep cone
                cx2 = rx + tp//2; cy2 = ry + tp//2
                # Sweep arc (pointing up – default facing)
                sweep_r = max(tp//2, tp//2 + 4)
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(QColor(140, 200, 70, 50)))
                p.drawPie(cx2-sweep_r, ry-sweep_r//2, sweep_r*2, sweep_r*2, 45*16, 90*16)
                # Camera body (horizontal rect)
                bw = max(4, tp//2); bh = max(3, tp//3)
                p.setPen(QPen(QColor(80, 160, 40), 2))
                p.setBrush(QBrush(col))
                p.drawRect(rx + tp//4, cy2 - bh//2, bw, bh)
                # Lens circle (dark inner)
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(QColor(10, 20, 8)))
                p.drawEllipse(rx + tp//4 + bw - 5, cy2 - 3, 6, 6)
                # Lens highlight
                p.setPen(QPen(col.lighter(160), 1))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawEllipse(rx + tp//4 + bw - 5, cy2 - 3, 6, 6)

            # label – skip for tile types that draw their own text via .lev
            _LEV_TEXT_TILES = {"mini_loot", "thin_door"}
            if tp >= 20 and t not in _LEV_TEXT_TILES:
                p.setPen(QPen(Qt.GlobalColor.white))
                p.drawText(rx, ry, tp, tp, Qt.AlignmentFlag.AlignCenter,
                           TILE_ICONS.get(t, t[0].upper()))

            # Teal corner dot – door is part of a linked pair (exactly 2 adjacent same-type)
            if t in _linked and (obj["col"], obj["row"]) in _linked[t]:
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(QColor(60, 200, 200)))
                dot_r = max(3, tp // 7)
                p.drawEllipse(rx + 2, ry + 2, dot_r, dot_r)

        # Grid
        if self.show_grid:
            minor = QPen(PAL["grid"], 1, Qt.PenStyle.SolidLine)
            major = QPen(PAL["grid_major"], 1, Qt.PenStyle.SolidLine)
            for c in range(m.cols + 1):
                pen = major if c % 4 == 0 else minor
                p.setPen(pen)
                x = ox + c * tp
                p.drawLine(x, oy, x, oy + H)
            for r in range(m.rows + 1):
                pen = major if r % 4 == 0 else minor
                p.setPen(pen)
                y = oy + r * tp
                p.drawLine(ox, y, ox + W, y)

        # Level border
        p.setPen(QPen(PAL["accent"], 2))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRect(ox, oy, W, H)

        # ── IO Connection wires ───────────────────────────────────────────
        if m.connections:
            sig_col  = QColor(80, 220, 255, 200)   # output signal colour
            slot_col = QColor(255, 160, 60,  200)   # input slot colour
            wire_col = QColor(140, 255, 180, 160)   # wire colour
            for conn in m.connections:
                fc, fr = conn.get("from_col", -1), conn.get("from_row", -1)
                tc2, tr = conn.get("to_col", -1),  conn.get("to_row", -1)
                if fc < 0 or tc2 < 0: continue
                fx = ox + fc * tp + tp // 2
                fy = oy + fr * tp + tp // 2
                tx2 = ox + tc2 * tp + tp // 2
                ty2 = oy + tr * tp + tp // 2
                # bezier-ish: draw as two lines via midpoint offset
                mid_x = (fx + tx2) // 2
                mid_y = (fy + ty2) // 2
                p.setPen(QPen(wire_col, 2, Qt.PenStyle.DashLine))
                p.drawLine(fx, fy, tx2, ty2)
                # signal dot at source
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(sig_col))
                p.drawEllipse(fx - 5, fy - 5, 10, 10)
                # slot dot at target
                p.setBrush(QBrush(slot_col))
                p.drawEllipse(tx2 - 5, ty2 - 5, 10, 10)
                # label midpoint
                if tp > 20:
                    p.setPen(QPen(wire_col))
                    p.setFont(QFont("Consolas", max(7, tp // 7)))
                    lbl = f"{conn.get('from_signal','')}→{conn.get('to_slot','')}"
                    p.drawText(mid_x - 40, mid_y - 8, 80, 16,
                               Qt.AlignmentFlag.AlignCenter, lbl)

        # Connection mode: highlight wiring source
        if getattr(self, "conn_mode", False) and getattr(self, "_conn_src", None):
            sc2, sr = self._conn_src
            src_r = self.tile_rect(sc2, sr)
            p.setPen(QPen(QColor(80, 220, 255), 3))
            p.setBrush(QBrush(QColor(80, 220, 255, 40)))
            p.drawRect(src_r)
            # draw pending wire to hover
            hc2, hr2 = self._hover
            if 0 <= hc2 < m.cols and 0 <= hr2 < m.rows:
                sx2 = src_r.center().x(); sy2 = src_r.center().y()
                hr_r = self.tile_rect(hc2, hr2)
                tx3 = hr_r.center().x(); ty3 = hr_r.center().y()
                p.setPen(QPen(QColor(140, 255, 180, 120), 2, Qt.PenStyle.DotLine))
                p.drawLine(sx2, sy2, tx3, ty3)

        # Hover highlight
        hc, hr = self._hover
        if 0 <= hc < m.cols and 0 <= hr < m.rows:
            hr_rect = self.tile_rect(hc, hr)
            p.setPen(QPen(PAL["select"], 2))
            p.setBrush(QBrush(QColor(100, 180, 255, 30)))
            p.drawRect(hr_rect)

        # Selected tiles (SELECT tool)
        if self._selected:
            p.setPen(QPen(PAL["select"], 2, Qt.PenStyle.DashLine))
            p.setBrush(QBrush(QColor(100, 180, 255, 45)))
            for (sc, sr) in self._selected:
                r = self.tile_rect(sc, sr)
                p.drawRect(r)

        # Drag selection rectangle
        if self._dragging_select and self._sel_rect:
            col0 = max(0, self._sel_rect.left())
            row0 = max(0, self._sel_rect.top())
            col1 = min(m.cols-1, self._sel_rect.right())
            row1 = min(m.rows-1, self._sel_rect.bottom())
            if col0 <= col1 and row0 <= row1:
                sx = ox + col0 * tp; sy = oy + row0 * tp
                sw = (col1 - col0 + 1) * tp; sh = (row1 - row0 + 1) * tp
                p.setPen(QPen(PAL["select"], 2, Qt.PenStyle.DashLine))
                p.setBrush(QBrush(QColor(100, 180, 255, 25)))
                p.drawRect(sx, sy, sw, sh)

        # WP mode indicator
        if self.wp_mode:
            p.setPen(QPen(PAL["waypoint"], 2))
            p.setFont(QFont("Consolas", 12, QFont.Weight.Bold))
            p.drawText(10, 20, "WAYPOINT MODE – click to place, press W or click button to finish")

        # Connection mode indicator
        if self.conn_mode:
            hint = ("CONNECT – click source tile, then destination tile  |  RMB or Esc = cancel")
            if self._conn_src:
                hint = f"CONNECT from ({self._conn_src[0]},{self._conn_src[1]}) – click destination tile  |  RMB = cancel"
            p.setPen(QPen(QColor(80, 220, 255), 2))
            p.setFont(QFont("Consolas", 11, QFont.Weight.Bold))
            p.drawText(10, 20, hint)

        # Select mode tip
        if self.current_tool == "select" and not self._selected:
            p.setPen(QPen(PAL["select"], 1))
            p.setFont(QFont("Consolas", 11))
            p.drawText(10, self.height() - 10, "SELECT: drag to select  |  dbl-click = edit props  |  Del = erase selected")

        # Edge tool hint + hover snap line
        if self.current_tool in ("edge_wall", "edge_door"):
            hint_col = PAL["edge_wall"] if self.current_tool == "edge_wall" else PAL["edge_door"]
            p.setPen(QPen(hint_col, 1))
            p.setFont(QFont("Consolas", 11))
            p.drawText(10, self.height() - 10,
                       "EDGE TOOL: click grid line to place  |  Shift+drag = erase  |  RMB = context menu")
            # Show snap preview — find nearest edge to current cursor
            cursor_pos = self.mapFromGlobal(self.cursor().pos())
            edge_snap = self._canvas_to_edge(cursor_pos.x(), cursor_pos.y())
            if edge_snap:
                ec, er, es = edge_snap
                if es == "N":
                    sx1, sy1 = ox + ec*tp, oy + er*tp
                    sx2, sy2 = sx1 + tp, sy1
                elif es == "S":
                    sx1, sy1 = ox + ec*tp, oy + (er+1)*tp
                    sx2, sy2 = sx1 + tp, sy1
                elif es == "W":
                    sx1, sy1 = ox + ec*tp, oy + er*tp
                    sx2, sy2 = sx1, sy1 + tp
                else:
                    sx1, sy1 = ox + (ec+1)*tp, oy + er*tp
                    sx2, sy2 = sx1, sy1 + tp
                snap_pen = QPen(hint_col, max(3, tp//10), Qt.PenStyle.DotLine,
                                Qt.PenCapStyle.RoundCap)
                p.setPen(snap_pen)
                p.drawLine(sx1, sy1, sx2, sy2)

        # Region tool hint
        if self.current_tool in ("region", "region_inbetween",
                                 "region_inbetween_doorway"):
            if self.current_tool == "region":
                hint_col = PAL["region"]
                rid = getattr(self, "_active_region_id", 1)
                hint_txt = (f"REGION TOOL: painting region {rid}  |  "
                            "Edit > Set Region ID to switch  |  Shift+drag = erase")
            elif self.current_tool == "region_inbetween":
                hint_col = PAL["region_inbetween"]
                hint_txt = ("INBETWEEN TOOL: paint connector corridor tiles  |  "
                            "Lights both bordering regions when player is near  |  "
                            "Shift+drag = erase")
            else:
                hint_col = PAL["region_inbetween_doorway"]
                hint_txt = ("DOORWAY TOOL: paint LOS-aware connector tiles  |  "
                            "Open door/crashdoor etc → far region lit; closed → dark  |  "
                            "Shift+drag = erase")
            p.setPen(QPen(hint_col, 1))
            p.setFont(QFont("Consolas", 11))
            p.drawText(10, self.height() - 10, hint_txt)

        # AI hint tool hint
        if self.current_tool in ("ai_coverhint", "ai_chokehint", "ai_avoidhint"):
            _hint_texts = {
                "ai_coverhint":  "COVER HINT: paint tiles NPCs prefer as combat cover  |  Shift+drag = erase",
                "ai_chokehint":  "CHOKE HINT: paint zone NPCs coordinate to block the player from  |  Shift+drag = erase",
                "ai_avoidhint":  "AVOID HINT: paint tiles guards route around during patrol  |  Shift+drag = erase",
            }
            hint_col2 = PAL.get(self.current_tool, PAL["text"])
            p.setPen(QPen(hint_col2, 1))
            p.setFont(QFont("Consolas", 11))
            p.drawText(10, self.height() - 10, _hint_texts[self.current_tool])

    # ── mouse ────────────────────────────────────────────────────────────────
    def _hit_wp_node(self, px, py, guard_obj):
        """Return index of waypoint node hit at canvas pixel (px,py), or -1."""
        if guard_obj is None:
            return -1
        nodes = guard_obj.get("wp_nodes") or []
        tp  = self.tile_px()
        ox  = self.offset.x(); oy = self.offset.y()
        r2  = max(6, tp // 6)
        for i, node in enumerate(nodes):
            cx2 = ox + node["col"]*tp + tp//2
            cy2 = oy + node["row"]*tp + tp//2
            if (px - cx2)**2 + (py - cy2)**2 <= r2**2:
                return i
        return -1

    def _canvas_to_edge(self, px, py):
        """Snap canvas pixel to nearest grid edge.
        Returns (col, row, side) where side is 'N' or 'W' (canonical),
        or None if not close to an edge."""
        tp  = self.tile_px()
        ox  = self.offset.x(); oy = self.offset.y()
        thresh = max(4, tp // 5)

        # Position relative to grid
        rx = px - ox
        ry = py - oy

        # Find nearest horizontal and vertical grid lines
        col_f = rx / tp
        row_f = ry / tp

        col = int(col_f)
        row = int(row_f)

        # Distance to nearest vertical line (W edge of col+1 or E of col)
        near_v_col = round(col_f)
        dist_v = abs(rx - near_v_col * tp)

        # Distance to nearest horizontal line (N edge of row+1 or S of row)
        near_h_row = round(row_f)
        dist_h = abs(ry - near_h_row * tp)

        m = self.model

        if dist_v < dist_h and dist_v < thresh:
            # Snapped to a vertical line → W edge of near_v_col
            c = near_v_col
            r = int(row_f)
            r = max(0, min(m.rows - 1, r))
            c = max(0, min(m.cols, c))
            # Allow border (c==0 or c==m.cols) but not outside
            if c < 0 or c > m.cols: return None
            return (c, r, "W")
        elif dist_h < thresh:
            # Snapped to a horizontal line → N edge of near_h_row
            c = int(col_f)
            r = near_h_row
            c = max(0, min(m.cols - 1, c))
            r = max(0, min(m.rows, r))
            # Allow border (r==0 or r==m.rows) but not outside
            if r < 0 or r > m.rows: return None
            return (c, r, "N")
        return None

    # Region id state
    _active_region_id = 1

    def _place_edge(self, px, py, tool):
        """Place an edge_wall or edge_door at the nearest grid edge."""
        edge = self._canvas_to_edge(px, py)
        if edge is None: return
        col, row, side = edge
        m = self.model
        # Remove any existing edge object at same position
        m.objects = [o for o in m.objects
                     if not (o.get("side") == side and
                             o.get("col") == col and
                             o.get("row") == row and
                             o.get("type") in ("edge_wall", "edge_door"))]
        obj = {"type": tool, "col": col, "row": row, "side": side}
        if tool == "edge_door":
            obj["open"] = False
        m.objects.append(obj)
        self.update()

    def _erase_edge(self, px, py):
        """Remove edge wall/door at nearest grid edge."""
        edge = self._canvas_to_edge(px, py)
        if edge is None: return
        col, row, side = edge
        m = self.model
        m.objects = [o for o in m.objects
                     if not (o.get("side") == side and
                             o.get("col") == col and
                             o.get("row") == row and
                             o.get("type") in ("edge_wall", "edge_door"))]

    def _edge_snap_to_canvas_px(self, edge_snap):
        """Convert (col, row, side) snap back to a canvas pixel at edge center."""
        col, row, side = edge_snap
        tp = self.tile_px()
        ox = self.offset.x(); oy = self.offset.y()
        if side == "N":
            px = ox + col * tp + tp // 2
            py = oy + row * tp
        elif side == "S":
            px = ox + col * tp + tp // 2
            py = oy + (row + 1) * tp
        elif side == "W":
            px = ox + col * tp
            py = oy + row * tp + tp // 2
        else:  # E
            px = ox + (col + 1) * tp
            py = oy + row * tp + tp // 2
        return px, py
        self.update()

    def mousePressEvent(self, e):
        btn = e.button()
        pos = e.position().toPoint()
        col, row = self.canvas_to_tile(pos.x(), pos.y())
        shift = bool(e.modifiers() & Qt.KeyboardModifier.ShiftModifier)

        if btn == Qt.MouseButton.MiddleButton:
            self._pan_last = pos
            self._panning  = True
            return

        # ── Right-click → context menu (never erase) ──────────────────────
        if btn == Qt.MouseButton.RightButton:
            # In special modes, RMB still cancels/erases wp nodes or connections
            if self.conn_mode:
                self._conn_src = None
                self.conn_mode = False
                self.update()
                return
            if self.wp_mode and self.selected_guard:
                hit = self._hit_wp_node(pos.x(), pos.y(), self.selected_guard)
                if hit > 0:
                    self.model.remove_waypoint(self.selected_guard, hit)
                    if self.selected_wp_idx >= hit:
                        self.selected_wp_idx = max(-1, self.selected_wp_idx - 1)
                    self.wp_node_clicked.emit(self.selected_wp_idx)
                    self.update()
                return
            # Normal: emit context menu signal for EditorWindow to handle
            if 0 <= col < self.model.cols and 0 <= row < self.model.rows:
                self.context_menu_requested.emit(col, row, e.globalPosition().toPoint())
            else:
                # Maybe an edge context menu?
                self.context_menu_requested.emit(col, row, e.globalPosition().toPoint())
            return

        # ── Edge tools ───────────────────────────────────────────────────
        if self.current_tool in ("edge_wall", "edge_door") and not self.wp_mode:
            if btn == Qt.MouseButton.LeftButton:
                if shift:
                    self._erase_edge(pos.x(), pos.y())
                else:
                    self._place_edge(pos.x(), pos.y(), self.current_tool)
            return

        # ── Region tool ──────────────────────────────────────────────────
        if self.current_tool in ("region", "region_inbetween",
                                 "region_inbetween_doorway") and not self.wp_mode:
            if btn == Qt.MouseButton.LeftButton:
                if shift:
                    self._erase_region_tile(col, row)
                elif 0 <= col < self.model.cols and 0 <= row < self.model.rows:
                    if self.current_tool == "region":
                        self._paint_region_tile(col, row)
                    else:
                        self._paint_inbetween_tile(col, row,
                                                   self.current_tool)
            return

        # ── AI hint tile tools ────────────────────────────────────────────
        if self.current_tool in ("ai_coverhint", "ai_chokehint",
                                 "ai_avoidhint") and not self.wp_mode:
            if btn == Qt.MouseButton.LeftButton:
                if shift:
                    self._erase_ai_hint_tile(col, row, self.current_tool)
                elif 0 <= col < self.model.cols and 0 <= row < self.model.rows:
                    self._paint_ai_hint_tile(col, row, self.current_tool)
            return

        # ── Connection wiring mode ───────────────────────────────────────
        if self.conn_mode:
            if btn == Qt.MouseButton.LeftButton:
                if 0 <= col < self.model.cols and 0 <= row < self.model.rows:
                    self.conn_tile_clicked.emit(col, row)
            return

        # ── Waypoint mode ────────────────────────────────────────────────
        if self.wp_mode and self.selected_guard:
            if btn == Qt.MouseButton.LeftButton:
                wt = self.current_wp_tool

                if wt == "wp_select":
                    # Try to pick an existing node
                    hit = self._hit_wp_node(pos.x(), pos.y(), self.selected_guard)
                    if hit >= 0:
                        self.selected_wp_idx = hit
                        self._wp_dragging    = True
                        self.wp_node_clicked.emit(hit)
                    else:
                        self.selected_wp_idx = -1
                        self._wp_dragging    = False
                        self.wp_node_clicked.emit(-1)
                    self.update()
                else:
                    # Place a new node of current wp type
                    if 0 <= col < self.model.cols and 0 <= row < self.model.rows:
                        self.model.add_waypoint_to_guard(
                            self.selected_guard, col, row, wp_type=wt)
                        self.wp_node_clicked.emit(
                            len(self.selected_guard.get("wp_nodes", [])) - 1)
                        self.update()
            return

        # ── Normal tile tools ─────────────────────────────────────────────
        if btn == Qt.MouseButton.LeftButton and self.current_tool == "select" and not self.wp_mode:
            self._sel_start = pos
            self._dragging_select = True
            self._sel_rect = QRect(col, row, 1, 1)
            self._selected.clear()
            self.selection_changed.emit([])
            self.update()
            return

        if btn == Qt.MouseButton.LeftButton:
            if shift:
                # Shift+LMB = erase
                self._shift_erasing = True
                self.tile_clicked.emit(col, row, 3)
            else:
                self.tile_clicked.emit(col, row, 1)

    def _paint_region_tile(self, col, row):
        """Add tile to current numbered region."""
        rid = self._active_region_id
        m = self.model
        # Remove tile from any other region-family object
        for obj in m.objects:
            if obj.get("type") in ("region", "region_inbetween",
                                   "region_inbetween_doorway"):
                if obj.get("type") != "region" or obj.get("region_id") != rid:
                    tiles = obj.get("tiles", [])
                    obj["tiles"] = [t for t in tiles
                                    if not (t[0] == col and t[1] == row)]
        # Add to this region's obj (or create it)
        region_obj = next((o for o in m.objects
                           if o.get("type") == "region" and o.get("region_id") == rid), None)
        if region_obj is None:
            region_obj = {"type": "region", "region_id": rid, "col": 0, "row": 0, "tiles": []}
            m.objects.append(region_obj)
        tiles = region_obj.get("tiles", [])
        if not any(t[0] == col and t[1] == row for t in tiles):
            tiles.append([col, row])
        region_obj["tiles"] = tiles
        self.update()

    def _erase_region_tile(self, col, row):
        for obj in self.model.objects:
            if obj.get("type") in ("region", "region_inbetween",
                                   "region_inbetween_doorway"):
                obj["tiles"] = [t for t in obj.get("tiles", [])
                                if not (t[0] == col and t[1] == row)]
        self.update()

    _AI_HINT_TYPES = ("ai_coverhint", "ai_chokehint", "ai_avoidhint")

    def _paint_ai_hint_tile(self, col, row, hint_type):
        """Add tile to an AI hint zone (cover/choke/avoid).
        Each hint type lives in a single shared object per level.
        A tile can only belong to one AI hint type at a time.
        """
        m = self.model
        # Remove from any other ai hint object
        for obj in m.objects:
            if obj.get("type") in self._AI_HINT_TYPES:
                if obj.get("type") != hint_type:
                    obj["tiles"] = [t for t in obj.get("tiles", [])
                                    if not (t[0] == col and t[1] == row)]
        # Find or create target object
        target = next((o for o in m.objects if o.get("type") == hint_type), None)
        if target is None:
            target = {"type": hint_type, "col": 0, "row": 0, "tiles": []}
            m.objects.append(target)
        tiles = target.get("tiles", [])
        if not any(t[0] == col and t[1] == row for t in tiles):
            tiles.append([col, row])
        target["tiles"] = tiles
        self.update()

    def _erase_ai_hint_tile(self, col, row, hint_type):
        """Remove a tile from an AI hint zone."""
        for obj in self.model.objects:
            if obj.get("type") == hint_type:
                obj["tiles"] = [t for t in obj.get("tiles", [])
                                if not (t[0] == col and t[1] == row)]
        self.update()

    def _paint_inbetween_tile(self, col, row, rtype):
        """Add tile to an inbetween or doorway connector object.

        Each inbetween type lives in a single shared object per level
        (there is normally only one inbetween blob and one doorway blob,
        but the user can create multiple by manually editing the JSON).
        For simplicity the editor always paints into the *first* object of
        that type it finds, creating one if none exists.
        A tile must be removed from any existing region_inbetween /
        region_inbetween_doorway / region object before being added.
        """
        m = self.model
        # Strip the tile from any other region-family object first
        for obj in m.objects:
            if obj.get("type") in ("region", "region_inbetween",
                                   "region_inbetween_doorway"):
                obj["tiles"] = [t for t in obj.get("tiles", [])
                                if not (t[0] == col and t[1] == row)]
        # Find or create the target object
        target = next((o for o in m.objects if o.get("type") == rtype), None)
        if target is None:
            target = {"type": rtype, "col": 0, "row": 0, "tiles": []}
            m.objects.append(target)
        tiles = target.get("tiles", [])
        if not any(t[0] == col and t[1] == row for t in tiles):
            tiles.append([col, row])
        target["tiles"] = tiles
        self.update()

    def mouseDoubleClickEvent(self, e):
        pos = e.position().toPoint()
        col, row = self.canvas_to_tile(pos.x(), pos.y())

        if self.wp_mode and self.selected_guard:
            hit = self._hit_wp_node(pos.x(), pos.y(), self.selected_guard)
            if hit >= 0:
                self.selected_wp_idx = hit
                self.wp_node_dbl_click.emit(hit)
                return

        self.tile_dbl_click.emit(col, row)

    def mouseMoveEvent(self, e):
        pos = e.position().toPoint()
        if self._panning and self._pan_last:
            d = pos - self._pan_last
            self.offset += d
            self._pan_last = pos
            self.update()
            return

        col, row = self.canvas_to_tile(pos.x(), pos.y())

        # ── WP node drag ─────────────────────────────────────────────────
        if self.wp_mode and self._wp_dragging and self.selected_guard:
            idx = self.selected_wp_idx
            if idx >= 0 and e.buttons() & Qt.MouseButton.LeftButton:
                m = self.model
                nc = max(0, min(m.cols-1, col))
                nr = max(0, min(m.rows-1, row))
                self.model.move_waypoint(self.selected_guard, idx, nc, nr)
                self.wp_node_clicked.emit(idx)
                self.update()
            return

        if self._dragging_select and self._sel_start:
            sc0, sr0 = self.canvas_to_tile(self._sel_start.x(), self._sel_start.y())
            c0 = min(sc0, col); r0 = min(sr0, row)
            c1 = max(sc0, col); r1 = max(sr0, row)
            self._sel_rect = QRect(c0, r0, c1-c0+1, r1-r0+1)
            self.update()
            return

        if e.buttons() & Qt.MouseButton.LeftButton:
            shift = bool(e.modifiers() & Qt.KeyboardModifier.ShiftModifier)
            is_erase = shift or self._shift_erasing
            if self.current_tool in ("edge_wall", "edge_door") and not self.wp_mode:
                if is_erase:
                    self._erase_edge(pos.x(), pos.y())
                else:
                    self._place_edge(pos.x(), pos.y(), self.current_tool)
            elif self.current_tool in ("region", "region_inbetween",
                                       "region_inbetween_doorway") and not self.wp_mode:
                if is_erase:
                    self._erase_region_tile(col, row)
                elif 0 <= col < self.model.cols and 0 <= row < self.model.rows:
                    if self.current_tool == "region":
                        self._paint_region_tile(col, row)
                    else:
                        self._paint_inbetween_tile(col, row,
                                                   self.current_tool)
            elif self.current_tool in ("ai_coverhint", "ai_chokehint",
                                       "ai_avoidhint") and not self.wp_mode:
                if is_erase:
                    self._erase_ai_hint_tile(col, row, self.current_tool)
                elif 0 <= col < self.model.cols and 0 <= row < self.model.rows:
                    self._paint_ai_hint_tile(col, row, self.current_tool)
            elif self.current_tool != "select" and not self.wp_mode:
                btn = 3 if is_erase else 1
                self.tile_clicked.emit(col, row, btn)

        self._hover = (col, row)
        m = self.model
        if 0 <= col < m.cols and 0 <= row < m.rows:
            objs = m.objects_at(col, row)
            info = ", ".join(o["type"] for o in objs) if objs else "empty"
            self.status_update.emit(
                f"  Col {col}, Row {row}  [{info}]  |  ({col*m.tile_size},{row*m.tile_size})px")
        self.update()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.MouseButton.MiddleButton:
            self._panning  = False
            self._pan_last = None
            return

        if e.button() == Qt.MouseButton.LeftButton:
            self._shift_erasing = False
            if self._wp_dragging:
                self._wp_dragging = False
                return
            if self._dragging_select:
                self._dragging_select = False
                m = self.model
                if self._sel_rect:
                    new_sel = set()
                    for c in range(self._sel_rect.left(), self._sel_rect.right()):
                        for r in range(self._sel_rect.top(), self._sel_rect.bottom()):
                            if 0 <= c < m.cols and 0 <= r < m.rows:
                                new_sel.add((c, r))
                    self._selected = new_sel
                    self.selection_changed.emit(list(new_sel))
                self.update()
            else:
                # End of a paint stroke — commit to undo stack
                self.stroke_ended.emit()

    def wheelEvent(self, e):
        delta = e.angleDelta().y()
        factor = 1.12 if delta > 0 else 1 / 1.12
        pos = e.position().toPoint()
        old_zoom = self.zoom
        self.zoom = max(0.15, min(4.0, self.zoom * factor))
        scale = self.zoom / old_zoom
        self.offset = QPoint(
            int(pos.x() - scale * (pos.x() - self.offset.x())),
            int(pos.y() - scale * (pos.y() - self.offset.y())),
        )
        self.update()

    def keyPressEvent(self, e):
        key = e.key()

        # ── Arrow key nudge ──────────────────────────────────────────────
        arrow_map = {
            Qt.Key.Key_Left:  (-1,  0),
            Qt.Key.Key_Right: ( 1,  0),
            Qt.Key.Key_Up:    ( 0, -1),
            Qt.Key.Key_Down:  ( 0,  1),
        }
        if key in arrow_map:
            dx, dy = arrow_map[key]

            if self.wp_mode and self.selected_guard and self.selected_wp_idx >= 0:
                # Nudge selected waypoint node
                nodes = self.model._ensure_wp_nodes(self.selected_guard)
                idx = self.selected_wp_idx
                if 0 <= idx < len(nodes):
                    nc = max(0, min(self.model.cols-1, nodes[idx]["col"] + dx))
                    nr = max(0, min(self.model.rows-1, nodes[idx]["row"] + dy))
                    self.model.move_waypoint(self.selected_guard, idx, nc, nr)
                    self.update()
                    self.wp_node_clicked.emit(idx)
                e.accept(); return

            elif self._selected and self.current_tool == "select":
                # Nudge all selected tiles
                m = self.model
                # Collect objects in selected tiles
                objs_to_move = []
                for (sc, sr) in self._selected:
                    for o in m.objects_at(sc, sr):
                        objs_to_move.append(o)

                # Check bounds
                for o in objs_to_move:
                    nc = o["col"] + dx; nr = o["row"] + dy
                    if nc < 0 or nr < 0 or nc >= m.cols or nr >= m.rows:
                        e.accept(); return   # would go out of bounds

                # Move: remove from old, update positions, targets are vacated first
                new_positions = {(o["col"]+dx, o["row"]+dy) for o in objs_to_move}
                old_positions = {(o["col"], o["row"]) for o in objs_to_move}
                # Remove objects at destination that aren't being moved
                for (nc, nr) in new_positions - old_positions:
                    m.remove_at(nc, nr)

                # Update object positions
                for o in objs_to_move:
                    o["col"] += dx; o["row"] += dy

                # Update selection
                self._selected = {(c+dx, r+dy) for (c,r) in self._selected}
                self.selection_nudged.emit(dx, dy)
                self.update()
                e.accept(); return

        if key == Qt.Key.Key_G:
            self.show_grid = not self.show_grid; self.update()
        elif key == Qt.Key.Key_F:
            self.fit()
        elif key == Qt.Key.Key_Z and e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            e.ignore(); return   # let EditorWindow handle Ctrl+Z
        elif key == Qt.Key.Key_Y and e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            e.ignore(); return   # let EditorWindow handle Ctrl+Y
        elif key == Qt.Key.Key_Space:
            self._panning = True
        elif key == Qt.Key.Key_W and self.wp_mode:
            self.wp_mode = False; self.update()
        elif key == Qt.Key.Key_Delete:
            if self.wp_mode and self.selected_guard and self.selected_wp_idx > 0:
                self.model.remove_waypoint(self.selected_guard, self.selected_wp_idx)
                self.selected_wp_idx = -1
                self.wp_node_clicked.emit(-1)
                self.update()
            elif self._selected:
                self.stroke_ended.emit()   # commit any pending stroke first
                for (c, r) in self._selected:
                    self.model.remove_at(c, r)
                self._selected.clear()
                self.selection_changed.emit([])
                self.update()
        elif (key == Qt.Key.Key_Return and
              e.modifiers() & Qt.KeyboardModifier.AltModifier):
            if self.wp_mode and self.selected_wp_idx >= 0:
                self.wp_node_dbl_click.emit(self.selected_wp_idx)
            else:
                hc, hr = self._hover
                self.tile_dbl_click.emit(hc, hr)
        e.accept()

    def keyReleaseEvent(self, e):
        if e.key() == Qt.Key.Key_Space:
            self._panning = False
            self._pan_last = None


# ════════════════════════════════════════════════════════════════════════════
# Side panel
# ════════════════════════════════════════════════════════════════════════════
def make_group(title):
    g = QGroupBox(title)
    g.setStyleSheet("""
        QGroupBox { color: #8090b0; font: bold 11px Consolas;
                    border: 1px solid #3a3e4a; border-radius: 4px;
                    margin-top: 8px; padding-top: 4px; }
        QGroupBox::title { subcontrol-origin: margin; left: 8px; }
    """)
    return g


def styled_button(text, color="#5880c8", hover="#6898e8"):
    b = QPushButton(text)
    b.setStyleSheet(f"""
        QPushButton {{
            background: {color}; color: #fff;
            border: none; border-radius: 3px;
            padding: 5px 10px; font: bold 11px Consolas;
        }}
        QPushButton:hover {{ background: {hover}; }}
        QPushButton:pressed {{ background: #405090; }}
        QPushButton:disabled {{ background: #444; color: #888; }}
    """)
    return b



# ════════════════════════════════════════════════════════════════════════════
# TimerNodeDialog – edit a single off-tile timer node
# ════════════════════════════════════════════════════════════════════════════
class TimerNodeDialog(QDialog):
    """Edit one timer_node dict. Returns the edited dict via result()."""

    _STYLE = """
        QDialog { background: #1a1c24; color: #c8d4e8; font: 12px Consolas; }
        QLabel  { color: #a0a8c0; }
        QGroupBox { color: #7080a0; font: bold 11px Consolas;
                    border: 1px solid #3a3e4a; border-radius: 4px;
                    margin-top:8px; padding-top:4px; }
        QGroupBox::title { subcontrol-origin:margin; left:8px; }
        QSpinBox, QDoubleSpinBox, QLineEdit, QCheckBox, QComboBox {
            background: #12141c; color: #c8d0e0;
            border: 1px solid #3a4060; border-radius:3px;
            padding:3px 6px; font:11px Consolas; }
        QPushButton { background:#3a5080; color:#fff; border:none;
                      border-radius:3px; padding:5px 14px; font:bold 11px Consolas; }
        QPushButton:hover { background:#4a68a0; }
    """

    def __init__(self, data=None, parent=None):
        super().__init__(parent)
        self._data = dict(data) if data else {}
        self.setWindowTitle("Timer Node")
        self.setMinimumWidth(340)
        self.setStyleSheet(self._STYLE)
        self._build()

    def _build(self):
        vbox = QVBoxLayout(self)
        grp = QGroupBox("Timer Node Properties")
        form = QFormLayout(grp)
        form.setSpacing(6)

        self._label = QLineEdit(self._data.get("label", "Timer"))
        form.addRow("Label:", self._label)

        self._channel = QSpinBox()
        self._channel.setRange(0, 255)
        self._channel.setValue(self._data.get("channel", 1))
        self._channel.setToolTip("IO channel to fire. Must match a Receive Node's channel.")
        form.addRow("Channel:", self._channel)

        self._interval = QDoubleSpinBox()
        self._interval.setRange(0.1, 3600.0)
        self._interval.setSingleStep(0.5)
        self._interval.setDecimals(2)
        self._interval.setSuffix(" s")
        self._interval.setValue(self._data.get("interval", 5.0))
        self._interval.setToolTip("Seconds between channel fires.")
        form.addRow("Interval:", self._interval)

        self._delay = QDoubleSpinBox()
        self._delay.setRange(0.0, 3600.0)
        self._delay.setSingleStep(0.5)
        self._delay.setDecimals(2)
        self._delay.setSuffix(" s")
        self._delay.setValue(self._data.get("delay", 0.0))
        self._delay.setToolTip("Initial delay before first fire.")
        form.addRow("Initial delay:", self._delay)

        self._one_shot = QCheckBox()
        self._one_shot.setChecked(self._data.get("one_shot", False))
        self._one_shot.setToolTip("Fire once then stop.")
        form.addRow("One-shot:", self._one_shot)

        self._active = QCheckBox()
        self._active.setChecked(self._data.get("active", True))
        self._active.setToolTip("Uncheck to start the timer paused.")
        form.addRow("Initially active:", self._active)

        info = QLabel(
            "Timer fires channel on a repeating schedule.\n"
            "Pair with a Receive Node on a door/camera/etc.\n"
            "Channel 0 = fires nothing."
        )
        info.setStyleSheet("color:#5878a0; font:10px Consolas;")
        info.setWordWrap(True)
        form.addRow("", info)

        vbox.addWidget(grp)
        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(self._accept)
        btns.rejected.connect(self.reject)
        vbox.addWidget(btns)

    def _accept(self):
        self._data["label"]    = self._label.text().strip() or "Timer"
        self._data["channel"]  = self._channel.value()
        self._data["interval"] = round(self._interval.value(), 2)
        self._data["delay"]    = round(self._delay.value(), 2)
        self._data["one_shot"] = self._one_shot.isChecked()
        self._data["active"]   = self._active.isChecked()
        self.accept()

    def result(self):
        return dict(self._data)


# ════════════════════════════════════════════════════════════════════════════
# RoomPropertiesDialog – per-level flags (Is shop?, etc.)
# ════════════════════════════════════════════════════════════════════════════
class RoomPropertiesDialog(QDialog):
    """
    Dialog for editing room-level properties.

    Currently exposes:
      • Is shop? (checkbox) – enables the SHOP toolbar tab with
        buy_item and shop_leave tiles.

    More properties can be added here without changing the level format
    (they are stored in LevelModel.room_props).
    """

    _SS = """
        QDialog { background: #1c1e26; color: #c0c8d8; }
        QLabel  { color: #c0c8d8; }
        QCheckBox { color: #c0c8d8; spacing: 8px; }
        QCheckBox::indicator { width: 16px; height: 16px; }
        QCheckBox::indicator:unchecked { border: 1px solid #506080; background: #22242e; border-radius: 3px; }
        QCheckBox::indicator:checked   { border: 1px solid #6090c0; background: #3a6090; border-radius: 3px; }
        QGroupBox { color: #8090b0; border: 1px solid #3a3e4a; margin-top: 8px;
                    border-radius: 4px; padding: 6px; }
        QGroupBox::title { subcontrol-origin: margin; left: 8px; }
        QPushButton { background: #2a2e3e; color: #c0c8d8; border: 1px solid #3a4060;
                      border-radius: 4px; padding: 4px 12px; }
        QPushButton:hover { background: #3a5080; }
    """

    def __init__(self, model: "LevelModel", parent=None):
        super().__init__(parent)
        self.model = model
        self.setWindowTitle("Room Properties")
        self.setStyleSheet(self._SS)
        self.setMinimumWidth(340)
        self._build()

    def _build(self):
        vbox = QVBoxLayout(self)
        vbox.setSpacing(10)

        # ── Shop section ──────────────────────────────────────────────────
        shop_grp = QGroupBox("Shop")
        shop_layout = QVBoxLayout(shop_grp)
        self.is_shop_cb = QCheckBox("Is shop?")
        self.is_shop_cb.setChecked(self.model.is_shop)
        shop_layout.addWidget(self.is_shop_cb)

        shop_desc = QLabel(
            "Checking <b>Is shop?</b> adds a <b>SHOP</b> tab to the tile toolbar.\n"
            "Shop tiles available:\n"
            "  • <b>buy_item</b> – opens an in-game keyboard purchase menu\n"
            "  • <b>shop_leave</b> – exits the shop and advances to next level"
        )
        shop_desc.setStyleSheet("color: #6070a0; font: 10px Consolas;")
        shop_desc.setWordWrap(True)
        shop_layout.addWidget(shop_desc)
        vbox.addWidget(shop_grp)

        # ── Buttons ───────────────────────────────────────────────────────
        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        vbox.addWidget(btns)


# ConnectionPanel – visual IO wiring panel
# ════════════════════════════════════════════════════════════════════════════
class ConnectionPanel(QDialog):
    """
    Floating dialog for managing IO connections between tiles.
    Opened from the View menu or via a toolbar button.

    Workflow:
      1. Select a SOURCE tile (click "Pick source" then click on canvas)
      2. Choose one of its SIGNAL (output) slots
      3. Select a TARGET tile (click "Pick target" then click on canvas)
      4. Choose one of its INPUT slots
      5. Click "Add Connection"
    """

    _STYLE = """
        QDialog { background: #1c1e28; }
        QLabel  { color: #c0c8d8; font: 11px Consolas; }
        QLabel#title { color: #80dcff; font: bold 14px Consolas;
                       border-bottom: 1px solid #3a3e4a; padding-bottom: 4px; }
        QLabel#section { color: #80c0ff; font: bold 11px Consolas; }
        QComboBox { background: #22242e; color: #c0c8d8; border: 1px solid #3a4060;
                    border-radius: 3px; padding: 2px 6px; font: 11px Consolas; }
        QComboBox QAbstractItemView { background: #1c1e28; color: #c0c8d8; }
        QListWidget { background: #1a1c24; color: #c0c8d8; border: 1px solid #3a3e4a;
                      font: 11px Consolas; }
        QListWidget::item:selected { background: #3a5080; color: #fff; }
        QPushButton { background: #2a3a60; color: #c0d8ff; border: 1px solid #3a5080;
                      border-radius: 3px; padding: 4px 10px; font: bold 11px Consolas; }
        QPushButton:hover { background: #3a5080; border: 1px solid #5888d8; }
        QPushButton:disabled { background: #2a2c36; color: #556; border: 1px solid #333; }
        QPushButton#add_btn { background: #2a5a30; color: #b0ffb8;
                              border: 1px solid #50a058; }
        QPushButton#add_btn:hover { background: #3a7040; }
        QPushButton#del_btn { background: #5a2a2a; color: #ffb0b0;
                              border: 1px solid #a05050; }
        QPushButton#del_btn:hover { background: #7a3030; }
    """

    def __init__(self, editor, parent=None):
        super().__init__(parent, Qt.WindowType.Tool)
        self.editor = editor
        self.setWindowTitle("IO Connections")
        self.resize(460, 560)
        self.setStyleSheet(self._STYLE)

        self._src_col = None; self._src_row = None
        self._dst_col = None; self._dst_row = None
        self._picking = None   # "src" or "dst"

        self._build()
        self._refresh_list()

    def _build(self):
        vbox = QVBoxLayout(self)
        vbox.setContentsMargins(12, 12, 12, 12)
        vbox.setSpacing(8)

        title = QLabel("IO Connections")
        title.setObjectName("title")
        vbox.addWidget(title)

        # ── Source tile ──
        sec_src = QLabel("SOURCE TILE  (signal sender)")
        sec_src.setObjectName("section")
        vbox.addWidget(sec_src)

        src_row_w = QWidget()
        src_h = QHBoxLayout(src_row_w)
        src_h.setContentsMargins(0,0,0,0)
        self._src_lbl = QLabel("none selected")
        self._pick_src_btn = QPushButton("Pick source tile…")
        self._pick_src_btn.clicked.connect(lambda: self._start_pick("src"))
        src_h.addWidget(self._src_lbl, 1)
        src_h.addWidget(self._pick_src_btn)
        vbox.addWidget(src_row_w)

        self._signal_combo = QComboBox()
        self._signal_combo.addItem("– select signal –")
        vbox.addWidget(self._signal_combo)

        # ── Destination tile ──
        sep1 = QFrame(); sep1.setFrameShape(QFrame.Shape.HLine)
        sep1.setStyleSheet("color: #3a3e4a;")
        vbox.addWidget(sep1)

        sec_dst = QLabel("DESTINATION TILE  (receives slot)")
        sec_dst.setObjectName("section")
        vbox.addWidget(sec_dst)

        dst_row_w = QWidget()
        dst_h = QHBoxLayout(dst_row_w)
        dst_h.setContentsMargins(0,0,0,0)
        self._dst_lbl = QLabel("none selected")
        self._pick_dst_btn = QPushButton("Pick destination tile…")
        self._pick_dst_btn.clicked.connect(lambda: self._start_pick("dst"))
        dst_h.addWidget(self._dst_lbl, 1)
        dst_h.addWidget(self._pick_dst_btn)
        vbox.addWidget(dst_row_w)

        self._slot_combo = QComboBox()
        self._slot_combo.addItem("– select slot –")
        vbox.addWidget(self._slot_combo)

        # ── Add button ──
        self._add_btn = QPushButton("Add Connection ▶")
        self._add_btn.setObjectName("add_btn")
        self._add_btn.setEnabled(False)
        self._add_btn.clicked.connect(self._add_connection)
        vbox.addWidget(self._add_btn)

        self._signal_combo.currentIndexChanged.connect(self._check_ready)
        self._slot_combo.currentIndexChanged.connect(self._check_ready)

        # ── Existing connections list ──
        sep2 = QFrame(); sep2.setFrameShape(QFrame.Shape.HLine)
        sep2.setStyleSheet("color: #3a3e4a;")
        vbox.addWidget(sep2)

        sec_list = QLabel("EXISTING CONNECTIONS")
        sec_list.setObjectName("section")
        vbox.addWidget(sec_list)

        self._conn_list = QListWidget()
        self._conn_list.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        vbox.addWidget(self._conn_list, 1)

        del_row = QWidget()
        del_h = QHBoxLayout(del_row)
        del_h.setContentsMargins(0,0,0,0)
        self._del_btn = QPushButton("Delete Selected")
        self._del_btn.setObjectName("del_btn")
        self._del_btn.clicked.connect(self._delete_selected)
        self._clear_btn = QPushButton("Clear All")
        self._clear_btn.setObjectName("del_btn")
        self._clear_btn.clicked.connect(self._clear_all)
        del_h.addWidget(self._del_btn)
        del_h.addWidget(self._clear_btn)
        vbox.addWidget(del_row)

        # ── Timer Nodes section ──────────────────────────────────────────
        sep_t = QFrame(); sep_t.setFrameShape(QFrame.Shape.HLine)
        sep_t.setStyleSheet("color: #3a3e4a;")
        vbox.addWidget(sep_t)

        sec_timer = QLabel("TIMER NODES  (off-tile; fire channel on schedule)")
        sec_timer.setObjectName("section")
        vbox.addWidget(sec_timer)

        self._timer_list = QListWidget()
        self._timer_list.setMaximumHeight(90)
        self._timer_list.setToolTip("Double-click to edit a timer node")
        self._timer_list.itemDoubleClicked.connect(self._edit_timer)
        vbox.addWidget(self._timer_list)

        timer_btns = QWidget()
        tbh = QHBoxLayout(timer_btns)
        tbh.setContentsMargins(0,0,0,0)
        self._add_timer_btn = QPushButton("+ Timer")
        self._add_timer_btn.clicked.connect(self._add_timer)
        self._del_timer_btn = QPushButton("Delete")
        self._del_timer_btn.setObjectName("del_btn")
        self._del_timer_btn.clicked.connect(self._del_timer)
        tbh.addWidget(self._add_timer_btn)
        tbh.addWidget(self._del_timer_btn)
        vbox.addWidget(timer_btns)
        self._refresh_timers()

    def _start_pick(self, which):
        """Tell canvas to go into connection-pick mode for src or dst."""
        self._picking = which
        canvas = self.editor.canvas
        canvas.conn_mode = True
        canvas._conn_src = None
        canvas.update()
        # connect one-shot
        try:
            canvas.conn_tile_clicked.disconnect(self._on_tile_picked)
        except Exception:
            pass
        canvas.conn_tile_clicked.connect(self._on_tile_picked)
        lbl = "source" if which == "src" else "destination"
        self.editor._set_status_right(f"CONNECT: click a tile on canvas to pick {lbl}…")

    def _on_tile_picked(self, col, row):
        canvas = self.editor.canvas
        m = self.editor.model

        try:
            canvas.conn_tile_clicked.disconnect(self._on_tile_picked)
        except Exception:
            pass
        canvas.conn_mode = False
        canvas._conn_src = None
        canvas.update()

        # Find the topmost object at this tile
        objs = m.objects_at(col, row)
        if not objs:
            self.editor._set_status_right(f"No tile at ({col},{row})")
            return

        obj = objs[-1]
        tile_type = obj.get("type", "?")
        label = f"({col},{row})  [{tile_type}]"

        if self._picking == "src":
            self._src_col = col; self._src_row = row
            self._src_lbl.setText(label)
            # populate signal combo
            self._signal_combo.blockSignals(True)
            self._signal_combo.clear()
            self._signal_combo.addItem("– select signal –")
            for sig in TILE_SIGNALS.get(tile_type, []):
                self._signal_combo.addItem(sig)
            self._signal_combo.blockSignals(False)
        else:
            self._dst_col = col; self._dst_row = row
            self._dst_lbl.setText(label)
            # populate slot combo
            self._slot_combo.blockSignals(True)
            self._slot_combo.clear()
            self._slot_combo.addItem("– select slot –")
            for slot in TILE_SLOTS.get(tile_type, []):
                self._slot_combo.addItem(slot)
            self._slot_combo.blockSignals(False)

        self._check_ready()

    def _check_ready(self):
        ok = (self._src_col is not None and self._dst_col is not None and
              self._signal_combo.currentIndex() > 0 and
              self._slot_combo.currentIndex() > 0)
        self._add_btn.setEnabled(ok)

    def _add_connection(self):
        m = self.editor.model
        conn = {
            "from_col":    self._src_col,
            "from_row":    self._src_row,
            "from_signal": self._signal_combo.currentText(),
            "to_col":      self._dst_col,
            "to_row":      self._dst_row,
            "to_slot":     self._slot_combo.currentText(),
        }
        # Prevent duplicates
        for c in m.connections:
            if (c["from_col"] == conn["from_col"] and c["from_row"] == conn["from_row"] and
                    c["from_signal"] == conn["from_signal"] and
                    c["to_col"] == conn["to_col"] and c["to_row"] == conn["to_row"] and
                    c["to_slot"] == conn["to_slot"]):
                self.editor._set_status_right("Connection already exists.")
                return
        m.connections.append(conn)
        self.editor._mark_unsaved()
        self.editor.canvas.update()
        self._refresh_list()

    def _delete_selected(self):
        m = self.editor.model
        idx = self._conn_list.currentRow()
        if 0 <= idx < len(m.connections):
            m.connections.pop(idx)
            self.editor._mark_unsaved()
            self.editor.canvas.update()
            self._refresh_list()

    def _clear_all(self):
        if not self.editor.model.connections:
            return
        reply = QMessageBox.question(self, "Clear all", "Remove all IO connections?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.editor.model.connections.clear()
            self.editor._mark_unsaved()
            self.editor.canvas.update()
            self._refresh_list()

    def _refresh_list(self):
        self._conn_list.clear()
        m = self.editor.model
        for conn in m.connections:
            txt = (f"({conn['from_col']},{conn['from_row']}) {conn['from_signal']}"
                   f"  →  ({conn['to_col']},{conn['to_row']}) {conn['to_slot']}")
            self._conn_list.addItem(txt)

    def _refresh_timers(self):
        self._timer_list.clear()
        m = self.editor.model
        for i, t in enumerate(m.timers):
            label = t.get("label", f"Timer {i+1}")
            every = t.get("interval", 5.0)
            ch    = t.get("channel", 0)
            shot  = "×1" if t.get("one_shot", False) else "∞"
            active = "ON" if t.get("active", True) else "OFF"
            self._timer_list.addItem(
                f"  {label}  |  ch:{ch}  every:{every:.1f}s  {shot}  [{active}]")

    def _add_timer(self):
        dlg = TimerNodeDialog(parent=self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.editor.model.timers.append(dlg.result())
            self.editor._mark_unsaved()
            self._refresh_timers()

    def _edit_timer(self, item):
        idx = self._timer_list.row(item)
        m = self.editor.model
        if not (0 <= idx < len(m.timers)): return
        dlg = TimerNodeDialog(m.timers[idx], parent=self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            m.timers[idx] = dlg.result()
            self.editor._mark_unsaved()
            self._refresh_timers()

    def _del_timer(self):
        idx = self._timer_list.currentRow()
        m = self.editor.model
        if 0 <= idx < len(m.timers):
            m.timers.pop(idx)
            self.editor._mark_unsaved()
            self._refresh_timers()

    def refresh(self):
        self._refresh_list()
        self._refresh_timers()

class SidePanel(QWidget):
    add_waypoint_req     = pyqtSignal()
    clear_waypoints_req  = pyqtSignal()
    remove_waypoint_req  = pyqtSignal(int)
    toggle_pause_req     = pyqtSignal(int)
    guard_selected       = pyqtSignal(object)

    def __init__(self):
        super().__init__()
        self.setFixedWidth(260)
        self.guard_list_data  = []
        self.snitch_list_data = []
        self._active_tab = "guards"   # "guards" or "snitches"
        self._build()

    _PANEL_STYLE = """
        QWidget { background: #2a2c34; color: #d2d7e1; font: 11px Consolas; }
        QListWidget { background: #1c1e26; border: 1px solid #3a3e4a; color: #c0c8d8; }
        QListWidget::item:selected { background: #3a5080; }
        QSpinBox, QLineEdit {
            background: #1c1e26; color: #c0c8d8;
            border: 1px solid #3a3e4a; border-radius: 3px;
            padding: 2px 6px; font: 11px Consolas;
        }
        QPushButton#npc_tab {
            background: #1e2030;
            border: 1px solid #2a2e42;
            border-radius: 3px 3px 0 0;
            color: #7090b8;
            font: bold 10px Consolas;
            padding: 2px 6px;
            min-width: 68px;
        }
        QPushButton#npc_tab:hover { background: #252840; color: #c0d0f0; }
        QPushButton#npc_tab[active="true"] {
            background: #2a3260;
            border: 1px solid #5888d8;
            border-bottom: none;
            color: #c8daff;
        }
    """

    def _build(self):
        self.setStyleSheet(self._PANEL_STYLE)
        vbox = QVBoxLayout(self)
        vbox.setContentsMargins(0, 0, 0, 0)
        vbox.setSpacing(0)

        # ── Project tree ───────────────────────────────────────────────────
        self.project_tree = ProjectTreePanel()
        # keep project_tree mp_mode in sync (set after _build_ui)
        self.project_tree.setMinimumHeight(120)
        self.project_tree.setMaximumHeight(260)

        sep_line = QFrame()
        sep_line.setFrameShape(QFrame.Shape.HLine)
        sep_line.setStyleSheet("color: #3a3e4a;")
        vbox.addWidget(self.project_tree)
        vbox.addWidget(sep_line)

        # ── Inner content ──────────────────────────────────────────────────
        inner = QWidget()
        inner_v = QVBoxLayout(inner)
        inner_v.setContentsMargins(8, 6, 8, 8)
        inner_v.setSpacing(4)

        # ── NPC panel with Guards / Snitches tabs ─────────────────────────
        grp_npc = make_group("NPCs")
        gv_npc = QVBoxLayout(grp_npc)
        gv_npc.setSpacing(4)

        # Tab row
        tab_row = QHBoxLayout()
        tab_row.setSpacing(2)
        tab_row.setContentsMargins(0, 0, 0, 0)

        self._tab_guards_btn   = QPushButton("Guards")
        self._tab_snitches_btn = QPushButton("Snitches")
        for btn, key in ((self._tab_guards_btn, "guards"),
                         (self._tab_snitches_btn, "snitches")):
            btn.setObjectName("npc_tab")
            btn.setProperty("active", str(key == self._active_tab).lower())
            btn.setStyleSheet(self._PANEL_STYLE)
            btn.clicked.connect(lambda _, k=key: self._switch_npc_tab(k))
            tab_row.addWidget(btn)
        tab_row.addStretch(1)
        gv_npc.addLayout(tab_row)

        # ── Guards page ───────────────────────────────────────────────────
        self._guards_page = QWidget()
        gp_v = QVBoxLayout(self._guards_page)
        gp_v.setContentsMargins(0, 4, 0, 0)
        gp_v.setSpacing(4)

        gp_v.addWidget(QLabel("Guards in level:"))
        self.guard_list = QListWidget()
        self.guard_list.setMinimumHeight(80)
        self.guard_list.itemClicked.connect(self._on_guard_selected)
        gp_v.addWidget(self.guard_list)

        gp_v.addWidget(QLabel("Waypoints (selected guard):"))
        self.wp_list = QListWidget()
        self.wp_list.setMinimumHeight(120)
        self.wp_list.setToolTip("Double-click a waypoint to toggle pause flag")
        self.wp_list.itemDoubleClicked.connect(self._on_wp_dblclick)
        gp_v.addWidget(self.wp_list, 1)

        row_btns = QHBoxLayout()
        self.btn_add_wp = styled_button("+ WP",  "#3a6030", "#4a8040")
        self.btn_del_wp = styled_button("− Del", "#703030", "#904040")
        self.btn_clr_wp = styled_button("Clear", "#505060", "#606080")
        self.btn_add_wp.clicked.connect(self.add_waypoint_req)
        self.btn_del_wp.clicked.connect(self._del_selected_wp)
        self.btn_clr_wp.clicked.connect(self.clear_waypoints_req)
        row_btns.addWidget(self.btn_add_wp)
        row_btns.addWidget(self.btn_del_wp)
        row_btns.addWidget(self.btn_clr_wp)
        gp_v.addLayout(row_btns)

        wp_info = QLabel("Click node: select  |  dbl-click: edit\nArrow keys: nudge  |  Del: remove")
        wp_info.setStyleSheet("color:#606878; font:10px Consolas;")
        gp_v.addWidget(wp_info)

        # ── Snitches page ─────────────────────────────────────────────────
        self._snitches_page = QWidget()
        sp_v = QVBoxLayout(self._snitches_page)
        sp_v.setContentsMargins(0, 4, 0, 0)
        sp_v.setSpacing(4)

        sp_v.addWidget(QLabel("Snitches in level:"))
        self.snitch_list = QListWidget()
        self.snitch_list.setMinimumHeight(80)
        sp_v.addWidget(self.snitch_list, 1)

        snitch_info = QLabel(
            "◈ Spots player → runs to nearest\n"
            "  guard to report. Does NOT fight.\n"
            "Alt+Enter on tile to edit props.")
        snitch_info.setStyleSheet("color:#606878; font:10px Consolas;")
        sp_v.addWidget(snitch_info)

        # Stack pages
        self._npc_stack = QStackedWidget()
        self._npc_stack.addWidget(self._guards_page)   # index 0 = guards
        self._npc_stack.addWidget(self._snitches_page) # index 1 = snitches
        self._npc_stack.setCurrentIndex(0)
        gv_npc.addWidget(self._npc_stack, 1)

        inner_v.addWidget(grp_npc, 1)

        # ── Level properties ───────────────────────────────────────────────
        grp3 = make_group("LEVEL PROPERTIES")
        form = QFormLayout(grp3)
        form.setSpacing(4)
        self.name_edit = QLineEdit("Untitled")
        self.cols_spin = QSpinBox(); self.cols_spin.setRange(8, 80)
        self.rows_spin = QSpinBox(); self.rows_spin.setRange(6, 60)
        # tile_spin kept as hidden widget so all existing wiring still works
        self.tile_spin = QSpinBox(); self.tile_spin.setRange(16, 96); self.tile_spin.setSingleStep(8)
        self.tile_spin.setVisible(False)
        self.cols_spin.setValue(DEFAULT_COLS)
        self.rows_spin.setValue(DEFAULT_ROWS)
        self.tile_spin.setValue(DEFAULT_TILE)
        form.addRow("Name:", self.name_edit)
        form.addRow("Cols:", self.cols_spin)
        form.addRow("Rows:", self.rows_spin)
        inner_v.addWidget(grp3)

        # Tips
        tips_lbl = QLabel(
            "🖱 Left-drag: paint\n"
            "🖱 Shift+drag: erase\n"
            "🖱 Middle-drag: pan\n"
            "Scroll: zoom | G: grid\n"
            "F: fit  |  Del: erase sel\n"
            "Alt+Enter: edit props"
        )
        tips_lbl.setStyleSheet("color: #606878; font: 10px Consolas;")
        inner_v.addWidget(tips_lbl)

        vbox.addWidget(inner, 1)

    def _switch_npc_tab(self, key):
        self._active_tab = key
        self._tab_guards_btn.setProperty("active",   str(key == "guards").lower())
        self._tab_snitches_btn.setProperty("active", str(key == "snitches").lower())
        # Re-apply stylesheet so property change takes effect
        self._tab_guards_btn.setStyleSheet(self._PANEL_STYLE)
        self._tab_snitches_btn.setStyleSheet(self._PANEL_STYLE)
        self._npc_stack.setCurrentIndex(0 if key == "guards" else 1)

    def refresh_guards(self, guards):
        self.guard_list.clear()
        self.guard_list_data = guards
        for i, g in enumerate(guards):
            item = QListWidgetItem(f"Guard {i}  @ ({g['col']},{g['row']})")
            self.guard_list.addItem(item)

    def refresh_snitches(self, snitches):
        self.snitch_list.clear()
        self.snitch_list_data = snitches
        for i, s in enumerate(snitches):
            rot = s.get("rotation_speed", 0.0)
            rot_str = f"  rot:{rot:.0f}°/s" if rot else "  stationary"
            item = QListWidgetItem(
                f"◈ Snitch {i}  @ ({s['col']},{s['row']}){rot_str}")
            item.setForeground(PAL.get("snitch", QColor(200, 130, 40)))
            self.snitch_list.addItem(item)

    def refresh_waypoints(self, guard_obj, selected_idx=-1):
        self.wp_list.clear()
        if guard_obj is None:
            return
        nodes = guard_obj.get("wp_nodes") or []
        if not nodes:
            # legacy fallback
            wps = guard_obj.get("waypoints", [])
            pfs = guard_obj.get("pause_flags", [])
            nodes = [{"col": w[0], "row": w[1],
                      "type": "waitpoint" if (i < len(pfs) and pfs[i]) else "waypoint"}
                     for i, w in enumerate(wps)]
        for i, node in enumerate(nodes):
            nt  = node.get("type", "waypoint")
            sym = WP_ICONS.get(nt, "●")
            suffix = " [spawn]" if i == 0 else ""
            label  = f"  {sym} {i}  {nt.upper()}  ({node['col']},{node['row']}){suffix}"
            item   = QListWidgetItem(label)
            col    = WP_COLORS.get(nt, QColor(180, 180, 180))
            item.setForeground(col)
            if i == selected_idx:
                item.setBackground(QColor(40, 60, 90))
            self.wp_list.addItem(item)

    def _on_guard_selected(self, item):
        idx = self.guard_list.row(item)
        if 0 <= idx < len(self.guard_list_data):
            g = self.guard_list_data[idx]
            self.guard_selected.emit(g)
            self.refresh_waypoints(g)

    def _del_selected_wp(self):
        idx = self.wp_list.currentRow()
        if idx > 0:
            self.remove_waypoint_req.emit(idx)

    def _on_wp_dblclick(self, item):
        idx = self.wp_list.row(item)
        self.toggle_pause_req.emit(idx)


# ════════════════════════════════════════════════════════════════════════════
# Undo / Redo  –  QUndoCommand subclasses
# ════════════════════════════════════════════════════════════════════════════

class _PlaceTileCmd(QUndoCommand):
    """Undo-able tile paint operation (single tile or batch of same stroke)."""

    def __init__(self, model: "LevelModel", operations, description="Paint"):
        """
        operations – list of (col, row, new_obj_or_None, old_snapshot_list)
          new_obj_or_None  : dict to add, or None for erase
          old_snapshot_list: copy of objects that were at (col,row) before
        """
        super().__init__(description)
        self._model = model
        self._ops   = operations   # [(col, row, new, old), ...]

    def redo(self):
        m = self._model
        for col, row, new_obj, _ in self._ops:
            m.remove_at(col, row)
            if new_obj is not None:
                obj = dict(new_obj)
                m.objects.append(obj)

    def undo(self):
        m = self._model
        for col, row, _, old_list in self._ops:
            m.remove_at(col, row)
            for old_obj in old_list:
                m.objects.append(dict(old_obj))


class _DeleteSelectionCmd(QUndoCommand):
    """Undo-able deletion of a marquee selection."""

    def __init__(self, model: "LevelModel", tiles, description="Delete Selection"):
        super().__init__(description)
        self._model    = model
        self._removed  = []   # [(col, row, [obj_snapshots...])]
        for (col, row) in tiles:
            snap = [dict(o) for o in model.objects_at(col, row)]
            if snap:
                self._removed.append((col, row, snap))

    def redo(self):
        for col, row, _ in self._removed:
            self._model.remove_at(col, row)

    def undo(self):
        for col, row, snap in self._removed:
            self._model.remove_at(col, row)
            for obj in snap:
                self._model.objects.append(dict(obj))


class _EditPropsCmd(QUndoCommand):
    """Undo-able property edit."""

    def __init__(self, obj_ref: dict, new_state: dict, description="Edit Properties"):
        super().__init__(description)
        self._obj = obj_ref
        self._old = dict(obj_ref)
        self._new = new_state

    def redo(self):
        self._obj.clear(); self._obj.update(self._new)

    def undo(self):
        self._obj.clear(); self._obj.update(self._old)


class _NudgeCmd(QUndoCommand):
    """Undo-able nudge of selected tiles."""

    def __init__(self, model: "LevelModel", objs, dx, dy, description="Nudge"):
        super().__init__(description)
        self._model = model
        self._keys  = [(o["col"], o["row"]) for o in objs]   # before move
        self._dx    = dx
        self._dy    = dy

    def redo(self):
        m = self._model
        objs = [o for o in m.objects
                if (o["col"], o["row"]) in set(self._keys)]
        new_pos = {(o["col"] + self._dx, o["row"] + self._dy) for o in objs}
        old_pos = set(self._keys)
        for nc, nr in new_pos - old_pos:
            m.remove_at(nc, nr)
        for o in objs:
            o["col"] += self._dx; o["row"] += self._dy

    def undo(self):
        m = self._model
        new_keys = [(c + self._dx, r + self._dy) for (c, r) in self._keys]
        objs = [o for o in m.objects
                if (o["col"], o["row"]) in set(new_keys)]
        old_pos = set(self._keys)
        new_pos = {(o["col"], o["row"]) for o in objs}
        for oc, orow in old_pos - new_pos:
            m.remove_at(oc, orow)
        for o in objs:
            o["col"] -= self._dx; o["row"] -= self._dy


class EditorWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("KeyRing – LockESC Editor  v5")
        self.resize(1200, 720)   # safe default; __main__ calls showMaximized()
        self.model    = LevelModel()
        self.filepath = None
        self.unsaved  = False
        self.wp_mode  = False
        self.mp_mode  = False   # True when editing a multiplayer level

        # ── Undo / Redo stack ──────────────────────────────────────────────
        self._undo_stack = QUndoStack(self)
        self._undo_stack.setUndoLimit(200)
        self._undo_stack.cleanChanged.connect(self._on_undo_clean_changed)

        # Ensure integrity/visuals/default.lev exists
        _ensure_lev_file()
        _load_lev_defs()

        # Accumulate paint-stroke operations before pushing (deduped per tile)
        self._stroke_ops: dict = {}   # (col,row) -> (new_obj, old_list)
        self._stroke_tool: str = ""

        self._build_ui()
        self._build_menu()
        self._build_status()
        self._apply_dark_theme()
        self.canvas.fit()
        self._conn_panel = ConnectionPanel(self)   # IO wiring dialog (floating)

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        main_h = QHBoxLayout(central)
        main_h.setContentsMargins(0, 0, 0, 0)
        main_h.setSpacing(0)

        # Left side panel
        self.panel = SidePanel()
        sep = QFrame(); sep.setFrameShape(QFrame.Shape.VLine)
        sep.setStyleSheet("color: #3a3e4a;")

        # Right side: entity toolbar + (hidden) waypoint toolbar + canvas
        right_widget = QWidget()
        right_widget.setStyleSheet("background: #1a1c22;")
        right_vbox = QVBoxLayout(right_widget)
        right_vbox.setContentsMargins(0, 0, 0, 0)
        right_vbox.setSpacing(0)

        self.toolbar    = TileToolBar()
        self.wp_toolbar = WaypointToolBar()
        self.wp_toolbar.setVisible(False)   # hidden until guard selected + wp mode
        self.canvas     = Canvas(self.model)

        right_vbox.addWidget(self.toolbar)
        right_vbox.addWidget(self.wp_toolbar)
        right_vbox.addWidget(self.canvas, 1)

        main_h.addWidget(self.panel)
        main_h.addWidget(sep)
        main_h.addWidget(right_widget, 1)

        # ── Story Dev Panel (only if integrity/functions/misc/dev.py exists) ──
        self.story_dev_panel = None
        try:
            from integrity.functions.misc.dev import StoryDevPanel as _SDP
            self.story_dev_panel = _SDP(editor_ref=None)
            self.story_dev_panel.set_editor(self)
            self.story_dev_panel.story_tile_selected.connect(self._on_story_tile_selected)
            _sep_story = QFrame()
            _sep_story.setFrameShape(QFrame.Shape.VLine)
            _sep_story.setStyleSheet("color: #1e1e2e;")
            main_h.addWidget(_sep_story)
            main_h.addWidget(self.story_dev_panel)
        except ImportError:
            pass  # dev.py not installed — story panel hidden

        # ── Wire signals ───────────────────────────────────────────────────
        self.canvas.tile_clicked.connect(self._on_tile_click)
        self.canvas.tile_dbl_click.connect(self._on_tile_dblclick)
        self.canvas.status_update.connect(self._set_status_right)
        self.canvas.selection_changed.connect(self._on_selection_changed)
        self.canvas.wp_node_clicked.connect(self._on_wp_node_clicked)
        self.canvas.wp_node_dbl_click.connect(self._on_wp_node_dblclick)
        self.canvas.stroke_ended.connect(self._stroke_commit)
        self.canvas.context_menu_requested.connect(self._on_canvas_context_menu)

        self.toolbar.tool_selected.connect(self._on_tool_change)
        self.wp_toolbar.tool_selected.connect(self._on_wp_tool_change)

        self.panel.add_waypoint_req.connect(self._start_wp_mode)
        self.panel.clear_waypoints_req.connect(self._clear_waypoints)
        self.panel.remove_waypoint_req.connect(self._remove_waypoint)
        self.panel.toggle_pause_req.connect(self._toggle_pause)
        self.panel.guard_selected.connect(self._on_guard_selected)
        self.panel.cols_spin.valueChanged.connect(self._resize_level)
        self.panel.rows_spin.valueChanged.connect(self._resize_level)
        self.panel.tile_spin.valueChanged.connect(self._retile_level)
        self.panel.name_edit.textChanged.connect(self._rename_level)
        self.panel.project_tree.room_open_requested.connect(self._on_room_open_requested)

    def _on_room_open_requested(self, path):
        """Handle double-click on a room in the project tree."""
        if not path:
            # empty string = "new room" button in tree
            self.new_level()
            return
        try:
            import json as _json
            real = _ler_json_path(path)
            with open(real, encoding="utf-8") as f:
                data = _json.load(f)
            self.model = LevelModel.from_json(data)
            self.filepath = path
            self.unsaved  = False
            for _w in (self.panel.cols_spin, self.panel.rows_spin,
                       self.panel.tile_spin, self.panel.name_edit):
                _w.blockSignals(True)
            self.canvas.set_model(self.model)
            self.panel.name_edit.setText(self.model.name)
            self.panel.cols_spin.setValue(self.model.cols)
            self.panel.rows_spin.setValue(self.model.rows)
            self.panel.tile_spin.setValue(self.model.tile_size)
            for _w in (self.panel.cols_spin, self.panel.rows_spin,
                       self.panel.tile_spin, self.panel.name_edit):
                _w.blockSignals(False)
            # Sync shop toolbar tab with loaded model's is_shop flag
            self.toolbar.set_shop_mode(self.model.is_shop)
            self._refresh_guard_list()
            self._set_title()
            self.canvas.fit()
        except Exception as e:
            QMessageBox.critical(self, "Open Room", f"Failed to load:\n{e}")

    def _build_menu(self):
        mb = self.menuBar()
        mb.setStyleSheet("""
            QMenuBar { background: #1c1e26; color: #c0c8d8; }
            QMenuBar::item:selected { background: #3a5080; }
            QMenu { background: #22242e; color: #c0c8d8; border: 1px solid #3a3e4a; }
            QMenu::item:selected { background: #3a5080; }
            QMenu::separator { height: 1px; background: #3a3e4a; margin: 2px 4px; }
        """)
        fm = mb.addMenu("File")
        for label, shortcut, slot in [
            ("New",        "Ctrl+N",       self.new_level),
            ("Open…",      "Ctrl+O",       self.open_level),
            ("Save",       "Ctrl+S",       self.save_level),
            ("Save As…",   "Ctrl+Shift+S", self.save_level_as),
        ]:
            a = QAction(label, self, shortcut=shortcut)
            a.triggered.connect(slot)
            fm.addAction(a)
        fm.addSeparator()
        a_run = QAction("▶  Run Level", self, shortcut="F5")
        a_run.triggered.connect(self.run_level)
        fm.addAction(a_run)
        fm.addSeparator()
        a_quit = QAction("Quit", self, shortcut="Ctrl+Q")
        a_quit.triggered.connect(self.close)
        fm.addAction(a_quit)

        em = mb.addMenu("Edit")
        # Undo / Redo backed by QUndoStack
        a_undo = self._undo_stack.createUndoAction(self, "Undo")
        a_undo.setShortcut(QKeySequence("Ctrl+Z"))
        a_redo = self._undo_stack.createRedoAction(self, "Redo")
        a_redo.setShortcut(QKeySequence("Ctrl+Y"))
        em.addAction(a_undo)
        em.addAction(a_redo)
        em.addSeparator()
        a_room_props = QAction("Room Properties…", self, shortcut="Ctrl+Shift+P")
        a_room_props.triggered.connect(self._edit_room_props)
        em.addAction(a_room_props)
        em.addSeparator()
        a_clr = QAction("Clear All Objects", self)
        a_brd = QAction("Fill Border Walls", self)
        a_fill_enc = QAction("Fill Enclosed Space with Walls…", self)
        a_region_sel = QAction("Set Active Region ID…", self)
        a_clr.triggered.connect(self._clear_all)
        a_brd.triggered.connect(self._fill_border)
        a_fill_enc.triggered.connect(self._fill_enclosed)
        a_region_sel.triggered.connect(self._choose_region_id)
        em.addActions([a_clr, a_brd, a_fill_enc, a_region_sel])

        vm = mb.addMenu("View")
        a_grid = QAction("Toggle Grid", self, shortcut="G")
        a_fit  = QAction("Fit Level",   self, shortcut="F")
        a_grid.triggered.connect(lambda: setattr(self.canvas, 'show_grid',
                                                  not self.canvas.show_grid) or self.canvas.update())
        a_fit.triggered.connect(self.canvas.fit)
        vm.addActions([a_grid, a_fit])
        vm.addSeparator()
        a_conn = QAction("IO Connections…", self, shortcut="Ctrl+Shift+C")
        a_conn.triggered.connect(self._show_conn_panel)
        vm.addAction(a_conn)

        hm = mb.addMenu("Help")
        a_about = QAction("About", self)
        a_about.triggered.connect(self._about)
        hm.addAction(a_about)

    def _build_status(self):
        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.status.setStyleSheet(
            "QStatusBar { background: #1c1e26; color: #8090b0; font: 10px Consolas; }")
        self._status_left  = QLabel("  Ready")
        self._status_right = QLabel("")
        self._status_tool  = QLabel("  Tool: WALL")
        self.status.addWidget(self._status_left, 1)
        self.status.addPermanentWidget(self._status_tool)
        self.status.addPermanentWidget(self._status_right)

    def _apply_dark_theme(self):
        self.setStyleSheet("QMainWindow { background: #2a2c34; }")

    # ── slots ─────────────────────────────────────────────────────────────────
    # ── Stroke-based undo helpers ──────────────────────────────────────────
    def _stroke_begin(self, tool):
        """Called on first tile-click of a paint stroke."""
        self._stroke_ops  = {}
        self._stroke_tool = tool

    def _stroke_record(self, col, row, new_obj):
        """Record one tile change within the current stroke (idempotent per tile)."""
        key = (col, row)
        if key not in self._stroke_ops:
            old = [dict(o) for o in self.model.objects_at(col, row)]
            self._stroke_ops[key] = (new_obj, old)
        else:
            # Keep original old snapshot, just update new_obj
            _, old = self._stroke_ops[key]
            self._stroke_ops[key] = (new_obj, old)

    def _stroke_commit(self):
        """Push accumulated stroke as one undo command."""
        if not self._stroke_ops:
            return
        ops = [(c, r, n, o) for (c, r), (n, o) in self._stroke_ops.items()]
        tool = self._stroke_tool
        desc = f"Erase" if tool == "erase" else f"Paint {tool}"
        cmd  = _PlaceTileCmd(self.model, ops, desc)
        self._undo_stack.push(cmd)
        self._stroke_ops  = {}
        self._stroke_tool = ""

    # ── tile click ────────────────────────────────────────────────────────
    def _on_tile_click(self, col, row, btn):
        m = self.model
        if col < 0 or row < 0 or col >= m.cols or row >= m.rows:
            return

        # wp_mode click is fully handled in Canvas mousePressEvent now
        if self.wp_mode:
            self._mark_unsaved()
            g = self.canvas.selected_guard
            if g:
                self.panel.refresh_waypoints(g, self.canvas.selected_wp_idx)
            return

        tool = self.canvas.current_tool
        if tool == "select":
            return

        # Begin a new stroke if tool or position changes (first call per drag)
        if not self._stroke_ops:
            self._stroke_begin(tool if btn != 3 else "erase")

        if btn == 3 or tool == "erase":
            old = [dict(o) for o in m.objects_at(col, row)]
            if (col, row) not in self._stroke_ops:
                self._stroke_ops[(col, row)] = (None, old)
            m.remove_at(col, row)
        elif btn == 1:
            # Build new obj
            if tool == "guard":
                new_obj = {
                    "type": "guard", "col": col, "row": row,
                    "waypoints": [[col, row]], "pause_flags": [False],
                    "wp_nodes": [{"col": col, "row": row, "type": "waypoint"}],
                }
            elif tool == "door":
                new_obj = {"type": "door", "col": col, "row": row, "open": False}
            elif tool == "crashdoor":
                new_obj = {"type": "crashdoor", "col": col, "row": row}
            elif tool == "window":
                new_obj = {"type": "window", "col": col, "row": row}
            elif tool == "noisemaker":
                new_obj = {"type": "noisemaker", "col": col, "row": row,
                           "radius": 240, "score": 60, "interval": 4.0, "ambiguous": True}
            else:
                new_obj = {"type": tool, "col": col, "row": row}

            old = [dict(o) for o in m.objects_at(col, row)]
            if (col, row) not in self._stroke_ops:
                self._stroke_ops[(col, row)] = (dict(new_obj), old)
            m.remove_at(col, row)
            m.objects.append(new_obj)
            if tool == "guard":
                self._refresh_guard_list()

        self._mark_unsaved()
        self._refresh_guard_list()
        self.canvas.update()

    def _on_tile_dblclick(self, col, row):
        """Open property editor for the topmost tile at (col, row)."""
        m = self.model
        objs = m.objects_at(col, row)
        if not objs:
            return
        obj = objs[-1]
        dlg = PropertyDialog(obj, self, bundle_path=self.filepath)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            new_obj = dlg.result_obj()
            cmd = _EditPropsCmd(obj, new_obj, f"Edit {obj['type']} properties")
            self._undo_stack.push(cmd)
            self._mark_unsaved()
            self._refresh_guard_list()
            self.canvas.update()

    def _on_canvas_context_menu(self, col, row, global_pt):
        """Show a right-click context menu on the canvas."""
        m   = self.model
        menu = QMenu(self)
        menu.setStyleSheet("""
            QMenu { background: #1e2030; color: #c0c8e0; border: 1px solid #3a4060;
                    font: 11px Consolas; }
            QMenu::item { padding: 5px 18px 5px 10px; }
            QMenu::item:selected { background: #2a4080; color: #e0eaff; }
            QMenu::separator { height: 1px; background: #3a3e4a; margin: 2px 4px; }
        """)

        valid = 0 <= col < m.cols and 0 <= row < m.rows
        objs  = m.objects_at(col, row) if valid else []
        top   = objs[-1] if objs else None

        # ── Tile actions ────────────────────────────────────────────────
        if top:
            a_props = menu.addAction(f"✏  Edit Properties  [{top['type']}]")
            a_props.triggered.connect(lambda: self._on_tile_dblclick(col, row))
            menu.addSeparator()

        if valid:
            # Place submenu: current tool
            tool = self.canvas.current_tool
            if tool not in ("select", "edge_wall", "edge_door",
                            "region", "region_inbetween",
                            "region_inbetween_doorway", "erase"):
                a_place = menu.addAction(f"🖌  Place {tool}  here")
                a_place.triggered.connect(lambda: self._ctx_place_tile(col, row, tool))

        if objs:
            a_erase = menu.addAction("🗑  Erase tile")
            a_erase.triggered.connect(lambda: self._ctx_erase_tile(col, row))

        # ── Edge actions ─────────────────────────────────────────────────
        # Check if cursor is near a grid edge
        canvas_pos = self.canvas.mapFromGlobal(global_pt)
        edge_snap  = self.canvas._canvas_to_edge(canvas_pos.x(), canvas_pos.y())
        if edge_snap:
            ec, er, es = edge_snap
            existing_edge = next(
                (o for o in m.objects if o.get("type") in ("edge_wall", "edge_door")
                 and o.get("col") == ec and o.get("row") == er and o.get("side") == es),
                None)
            menu.addSeparator()
            side_label = f"({ec},{er}) {es}"
            if existing_edge:
                a_del_edge = menu.addAction(f"🗑  Remove edge {existing_edge['type']}  @ {side_label}")
                a_del_edge.triggered.connect(
                    lambda checked=False, snap=edge_snap: self.canvas._erase_edge(
                        *self.canvas._edge_snap_to_canvas_px(snap)))
                # Toggle open/closed for edge door
                if existing_edge.get("type") == "edge_door":
                    is_open = existing_edge.get("open", False)
                    label   = "Close edge door" if is_open else "Open edge door"
                    a_tog = menu.addAction(f"🚪  {label}  @ {side_label}")
                    a_tog.triggered.connect(
                        lambda checked=False, obj=existing_edge:
                            obj.update({"open": not obj.get("open", False)}) or
                            self.canvas.update() or self._mark_unsaved())
            else:
                a_ew = menu.addAction(f"╟  Place edge wall  @ {side_label}")
                a_ed = menu.addAction(f"🚪  Place edge door  @ {side_label}")
                a_ew.triggered.connect(
                    lambda checked=False, snap=edge_snap:
                        self.canvas._place_edge(
                            *self.canvas._edge_snap_to_canvas_px(snap), "edge_wall"))
                a_ed.triggered.connect(
                    lambda checked=False, snap=edge_snap:
                        self.canvas._place_edge(
                            *self.canvas._edge_snap_to_canvas_px(snap), "edge_door"))

        # ── Guard actions ────────────────────────────────────────────────
        guard_obj = next((o for o in objs if o.get("type") == "guard"), None)
        if guard_obj:
            menu.addSeparator()
            a_wp = menu.addAction("🛤  Edit Waypoints")
            a_wp.triggered.connect(lambda: self._start_wp_mode_for(guard_obj))

        menu.addSeparator()
        a_undo = menu.addAction("↩  Undo  (Ctrl+Z)")
        a_undo.triggered.connect(self._undo_stack.undo)
        a_undo.setEnabled(self._undo_stack.canUndo())
        a_redo = menu.addAction("↪  Redo  (Ctrl+Y)")
        a_redo.triggered.connect(self._undo_stack.redo)
        a_redo.setEnabled(self._undo_stack.canRedo())

        if not menu.actions() or all(not a.text() for a in menu.actions()):
            return  # Nothing useful to show

        menu.exec(global_pt)
        self.canvas.update()

    def _ctx_place_tile(self, col, row, tool):
        """Place a tile via context menu - undo-able."""
        m = self.model
        old = [dict(o) for o in m.objects_at(col, row)]
        if tool == "guard":
            new_obj = {"type": "guard", "col": col, "row": row,
                       "wp_nodes": [{"col": col, "row": row, "type": "waypoint"}]}
        elif tool == "door":
            new_obj = {"type": "door", "col": col, "row": row, "open": False}
        else:
            new_obj = {"type": tool, "col": col, "row": row}
        m.remove_at(col, row)
        m.objects.append(new_obj)
        cmd = _PlaceTileCmd(m, [(col, row, dict(new_obj), old)], f"Place {tool}")
        self._undo_stack.push(cmd)
        self._mark_unsaved()
        self._refresh_guard_list()
        self.canvas.update()

    def _ctx_erase_tile(self, col, row):
        """Erase tile via context menu - undo-able."""
        m = self.model
        old = [dict(o) for o in m.objects_at(col, row)]
        if not old:
            return
        m.remove_at(col, row)
        cmd = _PlaceTileCmd(m, [(col, row, None, old)], "Erase")
        self._undo_stack.push(cmd)
        self._mark_unsaved()
        self._refresh_guard_list()
        self.canvas.update()

    def _start_wp_mode_for(self, guard_obj):
        """Start waypoint editing for a specific guard."""
        self.canvas.selected_guard = guard_obj
        self._on_guard_selected(guard_obj)
        self._start_wp_mode()

    def _on_selection_changed(self, tiles):
        count = len(tiles)
        if count:
            self._set_status(f"  {count} tile(s) selected  |  Del=erase  |  dbl-click=edit props")
        else:
            self._set_status("  Ready")

    def _on_tool_change(self, tool):
        self._status_tool.setText(f"  Tool: {tool.upper()}")
        self.canvas.current_tool = tool
        if self.wp_mode and tool != "guard":
            self._exit_wp_mode()
        self.canvas.update()

    def _on_story_tile_selected(self, tile_type: str):
        """Activate a story-dev tile type as the current canvas tool."""
        self.canvas.current_tool = tile_type
        self._status_tool.setText(f"  Tool: {tile_type.upper().replace('_', ' ')}")
        if self.wp_mode:
            self._exit_wp_mode()
        self.canvas.update()

    def _on_wp_tool_change(self, wt):
        self.canvas.current_wp_tool = wt
        self._status_tool.setText(f"  WP Tool: {wt.upper().replace('_',' ')}")
        self.canvas.update()

    def _on_guard_selected(self, guard_obj):
        self.canvas.selected_guard = guard_obj
        # Migrate to wp_nodes if needed
        if guard_obj:
            self.model._ensure_wp_nodes(guard_obj)
        # Show wp toolbar whenever a guard is active
        self._enter_wp_mode()
        self.canvas.update()

    def _enter_wp_mode(self):
        if not self.canvas.selected_guard:
            return
        self.wp_mode = True
        self.canvas.wp_mode = True
        self.wp_toolbar.setVisible(True)
        self.canvas.selected_wp_idx = -1
        g = self.canvas.selected_guard
        self.panel.refresh_waypoints(g)
        self._set_status("  WAYPOINT MODE — select tool to pick/drag nodes, "
                         "place tools to add new nodes, Del=remove, arrows=nudge")

    def _exit_wp_mode(self):
        self.wp_mode = False
        self.canvas.wp_mode = False
        self.wp_toolbar.setVisible(False)
        self.canvas.selected_wp_idx = -1
        self.canvas._wp_dragging    = False

    def _start_wp_mode(self):
        if not self.canvas.selected_guard:
            QMessageBox.information(self, "No Guard Selected",
                                    "Select a guard from the list first.")
            return
        self._enter_wp_mode()
        self.canvas.update()

    def _on_wp_node_clicked(self, idx):
        """Canvas reported a node was selected or deselected."""
        g = self.canvas.selected_guard
        if g:
            self.model._sync_legacy(g)
            self.panel.refresh_waypoints(g, selected_idx=idx)
            if idx >= 0:
                nodes = g.get("wp_nodes", [])
                if 0 <= idx < len(nodes):
                    n = nodes[idx]
                    nt = n.get("type","waypoint")
                    self._set_status(
                        f"  Node {idx}: {nt.upper()} @ ({n['col']},{n['row']})  "
                        f"|  arrows=nudge  Del=remove  dbl-click=properties")
        self._mark_unsaved()
        self.canvas.update()

    def _on_wp_node_dblclick(self, idx):
        """Open property editor for a waypoint node."""
        g = self.canvas.selected_guard
        if not g:
            return
        nodes = self.model._ensure_wp_nodes(g)
        if not (0 <= idx < len(nodes)):
            return
        node = nodes[idx]
        dlg  = WaypointPropertyDialog(node, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            result = dlg.result_data()
            node.clear(); node.update(result)
            self.model._sync_legacy(g)
            self.panel.refresh_waypoints(g, selected_idx=idx)
            self._mark_unsaved()
            self.canvas.update()

    def _clear_waypoints(self):
        g = self.canvas.selected_guard
        if g:
            spawn = [g["col"], g["row"]]
            g["waypoints"]   = [spawn]
            g["pause_flags"] = [False]
            g["wp_nodes"]    = [{"col": g["col"], "row": g["row"], "type": "waypoint"}]
            self.canvas.selected_wp_idx = -1
            self.panel.refresh_waypoints(g)
            self._mark_unsaved()
            self.canvas.update()

    def _remove_waypoint(self, idx):
        g = self.canvas.selected_guard
        if g:
            self.model.remove_waypoint(g, idx)
            if self.canvas.selected_wp_idx >= idx:
                self.canvas.selected_wp_idx = max(-1, self.canvas.selected_wp_idx - 1)
            self.panel.refresh_waypoints(g, self.canvas.selected_wp_idx)
            self._mark_unsaved()
            self.canvas.update()

    def _toggle_pause(self, idx):
        g = self.canvas.selected_guard
        if g:
            self.model.toggle_pause_flag(g, idx)
            self.panel.refresh_waypoints(g, self.canvas.selected_wp_idx)
            self._mark_unsaved()
            self.canvas.update()

    def _refresh_guard_list(self):
        self.panel.refresh_guards(self.model.guards())
        # Also refresh snitches tab
        snitches = [o for o in self.model.objects if o.get("type") == "snitch"]
        self.panel.refresh_snitches(snitches)
        if hasattr(self, "_conn_panel"):
            self._conn_panel.refresh()

    def _resize_level(self):
        self.model.cols = self.panel.cols_spin.value()
        self.model.rows = self.panel.rows_spin.value()
        self.model.objects = [
            o for o in self.model.objects
            if 0 <= o["col"] < self.model.cols and 0 <= o["row"] < self.model.rows
        ]
        self._mark_unsaved()
        self.canvas.update()

    def _retile_level(self):
        self.model.tile_size = self.panel.tile_spin.value()
        self._mark_unsaved()

    def _rename_level(self, name):
        self.model.name = name
        self._mark_unsaved()

    def _clear_all(self):
        r = QMessageBox.question(self, "Clear All", "Remove all objects?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if r == QMessageBox.StandardButton.Yes:
            self.model.clear()
            self._mark_unsaved()
            self._refresh_guard_list()
            self.canvas.update()

    def _fill_border(self):
        m = self.model
        for c in range(m.cols):
            m.place(c, 0, "wall"); m.place(c, m.rows-1, "wall")
        for r in range(1, m.rows-1):
            m.place(0, r, "wall"); m.place(m.cols-1, r, "wall")
        self._mark_unsaved()
        self.canvas.update()

    def _fill_enclosed(self):
        """Flood-fill from outside the level to find open space,
        then fill any enclosed area that wasn't reached as walls.
        A dialog lets user pick a seed tile to fill just one enclosed region."""
        m = self.model
        walls = {(o["col"], o["row"]) for o in m.objects
                 if o["type"] in ("wall", "invisible_wall")}

        # Flood fill from (0,0) outward — everything reachable from edge is 'outside'
        outside = set()
        queue = []
        for c in range(m.cols):
            for start_r in (0, m.rows - 1):
                k = (c, start_r)
                if k not in walls and k not in outside:
                    outside.add(k)
                    queue.append(k)
        for r in range(m.rows):
            for start_c in (0, m.cols - 1):
                k = (start_c, r)
                if k not in walls and k not in outside:
                    outside.add(k)
                    queue.append(k)

        while queue:
            col, row = queue.pop()
            for dc, dr in ((1,0),(-1,0),(0,1),(0,-1)):
                nc, nr = col+dc, row+dr
                if 0 <= nc < m.cols and 0 <= nr < m.rows:
                    k = (nc, nr)
                    if k not in walls and k not in outside:
                        outside.add(k)
                        queue.append(k)

        # Enclosed = all non-wall tiles not reachable from outside
        enclosed = set()
        for r in range(m.rows):
            for c in range(m.cols):
                k = (c, r)
                if k not in walls and k not in outside:
                    enclosed.add(k)

        if not enclosed:
            QMessageBox.information(self, "Fill Enclosed",
                                    "No enclosed spaces found.\n"
                                    "Make sure walls form complete boundaries.")
            return

        reply = QMessageBox.question(
            self, "Fill Enclosed Space",
            f"Found {len(enclosed)} enclosed tile(s).\n"
            "Fill all of them with walls?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            for (c, r) in enclosed:
                m.place(c, r, "wall")
            self._mark_unsaved()
            self.canvas.update()

    def _choose_region_id(self):
        """Let user select which region ID to paint."""
        from PyQt6.QtWidgets import QInputDialog
        rid, ok = QInputDialog.getInt(
            self, "Region ID", "Active region ID (1–9):",
            self.canvas._active_region_id, 1, 9)
        if ok:
            self.canvas._active_region_id = rid
            self._set_status_right(f"  Active region ID set to {rid}")

    # ── File ops ───────────────────────────────────────────────────────────────
    def new_level(self):
        if self.unsaved:
            r = QMessageBox.question(self, "Unsaved changes", "Save before new level?",
                QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard |
                QMessageBox.StandardButton.Cancel)
            if r == QMessageBox.StandardButton.Save:
                if not self.save_level(): return
            elif r == QMessageBox.StandardButton.Cancel: return
        self.model = LevelModel()
        self.filepath = None; self.unsaved = False
        self._undo_stack.clear()
        self.panel.name_edit.setText("Untitled")
        self.panel.cols_spin.setValue(DEFAULT_COLS)
        self.panel.rows_spin.setValue(DEFAULT_ROWS)
        self.panel.tile_spin.setValue(DEFAULT_TILE)
        self.canvas.set_model(self.model)
        self._refresh_guard_list()
        self._set_title()

    def open_level(self):
        path, ok = LevelBrowserDialog.get_open(self, "Open Level", ".ler")
        if not ok or not path: return
        try:
            real = _ler_json_path(path)
            with open(real, encoding="utf-8") as f: data = json.load(f)
            self.model = LevelModel.from_json(data)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load:\n{e}"); return
        self.filepath = path; self.unsaved = False
        # Auto-enable MP mode if the file lives under ~/mplevels/
        _mplevels = os.path.normpath(
            os.path.join(os.path.expanduser("~"), "mplevels"))
        if os.path.normpath(os.path.abspath(path)).startswith(_mplevels):
            self.mp_mode = True
            if hasattr(self, 'panel') and hasattr(self.panel, 'project_tree'):
                self.panel.project_tree.mp_mode = True
        self._undo_stack.clear()
        for _w in (self.panel.cols_spin, self.panel.rows_spin,
                   self.panel.tile_spin, self.panel.name_edit):
            _w.blockSignals(True)
        self.canvas.set_model(self.model)
        self.panel.name_edit.setText(self.model.name)
        self.panel.cols_spin.setValue(self.model.cols)
        self.panel.rows_spin.setValue(self.model.rows)
        self.panel.tile_spin.setValue(self.model.tile_size)
        for _w in (self.panel.cols_spin, self.panel.rows_spin,
                   self.panel.tile_spin, self.panel.name_edit):
            _w.blockSignals(False)
        self._refresh_guard_list()
        self._set_title()
        # ── Integrity check: warn about missing tile assets ────────────────
        required = _collect_required_tiles_kr(data)
        missing  = _missing_tile_assets_kr(required)
        if missing:
            by_tile: dict = {}
            for tt, kind in missing:
                by_tile.setdefault(tt, []).append(kind)
            lines = ["This level references tile types with missing asset files:\n"]
            for tt, kinds in sorted(by_tile.items()):
                desc = []
                if "let"         in kinds: desc.append(f"{tt}.let")
                if "keyring_lev" in kinds: desc.append(f"{tt}_keyring.lev")
                lines.append(f"  {tt}: {', '.join(desc)}")
            level_stem = os.path.splitext(os.path.basename(path))[0]
            lines += [
                "",
                f"Run  python build_{level_stem}.py  (in the level folder) to",
                "auto-create placeholder files, then edit them to define visuals.",
                "",
                "Tiles without asset files will show as '?' in the editor.",
            ]
            QMessageBox.warning(self, "Missing Tile Assets", "\n".join(lines))

    def save_level(self):
        if not self.filepath: return self.save_level_as()
        return self._write(self.filepath)

    def save_level_as(self):
        if self.mp_mode:
            save_dir = os.path.join(os.path.expanduser("~"), "mplevels")
        else:
            save_dir = "levels"
        os.makedirs(save_dir, exist_ok=True)
        path, ok = LevelBrowserDialog.get_save(self, "Save Room", ".ler",
                                               start_dir=save_dir)
        if not ok or not path: return False
        return self._write(path)

    def _write(self, path):
        try:
            _save_ler_bundle(self.model.to_json(), path)
            self.filepath = path; self.unsaved = False
            # Auto-enable MP mode if saved inside ~/mplevels/
            _mplevels = os.path.normpath(
                os.path.join(os.path.expanduser("~"), "mplevels"))
            if os.path.normpath(os.path.abspath(path)).startswith(_mplevels):
                self.mp_mode = True
                if hasattr(self, 'panel') and hasattr(self.panel, 'project_tree'):
                    self.panel.project_tree.mp_mode = True
            self._undo_stack.setClean()
            self._set_title()
            self._set_status(f"  Saved \u2192 {path}")
            return True
        except Exception as e:
            QMessageBox.critical(self, "Save Error", str(e))
            return False

    def run_level(self):
        if not self.filepath:
            r = QMessageBox.question(self, "Save first",
                "Save before running?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if r == QMessageBox.StandardButton.Yes:
                if not self.save_level(): return
            else: return
        game = os.path.join(os.path.dirname(os.path.abspath(__file__)), "lockesc.py")
        if not os.path.exists(game):
            QMessageBox.warning(self, "Not found", f"lockesc.py not found at:\n{game}")
            return
        subprocess.Popen([sys.executable, game, self.filepath])

    def _mark_unsaved(self):
        self.unsaved = True; self._set_title()

    def _on_undo_clean_changed(self, clean):
        """Called by QUndoStack when clean state changes."""
        if not clean:
            self.unsaved = True
        self._set_title()

    def _show_conn_panel(self):
        """Show (or raise) the IO connections floating panel."""
        self._conn_panel.refresh()
        self._conn_panel.show()
        self._conn_panel.raise_()

    def _set_title(self):
        name = self.model.name or "Untitled"
        fp   = f" – {self.filepath}" if self.filepath else ""
        dot  = " •" if self.unsaved else ""
        mp   = "  [MP]" if self.mp_mode else ""
        self.setWindowTitle(f"KeyRing – LockESC Editor{dot}{mp} – {name}{fp}")

    def _set_status(self, msg): self._status_left.setText(msg)
    def _set_status_right(self, msg): self._status_right.setText(msg)

    def _about(self):
        QMessageBox.about(self, "About",
            "<b>LockESC – KeyRing Editor v5</b><br>"
            "Hammer-style editor for LockESC (pygame)<br><br>"
            "• Left-drag: paint tiles<br>"
            "• Right-click: erase<br>"
            "• SELECT tool: drag to marquee-select<br>"
            "• Double-click tile: edit properties<br>"
            "• Alt+Enter: edit hovered tile<br>"
            "• Double-click waypoint in list: toggle pause<br>"
            "• Pause (ring) waypoints: guard lingers and looks around<br>"
            "• F5: run level")

    def _edit_room_props(self):
        """Open the Room Properties dialog (is_shop flag, etc.)."""
        dlg = RoomPropertiesDialog(self.model, self)
        if dlg.exec():
            self.model.is_shop   = dlg.is_shop_cb.isChecked()
            # Notify toolbar to show/hide shop tab
            self.toolbar.set_shop_mode(self.model.is_shop)
            self.unsaved = True
            self._set_title()



    def closeEvent(self, e):
        if self.unsaved:
            r = QMessageBox.question(self, "Unsaved", "Save before quitting?",
                QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard |
                QMessageBox.StandardButton.Cancel)
            if r == QMessageBox.StandardButton.Save:
                if not self.save_level(): e.ignore(); return
            elif r == QMessageBox.StandardButton.Cancel:
                e.ignore(); return
        e.accept()


# ════════════════════════════════════════════════════════════════════════════
# Integrity Editor – standalone visual configuration tool
# ════════════════════════════════════════════════════════════════════════════
IMAGE_FILTER = "Images (*.png *.jpg *.bmp *.gif *.svg);;All Files (*)"

# ── In-process pixmap cache (keyed by (abs_path, size)) ─────────────────────
_PIXMAP_CACHE = {}   # (abs_path, size) -> QPixmap | None


def _pixmap_for_path(path, size=(64, 64)):
    """
    Return a QPixmap preview for any image or SVG path, or None.

    Results are cached in _PIXMAP_CACHE so thumbnails throughout the
    IntegrityEditor never re-read the same file twice.  The cache also
    doubles as the backing store for bake_images_to_assets(), which
    writes every cached QPixmap as a PNG into _assets/ so the game engine
    can load sprites without cairosvg/Inkscape on the target machine.
    """
    path = path.strip() if path else ""
    if not path or not os.path.exists(path):
        return None
    abs_path = os.path.normpath(os.path.abspath(path))
    key = (abs_path, size)
    if key in _PIXMAP_CACHE:
        return _PIXMAP_CACHE[key]
    try:
        if abs_path.lower().endswith(".svg"):
            from PyQt6.QtSvg import QSvgRenderer
            from PyQt6.QtGui  import QImage
            renderer = QSvgRenderer(abs_path)
            if not renderer.isValid():
                _PIXMAP_CACHE[key] = None
                return None
            img = QImage(size[0], size[1], QImage.Format.Format_ARGB32)
            img.fill(0)
            p = QPainter(img)
            renderer.render(p)
            p.end()
            pix = QPixmap.fromImage(img)
        else:
            pix = QPixmap(abs_path)
            if pix.isNull():
                _PIXMAP_CACHE[key] = None
                return None
            pix = pix.scaled(size[0], size[1],
                             Qt.AspectRatioMode.KeepAspectRatio,
                             Qt.TransformationMode.SmoothTransformation)
        _PIXMAP_CACHE[key] = pix
        return pix
    except Exception:
        _PIXMAP_CACHE[key] = None
        return None


def _clear_pixmap_cache():
    """Discard all cached pixmaps (call after loading a new room/project)."""
    _PIXMAP_CACHE.clear()


def bake_images_to_assets(visuals, assets_dir, src_file):
    """
    For every asset path in *visuals* that refers to an SVG (or any image):

    1. Load the image via _pixmap_for_path at the engine's native tile size (48x48).
    2. Save it as a PNG into *assets_dir*.
    3. Return a dict {visuals_key: new_relative_path} for the baked files.

    This lets the project run on machines that do not have cairosvg / Inkscape
    installed, and means the game engine can load sprites with a plain
    pygame.image.load() call instead of going through the SVG pipeline.
    """
    import shutil
    from PyQt6.QtCore import QBuffer, QIODevice
    SPRITE_KEYS = [
        "background_image", "player_sprite", "guard_sprite",
        "snitch_sprite", "camera_sprite",
        "door_sprite", "oiled_door_sprite", "wall_sprite", "floor_sprite",
        "exit_sprite", "loot_sprite", "mini_loot_sprite", "main_loot_sprite",
        "crashdoor_sprite", "window_sprite", "hide_sprite",
        "fence_sprite", "pit_sprite", "creak_floor_sprite",
    ]
    BAKE_SIZE = (96, 96)   # 2x native tile for crispness; engine scales down
    os.makedirs(assets_dir, exist_ok=True)
    src_dir   = os.path.dirname(os.path.abspath(src_file))
    rewrites  = {}
    errors    = []

    for key in SPRITE_KEYS:
        raw = visuals.get(key, "")
        if not raw:
            continue
        # resolve path relative to the .ler file
        if os.path.isabs(raw):
            abs_src = raw
        else:
            abs_src = os.path.normpath(os.path.join(src_dir, raw))
        if not os.path.exists(abs_src):
            errors.append(f"Missing: {abs_src}")
            continue

        stem = os.path.splitext(os.path.basename(abs_src))[0]
        out_name = stem + "_baked.png"
        out_path = os.path.join(assets_dir, out_name)

        if abs_src.lower().endswith(".svg"):
            # Rasterise via Qt
            pix = _pixmap_for_path(abs_src, BAKE_SIZE)
            if pix is None:
                errors.append(f"Could not rasterise: {abs_src}")
                continue
            if not pix.save(out_path, "PNG"):
                errors.append(f"Could not save PNG: {out_path}")
                continue
        else:
            # Plain copy (already a raster format)
            shutil.copy2(abs_src, out_path)

        rel = os.path.join("_assets", out_name)
        rewrites[key] = rel

    return rewrites, errors


# ── Reusable row widgets ──────────────────────────────────────────────────────

class _AssetRow(QWidget):
    """Line-edit + browse button + live thumbnail for a file path."""
    def __init__(self, placeholder="", value="", parent=None):
        super().__init__(parent)
        h = QHBoxLayout(self)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(4)
        self._edit   = QLineEdit(value)
        self._edit.setPlaceholderText(placeholder)
        self._browse = QPushButton("…")
        self._browse.setFixedWidth(26)
        self._browse.setToolTip("Browse for image / SVG")
        self._thumb  = QLabel()
        self._thumb.setFixedSize(26, 26)
        self._thumb.setStyleSheet(
            "border:1px solid #2a3040; background:#0a0c12; border-radius:2px;")
        self._thumb.setAlignment(Qt.AlignmentFlag.AlignCenter)
        h.addWidget(self._edit, 1)
        h.addWidget(self._browse)
        h.addWidget(self._thumb)
        self._browse.clicked.connect(self._do_browse)
        self._edit.textChanged.connect(self._refresh_thumb)
        self._refresh_thumb(value)

    def _do_browse(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Asset", "", IMAGE_FILTER)
        if path:
            self._edit.setText(path)

    def _refresh_thumb(self, path):
        pix = _pixmap_for_path(path.strip(), (24, 24))
        if pix:
            self._thumb.setPixmap(pix)
            self._thumb.setToolTip(path.strip())
        else:
            self._thumb.setPixmap(QPixmap())
            self._thumb.setToolTip("(no preview)")

    def text(self):       return self._edit.text().strip()
    def setText(self, v): self._edit.setText(v)


class _ColourRow(QWidget):
    """R,G,B[,A] text entry + live colour swatch + optional colour-picker button."""
    def __init__(self, placeholder="R, G, B", value=None, has_alpha=False,
                 parent=None):
        super().__init__(parent)
        self._has_alpha = has_alpha
        h = QHBoxLayout(self)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(4)
        self._edit = QLineEdit()
        ph = "R, G, B, A" if has_alpha else "R, G, B"
        self._edit.setPlaceholderText(ph + "  (0–255)")
        self._swatch = QLabel()
        self._swatch.setFixedSize(26, 20)
        self._swatch.setStyleSheet(
            "border:1px solid #2a3040; background:#0a0c12; border-radius:2px;")
        self._swatch.setToolTip("Click to open colour picker")
        self._swatch.mousePressEvent = lambda _: self._open_picker()
        if value:
            self._edit.setText(", ".join(str(x) for x in value))
        h.addWidget(self._edit, 1)
        h.addWidget(self._swatch)
        self._edit.textChanged.connect(self._refresh)
        self._refresh("")

    def _refresh(self, _):
        col = self._parse()
        if col:
            r, g, b = col[0], col[1], col[2]
            self._swatch.setStyleSheet(
                f"background:rgb({r},{g},{b}); border:1px solid #555;"
                " border-radius:2px;")
        else:
            self._swatch.setStyleSheet(
                "border:1px solid #2a3040; background:#0a0c12; border-radius:2px;")

    def _parse(self):
        txt = self._edit.text().strip()
        if not txt:
            return None
        parts = [p.strip() for p in txt.replace(";", ",").split(",") if p.strip()]
        try:
            vals = [max(0, min(255, int(p))) for p in parts]
            need = 4 if self._has_alpha else 3
            return vals[:need] if len(vals) >= 3 else None
        except ValueError:
            return None

    def _open_picker(self):
        from PyQt6.QtWidgets import QColorDialog
        cur = self._parse()
        init = QColor(cur[0], cur[1], cur[2]) if cur else QColor(128, 128, 128)
        col = QColorDialog.getColor(init, self, "Pick Colour")
        if col.isValid():
            if self._has_alpha:
                self._edit.setText(f"{col.red()}, {col.green()}, {col.blue()}, {col.alpha()}")
            else:
                self._edit.setText(f"{col.red()}, {col.green()}, {col.blue()}")

    def value(self): return self._parse()
    def text(self):  return self._edit.text().strip()
    def setValue(self, lst):
        self._edit.setText(", ".join(str(x) for x in lst))


# ── Monicle launcher (replaces IntegrityEditor) ──────────────────────────────
# The full implementation lives in .editortools/monicle.py.
# This stub launches it as a subprocess so it runs in its own window / event
# loop and returns cleanly when the user closes it.

def _launch_monicle():
    """Launch Monicle Editor in a subprocess (non-blocking)."""
    import subprocess
    # Primary: .editortools/ at project root (next to keyring.py)
    script = os.path.join(_PROJECT_ROOT, ".editortools", "monicle.py")
    # Fallback: alongside this file (legacy layout)
    if not os.path.isfile(script):
        script = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              ".editortools", "monicle.py")
    if not os.path.isfile(script):
        QMessageBox.critical(None, "Monicle",
                             f"Cannot find Monicle:\n{script}")
        return
    subprocess.Popen([sys.executable, script], cwd=_PROJECT_ROOT)

def _launch_forgemason(action: str = "", path: str = ""):
    """
    Launch Forgemason Tile + Tag Editor in a subprocess (non-blocking).

    action : one of  ''  'new_tile'  'load_tile'  'new_tag'  'load_tag'
    path   : file path passed via --path when action is a load variant
    """
    import subprocess
    script = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          ".editortools", "forgemason.py")
    if not os.path.isfile(script):
        QMessageBox.critical(None, "Forgemason",
                             f"Cannot find Forgemason:\n{script}")
        return
    args = [sys.executable, script]
    if action:
        args += ["--action", action]
    if path:
        args += ["--path", path]
    subprocess.Popen(args)



# ── IntegrityEditor kept for reference (no longer shown in UI) ───────────────

class IntegrityEditor(QDialog):
    """
    Standalone visual-configuration tool for LockESC.

    Works directly with .ler (room) and .lep (project) files — open them
    with the buttons in the toolbar. Both can be open simultaneously.

    Configures EVERY visual property:
      Colours  – every colour constant the engine uses (walls, floor, guards,
                 player, loot, doors, HUD, noise rings, FOV cones …)
      Assets   – background image, player/guard/door/wall/floor/loot sprites
                 PNG, JPG, BMP, GIF, and SVG all supported.

    Export Assets  – copies every referenced file into an _assets/ folder
                     next to the project and rewrites paths to relative, so
                     the whole project folder is self-contained and portable.

    Save & Close / Close → both return to KeyRingWelcome.
    """

    # Every colour the engine uses.
    # (visuals_key, display_label, default_value, has_alpha_channel)
    COLOUR_KEYS = [
        # World / environment
        ("bg_color",             "World background",        [10,  13,  28],      False),
        ("floor_color_a",        "Floor tile A",            [20,  46,  84],      False),
        ("floor_color_b",        "Floor tile B",            [16,  38,  70],      False),
        ("wall_color",           "Wall fill",               [18,  26,  52],      False),
        ("wall_edge_color",      "Wall edge / bevel",       [35,  52,  95],      False),
        ("window_color",         "Window",                  [80, 160, 200],      False),
        ("fence_color",          "Fence",                   [90, 120,  70],      False),
        ("pit_color",            "Pit void",                [12,  16,  36],      False),
        ("creak_floor_color",    "Creak floor",             [55,  80, 130],      False),
        ("hide_color",           "Hide spot",               [55,  90, 155],      False),
        ("hide_active_color",    "Hide spot (player on)",   [90, 150, 220],      False),
        ("noisemaker_color",     "Noisemaker",              [200, 100, 220],     False),
        # Doors
        ("door_open_color",      "Door – open",             [140, 100,  40],     False),
        ("door_closed_color",    "Door – closed",           [ 75,  50,  18],     False),
        ("door_bashed_color",    "Door – bashed open",      [220,  80,  20],     False),
        ("oiled_door_open_color","Oiled door – open",       [100, 160,  60],     False),
        ("oiled_door_closed_color","Oiled door – closed",   [ 55,  90,  30],     False),
        ("wall_door_open_color", "Wall door – open",        [ 90,  70, 140],     False),
        ("crashdoor_open_color", "Crash-door – open",       [180,  60,  20],     False),
        ("crashdoor_closed_color","Crash-door – closed",    [ 90,  30,  10],     False),
        # Collectibles & exit
        ("loot_color",           "Loot",                    [255, 210,   0],     False),
        ("loot_glow_color",      "Loot inner glow",         [255, 245, 140],     False),
        ("mini_loot_color",      "Mini loot",               [200, 165,   0],     False),
        ("main_loot_color",      "Main loot",               [255,  80,  20],     False),
        ("main_loot_glow_color", "Main loot glow",          [255, 160,  80],     False),
        ("exit_open_color",      "Exit – unlocked",         [  0, 220, 120],     False),
        ("exit_locked_color",    "Exit – locked",           [  0,  80,  50],     False),
        # Player
        ("player_color",         "Player",                  [220,  55,  75],     False),
        ("player_sprint_color",  "Player – sprinting",      [255, 110,  40],     False),
        ("player_hidden_color",  "Player – hidden",         [ 55,  75, 125],     False),
        # Guards – body colours
        ("guard_patrol_color",   "Guard – patrol",          [240, 170,  30],     False),
        ("guard_alert_color",    "Guard – alert",           [255, 130,   0],     False),
        ("guard_chase_color",    "Guard – chase",           [255,  40,  40],     False),
        ("guard_inspect_color",  "Guard – inspect",         [ 80, 180, 255],     False),
        ("guard_search_color",   "Guard – search",          [200,  60, 255],     False),
        # Snitch & camera
        ("snitch_color",         "Snitch",                  [200, 130,  40],     False),
        ("camera_color",         "Security camera",         [140, 200,  70],     False),
        # I/O nodes
        ("transmit_node_color",  "Transmit node",           [ 60, 200, 210],     False),
        ("receive_node_color",   "Receive node",            [210, 170,  60],     False),
        # Guards – FOV cones (RGBA fills)
        ("fov_patrol_fill",      "FOV cone – patrol (RGBA)",[240, 170, 30,  20], True),
        ("fov_alert_fill",       "FOV cone – alert  (RGBA)",[255, 130,  0,  35], True),
        ("fov_chase_fill",       "FOV cone – chase  (RGBA)",[255,  40, 40,  40], True),
        ("fov_search_fill",      "FOV cone – search (RGBA)",[200,  60,255,  38], True),
        ("fov_snitch_fill",      "FOV cone – snitch (RGBA)",[200, 130, 40,  25], True),
        ("fov_camera_fill",      "FOV cone – camera (RGBA)",[140, 200, 70,  22], True),
        # Waypoints
        ("waypoint_color",       "Waypoint dot",            [ 70, 140, 200],     False),
        ("waitpoint_color",      "Wait-point ring",         [200, 160,  60],     False),
        # Noise
        ("noise_ring_color",     "Noise ring",              [255, 170,   0],     False),
        # HUD
        ("hud_bg_color",         "HUD bar background",      [  7,   9,  22],     False),
        ("hud_text_color",       "HUD text",                [255, 255, 255],     False),
        ("hud_dim_color",        "HUD dim / label text",    [150, 155, 175],     False),
    ]

    # Every asset slot the engine can use.
    # (visuals_key, display_label)
    ASSET_KEYS = [
        ("background_image",    "Background (tiled)"),
        ("player_sprite",       "Player sprite"),
        ("guard_sprite",        "Guard sprite"),
        ("snitch_sprite",       "Snitch sprite"),
        ("camera_sprite",       "Camera sprite"),
        ("door_sprite",         "Door (open) sprite"),
        ("oiled_door_sprite",   "Oiled door sprite"),
        ("wall_sprite",         "Wall tile sprite"),
        ("floor_sprite",        "Floor tile sprite"),
        ("exit_sprite",         "Exit sprite"),
        ("loot_sprite",         "Loot sprite"),
        ("mini_loot_sprite",    "Mini loot sprite"),
        ("main_loot_sprite",    "Main-loot sprite"),
        ("crashdoor_sprite",    "Crash-door sprite"),
        ("window_sprite",       "Window sprite"),
        ("hide_sprite",         "Hide-spot sprite"),
        ("fence_sprite",        "Fence sprite"),
        ("pit_sprite",          "Pit sprite"),
        ("creak_floor_sprite",  "Creak floor sprite"),
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Integrity Editor  –  LockESC")
        self.resize(800, 700)
        self.setWindowFlags(
            self.windowFlags()
            | Qt.WindowType.WindowMaximizeButtonHint
            | Qt.WindowType.WindowMinimizeButtonHint
        )

        # raw JSON dicts of currently-open files
        self._room_raw    = None   # dict
        self._room_path   = None
        self._proj_raw    = None   # dict
        self._proj_path   = None

        # widget dicts keyed by scope ("room" / "project")
        self._colour_rows = {"room": {}, "project": {}}
        self._asset_rows  = {"room": {}, "project": {}}

        self.setStyleSheet("""
            QDialog {
                background: #0d0f17;
                color: #b8c8d8;
                font: 11px Consolas;
            }
            QTabWidget::pane {
                border: 1px solid #1e2838;
                background: #10121a;
            }
            QTabBar::tab {
                background: #141820;
                color: #4a6070;
                padding: 7px 22px;
                border: 1px solid #1e2838;
                border-bottom: none;
                font: bold 10px Consolas;
                letter-spacing: 1px;
            }
            QTabBar::tab:selected {
                background: #10121a;
                color: #90b8d8;
            }
            QTabBar::tab:hover { color: #70a0c0; }
            QGroupBox {
                border: 1px solid #1e2a3a;
                border-radius: 4px;
                margin-top: 12px;
                padding: 10px 8px 8px 8px;
                font: bold 10px Consolas;
                color: #3a6080;
                letter-spacing: 1px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
            }
            QLabel { color: #607888; }
            QLineEdit {
                background: #080a10;
                color: #a0b8c8;
                border: 1px solid #1e2838;
                border-radius: 3px;
                padding: 3px 6px;
                font: 11px Consolas;
            }
            QLineEdit:focus { border-color: #3a6090; }
            QPushButton {
                background: #141c28;
                color: #6088a8;
                border: 1px solid #1e3048;
                border-radius: 3px;
                padding: 4px 12px;
                font: 10px Consolas;
            }
            QPushButton:hover  { background: #1c2838; color: #90b8d8;
                                 border-color: #3a6090; }
            QPushButton:pressed { background: #0e1420; }
            QScrollArea { border: none; background: transparent; }
            QScrollBar:vertical {
                background: #0a0c14; width: 7px; border-radius: 3px;
            }
            QScrollBar::handle:vertical {
                background: #1e2a3a; border-radius: 3px; min-height: 20px;
            }
            QFormLayout QLabel { min-width: 160px; }
        """)
        self._build()

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── toolbar ──────────────────────────────────────────────────────────
        bar = QWidget()
        bar.setStyleSheet("background:#080a10; border-bottom:1px solid #181e28;")
        bar.setFixedHeight(48)
        bh = QHBoxLayout(bar)
        bh.setContentsMargins(12, 6, 12, 6)
        bh.setSpacing(6)

        title_lbl = QLabel("🎨  INTEGRITY EDITOR")
        title_lbl.setStyleSheet(
            "font:bold 15px Consolas; color:#3870b8; letter-spacing:1px;")
        bh.addWidget(title_lbl)
        bh.addStretch()

        for lbl, tip, slot in [
            ("Open Room…",    "Open a .ler room file",           self._open_room),
            ("Open Project…", "Open a .lep project file",        self._open_project),
            ("Save",          "Save open files",                  self._save),
            ("Export Assets…","Copy all assets into _assets/",   self._export_assets),
            ("Bake Images…",  "Rasterise SVGs → PNGs for portable use", self._bake_images),
        ]:
            b = QPushButton(lbl)
            b.setToolTip(tip)
            b.setFixedHeight(32)
            b.clicked.connect(slot)
            bh.addWidget(b)

        root.addWidget(bar)

        # ── file indicator ────────────────────────────────────────────────────
        self._file_lbl = QLabel(
            "  No file open  –  use Open Room… or Open Project… above")
        self._file_lbl.setStyleSheet(
            "background:#080a10; color:#253040; font:9px Consolas;"
            " padding:3px 14px; border-bottom:1px solid #141e2a;")
        root.addWidget(self._file_lbl)

        # ── tabs ─────────────────────────────────────────────────────────────
        self._tabs = QTabWidget()
        self._tabs.addTab(self._make_tab("room"),    "Room Visuals  (.ler)")
        self._tabs.addTab(self._make_tab("project"), "Project Defaults  (.lep)")
        root.addWidget(self._tabs, 1)

        # ── status / button bar ───────────────────────────────────────────────
        bot = QWidget()
        bot.setStyleSheet("background:#080a10; border-top:1px solid #181e28;")
        bot.setFixedHeight(44)
        bh2 = QHBoxLayout(bot)
        bh2.setContentsMargins(12, 6, 12, 6)
        bh2.setSpacing(6)

        self._status_lbl = QLabel("")
        self._status_lbl.setStyleSheet("color:#2a4050; font:9px Consolas;")
        bh2.addWidget(self._status_lbl, 1)

        save_close = QPushButton("✓  Save & Close")
        save_close.setStyleSheet(
            "QPushButton { background:#0e2018; color:#40b870;"
            " border:1px solid #1a4030; padding:6px 18px; }"
            "QPushButton:hover { background:#142a20; color:#60d890; }")
        close_btn = QPushButton("✕  Close")
        close_btn.setStyleSheet(
            "QPushButton { background:#180e0e; color:#a04040;"
            " border:1px solid #301818; padding:6px 14px; }"
            "QPushButton:hover { background:#201212; color:#d06060; }")
        save_close.clicked.connect(self._on_save_close)
        close_btn.clicked.connect(self._on_close)
        bh2.addWidget(save_close)
        bh2.addWidget(close_btn)
        root.addWidget(bot)

    def _make_tab(self, scope):
        """Build a scrollable tab with colour + asset sections for `scope`."""
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        inner = QWidget()
        v = QVBoxLayout(inner)
        v.setContentsMargins(14, 14, 14, 14)
        v.setSpacing(14)

        # ── Colours ───────────────────────────────────────────────────────────
        grp_c = QGroupBox("COLOURS")
        form_c = QFormLayout(grp_c)
        form_c.setSpacing(5)
        form_c.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        form_c.setFieldGrowthPolicy(
            QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)

        c_rows = {}
        for key, label, default, has_a in self.COLOUR_KEYS:
            row = _ColourRow(has_alpha=has_a)
            form_c.addRow(label + ":", row)
            c_rows[key] = row
        v.addWidget(grp_c)
        self._colour_rows[scope] = c_rows

        # ── Assets ────────────────────────────────────────────────────────────
        grp_a = QGroupBox("SPRITES  &  ASSETS")
        form_a = QFormLayout(grp_a)
        form_a.setSpacing(5)
        form_a.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        form_a.setFieldGrowthPolicy(
            QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)

        a_rows = {}
        for key, label in self.ASSET_KEYS:
            row = _AssetRow("path/to/asset.png  or  .svg")
            form_a.addRow(label + ":", row)
            a_rows[key] = row

        hint = QLabel(
            "PNG · JPG · BMP · GIF · SVG all supported.\n"
            "Sprites are rotated to face direction of travel.\n"
            "Use square images (48×48, 96×96) for best results.\n"
            "Paths may be absolute or relative to the .ler / .lep file.\n"
            "Use  Export Assets…  to bundle everything for shipping."
        )
        hint.setStyleSheet("color:#1e3040; font:9px Consolas; padding:4px 0 0 0;")
        form_a.addRow(hint)
        v.addWidget(grp_a)
        self._asset_rows[scope] = a_rows

        v.addStretch()
        scroll.setWidget(inner)
        return scroll

    # ── File operations ───────────────────────────────────────────────────────

    def _open_room(self):
        path, ok = LevelBrowserDialog.get_open(self, "Open Room (.ler)", ".ler")
        if not ok or not path:
            return
        try:
            real = _ler_json_path(path)
            with open(real, encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            QMessageBox.critical(self, "Open Room", f"Failed to load:\n{e}")
            return
        _clear_pixmap_cache()
        self._room_raw  = data
        self._room_path = path
        self.canvas.level_stem = os.path.splitext(os.path.basename(
            path.rstrip("/\\")))[0]
        self._populate("room", data.get("visuals", {}))
        self._refresh_file_label()
        self._tabs.setCurrentIndex(0)
        self._status(f"Room loaded: {os.path.basename(path)}")

    def _open_project(self):
        path, ok = LevelBrowserDialog.get_open(self, "Open Project (.lep)", ".lep")
        if not ok or not path:
            return
        try:
            real = _lep_json_path(path)
            with open(real, encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            QMessageBox.critical(self, "Open Project", f"Failed to load:\n{e}")
            return
        _clear_pixmap_cache()
        self._proj_raw  = data
        self._proj_path = path
        self.canvas.level_stem = os.path.splitext(os.path.basename(
            path.rstrip("/\\")))[0]
        self._populate("project", data.get("default_visuals", {}))
        self._refresh_file_label()
        self._tabs.setCurrentIndex(1)
        self._status(f"Project loaded: {os.path.basename(path)}")

    def _save(self):
        saved, errors = [], []
        if self._room_path and self._room_raw is not None:
            self._room_raw["visuals"] = self._collect("room")
            try:
                _save_ler_bundle(self._room_raw, self._room_path)
                saved.append("room")
            except Exception as e:
                errors.append(f"Room: {e}")

        if self._proj_path and self._proj_raw is not None:
            self._proj_raw["default_visuals"] = self._collect("project")
            try:
                _save_lep_bundle(self._proj_raw, self._proj_path)
                saved.append("project")
            except Exception as e:
                errors.append(f"Project: {e}")

        if errors:
            QMessageBox.critical(self, "Save Error", "\n".join(errors))
        if saved:
            self._status("Saved: " + ", ".join(saved))
        else:
            self._status("Nothing open to save — open a room or project first.")

    def _export_assets(self):
        """
        Copy every referenced asset file into the bundle's images/ folder
        (or _assets/ for project-level defaults), then rewrite stored paths
        to relative filenames. Makes the bundle self-contained for shipping.
        """
        base_path = self._proj_path or self._room_path
        if not base_path:
            QMessageBox.warning(self, "Export Assets",
                                "Open a room or project first.")
            return

        # For bundles, images go inside the bundle; for flat files, use _assets/
        def _assets_dir_for(path):
            if path and os.path.isdir(path):
                d = os.path.join(path, "images")
            else:
                d = os.path.join(os.path.dirname(os.path.abspath(path or ".")), "_assets")
            os.makedirs(d, exist_ok=True)
            return d

        import shutil
        copied, errors = 0, []

        for scope, raw, path_attr, vis_key in [
            ("room",    self._room_raw,  "_room_path",  "visuals"),
            ("project", self._proj_raw,  "_proj_path",  "default_visuals"),
        ]:
            if raw is None:
                continue
            src_file = getattr(self, path_attr)
            assets_dir = _assets_dir_for(src_file)
            vis = raw.get(vis_key, {})
            dirty = False

            for key, _ in self.ASSET_KEYS:
                old_val = vis.get(key, "")
                if not old_val:
                    continue
                if os.path.isabs(old_val):
                    abs_src = old_val
                else:
                    src_dir = (src_file if os.path.isdir(src_file)
                               else os.path.dirname(src_file))
                    for sub in ("images", "_assets", ""):
                        candidate = os.path.normpath(
                            os.path.join(src_dir, sub, old_val) if sub
                            else os.path.join(src_dir, old_val))
                        if os.path.exists(candidate):
                            abs_src = candidate; break
                    else:
                        abs_src = os.path.normpath(os.path.join(src_dir, old_val))
                if not os.path.exists(abs_src):
                    errors.append(f"Missing: {abs_src}")
                    continue

                dest_name = os.path.basename(abs_src)
                dest_path = os.path.join(assets_dir, dest_name)
                if (os.path.exists(dest_path) and
                        not os.path.samefile(abs_src, dest_path)):
                    stem, ext = os.path.splitext(dest_name)
                    dest_name = f"{stem}_{scope}{ext}"
                    dest_path = os.path.join(assets_dir, dest_name)

                shutil.copy2(abs_src, dest_path)
                # Store as plain filename (resolved from bundle/images/ at runtime)
                if vis[key] != dest_name:
                    vis[key] = dest_name
                    dirty = True
                copied += 1

            if dirty:
                raw[vis_key] = vis
                try:
                    if os.path.isdir(src_file):
                        if scope == "room":
                            _save_ler_bundle(raw, src_file)
                        else:
                            _save_lep_bundle(raw, src_file)
                    else:
                        with open(src_file, "w", encoding="utf-8") as f:
                            json.dump(raw, f, indent=2)
                    self._populate(scope, vis)
                except Exception as e:
                    errors.append(str(e))

        msg = f"Copied {copied} asset(s) → {assets_dir}"
        if errors:
            msg += "\n\nWarnings:\n" + "\n".join(errors)
        QMessageBox.information(self, "Export Assets", msg)
        self._status(f"Export done — {copied} file(s) in _assets/")

    # ── Bake Images ──────────────────────────────────────────────────────────

    def _bake_images(self):
        """
        Rasterise every SVG (and copy every raster) from the open room/project
        visuals into _assets/ as PNG files, then rewrite the stored paths.

        After baking, the level can be used on machines without cairosvg or
        Inkscape — the game engine will load plain PNGs via pygame.image.load().
        The pixmap cache is invalidated so the editor refreshes thumbnails from
        the new baked paths.
        """
        base_path = self._proj_path or self._room_path
        if not base_path:
            QMessageBox.warning(self, "Bake Images",
                                "Open a room or project first.")
            return

        base_dir   = os.path.dirname(os.path.abspath(base_path))
        assets_dir = os.path.join(base_dir, "_assets")
        total_baked, all_errors = 0, []

        for scope, raw, path_attr, vis_key in [
            ("room",    self._room_raw,  "_room_path",  "visuals"),
            ("project", self._proj_raw,  "_proj_path",  "default_visuals"),
        ]:
            if raw is None:
                continue
            src_file = getattr(self, path_attr)
            vis = raw.get(vis_key, {})
            rewrites, errors = bake_images_to_assets(vis, assets_dir, src_file)
            all_errors.extend(errors)
            if rewrites:
                vis.update(rewrites)
                raw[vis_key] = vis
                total_baked += len(rewrites)
                try:
                    with open(src_file, "w", encoding="utf-8") as f:
                        json.dump(raw, f, indent=2)
                    _clear_pixmap_cache()
                    self._populate(scope, vis)   # refresh UI thumbnails
                except Exception as e:
                    all_errors.append(str(e))

        msg = f"Baked {total_baked} image(s) → {assets_dir}"
        if all_errors:
            msg += "\n\nWarnings:\n" + "\n".join(all_errors)
        QMessageBox.information(self, "Bake Images", msg)
        self._status(f"Bake done — {total_baked} PNG(s) in _assets/")

    # ── Populate / collect ────────────────────────────────────────────────────

    def _populate(self, scope, visuals):
        """Fill every row widget from a visuals dict."""
        for key, _label, default, _ha in self.COLOUR_KEYS:
            w = self._colour_rows[scope].get(key)
            if w is None:
                continue
            val = visuals.get(key)
            w.setValue(val if val is not None else default)

        for key, _label in self.ASSET_KEYS:
            w = self._asset_rows[scope].get(key)
            if w is None:
                continue
            w.setText(visuals.get(key, ""))

    def _collect(self, scope):
        """Read every row widget back into a visuals dict."""
        vis = {}
        for key, _label, _default, _ha in self.COLOUR_KEYS:
            w = self._colour_rows[scope].get(key)
            if w:
                v = w.value()
                if v is not None:
                    vis[key] = v
        for key, _label in self.ASSET_KEYS:
            w = self._asset_rows[scope].get(key)
            if w:
                v = w.text()
                if v:
                    vis[key] = v
        return vis

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _refresh_file_label(self):
        parts = []
        if self._room_path:
            parts.append(f"Room: {os.path.basename(self._room_path)}")
        if self._proj_path:
            parts.append(f"Project: {os.path.basename(self._proj_path)}")
        txt = "   |   ".join(parts) if parts else \
              "No file open  –  use Open Room… or Open Project…"
        self._file_lbl.setText("  " + txt)

    def _status(self, msg):
        self._status_lbl.setText("  " + msg)

    def _on_save_close(self):
        self._save()
        self.accept()   # → back to KeyRingWelcome

    def _on_close(self):
        self.reject()   # → back to KeyRingWelcome


# ════════════════════════════════════════════════════════════════════════════
# KeyRing welcome / launcher screen
# ════════════════════════════════════════════════════════════════════════════

class KeyRingWelcome(QDialog):
    """
    Shown at launch and whenever KeyRing's editor window closes.
    Monicle is launched as a subprocess in its own window — it opens
    independently and does not block this screen.
    """
    A_NEW            = "new"
    A_ROOM           = "open_room"
    A_PROJECT        = "open_project"
    A_INTEG          = "monicle"
    A_FORGE          = "forgemason"
    A_MP_NEW         = "mp_new"
    A_MP_ROOM        = "mp_open_room"
    A_MP_PROJECT     = "mp_open_project"
    A_FORGE_NEW_TILE = "forge_new_tile"
    A_FORGE_LOAD_TILE= "forge_load_tile"
    A_FORGE_NEW_TAG  = "forge_new_tag"
    A_FORGE_LOAD_TAG = "forge_load_tag"

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("KeyRing  –  LockESC")
        self.setModal(True)
        self.resize(460, 620)
        self.action          = self.A_NEW
        self.chosen_path     = None
        self.mp_mode         = False   # True when a multiplayer action was chosen
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)
        self.setStyleSheet("""
            QDialog {
                background: #0a0c12;
                color: #b0c0d0;
            }
            QLabel { color: #b0c0d0; }
            QPushButton {
                background: #12182a;
                color: #6080a0;
                border: 1px solid #1e2e48;
                border-radius: 6px;
                padding: 11px 20px;
                font: bold 12px Consolas;
                text-align: left;
            }
            QPushButton:hover {
                background: #18223a;
                border-color: #3a5888;
                color: #a0c8e8;
            }
            QPushButton:pressed { background: #0e1420; }
            QFrame { background: #141c28; }
        """)
        self._build()

    # ─── page indices ───────────────────────────────────────────────────────
    _PAGE_LEVEL   = 0   # singleplayer / multiplayer level editor
    _PAGE_MONICLE = 1   # visual editor
    _PAGE_FORGE   = 2   # tile/tag forge

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ══ top nav bar ══════════════════════════════════════════════════════
        nav = QWidget()
        nav.setFixedHeight(46)
        nav.setStyleSheet("background:#060810;border-bottom:1px solid #121a2a;")
        nh = QHBoxLayout(nav)
        nh.setContentsMargins(14, 0, 14, 0)
        nh.setSpacing(0)

        # left arrow
        self._btn_prev = QPushButton("◀")
        self._btn_prev.setFixedSize(30, 30)
        self._btn_prev.setStyleSheet(
            "QPushButton{background:transparent;color:#203040;border:none;"
            "font:14px Consolas;border-radius:4px;padding:0;}"
            "QPushButton:hover{color:#5090c0;background:#0e1828;}"
            "QPushButton:disabled{color:#141e28;}")
        self._btn_prev.clicked.connect(self._page_prev)
        nh.addWidget(self._btn_prev)

        nh.addStretch(1)

        # page title
        self._nav_title = QLabel("")
        self._nav_title.setStyleSheet(
            "color:#3a6080;font:bold 10px Consolas;letter-spacing:3px;")
        self._nav_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        nh.addWidget(self._nav_title)

        # SP/MP toggle — only visible on level page
        self._mp_toggle = QPushButton("⇄ MP")
        self._mp_toggle.setCheckable(True)
        self._mp_toggle.setFixedHeight(26)
        self._mp_toggle.setStyleSheet(
            "QPushButton{background:#081808;color:#1a4828;border:1px solid #102018;"
            "border-radius:4px;padding:2px 10px;font:bold 9px Consolas;margin:0 8px;}"
            "QPushButton:hover{color:#40a868;border-color:#204830;}"
            "QPushButton:checked{background:#0c2818;color:#40c870;"
            "border-color:#30a858;}")
        self._mp_toggle.toggled.connect(self._on_mp_toggle)
        nh.addWidget(self._mp_toggle)

        nh.addStretch(1)

        # right arrow
        self._btn_next = QPushButton("▶")
        self._btn_next.setFixedSize(30, 30)
        self._btn_next.setStyleSheet(
            "QPushButton{background:transparent;color:#3060a0;border:none;"
            "font:14px Consolas;border-radius:4px;padding:0;}"
            "QPushButton:hover{color:#60a0e0;background:#0e1828;}"
            "QPushButton:disabled{color:#141e28;}")
        self._btn_next.clicked.connect(self._page_next)
        nh.addWidget(self._btn_next)

        root.addWidget(nav)

        # ══ page stack ═══════════════════════════════════════════════════════
        from PyQt6.QtWidgets import QStackedWidget
        self._stack = QStackedWidget()
        self._stack.setStyleSheet("background:#0a0c12;")
        root.addWidget(self._stack, 1)

        self._stack.addWidget(self._build_page_level())   # 0
        self._stack.addWidget(self._build_page_monicle()) # 1
        self._stack.addWidget(self._build_page_forge())   # 2

        # ══ footer ═══════════════════════════════════════════════════════════
        footer = QLabel("rooms: .ler    projects: .lep    assets: _assets/")
        footer.setStyleSheet(
            "color:#1a2e40;font:8px Consolas;padding:5px 18px;"
            "background:#060810;border-top:1px solid #0e1624;")
        root.addWidget(footer)

        self._cur_page = 0
        self._go_page(0)

    # ── page builders ─────────────────────────────────────────────────────────

    def _page_scroll(self, content_widget):
        """Wrap a widget in a scroll area with standard styling."""
        from PyQt6.QtWidgets import QScrollArea
        sa = QScrollArea()
        sa.setWidgetResizable(True)
        sa.setFrameShape(QFrame.Shape.NoFrame)
        sa.setStyleSheet(
            "QScrollArea{background:#0a0c12;border:none;}"
            "QScrollBar:vertical{background:#080c12;width:5px;margin:0;}"
            "QScrollBar::handle:vertical{background:#182030;border-radius:2px;}"
            "QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0;}")
        sa.setWidget(content_widget)
        return sa

    def _build_page_level(self):
        """Page 0 — level editor (SP and MP, toggled by the switch)."""
        outer = QWidget()
        outer.setStyleSheet("background:#0a0c12;")
        v = QVBoxLayout(outer)
        v.setContentsMargins(36, 0, 36, 16)
        v.setSpacing(0)

        # logo block
        logo = QLabel("🔑  KeyRing")
        logo.setStyleSheet(
            "font:bold 32px Consolas;color:#2060a8;letter-spacing:2px;"
            "padding-top:24px;")
        tagline = QLabel("LockESC Level Editor")
        tagline.setStyleSheet(
            "font:10px Consolas;color:#2a4860;margin-bottom:18px;")
        v.addWidget(logo); v.addWidget(tagline)

        sep = QFrame(); sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet("background:#121a28;margin-bottom:14px;")
        v.addWidget(sep)

        # SP pane — visible when MP toggle OFF
        self._sp_pane = QWidget()
        sp = QVBoxLayout(self._sp_pane)
        sp.setContentsMargins(0, 0, 0, 0); sp.setSpacing(5)

        sec_sp = QLabel("SINGLEPLAYER")
        sec_sp.setStyleSheet(
            "font:bold 8px Consolas;color:#3a6888;letter-spacing:4px;"
            "margin-bottom:4px;")
        sp.addWidget(sec_sp)

        for label, action, bg in [
            ("▶  New Room",               self.A_NEW,     "#0e1e0e"),
            ("📂  Open Room  (.ler)…",    self.A_ROOM,    "#0e1220"),
            ("📁  Open Project  (.lep)…", self.A_PROJECT, "#0e1220"),
        ]:
            b = QPushButton(label)
            b.setStyleSheet(
                f"QPushButton{{background:{bg};}}"
                "QPushButton:hover{background:#18223a;}")
            b.clicked.connect(lambda _, a=action: self._pick(a))
            sp.addWidget(b)

        v.addWidget(self._sp_pane)

        # MP pane — visible when MP toggle ON
        self._mp_pane = QWidget()
        mp = QVBoxLayout(self._mp_pane)
        mp.setContentsMargins(0, 0, 0, 0); mp.setSpacing(5)

        sec_mp = QLabel("MULTIPLAYER")
        sec_mp.setStyleSheet(
            "font:bold 8px Consolas;color:#208060;letter-spacing:4px;"
            "margin-bottom:2px;")
        mp.addWidget(sec_mp)

        mp_sub = QLabel(
            "  saves to ~/mplevels/  ·  unlocks player2, co-op properties")
        mp_sub.setStyleSheet(
            "font:9px Consolas;color:#1a4830;margin-bottom:6px;")
        mp.addWidget(mp_sub)

        for label, action, fg, border in [
            ("▶  New MP Room",               self.A_MP_NEW,     "#30a060", "#143820"),
            ("📂  Open MP Room  (.ler)…",    self.A_MP_ROOM,    "#2878a0", "#102030"),
            ("📁  Open MP Project  (.lep)…", self.A_MP_PROJECT, "#2878a0", "#102030"),
        ]:
            b = QPushButton(label)
            b.setStyleSheet(
                f"QPushButton{{background:#081408;color:{fg};"
                f"border:1px solid {border};}}"
                "QPushButton:hover{background:#0e2818;color:#50c888;"
                "border-color:#207848;}")
            b.clicked.connect(lambda _, a=action: self._pick(a))
            mp.addWidget(b)

        self._mp_pane.setVisible(False)
        v.addWidget(self._mp_pane)

        v.addStretch()
        return self._page_scroll(outer)

    def _build_page_monicle(self):
        """Page 1 — Monicle visual editor."""
        outer = QWidget()
        outer.setStyleSheet("background:#0a0c12;")
        v = QVBoxLayout(outer)
        v.setContentsMargins(36, 28, 36, 16)
        v.setSpacing(0)

        logo = QLabel("🔍  Monicle")
        logo.setStyleSheet(
            "font:bold 28px Consolas;color:#2858a0;letter-spacing:2px;"
            "margin-bottom:4px;")
        sub = QLabel("Visual Definition Editor")
        sub.setStyleSheet("font:10px Consolas;color:#2a4860;margin-bottom:18px;")
        v.addWidget(logo); v.addWidget(sub)

        sep = QFrame(); sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet("background:#121a28;margin-bottom:18px;")
        v.addWidget(sep)

        open_btn = QPushButton("🔍  Open Monicle Editor…")
        open_btn.setStyleSheet(
            "QPushButton{background:#0a1420;color:#3060a8;"
            "border:1px solid #162030;font:bold 13px Consolas;padding:14px 20px;}"
            "QPushButton:hover{background:#101e34;color:#5090c8;"
            "border-color:#2a4878;}")
        open_btn.clicked.connect(lambda: self._pick(self.A_INTEG))
        v.addWidget(open_btn)
        v.addSpacing(14)

        desc = QLabel(
            "Edit procedural tile visuals (.lev layer stacks)\n"
            "and assign PNG overrides per tile and per level.\n\n"
            "PNG priority:  level-specific -> global default -> .lev fallback\n"
            "Custom tiles (CUSTOM/) are always available.\n"
            "Built-in tile PNGs require dev.py to be present at runtime."
        )
        desc.setStyleSheet("font:9px Consolas;color:#2a4060;line-height:160%;")
        desc.setWordWrap(True)
        v.addWidget(desc)

        v.addStretch()
        return self._page_scroll(outer)

    def _build_page_forge(self):
        """Page 2 — Forgemason tile/tag forge."""
        outer = QWidget()
        outer.setStyleSheet("background:#0a0c12;")
        v = QVBoxLayout(outer)
        v.setContentsMargins(36, 28, 36, 16)
        v.setSpacing(0)

        logo = QLabel("⚒  ForgeMason")
        logo.setStyleSheet(
            "font:bold 26px Consolas;color:#883010;letter-spacing:2px;"
            "margin-bottom:4px;")
        sub = QLabel("Tile + Tag Definition Editor")
        sub.setStyleSheet("font:10px Consolas;color:#4a2010;margin-bottom:18px;")
        v.addWidget(logo); v.addWidget(sub)

        sep = QFrame(); sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet("background:#1a1008;margin-bottom:18px;")
        v.addWidget(sep)

        # Tiles section
        sec_tile = QLabel("TILES")
        sec_tile.setStyleSheet(
            "font:bold 8px Consolas;color:#6a2810;letter-spacing:4px;margin-bottom:6px;")
        v.addWidget(sec_tile)

        bh1 = QHBoxLayout(); bh1.setSpacing(8)
        nt = QPushButton("⊕  New Tile +")
        nt.setStyleSheet(
            "QPushButton{background:#1a0e08;color:#c07050;border:1px solid #3a1808;}"
            "QPushButton:hover{background:#281408;color:#e08060;border-color:#6a2810;}")
        nt.clicked.connect(lambda: self._pick(self.A_FORGE_NEW_TILE))
        lt = QPushButton("📂  Load Tile…")
        lt.setStyleSheet(
            "QPushButton{background:#140c08;color:#7a4828;border:1px solid #2a1810;}"
            "QPushButton:hover{background:#201410;color:#aa6840;border-color:#4a2c18;}")
        lt.clicked.connect(lambda: self._pick(self.A_FORGE_LOAD_TILE))
        bh1.addWidget(nt); bh1.addWidget(lt)
        v.addLayout(bh1)
        v.addSpacing(16)

        # Tags section
        sec_tag = QLabel("TAGS  (INDENTS)")
        sec_tag.setStyleSheet(
            "font:bold 8px Consolas;color:#386898;letter-spacing:4px;margin-bottom:6px;")
        v.addWidget(sec_tag)

        bh2 = QHBoxLayout(); bh2.setSpacing(8)
        ntag = QPushButton("⧫  New Tag +")
        ntag.setStyleSheet(
            "QPushButton{background:#0a1220;color:#4878b8;border:1px solid #162038;}"
            "QPushButton:hover{background:#10203a;color:#70a8e8;border-color:#2a4878;}")
        ntag.clicked.connect(lambda: self._pick(self.A_FORGE_NEW_TAG))
        ltag = QPushButton("📂  Load Tag…")
        ltag.setStyleSheet(
            "QPushButton{background:#0a1018;color:#384868;border:1px solid #141c2a;}"
            "QPushButton:hover{background:#101828;color:#6888a8;border-color:#243858;}")
        ltag.clicked.connect(lambda: self._pick(self.A_FORGE_LOAD_TAG))
        bh2.addWidget(ntag); bh2.addWidget(ltag)
        v.addLayout(bh2)
        v.addSpacing(12)

        fdesc = QLabel(
            ".let  tile defs  \xb7  .lei  tag (Indent) defs\n"
            "Tag saves rebuild builttags + write cache.pkl for pygame."
        )
        fdesc.setStyleSheet("font:9px Consolas;color:#3a2010;margin-top:4px;")
        v.addWidget(fdesc)

        v.addStretch()
        return self._page_scroll(outer)

    # ── nav helpers ───────────────────────────────────────────────────────────

    _PAGE_TITLES = ["LEVEL EDITOR", "MONICLE", "FORGEMASON"]
    _PAGE_COLORS = ["#3a6080",      "#2858a0", "#883010"   ]

    def _go_page(self, idx):
        self._cur_page = idx
        self._stack.setCurrentIndex(idx)
        self._nav_title.setText(self._PAGE_TITLES[idx])
        self._nav_title.setStyleSheet(
            f"color:{self._PAGE_COLORS[idx]};font:bold 10px Consolas;"
            "letter-spacing:3px;")
        self._btn_prev.setEnabled(idx > 0)
        self._btn_next.setEnabled(idx < 2)
        # MP toggle only on level page
        self._mp_toggle.setVisible(idx == self._PAGE_LEVEL)

    def _page_prev(self):
        if self._cur_page > 0:
            self._go_page(self._cur_page - 1)

    def _page_next(self):
        if self._cur_page < 2:
            self._go_page(self._cur_page + 1)

    def _on_mp_toggle(self, checked):
        self._sp_pane.setVisible(not checked)
        self._mp_pane.setVisible(checked)

    def _pick(self, action):
        _mplevels = os.path.join(os.path.expanduser("~"), "mplevels")
        os.makedirs(_mplevels, exist_ok=True)

        if action == self.A_ROOM:
            path, ok = LevelBrowserDialog.get_open(self, "Open Room (.ler)", ".ler")
            if not ok or not path:
                return
            self.chosen_path = path
        elif action == self.A_PROJECT:
            path, ok = LevelBrowserDialog.get_open(self, "Open Project (.lep)", ".lep")
            if not ok or not path:
                return
            self.chosen_path = path
        elif action == self.A_MP_ROOM:
            path, ok = LevelBrowserDialog.get_open(
                self, "Open Multiplayer Room (.ler)", ".ler",
                start_dir=_mplevels)
            if not ok or not path:
                return
            self.chosen_path = path
            self.mp_mode = True
            if hasattr(self, 'panel') and hasattr(self.panel, 'project_tree'): self.panel.project_tree.mp_mode = True
        elif action == self.A_MP_PROJECT:
            path, ok = LevelBrowserDialog.get_open(
                self, "Open Multiplayer Project (.lep)", ".lep",
                start_dir=_mplevels)
            if not ok or not path:
                return
            self.chosen_path = path
            self.mp_mode = True
            if hasattr(self, 'panel') and hasattr(self.panel, 'project_tree'): self.panel.project_tree.mp_mode = True
        elif action == self.A_MP_NEW:
            self.mp_mode = True
            if hasattr(self, 'panel') and hasattr(self.panel, 'project_tree'): self.panel.project_tree.mp_mode = True
            # no path — blank model, but mp_mode tells the editor where to save
        elif action == self.A_FORGE_LOAD_TILE:
            _tile_dir = os.path.join(_PROJECT_ROOT, "integrity", "tiles")
            path, _ = QFileDialog.getOpenFileName(
                self, "Open Tile Definition", _tile_dir,
                "LockESC Tile (*.let);;All Files (*)")
            if not path:
                return
            self.chosen_path = path
        elif action == self.A_FORGE_LOAD_TAG:
            _tag_dir = os.path.join(_PROJECT_ROOT, "integrity", "tags")
            path, _ = QFileDialog.getOpenFileName(
                self, "Open Tag Definition", _tag_dir,
                "LockESC Tag (*.lei);;All Files (*)")
            if not path:
                return
            self.chosen_path = path
        self.action = action
        self.accept()


# ════════════════════════════════════════════════════════════════════════════
# Entry point
# ════════════════════════════════════════════════════════════════════════════

def _apply_room_to_editor(win, path):
    """Load a .ler (bundle or flat) into EditorWindow."""
    real = _ler_json_path(path)
    with open(real, encoding="utf-8") as f:
        data = json.load(f)
    win.model = LevelModel.from_json(data)
    win.filepath = path   # store the bundle path, not the inner JSON path
    win.unsaved  = False
    # Auto-set mp_mode if the room lives under ~/mplevels/
    _mplevels = os.path.normpath(os.path.join(os.path.expanduser("~"), "mplevels"))
    if os.path.normpath(os.path.abspath(path)).startswith(_mplevels):
        win.mp_mode = True
        if hasattr(win, 'panel') and hasattr(win.panel, 'project_tree'):
            win.panel.project_tree.mp_mode = True
    for _w in (win.panel.cols_spin, win.panel.rows_spin,
               win.panel.tile_spin, win.panel.name_edit):
        _w.blockSignals(True)
    win.canvas.set_model(win.model)
    win.panel.name_edit.setText(win.model.name)
    win.panel.cols_spin.setValue(win.model.cols)
    win.panel.rows_spin.setValue(win.model.rows)
    win.panel.tile_spin.setValue(win.model.tile_size)
    for _w in (win.panel.cols_spin, win.panel.rows_spin,
               win.panel.tile_spin, win.panel.name_edit):
        _w.blockSignals(False)
    win._refresh_guard_list()
    win._set_title()


def _apply_project_to_editor(win, path):
    """Load a .lep project (bundle or flat) into EditorWindow and open its first room."""
    real = _lep_json_path(path)
    with open(real, encoding="utf-8") as f:
        data = json.load(f)
    proj = ProjectModel.from_dict(data, real)
    tree = win.panel.project_tree
    tree.project      = proj
    tree.project_path = path   # bundle path
    tree._refresh_list()
    # Auto-set mp_mode if the project lives under ~/mplevels/
    _mplevels = os.path.normpath(os.path.join(os.path.expanduser("~"), "mplevels"))
    if os.path.normpath(os.path.abspath(path)).startswith(_mplevels):
        win.mp_mode  = True
        tree.mp_mode = True
    if proj.rooms:
        rp = proj.rooms[0]["path"]
        if os.path.exists(rp):
            _apply_room_to_editor(win, rp)


# ════════════════════════════════════════════════════════════════════════════
# Crash logger
# ════════════════════════════════════════════════════════════════════════════

_LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")


def _write_crash_log(text: str) -> str:
    """Write *text* to a timestamped .log file in logs/ and return the path."""
    try:
        os.makedirs(_LOG_DIR, exist_ok=True)
        stamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        path  = os.path.join(_LOG_DIR, f"keyring_crash_{stamp}.log")
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
        return path
    except Exception:
        return ""


def _format_crash(exc_type, exc_value, exc_tb) -> str:
    """Build the full crash report string."""
    stamp   = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    tb_text = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
    return (
        f"KeyRing – LockESC  crash report\n"
        f"{'=' * 72}\n"
        f"Time   : {stamp}\n"
        f"Python : {sys.version}\n"
        f"{'=' * 72}\n\n"
        f"{tb_text}"
    )


def _excepthook(exc_type, exc_value, exc_tb):
    """Global uncaught-exception handler: log + show a dialog."""
    # Don't intercept KeyboardInterrupt
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_tb)
        return

    report = _format_crash(exc_type, exc_value, exc_tb)

    # Always print to stderr so the console still shows the traceback
    print(report, file=sys.stderr)

    log_path = _write_crash_log(report)

    # Try to show a Qt dialog (app may already be gone, so guard carefully)
    try:
        from PyQt6.QtWidgets import QApplication, QMessageBox
        app = QApplication.instance()
        if app is not None:
            short = traceback.format_exception_only(exc_type, exc_value)[-1].strip()
            msg = (
                f"KeyRing crashed:\n\n{short}\n\n"
                + (f"Crash log saved to:\n{log_path}" if log_path
                   else "Could not write crash log.")
            )
            box = QMessageBox()
            box.setWindowTitle("KeyRing – Crash")
            box.setIcon(QMessageBox.Icon.Critical)
            box.setText(msg)
            box.setDetailedText(report)
            box.exec()
    except Exception:
        pass  # if the dialog itself fails, at least the file is written


def _setup_crash_log():
    """Install the crash hook. Call once before the main loop."""
    sys.excepthook = _excepthook

    # Also catch exceptions that Qt swallows inside slots/event handlers
    try:
        from PyQt6.QtCore import qInstallMessageHandler, QtMsgType

        def _qt_msg_handler(msg_type, context, message):
            if msg_type in (QtMsgType.QtCriticalMsg, QtMsgType.QtFatalMsg):
                stamp   = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                report  = (
                    f"KeyRing – Qt message ({msg_type.name})\n"
                    f"{'=' * 72}\n"
                    f"Time   : {stamp}\n"
                    f"File   : {context.file}:{context.line}  {context.function}\n"
                    f"{'=' * 72}\n\n"
                    f"{message}\n"
                )
                print(report, file=sys.stderr)
                _write_crash_log(report)
            else:
                # Pass non-critical messages through to the default handler
                print(f"[Qt {msg_type.name}] {message}", file=sys.stderr)

        qInstallMessageHandler(_qt_msg_handler)
    except Exception:
        pass  # older Qt build without qInstallMessageHandler – no problem



if __name__ == "__main__":
    _setup_crash_log()

    try:
        app = QApplication(sys.argv)
        app.setStyle("Fusion")
        _ico = os.path.join(os.path.dirname(os.path.abspath(__file__)), "keyring.ico")
        if os.path.isfile(_ico):
            from PyQt6.QtGui import QIcon
            app.setWindowIcon(QIcon(_ico))

        # Load per-tile .let definitions and merge into editor tile lists
        _apply_let_defs()

        while True:
            # ── Show welcome screen ───────────────────────────────────────────────
            welcome = KeyRingWelcome()
            result  = welcome.exec()

            if result != QDialog.DialogCode.Accepted:
                break   # X on welcome → quit

            action = welcome.action
            path   = welcome.chosen_path

            # ── Monicle (launches as separate process, doesn't block) ─────────────
            if action == KeyRingWelcome.A_INTEG:
                _launch_monicle()
                continue   # back to welcome immediately

            # ── Forgemason (launches as separate process, doesn't block) ──────────
            if action == KeyRingWelcome.A_FORGE:
                _launch_forgemason()
                continue   # back to welcome immediately

            if action == KeyRingWelcome.A_FORGE_NEW_TILE:
                _launch_forgemason(action="new_tile")
                continue

            if action == KeyRingWelcome.A_FORGE_LOAD_TILE:
                _launch_forgemason(action="load_tile", path=path or "")
                continue

            if action == KeyRingWelcome.A_FORGE_NEW_TAG:
                _launch_forgemason(action="new_tag")
                continue

            if action == KeyRingWelcome.A_FORGE_LOAD_TAG:
                _launch_forgemason(action="load_tag", path=path or "")
                continue

            # ── Level editor — create a fresh window every time ───────────────────
            win = EditorWindow()

            try:
                if action in (KeyRingWelcome.A_ROOM, KeyRingWelcome.A_MP_ROOM) and path:
                    _apply_room_to_editor(win, path)
                elif action in (KeyRingWelcome.A_PROJECT, KeyRingWelcome.A_MP_PROJECT) and path:
                    _apply_project_to_editor(win, path)
                elif action == KeyRingWelcome.A_MP_NEW:
                    pass   # blank model already in win
                # A_NEW → blank model already in win
                # Propagate mp_mode from the welcome screen choice to EditorWindow
                if welcome.mp_mode:
                    win.mp_mode = True
            except Exception as e:
                QMessageBox.critical(None, "Open Error", str(e))
                win.close()
                continue

            # Sync mp_mode to project_tree now that the window is fully built
            win.panel.project_tree.mp_mode = win.mp_mode
            win.showMaximized()
            win.canvas.fit()
            app.exec()   # blocks until EditorWindow is closed
            # loop → welcome reappears

    except Exception:
        _excepthook(*sys.exc_info())
        sys.exit(1)
