"""
KeyRing Editor - Data models
Project model, level model
"""

from .. import core

# Re-export model classes
ProjectModel = core.ProjectModel
LevelModel = core.LevelModel

__all__ = ['ProjectModel', 'LevelModel']
