"""
KeyRing Level Editor - Modular Package
All classes and UI components are organized in categorized submodules.
The full implementation is currently in core.py during this transition phase.

Main module exports backward compatibility with original keyring.py imports:
    from integrity.functions.keyring import EditorWindow, PropertyDialog, ...

Transitional Architecture Plan:
  Phase 1: Keep all code in core.py (CURRENT)
  Phase 2: Split core.py into categorized submodules
  Phase 3: Update category __init__.py files to re-export
  Phase 4: Update main keyring.py to import from this package
"""

# During transition phase: Import all exports from core module
try:
    from .core import *
    # Explicitly import underscore-prefixed functions (not imported by *)
    from .core import (
        _launch_monicle, _launch_forgemason,
        _make_wp_pixmap, _make_tile_pixmap, _pixmap_for_path, _clear_pixmap_cache,
        _load_tile_png_qt, _load_lev_defs, _load_state_vis_defs,
        _load_let_defs, _apply_let_defs, _let_flag,
        _ensure_lev_file, _collect_required_tiles_kr, _missing_tile_assets_kr,
        _qcol, _draw_lev_tile, _hinge_corner, _draw_hinge_layer, _thin_wall_segs,
        _PlaceTileCmd, _DeleteSelectionCmd, _EditPropsCmd, _NudgeCmd,
        _AssetRow, _ColourRow,
        _write_crash_log, _format_crash, _excepthook, _setup_crash_log,
        _proj_ss, _apply_room_to_editor, _apply_project_to_editor
    )
except ImportError as e:
    raise ImportError(
        "KeyRing core module not found. "
        "Expected to find core.py at: integrity/functions/keyring/core.py\n"
        f"Original error: {e}"
    )

# Define all public exports
__all__ = [
    # ════ UI Components ══════════════════════════════════════
    'EditorWindow', 'Canvas', 'TileToolBar', 'WaypointToolBar',
    'ProjectTreePanel', 'SidePanel',
    
    # ════ Dialog Windows ═════════════════════════════════════
    'PropertyDialog', 'WaypointPropertyDialog', 'TimerNodeDialog',
    'ConnectionPanel', 'RoomPropertiesDialog',
    
    # ════ Data Models ════════════════════════════════════════
    'ProjectModel', 'LevelModel',
    
    # ════ External Tools ═════════════════════════════════════
    '_launch_monicle', '_launch_forgemason', 'bake_images_to_assets',
    
    # ════ Pixmap/Icon Generation ════════════════════════════
    '_make_wp_pixmap', '_make_tile_pixmap', '_pixmap_for_path',
    '_clear_pixmap_cache',
    
    # ════ File Loading & Utilities ═══════════════════════════
    '_load_tile_png_qt', '_load_lev_defs', '_load_state_vis_defs',
    '_load_let_defs', '_apply_let_defs', '_let_flag',
    '_ensure_lev_file', '_collect_required_tiles_kr', '_missing_tile_assets_kr',
    
    # ════ Visual Rendering ═══════════════════════════════════
    '_qcol', '_draw_lev_tile', '_hinge_corner', '_draw_hinge_layer',
    '_thin_wall_segs',
    
    # ════ Undo/Command System ═══════════════════════════════
    '_PlaceTileCmd', '_DeleteSelectionCmd', '_EditPropsCmd', '_NudgeCmd',
    
    # ════ UI Widget Helpers ══════════════════════════════════
    'make_group', 'styled_button', '_AssetRow', '_ColourRow',
    
    # ════ Error Handling ═════════════════════════════════════
    '_write_crash_log', '_format_crash', '_excepthook', '_setup_crash_log',
    
    # ════ Misc ═══════════════════════════════════════════════
    '_proj_ss', '_apply_room_to_editor', '_apply_project_to_editor',
    'KeyRingWelcome', 'IntegrityEditor',
]
