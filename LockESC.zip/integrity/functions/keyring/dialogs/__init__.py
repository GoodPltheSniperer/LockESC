"""
KeyRing Editor - Dialog windows
Property dialogs, waypoint dialogs, connection panels
"""

from .. import core

# Re-export dialog classes
PropertyDialog = core.PropertyDialog
WaypointPropertyDialog = core.WaypointPropertyDialog
TimerNodeDialog = core.TimerNodeDialog
ConnectionPanel = core.ConnectionPanel

__all__ = ['PropertyDialog', 'WaypointPropertyDialog', 'TimerNodeDialog',
           'ConnectionPanel']
