#!/usr/bin/env python3
"""
KeyRing Level Editor – LockESC v7
==================================
Modular thin wrapper that imports and delegates to integrity.functions.keyring

pip install PyQt6
python keyring.py [project_dir]
"""

import sys
import os
import traceback
from pathlib import Path

# Import all editor components from modular package
from integrity.functions.keyring import (
    EditorWindow, KeyRingWelcome,
    TileToolBar, LevelModel, Canvas, SidePanel,
    _apply_let_defs, _launch_monicle, _launch_forgemason,
    _apply_room_to_editor, _apply_project_to_editor,
    _setup_crash_log, _excepthook
)

# Re-export for external scripts (e.g. keyring_tracebackfinder)
GROUPS = TileToolBar.GROUPS

try:
    from PyQt6.QtWidgets import QApplication
    from PyQt6.QtCore import Qt
except ImportError:
    print("ERROR: PyQt6 not installed. Run: pip install PyQt6")
    sys.exit(1)


def main():
    """Main application entry point"""
    from PyQt6.QtWidgets import QDialog, QMessageBox

    _setup_crash_log()
    sys.excepthook = _excepthook

    app = QApplication(sys.argv)
    app.setStyle("Fusion")

    _apply_let_defs()

    while True:
        welcome = KeyRingWelcome()
        result  = welcome.exec()

        if result != QDialog.DialogCode.Accepted:
            break   # X on welcome → quit

        action = welcome.action
        path   = welcome.chosen_path

        # Monicle / Forgemason launch as separate processes → back to welcome
        if action == KeyRingWelcome.A_INTEG:
            _launch_monicle()
            continue

        if action == KeyRingWelcome.A_FORGE:
            _launch_forgemason()
            continue

        if action == KeyRingWelcome.A_FORGE_NEW_TILE:
            _launch_forgemason(action="new_tile")
            continue

        if action == KeyRingWelcome.A_FORGE_LOAD_TILE:
            _launch_forgemason(action="load_tile", path=path or "")
            continue

        if action == KeyRingWelcome.A_FORGE_NEW_TAG:
            _launch_forgemason(action="new_tag")
            continue

        if action == KeyRingWelcome.A_FORGE_LOAD_TAG:
            _launch_forgemason(action="load_tag", path=path or "")
            continue

        # Level editor
        win = EditorWindow()

        try:
            if action in (KeyRingWelcome.A_ROOM, KeyRingWelcome.A_MP_ROOM) and path:
                _apply_room_to_editor(win, path)
            elif action in (KeyRingWelcome.A_PROJECT, KeyRingWelcome.A_MP_PROJECT) and path:
                _apply_project_to_editor(win, path)
            # A_NEW / A_MP_NEW → blank model already in win
        except Exception as e:
            QMessageBox.critical(None, "Open Error", str(e))
            win.close()
            continue

        # Multiplayer editing mode — set flag so tools, save dir, title all reflect it
        if welcome.mp_mode:
            win.mp_mode = True
            win._set_title()

        win.showMaximized()
        win.canvas.fit()
        app.exec()   # blocks until EditorWindow closed → loop back to welcome


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        # Fallback error handling
        print(f"ERROR: {e}", file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)
