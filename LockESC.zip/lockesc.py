"""
LockESC – stealth game engine  v7
==================================
Thin wrapper that imports all functionality from integrity.functions.lockesc

pip install pygame
python lockesc.py [level_file.ler]
"""

import sys

from integrity.functions.lockesc import Game


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else None
    Game(path).run()
